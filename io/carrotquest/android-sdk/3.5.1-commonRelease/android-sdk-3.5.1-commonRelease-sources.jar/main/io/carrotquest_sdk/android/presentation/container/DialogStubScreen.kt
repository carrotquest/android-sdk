package io.carrotquest_sdk.android.presentation.container

import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogFragment

private const val DIALOG_FRAGMENT_TAG = "sdk_dialog_fragment"
// КОСТЫЛЬ: задержка между удалением старого DialogFragment и добавлением нового —
// только когда реально заменяем один фрагмент другим (пересоздание). При быстром
// "Написать → ← → Написать" Chromium renderer process не успевает очистить ресурсы
// предыдущего WebView, и новый WebView получает сломанный renderer →
// "TypeError: window.webView.initDialogue is not a function" → кнопки бота не отрисовываются.
// 400мс хватает, чтобы Chromium выдохнул. Убрать, когда WebView выпилят из диалога.
private const val FRAGMENT_RECREATE_DELAY_MS = 400L

@Composable
fun DialogScreen(
    conversationId: String,
    fragmentManager: FragmentManager,
    modifier: Modifier = Modifier,
    // Экран тикета: фрагмент стартует в ticket mode (гейт автопоказа инпута,
    // кнопка «Дополнить тикет», локальный markAsRead)
    isTicket: Boolean = false
) {
    // После пересоздания Activity FragmentManager восстанавливает DialogFragment вместе с его
    // ViewModel (лента, набранный текст). Берём его контейнер-id, чтобы не заменять фрагмент
    // новым (CAR-78242). Иначе — новый id, как при обычной навигации.
    val adopted = remember { findAdoptableDialogFragment(fragmentManager, conversationId, isTicket) }
    val containerId = remember { adopted?.id ?: View.generateViewId() }
    // Свой Handler на композицию: removeCallbacksAndMessages(null) в onDispose отменяет
    // только колбэк ЭТОГО экрана, не задевая другие. Без этого при повторной навигации
    // раньше, чем истекли FRAGMENT_RECREATE_DELAY_MS с прошлого открытия, отложенный
    // addNewFragment всё равно срабатывал позже — добавлял DialogFragment под уже
    // неактуальный containerId, и следующий findFragmentByTag находил чужой/лишний
    // фрагмент вместо актуального.
    val handler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(conversationId) {
        onDispose {
            handler.removeCallbacksAndMessages(null)
            if (fragmentManager.isStateSaved) return@onDispose
            val frag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG) ?: return@onDispose
            if (frag.id == containerId) {
                fragmentManager.beginTransaction()
                    .remove(frag)
                    .commitAllowingStateLoss()
            }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            FragmentContainerView(ctx).also { fcv ->
                fcv.id = containerId

                if (adopted != null && adopted.id == containerId) {
                    // Восстановленный фрагмент уже создал view, но без контейнера: программно
                    // созданный FragmentContainerView сам об этом FragmentManager не сообщает
                    // (так делает только XML-конструктор). Прикрепляем view вручную, без транзакции.
                    fragmentManager.onContainerAvailable(fcv)
                    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.LIFECYCLE, RECREATE_TAG) {
                        "DialogScreen adopted restored fragment=${System.identityHashCode(adopted)}"
                    }
                } else if (!fragmentManager.isStateSaved) {
                    val existingFrag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG)
                    val addNewFragment = {
                        if (!fragmentManager.isStateSaved) {
                            fragmentManager.beginTransaction()
                                .add(
                                    containerId,
                                    DialogFragment.newInstance(conversationId, isTicket),
                                    DIALOG_FRAGMENT_TAG
                                )
                                .commitAllowingStateLoss()
                        }
                    }

                    if (existingFrag != null && existingFrag.id != containerId) {
                        // Пересоздание: прибираем старый фрагмент сразу, новый — с задержкой
                        // (см. FRAGMENT_RECREATE_DELAY_MS выше, костыль под Chromium).
                        fragmentManager.beginTransaction()
                            .remove(existingFrag)
                            .commitAllowingStateLoss()
                        handler.postDelayed(addNewFragment, FRAGMENT_RECREATE_DELAY_MS)
                    } else {
                        // Первое открытие — заменять нечего, Chromium-костыль не нужен:
                        // добавляем сразу, без искусственной задержки.
                        addNewFragment()
                    }
                }
            }
        },
        update = { /* Не пересоздаем фрагмент при обновлении параметров, если id тот же */ }
    )
}

private fun findAdoptableDialogFragment(
    fragmentManager: FragmentManager,
    navConversationId: String,
    navIsTicket: Boolean,
): DialogFragment? {
    val frag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG) as? DialogFragment ?: return null
    val view = frag.view
    return frag.takeIf {
        shouldAdoptDialogFragment(
            hasView = view != null,
            isViewAttached = view?.parent != null,
            fragmentIsTicket = frag.isTicketArg,
            fragmentArgId = frag.originalArgId,
            fragmentLiveId = frag.restoredLiveId,
            navConversationId = navConversationId,
            navIsTicket = navIsTicket,
        )
    }
}

/**
 * Переиспользовать ли существующий DialogFragment вместо замены новым.
 *
 * Да — только восстановленный после пересоздания фрагмент того же экрана: его view создана, но ни
 * к чему не прикреплена (при обычной навигации view фрагмента всегда в контейнере — тогда работает
 * прежний путь с заменой и задержкой под Chromium). Экран тот же, если совпадает режим тикета и id:
 * исходный аргумент фрагмента, либо реальный id созданного диалога (восстановленная навигация
 * после смерти процесса открывает новый диалог уже по реальному id).
 */
internal fun shouldAdoptDialogFragment(
    hasView: Boolean,
    isViewAttached: Boolean,
    fragmentIsTicket: Boolean,
    fragmentArgId: String,
    fragmentLiveId: String?,
    navConversationId: String,
    navIsTicket: Boolean,
): Boolean {
    if (!hasView || isViewAttached) return false
    if (fragmentIsTicket != navIsTicket) return false
    return navConversationId == fragmentArgId ||
        (navConversationId.isNotEmpty() && navConversationId == fragmentLiveId)
}
