package io.carrotquest_sdk.android.domain.use_cases.bot

import io.carrotquest_sdk.android.core.main.CarrotInternal

/**
 * suspend-версия startRoutingBot (ветка remove_rx). Возвращает успех (meta.status == 200).
 * - пустой actionId/Text → false;
 * - ошибка сети/HTTP пробрасывается для любого диалога. Раньше для реального conversationId она
 *   глоталась в false, и презентер помечал стартовую ветку отвеченной при 400 на routing/start
 *   (например, закрытый диалог при включённом запрете) — ни ошибки, ни продолжения (аудит CAR-77064).
 */
suspend fun startRoutingBot(
    botId: String,
    answerActionId: String,
    answerActionText: String,
    randomId: String?,
    conversationId: String?
): Boolean {
    if (answerActionId.isEmpty() || answerActionText.isEmpty()) {
        return false
    }

    val carrotLib = CarrotInternal.getService().carrotLib
    return if (!conversationId.isNullOrEmpty() && !conversationId.contains("routing")) {
        val res = carrotLib.startRoutingBotSuspend(botId, answerActionId, answerActionText, randomId, conversationId)
        res.meta != null && res.meta?.status == 200
    } else {
        val res = carrotLib.startRoutingBotSuspend(botId, answerActionId, answerActionText, randomId)
        res.meta != null && res.meta?.status == 200
    }
}
