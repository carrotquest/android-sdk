package io.carrotquest_sdk.android.core.secrets

/**
 * Симметричный шифр для значений [SecretStore]. Работает с «полезной нагрузкой» без префикса
 * версии (`enc1:` добавляет и снимает сам стор), поэтому тестовый фейк не зависит от Base64.
 *
 * Контракт: любой сбой — `null`, исключения наружу не выходят. Реализации потокобезопасны.
 */
internal interface SecretCipher {
    /** Зашифровать [plain]; null — не удалось (Keystore недоступен, ключ инвалидирован…). */
    fun encrypt(plain: String): String?

    /** Расшифровать [payload]; null — не удалось (битые данные, чужой ключ, ключ потерян…). */
    fun decrypt(payload: String): String?
}
