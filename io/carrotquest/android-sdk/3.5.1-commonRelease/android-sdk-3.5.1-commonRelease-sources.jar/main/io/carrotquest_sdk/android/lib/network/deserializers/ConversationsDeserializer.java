package io.carrotquest_sdk.android.lib.network.deserializers;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.conversation.MetaConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

public class ConversationsDeserializer implements JsonDeserializer<UserConversations> {
    @Override
    public UserConversations deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        UserConversations response = new UserConversations();

        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("ConversationDeserializer. meta is null or dataJsonElement is null");
        }

        JsonElement metaJsonElement = json.getAsJsonObject().get(F.META);
        JsonElement nextAfterJsonElement;

        if(metaJsonElement != null) {
            if (metaJsonElement.getAsJsonObject().has(F.NEXT_ARTER) && !metaJsonElement.getAsJsonObject().get(F.NEXT_ARTER).isJsonNull()) {
                nextAfterJsonElement = metaJsonElement.getAsJsonObject().get(F.NEXT_ARTER);
                response.setMeta(getMetaFromJsonElement(nextAfterJsonElement, metaJsonElement));
            } else if (metaJsonElement.getAsJsonObject().has(F.NEXT_BEFORE_POSITION) && !metaJsonElement.getAsJsonObject().get(F.NEXT_BEFORE_POSITION).isJsonNull()) {
                nextAfterJsonElement = metaJsonElement.getAsJsonObject().get(F.NEXT_BEFORE_POSITION);
                response.setMeta(getMetaFromJsonElement(nextAfterJsonElement, metaJsonElement));
            } else {
                response.setMeta(new Gson().fromJson(metaJsonElement, MetaConversation.class));
            }
        }


        JsonElement dataJsonElement = json.getAsJsonObject().get(F.DATA);
        if(dataJsonElement != null && !dataJsonElement.isJsonNull()) {
            JsonArray jsonElements = dataJsonElement.getAsJsonArray();
            if (jsonElements != null && jsonElements.size() > 0) {
                ArrayList<DataConversation> listData = new ArrayList<>();
                for (JsonElement element : jsonElements) {
                    DataConversation data = geDataConversationFromJsonElement(element);
                    listData.add(data);
                }
                response.setConversations(listData);
            }
        }

        return response;
    }

    private MetaConversation getMetaFromJsonElement(JsonElement jsonElement, JsonElement metaJson) {
        if (jsonElement != null) {
            MetaConversation metaConversation = new MetaConversation();
            metaConversation.setStatus(metaJson.getAsJsonObject().get(F.STATUS).getAsInt());
            if (jsonElement.isJsonArray() && jsonElement.getAsJsonArray().size() > 0) {
                metaConversation.setNextAfter(jsonElement.getAsJsonArray().toString());
            } else {
                metaConversation.setNextAfter(jsonElement.getAsString());
            }
            return metaConversation;
        }
        return (new Gson().fromJson(metaJson, MetaConversation.class));
    }


    private DataConversation geDataConversationFromJsonElement(JsonElement jsonElement) throws JsonParseException {
        DataConversation conversation = new DataConversation();
        JsonObject jsonObject = jsonElement.getAsJsonObject();

        if(!jsonElementNotNull(jsonObject, F.ID)) {
            throw new JsonParseException("Conversation Id is null");
        }
        conversation.setId(jsonObject.get(F.ID).getAsString());
        conversation.setSourceJsonData(jsonObject);

        if(jsonElementNotNull(jsonObject, F.RANDOM_ID)) {
            conversation.setRandomId(jsonObject.get(F.RANDOM_ID).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.CREATED)) {
            conversation.setCreated(jsonObject.get(F.CREATED).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.READ)) {
            conversation.setRead(jsonObject.get(F.READ).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.CLIKCKED)) {
            conversation.setClicked(jsonObject.get(F.CLIKCKED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.UNSUBSCRIBED)) {
            conversation.setUnsubscribed(jsonObject.get(F.UNSUBSCRIBED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.CLOSED)) {
            conversation.setClosed(jsonObject.get(F.CLOSED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.REPLIED)) {
            conversation.setReplied(jsonObject.get(F.REPLIED).getAsBoolean());
        }

        // Время автозакрытия диалога ботом (unix-секунды) — по нему клиент понимает,
        // что бот «сгорел»: RTS о закрытии по тайм-ауту бэк не шлёт (CAR-77064).
        if(jsonElementNotNull(jsonObject, F.EXPIRATION_TIME)) {
            conversation.setExpirationTime(jsonObject.get(F.EXPIRATION_TIME).getAsLong());
        }

        if(jsonElementNotNull(jsonObject, F.REPLY_TYPE)) {
            conversation.setReplyType(jsonObject.get(F.REPLY_TYPE).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.TYPE)) {
            conversation.setType(jsonObject.get(F.TYPE).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.PARTS_COUNT)) {
            conversation.setPartsCount(jsonObject.get(F.PARTS_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.UNREAD_PARTS_COUNT)) {
            conversation.setUnreadPartsCount(jsonObject.get(F.UNREAD_PARTS_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.USER_UNREAD_COUNT)) {
            conversation.setUserUnreadCount(jsonObject.get(F.USER_UNREAD_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.LAST_UPDATE)) {
            conversation.setLastUpdate(jsonObject.get(F.LAST_UPDATE).getAsString()
            );
        }

        if(jsonElementNotNull(jsonObject, F.PART_LAST)) {
            MessageData partLast = ConvertUtilsKt.convertJsonToMessageData(jsonObject.get(F.PART_LAST));
            conversation.setPartLast(partLast);
        }

        if(jsonElementNotNull(jsonObject, F.LAST_ADMIN)
                && jsonObject.get(F.LAST_ADMIN).isJsonObject()) {
            // См. ConversationDeserializer:139 — last_admin изредка приходит не объектом.
            conversation.setLastAdmin(parseAdmin(jsonObject.get(F.LAST_ADMIN).getAsJsonObject()));
        }

        // last_sender — публичная персона отправителя (message_sender у ботов/триггеров):
        // превью диалога обязано показывать его, а не last_admin (веб-паритет, getOperator)
        if(jsonElementNotNull(jsonObject, F.LAST_SENDER)
                && jsonObject.get(F.LAST_SENDER).isJsonObject()) {
            conversation.setLastSender(parseAdmin(jsonObject.get(F.LAST_SENDER).getAsJsonObject()));
        }

        if(jsonElementNotNull(jsonObject, F.RECIPIENT_TYPE)) {
            conversation.setRecipientType(jsonObject.get(F.RECIPIENT_TYPE).getAsString());
        }


        return conversation;
    }

    private Admin parseAdmin(JsonObject lastAdminJsonObject) {
        Admin admin = new Admin();

        if (jsonElementNotNull(lastAdminJsonObject, F.ID)) {
            admin.setId(lastAdminJsonObject.get(F.ID).getAsString());
        }

        if (jsonElementNotNull(lastAdminJsonObject, F.NAME)) {
            admin.setName(lastAdminJsonObject.get(F.NAME).getAsString());
        }
        if (jsonElementNotNull(lastAdminJsonObject, F.TYPE)) {
            admin.setType(lastAdminJsonObject.get(F.TYPE).getAsString());
        }
        if (jsonElementNotNull(lastAdminJsonObject, F.AVATAR)) {
            admin.setAvatar(lastAdminJsonObject.get(F.AVATAR).getAsString());
        }

        return admin;
    }


    private boolean jsonElementNotNull(JsonObject json, String jsonName) {
        return json.has(jsonName) && !json.get(jsonName).isJsonNull();
    }

}