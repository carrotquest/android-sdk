package io.carrotquest_sdk.android.presentation.mvp.dialog.presenter

import io.carrotquest_sdk.android.core.util.ServerClock

/**
 * Метка сгорания чат-бота по тайм-ауту (CAR-77064) — чистая логика без корутин и вью,
 * зеркало cqstatic `bot-expiration.js` (arm/isPending).
 *
 * Бот с настроенным close_delay «сгорает», если пользователь не отвечает: бэк планирует закрытие
 * диалога и проставляет диалогу абсолютную метку `conversation.expiration_time`. RTS о самом
 * закрытии не будет, поэтому таймер ведёт клиент — по серверным часам ([ServerClock]).
 *
 * Сгорание срабатывает только как переход «бот ждал ответа → время вышло» ([isPending]).
 * Если диалог открыт уже после сгорания, реакции нет: пользователь просто читает диалог, а
 * кнопки бота и поле ввода прячутся по [isExpired] — иначе открытие такого диалога выкидывало
 * бы обратно в список.
 */
internal class BotExpirationTracker(
    private val nowMs: () -> Long = { ServerClock.nowMs() },
) {

    /** Что делать с таймером после [arm]. */
    sealed class Decision {
        /** Метки нет или она давно в прошлом — таймер не нужен. */
        object None : Decision()
        /** Сгорание наступило, пока бот ждал ответа — реагируем один раз. */
        object Fire : Decision()
        /** Метка в будущем — перепроверить через [delayMs]. */
        data class Wait(val delayMs: Long) : Decision()
    }

    /** Текущая метка, unix-секунды; null — бот сейчас не ждёт ответа. */
    var expirationSec: Long? = null
        private set

    // Была ли метка хоть раз в будущем за время наблюдения.
    private var isPending = false

    // Ждали ли мы в этой сессии хоть одно сгорание. Диалог, который пришёл с сервера уже закрытым
    // (closed=true) с меткой в прошлом, сгорать на наших глазах не мог: его закрыл бит, финальная
    // ветка бота или оператор, а метку сервер при закрытии не чистит. Такую метку игнорируем —
    // дальше диалог ведёт сервер (choose перезапустит бота, запрет даст read-only плашку), а
    // «Диалог завершён» без выхода тут только мешал бы. Если сгорание случилось при нас и бит
    // закрыл диалог следом, метку держим — плашка остаётся на месте.
    private var everPending = false

    // Метка, снятая ответом пользователя ([cancel]). Сервер при закрытии диалога expiration_time
    // не чистит (чистят только штатное завершение и прерывание бота), поэтому после ответа на
    // стартовую ветку перезапущенного бота первые батчи ещё несут старую истёкшую метку —
    // без этого фильтра бот на секунду считался бы сгоревшим (моргала плашка), пока следующая
    // ветка не привезёт новую метку. Игнорируем всё не новее снятой; метки строго растут.
    private var cancelledSec: Long? = null

    // Метка проставлена принудительно ([forceExpire]) по 400 «already closed», а не пришла с
    // сервера — аналог iOS forcedSec. [cancel] с answeredMark снимает такую метку всегда: это не
    // «следующий вопрос», а наша отметка о закрытии, и после принятого сервером ответа держать
    // её нельзя (иначе поле ввода осталось бы скрытым).
    private var forced = false

    /**
     * Свежая метка из объекта диалога (приходит с каждым conversation_parts_batch).
     * [closedByServer] — объект диалога пришёл с closed=true (см. [everPending]).
     */
    fun sync(expirationSec: Long?, closedByServer: Boolean = false) {
        // Метки строго растут: метка старее текущей — поздний повтор уже отвеченного вопроса
        // (пачка с M1 пришла после пачки с M2, CAR-78163), текущую ею не затираем. sync(null)
        // проходит всегда, равная метка — тоже (повтор текущей безвреден).
        val current = this.expirationSec
        if (expirationSec != null && current != null && expirationSec < current) return
        val cancelled = cancelledSec
        if (expirationSec != null && cancelled != null) {
            if (expirationSec <= cancelled) return
            cancelledSec = null
        }
        if (closedByServer && expirationSec != null && !everPending && expirationSec * 1000 <= nowMs()) {
            cancelledSec = expirationSec
            this.expirationSec = null
            forced = false
            return
        }
        this.expirationSec = expirationSec
        forced = false
    }

    /**
     * Сервер отверг ответ боту, потому что диалог уже закрыт (400): бот сгорел раньше нашего таймера
     * (часы, бит) — или метку уже снял предыдущий ответ. Считаем метку истёкшей прямо сейчас —
     * [isExpired] становится true, а [arm] больше не выдаст [Decision.Fire] (реакцию вызывает
     * презентер сам).
     */
    fun forceExpire() {
        expirationSec = nowMs() / 1000 - 1
        isPending = false
        forced = true
        // Сгорание увидено нами (сервер отверг наш ответ): закрытый диалог с меткой той же секунды
        // из следующих пачек её не снимет (ветка closedByServer в [sync]).
        everPending = true
    }

    /**
     * Сервер принял ответ, ушедший под меткой [answeredMark] (null — метки в момент отправки не
     * было): бэк в этот момент снимает метку и закрытие, делаем то же локально, не дожидаясь
     * следующего батча. Снимаем только отвеченную метку: если текущая новее, это уже следующий
     * вопрос, чья RTS-пачка обогнала HTTP-ответ (CAR-78163), — её оставляем, а отвеченную
     * запоминаем в [cancelledSec], чтобы её поздний повтор не вернул сгоревший вопрос.
     * Принудительную метку ([forceExpire]) снимаем всегда, как iOS forcedSec. Зеркало cqios
     * BotExpirationTracker.cancel(answeredMark:). Ограничение: вопрос и ответ в одну секунду
     * (M2 == M1) — новая метка снимется вместе с отвеченной; сравнение строгое намеренно, иначе
     * эхо отвеченной метки никогда бы не снималось.
     */
    fun cancel(answeredMark: Long?) {
        val current = expirationSec
        if (!forced && current != null && (answeredMark == null || current > answeredMark)) {
            if (answeredMark != null) cancelledSec = maxOf(cancelledSec ?: answeredMark, answeredMark)
            return
        }
        cancel()
    }

    /**
     * Снять текущую метку целиком: прогон бота перекрыт чужой частью ([isBotRunSuperseded]) или
     * перезапуск не состоялся (found=false). Для принятого ответа пользователя — [cancel] с
     * answeredMark. Наблюдение не снимается — следующая ветка может запланировать новое закрытие,
     * метка приедет в батче.
     */
    fun cancel() {
        expirationSec?.let { cancelledSec = it }
        expirationSec = null
        forced = false
    }

    /** Новая сессия диалога — прошлую метку не переносим. */
    fun reset() {
        expirationSec = null
        isPending = false
        everPending = false
        cancelledSec = null
        forced = false
    }

    /** Миллисекунды до сгорания; null — метки нет. */
    fun remainingMs(): Long? = expirationSec?.let { it * 1000 - nowMs() }

    /** Сгорел ли бот в этом диалоге по серверным часам. */
    fun isExpired(): Boolean {
        val remaining = remainingMs() ?: return false
        return remaining <= 0
    }

    /** Решение по таймеру для текущего состояния метки. [Decision.Fire] выдаётся один раз. */
    fun arm(): Decision {
        val remaining = remainingMs() ?: return Decision.None
        if (remaining <= 0) {
            if (!isPending) return Decision.None
            isPending = false
            return Decision.Fire
        }
        isPending = true
        everPending = true
        return Decision.Wait(remaining)
    }
}
