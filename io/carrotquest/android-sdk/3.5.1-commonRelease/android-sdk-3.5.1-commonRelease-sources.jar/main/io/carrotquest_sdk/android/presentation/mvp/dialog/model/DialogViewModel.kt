package io.carrotquest_sdk.android.presentation.mvp.dialog.model

import io.carrotquest_sdk.android.core.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DialogViewModel {
    companion object {
        private var instance: DialogViewModel? = null
        fun getInstance(): DialogViewModel {
            if (instance == null) {
                instance = DialogViewModel()
            }
            return instance!!
        }
    }

    // Пишется/читается с разных диспатчеров (Main и IO) — StateFlow потокобезопасен.
    // Flow нужен контейнеру: шапка нового диалога берёт id только того диалога, который назначил
    // презентер, а не любой новой беседы (CAR-78242: рассылка в открытом черновике).
    private val _currentConversationId = MutableStateFlow("")
    val currentConversationIdFlow: StateFlow<String> = _currentConversationId.asStateFlow()
    private var needStartRoutingBot = false
    private var botId: String = ""

    fun updateCurrentConversationId(id: String) {
        _currentConversationId.value = id
    }

    fun getCurrentConversationId(): String = _currentConversationId.value

    fun needStartRoutingBot() = this.needStartRoutingBot

    fun setNeedStartRoutingBot(needStartRoutingBot: Boolean) {
        // Тег CQ_BotInput (а не println): смена флага должна быть видна в отфильтрованном
        // логкате — по репорту welcome-bot-phone-input-missing именно её не хватало.
        Log.d("CQ_BotInput", "setNeedStartRoutingBot $needStartRoutingBot (was ${this.needStartRoutingBot})")
        this.needStartRoutingBot = needStartRoutingBot
    }

    fun setRoutingBotId(botId: String) {
        this.botId = botId
    }

    fun getRoutingBotId() = this.botId
}