package io.carrotquest_sdk.android.presentation.chat

import androidx.compose.animation.core.Spring
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.domain.use_cases.settings.VoteIconType
import io.carrotquest_sdk.android.presentation.ui.SdkColors

/** Шкала оценки оператора 1–5 (CAR-77291), слева направо. */
internal val VOTE_SCORES = 1..5

/**
 * Эмодзи по баллу (индекс = score − 1), набор как в веб-виджете (entities/vote/const.js).
 * Старые оценки 1/3/5 показываются на новой шкале как есть: 1 → 😠, 3 → 😐, 5 → 🤩.
 */
internal val VOTE_EMOJI = listOf("😠", "🙁", "😐", "😊", "🤩")

/** С этой оценки комментарий спрашиваем как «что понравилось», ниже — «что можно улучшить». */
internal const val POSITIVE_VOTE_SCORE = 4

/** true — оценка «позитивная»: влияет только на плейсхолдер комментария (сама оценка уходит сразу при любом балле). */
internal fun isPositiveVote(score: Int): Boolean = score >= POSITIVE_VOTE_SCORE

/** Плейсхолдер поля комментария по оценке. Чистая — покрыта VoteCommentHintTest. */
internal fun voteCommentHintRes(score: Int): Int =
    if (isPositiveVote(score)) R.string.vote_comment_hint_positive else R.string.vote_comment_hint

private val CARD_SHAPE = RoundedCornerShape(16.dp)
private val INPUT_SHAPE = RoundedCornerShape(20.dp)

@Composable
fun VoteCardItem(
    item: ChatListItem.VoteCard,
    isDark: Boolean,
    accentColor: Color,
    voteIconType: VoteIconType = VoteIconType.EMOJI,
    onVoteSelected: (Int) -> Unit = {},
    onCommentSend: (Int, String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier,
) {
    var commentText by remember(item.messageId) { mutableStateOf("") }

    // Когда сервер подтвердил комментарий (Rated с comment), сбрасываем черновик.
    // remember(messageId) не реагирует на смену voteState — нужен явный LaunchedEffect.
    val hasServerComment = (item.voteState as? VoteState.Rated)?.comment != null
    LaunchedEffect(hasServerComment) {
        if (hasServerComment) commentText = ""
    }

    val questionText = item.questionText.ifEmpty { stringResource(R.string.list_message_vote) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SdkColors.voteBorder(isDark), CARD_SHAPE)
                .background(SdkColors.pageBackground(isDark), CARD_SHAPE)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = questionText,
                color = SdkColors.title(isDark),
                fontSize = 15.sp,
                lineHeight = 20.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Оценка уходит сразу по тапу (любой балл), комментарий — опциональный второй шаг:
            // Pending → Loading → Rated(без комментария, поле открыто) → CommentSending → Rated(с комментарием).
            when (val state = item.voteState) {
                is VoteState.Pending -> VoteButtons(
                    selectedScore = null,
                    enabled = true,
                    iconType = voteIconType,
                    isDark = isDark,
                    onVoteSelected = onVoteSelected,
                )
                is VoteState.Loading -> Box(
                    modifier = Modifier.height(30.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                }
                is VoteState.Rated -> {
                    VoteButtons(
                        selectedScore = state.score,
                        enabled = false,
                        iconType = voteIconType,
                        isDark = isDark,
                        onVoteSelected = {},
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    if (state.comment != null) {
                        ThanksPill(isDark = isDark)
                    } else {
                        // Как в вебе: поле появляется с анимацией после любой оценки и остаётся
                        // доступным, пока комментарий не отправлен (в т.ч. после перезахода).
                        AnimatedVisibility(visible = true, enter = expandVertically() + fadeIn()) {
                            CommentInput(
                                value = commentText,
                                onValueChange = { commentText = it },
                                hintRes = voteCommentHintRes(state.score),
                                isDark = isDark,
                                accentColor = accentColor,
                                onSend = { onCommentSend(state.score, commentText) },
                            )
                        }
                    }
                }
                is VoteState.CommentSending -> {
                    VoteButtons(
                        selectedScore = state.score,
                        enabled = false,
                        iconType = voteIconType,
                        isDark = isDark,
                        onVoteSelected = {},
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    CommentInput(
                        value = commentText,
                        onValueChange = {},
                        hintRes = voteCommentHintRes(state.score),
                        isDark = isDark,
                        accentColor = accentColor,
                        enabled = false,
                        sending = true,
                        onSend = {},
                    )
                }
            }
        }
    }
}

@Composable
private fun VoteButtons(
    selectedScore: Int?,
    enabled: Boolean,
    iconType: VoteIconType,
    isDark: Boolean,
    onVoteSelected: (Int) -> Unit,
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Значение вне шкалы (битые данные) — ничего не выделяем, кнопки просто disabled.
        val selected = selectedScore?.takeIf { it in VOTE_SCORES }
        VOTE_SCORES.forEach { score ->
            when (iconType) {
                VoteIconType.STARS -> StarButton(
                    filled = selected != null && score <= selected,
                    enabled = enabled,
                    isDark = isDark,
                    onClick = { onVoteSelected(score) },
                )
                VoteIconType.EMOJI -> EmojiButton(
                    emoji = VOTE_EMOJI[score - 1],
                    isSelected = selected == score,
                    anySelected = selected != null,
                    enabled = enabled,
                    isDark = isDark,
                    onClick = { onVoteSelected(score) },
                )
            }
        }
    }
}

@Composable
private fun EmojiButton(
    emoji: String,
    isSelected: Boolean,
    anySelected: Boolean,
    enabled: Boolean,
    isDark: Boolean,
    onClick: () -> Unit,
) {
    val alpha = if (!anySelected || isSelected) 1f else 0.3f
    // Размеры под макет: эмодзи заполняют кружок 30dp (база ~23dp, выбранный ~30dp).
    val animatedFontSize by animateFloatAsState(
        targetValue = if (isSelected) 28f else 22f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "emojiSize",
    )
    Box(
        modifier = Modifier
            .size(30.dp)
            .alpha(alpha)
            .clip(CircleShape)
            // По макету фон-кружок есть только у невыбранных; у выбранного его нет.
            .then(
                if (isSelected) Modifier
                else Modifier.background(SdkColors.voteButtonBg(isDark))
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = emoji,
            fontSize = animatedFontSize.sp,
            textAlign = TextAlign.Center,
            // includeFontPadding масштабируется с fontSize: у выбранного (28sp) паддинг
            // больше, чем у соседних (22sp), из-за чего глиф визуально съезжает вверх.
            // Отключаем — эмодзи центрируется по реальным границам глифа при любом размере.
            style = TextStyle(
                platformStyle = PlatformTextStyle(includeFontPadding = false),
            ),
        )
    }
}

/** Звезда с накопительной заливкой (1..N закрашены); форма и цвета по макету Figma — см. SdkColors.voteStar*. */
@Composable
private fun StarButton(
    filled: Boolean,
    enabled: Boolean,
    isDark: Boolean,
    onClick: () -> Unit,
) {
    val tint by animateColorAsState(
        targetValue = if (filled) SdkColors.voteStarFilled else SdkColors.voteStarEmpty(isDark),
        label = "starTint",
    )
    Box(
        modifier = Modifier
            .size(30.dp)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.cq_sdk_ic_vote_star),
            contentDescription = null,
            tint = tint,
            // По макету звезда заполняет контейнер 30dp целиком.
            modifier = Modifier.size(30.dp),
        )
    }
}

@Composable
private fun ThanksPill(isDark: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(SdkColors.background(isDark), RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = stringResource(R.string.vote_comment_thanks),
            color = SdkColors.secondaryText(isDark),
            fontSize = 14.sp,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun CommentInput(
    value: String,
    onValueChange: (String) -> Unit,
    hintRes: Int,
    isDark: Boolean,
    accentColor: Color,
    onSend: () -> Unit,
    enabled: Boolean = true,
    sending: Boolean = false,
) {
    var isFocused by remember { mutableStateOf(false) }
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val imeVisible = WindowInsets.isImeVisible

    LaunchedEffect(imeVisible) {
        if (imeVisible && isFocused) bringIntoViewRequester.bringIntoView()
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .border(1.dp, SdkColors.commentInputBorder(isDark), INPUT_SHAPE)
            .padding(start = 15.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .weight(1f)
                .bringIntoViewRequester(bringIntoViewRequester)
                .onFocusChanged { isFocused = it.isFocused },
            textStyle = TextStyle(
                color = SdkColors.title(isDark),
                fontSize = 14.sp,
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                capitalization = KeyboardCapitalization.Sentences,
            ),
            singleLine = true,
            enabled = enabled,
            decorationBox = { innerTextField ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text(
                            text = stringResource(hintRes),
                            color = SdkColors.sectionLabel,
                            fontSize = 14.sp,
                        )
                    }
                    innerTextField()
                }
            },
        )
        Spacer(modifier = Modifier.width(15.dp))
        Box(
            modifier = Modifier
                .size(30.dp)
                .alpha(if (value.isEmpty() && !sending) 0.3f else 1f)
                .clip(CircleShape)
                .background(accentColor)
                .clickable(enabled = enabled && value.isNotEmpty(), onClick = onSend),
            contentAlignment = Alignment.Center,
        ) {
            if (sending) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = SdkColors.onAccent(accentColor),
                    strokeWidth = 2.dp,
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.ArrowUpward,
                    contentDescription = null,
                    tint = SdkColors.onAccent(accentColor),
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}
