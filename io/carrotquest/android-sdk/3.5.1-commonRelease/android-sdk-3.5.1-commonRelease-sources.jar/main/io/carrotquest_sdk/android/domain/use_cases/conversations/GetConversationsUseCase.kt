package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.Callback

import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.domain.use_cases.settings.isReplyToClosedConversationRestricted
import io.carrotquest_sdk.android.core.util.ServerClock
import android.content.Context
import io.carrotquest_sdk.android.core.constants.isPopUpConversationType
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.isWebConversation
import io.carrotquest_sdk.android.core.util.recipientTypeIsRight
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.presentation.mvp.dialog.presenter.isBotRunSuperseded
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Тег логирования (используется и внешними потребителями, напр. DialogPresenter).
const val TAG = "Conversations"

// Observable-ext getConversations/getPopupConversations/getUnreadConversations/getNotPopup* удалены —
// все потребители на чистые фильтры/Flow ниже (ветка remove_rx).

// --- Чистые фильтры (без Rx) + Flow/snapshot для Kotlin-потребителей ---

internal fun List<DataConversation>.validConversations(): List<DataConversation> =
    filter { it.id != null }.distinctBy { it.id }.filter { it.recipientType.recipientTypeIsRight() }

internal fun List<DataConversation>.notPopup(): List<DataConversation> =
    filter { it.id != null && it.type != null }

internal fun List<DataConversation>.notPopupHard(): List<DataConversation> =
    filter {
        it.id != null && it.type != null &&
                (it.type == ConversationType.CHAT.stringValue ||
                        it.type == ConversationType.ROUTING_BOT.stringValue ||
                        it.type == ConversationType.LEAD_BOT.stringValue) &&
                it.recipientType.recipientTypeIsRight()
    }

// Тикет-диалоги исключены: они лежат в общем кэше (пайплайн открытого тикета использует его как
// кэш беседы), но их непрочитанное ведёт TicketsRepository и показывает бейдж вкладки «Тикеты».
// Без фильтра здесь они утекали в публичный getUnreadConversations/setUnreadConversationsCallback
// (хост-приложение видело завышенный счётчик) и в бейдж FloatingButton.
internal fun List<DataConversation>.unread(): List<DataConversation> =
    filter {
        it.id != null && it.unreadPartsCount > 0 && it.recipientType.recipientTypeIsRight() &&
                !it.isTicketConversation
    }

internal fun List<DataConversation>.popup(): List<DataConversation> =
    filter {
        it.id != null && it.type == ConversationType.BLOCK_POPUP_SMALL.stringValue &&
                it.recipientType.recipientTypeIsRight()
    }

/** Continuous-поток валидных бесед (как getConversations() Observable, но без Rx). */
fun conversationsFlow(): Flow<List<DataConversation>> =
    ConversationsRepository.getInstance().conversationsChangesFlow().map { it.validConversations() }

/** Снимок валидных бесед (как getConversations().awaitFirstOrNull()). */
fun currentConversations(): List<DataConversation> =
    ConversationsRepository.getInstance().getConversationsSync().validConversations()

/**
 * Самый свежий диалог по lastUpdate. Сравнение строго ЧИСЛОВОЕ: lastUpdate приходит строкой,
 * и строковая сортировка даёт неверный порядок ("999999999" > "1000000000"). Единственная точка
 * выбора «самого свежего» — обе публичные функции ниже обязаны идти через неё.
 */
internal fun List<DataConversation>.freshestByLastUpdate(): DataConversation? =
    maxByOrNull { it.lastUpdate?.toLongOrNull() ?: 0L }

// Типы диалогов, на которые распространяется запрет писать в закрытые (как RESTRICT_REPLY_TO_CLOSED_TYPES
// на бэкенде и RESTRICTABLE_TYPES в вебе; поп-апы сюда не попадают — их как чат не открываем вовсе).
private val REPLY_RESTRICTABLE_TYPES = setOf(
    ConversationType.CHAT.stringValue,
    ConversationType.LEAD_BOT.stringValue,
    ConversationType.ROUTING_BOT.stringValue,
)

/**
 * Свежесть диалога как в списке истории — по последней реплике. last_update для этого не годится:
 * закрытие диалога обновляет его без новой реплики, и давно заброшенный диалог вылезал бы вперёд.
 * Сравнение ЧИСЛОВОЕ: created/last_update приходят строками.
 */
internal fun DataConversation.freshnessKey(): Long =
    partLast?.created?.toDoubleOrNull()?.toLong() ?: lastUpdate?.toLongOrNull() ?: 0L

/**
 * Диалог, который продолжает кнопка «Написать» в режимах с одним диалогом и кнопка плашки
 * закрытого/сгоревшего диалога. Зеркало веба (cqstatic `select-to-continue.js`). Автооткрытие при
 * старте контейнера идёт через [selectConversationToOpen] (CAR-78149): там нужен самый свежий диалог,
 * а не «куда писать».
 *
 * Приоритет: свежий диалог, где пользователь написал сам или бот уже передал диалог оператору (сервер
 * ставит `replied` по обоим событиям), затем свежий диалог с велком-ботом, которого пользователь сам
 * запустил. Ответы боту кнопками и полями репликой не считаются — `replied` от них не меняется, и без
 * второго уровня кнопка уводила бы в диалог триггерного бота вместо диалога с оператором. Диалог
 * триггерного бота на второй уровень не попадает: у него тип lead_bot, а не routing_bot (веб проверяет
 * ещё и `message`, но SDK это поле с сервера не читает — здесь достаточно типа). Сгоревший велком-бот
 * (CAR-77064) открылся бы без поля ввода — его тоже не продолжаем.
 *
 * Кандидаты: открываемые как чат (не поп-апы, не тикеты, не веб-диалоги — CAR-78107) и не закрытые при
 * запрете писать в закрытые ([restrictEnabled], CAR-77491) — иначе «Написать» возвращала бы в read-only
 * диалог или в диалог веб-бота, которого в списке нет.
 *
 * @param nowMs серверное «сейчас» для метки сгорания бота (ServerClock)
 * @return диалог или null — продолжать нечего, нужен новый
 */
internal fun selectConversationToContinue(
    conversations: List<DataConversation>,
    restrictEnabled: Boolean,
    nowMs: Long,
): DataConversation? {
    val candidates = conversations
        .filter {
            it.id != null && it.type != null && !isPopUpConversationType(it.type) &&
                !it.isTicketConversation && !it.isWebConversation()
        }
        .filterNot { restrictEnabled && it.closed == true && it.type in REPLY_RESTRICTABLE_TYPES }
        .sortedByDescending { it.freshnessKey() }
    return candidates.firstOrNull { it.replied == true }
        ?: candidates.firstOrNull { it.isUserStartedWelcomeBot(nowMs) }
}

// Диалог велком-бота появляется на сервере только после ответа пользователя на первую ветку, поэтому
// отдельный признак того, что пользователь в нём что-то делал, не нужен.
private fun DataConversation.isUserStartedWelcomeBot(nowMs: Long): Boolean =
    type == ConversationType.ROUTING_BOT.stringValue &&
        (expirationTime?.let { it * 1000 > nowMs } ?: true)

// Сгоревший велком-бот, чей прогон никто не перекрыл: открылся бы тупиком — без поля ввода, с плашкой
// «Диалог завершён». Порог тот же, что у BotExpirationTracker.isExpired (remaining <= 0):
// expirationTime*1000 <= nowMs; нет метки — не сгорел (как в isUserStartedWelcomeBot). Реплика
// оператора, закрытие не ботом, свободный текст пользователя или автоответ на него снимают метку
// (isBotRunSuperseded): бэкенд expiration_time после них не чистит, а такой диалог открывается
// нормально (CAR-78149, сценарий 2; CAR-78162 — ответ пользователя). Оптимистичная копия
// исходящего (id == randomId) не считается — она ещё не на сервере.
private fun DataConversation.isExpiredWelcomeBot(nowMs: Long): Boolean =
    type == ConversationType.ROUTING_BOT.stringValue &&
        expirationTime?.let { it * 1000 <= nowMs } == true &&
        !isBotRunSuperseded(partLast)

/**
 * Диалог, который SDK открывает при старте контейнера (`openChat()` →
 * SdkContainerActivity.autoOpenLastDialog). Не путать с [selectConversationToContinue]: тот отвечает
 * «куда писать» и берёт только диалоги с `replied` или живого велком-бота, из-за чего автооткрытие
 * с 3.5.0 прятало непрочитанную рассылку и диалог сгоревшего бота, перехваченный оператором
 * (CAR-78149). Здесь — как до 3.5.0: самый свежий диалог независимо от `replied`, но свежесть по
 * последней реплике ([freshnessKey]), как в списке истории.
 *
 * Отсекаем только то, что открылось бы тупиком:
 *  - поп-апы и тикеты (как чат не открываются);
 *  - веб-диалоги (`recipient_type = web`, CAR-78107) — в списке их нет, для SDK они не существуют;
 *  - закрытые при запрете писать в закрытые ([restrictEnabled], CAR-77491) — иначе read-only диалог;
 *  - сгоревший велком-бот, чей прогон никто не перекрыл — ни оператор, ни сам пользователь
 *    (CAR-77064, CAR-78162) — без поля ввода.
 * `recipient_type` намеренно не фильтруем (как и до 3.5.0; iOS фильтрует) — см. лог в [conversationToOpenId].
 *
 * @param nowMs серверное «сейчас» для метки сгорания бота (ServerClock)
 * @return диалог или null — открывать нечего, нужен новый пустой
 */
internal fun selectConversationToOpen(
    conversations: List<DataConversation>,
    restrictEnabled: Boolean,
    nowMs: Long,
): DataConversation? =
    conversations
        .filter {
            it.id != null && it.type != null && !isPopUpConversationType(it.type) &&
                !it.isTicketConversation && !it.isWebConversation()
        }
        .filterNot { restrictEnabled && it.closed == true && it.type in REPLY_RESTRICTABLE_TYPES }
        .filterNot { it.isExpiredWelcomeBot(nowMs) }
        .maxByOrNull { it.freshnessKey() }

/**
 * Id диалога для продолжения ([selectConversationToContinue]) по текущему репозиторию и настройкам аппа;
 * null — продолжать нечего, открываем новый пустой диалог. Кнопка «Написать» и плашка; автооткрытие
 * при старте контейнера — [conversationToOpenId].
 */
fun conversationToContinueId(context: Context): String? {
    val all = ConversationsRepository.getInstance().getConversationsSync()
    val chosen = selectConversationToContinue(
        conversations = all,
        restrictEnabled = isReplyToClosedConversationRestricted(context),
        nowMs = ServerClock.nowMs(),
    )
    // Диагностика: этим выбором «Написать» и плашка продолжают диалог, а фильтр здесь ШИРЕ, чем
    // validConversations() (нет recipientTypeIsRight, отсекается только web). Логируем recipientType,
    // чтобы по логам было видно, когда SDK открыл диалог, который остальные потоки считают «не своим».
    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, TAG) {
        "conversationToContinueId: total=${all.size} chosen=${chosen?.id} type=${chosen?.type} " +
            "replied=${chosen?.replied} closed=${chosen?.closed} recipientType=${chosen?.recipientType} " +
            "recipientTypeIsRight=${chosen?.recipientType?.recipientTypeIsRight()}"
    }
    return chosen?.id
}

/**
 * Id диалога для автооткрытия при старте контейнера ([selectConversationToOpen]) по текущему
 * репозиторию и настройкам аппа; null — открывать нечего, открываем новый пустой диалог.
 * Только для SdkContainerActivity.autoOpenLastDialog; кнопка «Написать» и плашка идут через
 * [conversationToContinueId].
 */
internal fun conversationToOpenId(context: Context): String? {
    val all = ConversationsRepository.getInstance().getConversationsSync()
    val chosen = selectConversationToOpen(
        conversations = all,
        restrictEnabled = isReplyToClosedConversationRestricted(context),
        nowMs = ServerClock.nowMs(),
    )
    // Диагностика: этим выбором открывается чат, а фильтр ШИРЕ validConversations() (нет
    // recipientTypeIsRight) — логируем recipientType, чтобы по логам было видно, когда SDK открыл
    // диалог, который остальные потоки считают «не своим».
    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, TAG) {
        "conversationToOpenId: total=${all.size} chosen=${chosen?.id} type=${chosen?.type} " +
            "replied=${chosen?.replied} closed=${chosen?.closed} expiration=${chosen?.expirationTime} " +
            "lastPart=${chosen?.partLast?.type}/${chosen?.partLast?.sentVia} " +
            "recipientType=${chosen?.recipientType} " +
            "recipientTypeIsRight=${chosen?.recipientType?.recipientTypeIsRight()}"
    }
    return chosen?.id
}

/**
 * Куда ведёт кнопка плашки закрытого/сгоревшего диалога (CAR-77491/CAR-77064) — как кнопка «Написать»
 * и веб (closed-conversation-notice → selectConversationToContinue): в режиме «один диалог за раз»
 * ([newDialogEnabled] == false) продолжаем диалог, выбранный селектором ([candidateId]), иначе и когда
 * продолжать нечего — новый черновик (null). Сам открытый диалог ([currentIds]: id из аргументов
 * экрана и живой id презентера) не продолжаем: при запрете он закрыт и селектор его не вернёт, но без
 * запрета плашки сгоревшего бота с кнопкой это был бы переход «в себя».
 */
internal fun plateContinueConversationId(
    newDialogEnabled: Boolean,
    candidateId: String?,
    currentIds: Set<String>,
): String? = candidateId?.takeIf { !newDialogEnabled && it.isNotEmpty() && it !in currentIds }

/**
 * Нужно ли скрыть уведомление о сообщении в диалоге [conversationId]: диалог «для web»
 * (recipient_type = web) для SDK не существует (CAR-78107). Решаем только по кэшу
 * [ConversationsRepository], в сеть не ходим: догрузка диалога из обработчика пуша откладывала бы
 * показ уведомления, добавляла auth-запрос на холодном старте и писала диалог в кэш (эмиссия
 * newConversationFlow). Диалога в кэше нет (холодный старт, диалог создан после загрузки списка) —
 * fail-open: false, уведомление показывается как раньше (на iOS гейта уведомлений нет вовсе).
 */
internal fun isConversationHiddenFromSdk(conversationId: String?): Boolean =
    isConversationHiddenFromSdk(conversationId) { ConversationsRepository.getInstance().getConversationById(it) }

internal fun isConversationHiddenFromSdk(
    conversationId: String?,
    cached: (String) -> DataConversation?,
): Boolean {
    if (conversationId.isNullOrEmpty()) return false
    return cached(conversationId)?.isWebConversation() == true
}

/** Последний (по lastUpdate, численно) не-попап диалог; null если нет (как Observable-ext getLastConversation). */
fun getLastConversation(): DataConversation? =
    ConversationsRepository.getInstance().getConversationsSync()
        .validConversations()
        .notPopupHard()
        .freshestByLastUpdate()

/**
 * Непрерывно уведомляет [callback] id-шниками непрочитанных диалогов при изменении списка
 * (раньше — getUnreadConversations(getConversations()).subscribe в CarrotSDK). Возвращает
 * [Cancellable] для отписки (на deInit). Для Java-вызывателя CarrotSDK.
 */
fun observeUnreadConversationIds(callback: Callback<List<String>>): Cancellable {
    val scope = sdkScope(SdkDispatchers.io)
    scope.launch {
        conversationsFlow().collect { conversations ->
            val ids = conversations.unread().mapNotNull { it.id }
            // Бросок в клиентском колбэке не должен убивать подписку (иначе непрочитанные
            // перестают приходить до конца сессии). Глотаем с логом.
            withContext(SdkDispatchers.main) {
                try {
                    callback.onResponse(ids)
                } catch (t: Throwable) {
                    Log.e(TAG, t)
                }
            }
        }
    }
    return Cancellable { scope.cancel() }
}
