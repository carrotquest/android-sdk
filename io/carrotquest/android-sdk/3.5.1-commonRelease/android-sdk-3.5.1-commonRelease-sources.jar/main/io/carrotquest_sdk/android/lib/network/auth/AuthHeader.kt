package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.lib.network.F
import okhttp3.Request

/**
 * Транспорт auth-токена в REST-запросах (CAR-78139, часть 2): заголовок `Authorization: Token <t>`
 * вместо query-параметра `auth_token`, чтобы токены не попадали в URL, access-логи и прокси.
 * Формат тот же, что у WebSocket (JwtClientWebSocket).
 *
 * [useHeader] — build-time переключатель `AUTH_IN_HEADER` на один релиз: при проблемах на проде
 * возвращаемся к query патчем без правки логики. Единственное место, где читается флаг; интерсепторы
 * рефреша и барьера идентичности от флага не зависят — они берут токен оттуда, где он есть в
 * конкретном запросе ([tokenOf]), поэтому одинаково работают в обоих режимах.
 */
internal object AuthHeader {

    const val NAME = "Authorization"
    const val SCHEME = "Token "

    @JvmStatic
    @Volatile
    var useHeader: Boolean = BuildConfig.AUTH_IN_HEADER
        private set

    @JvmStatic
    fun value(token: String): String = SCHEME + token

    /** Токен запроса: из заголовка (без схемы), иначе из query `auth_token`; null — запрос без токена. */
    @JvmStatic
    fun tokenOf(request: Request): String? =
        request.header(NAME)?.removePrefix(SCHEME)?.takeIf { it.isNotEmpty() }
            ?: request.url.queryParameter(F.AUTH_TOKEN)

    /**
     * Явный токен вызывающего кода (pushes_unsubscribe при deInit: токен уже вышедшего юзера),
     * разложенный по транспорту текущего режима: в режиме заголовка — только [ExplicitToken.authorization],
     * в query-режиме — только [ExplicitToken.query]. Пустой/null токен — оба поля null.
     */
    @JvmStatic
    fun explicit(token: String?): ExplicitToken {
        val t = token?.takeIf { it.isNotEmpty() } ?: return ExplicitToken(null, null)
        return if (useHeader) ExplicitToken(query = null, authorization = value(t)) else ExplicitToken(query = t, authorization = null)
    }

    internal data class ExplicitToken(val query: String?, val authorization: String?)

    /** Только для тестов: режим query (AUTH_IN_HEADER=false) без пересборки. */
    internal fun setForTest(value: Boolean) {
        useHeader = value
    }

    internal fun resetForTest() {
        useHeader = BuildConfig.AUTH_IN_HEADER
    }
}
