package io.carrotquest_sdk.android.core.secrets

/**
 * Режим хранения секретов SDK — наружу уходит только строка [wire] (поле в SdkDiagnostics).
 *
 *  - [KEYSTORE] — значения шифруются ключом из Android Keystore (API 23+), штатный режим;
 *  - [PLAINTEXT_FALLBACK] — шифрования сейчас нет: API 21–22, Keystore недоступен или ещё не
 *    ответил, либо на диске есть значение, которое не удалось зашифровать;
 *  - [UNKNOWN] — до setup: инициализация Keystore ещё не запускалась.
 */
internal enum class SecretStorageMode(val wire: String) {
    KEYSTORE("keystore"),
    PLAINTEXT_FALLBACK("plaintext-fallback"),
    UNKNOWN("unknown"),
}
