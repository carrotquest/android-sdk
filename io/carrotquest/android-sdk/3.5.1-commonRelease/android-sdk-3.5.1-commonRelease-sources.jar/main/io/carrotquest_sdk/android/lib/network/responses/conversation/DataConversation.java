package io.carrotquest_sdk.android.lib.network.responses.conversation;
import androidx.annotation.Keep;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.utils.messages.ChatBotMessagesUserCasesKt;

@Keep
public class DataConversation {
    @SerializedName(F.ID)
    private String id;
    @SerializedName(F.RANDOM_ID)
    private String randomId;
    @SerializedName(F.CREATED)
    private String created;
    @SerializedName(F.READ)
    private Boolean read;
    @SerializedName(F.CLIKCKED)
    private Boolean clicked;
    @SerializedName(F.UNSUBSCRIBED)
    private Boolean unsubscribed;
    @SerializedName(F.CLOSED)
    private Boolean closed;
    // Пользователь писал в диалог сам или бот передал его оператору (сервер ставит флаг по обоим
    // событиям; ответы боту кнопками/полями его не меняют). По нему кнопка «Написать» выбирает,
    // какой диалог продолжать (веб: select-to-continue.js).
    @SerializedName(F.REPLIED)
    private Boolean replied;
    @SerializedName(F.MESSAGE)
    private Object message;
    @SerializedName(F.TYPE)
    private String type;
    @SerializedName(F.REPLY_TYPE)
    private String replyType;
    @SerializedName(F.PART_LAST)
    private MessageData partLast;
    @SerializedName(F.PARTS_COUNT)
    private Integer partsCount;
    @SerializedName(F.ASSIGNEE)
    private Object assignee;
    @SerializedName(F.UNREAD_PARTS_COUNT)
    private Integer unreadPartsCount;
    @SerializedName(F.USER_UNREAD_COUNT)
    private Integer userUnreadCount;
    @SerializedName(F.LAST_ADMIN)
    private Admin lastAdmin;
    @SerializedName(F.LAST_SENDER)
    private Admin lastSender;
    @SerializedName(F.LAST_UPDATE)
    private String lastUpdate;
    @SerializedName(F.TAGS)
    private List<Object> tags = null;
    @SerializedName(F.RECIPIENT_TYPE)
    private String recipientType;
    @SerializedName(F.ALLOW_USER_REPLIES)
    private Boolean allowUserReplies;
    @SerializedName(F.EXPIRATION_TIME)
    private Long expirationTime;
    // id тикета строкой; null у обычных диалогов. Приходит в RTS-кадрах и ответах
    // тикет-эндпоинтов; из /conversations/ тикет-диалоги исключены бэком.
    @SerializedName(F.TICKET)
    private String ticket;

    private JsonObject sourceJsonData;

    private boolean isChatBotFinished = false;

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    /**
     * Диалог принадлежит тикету. Двойной признак (ticket-связь ИЛИ type) — страховка
     * от рассинхрона сериализаторов бэка; такие диалоги не должны попадать в обычную
     * ленту/счётчики.
     */
    public boolean isTicketConversation() {
        return ticket != null || "ticket".equals(type);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRandomId() {
        return randomId;
    }

    public void setRandomId(String randomId) {
        this.randomId = randomId;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public Boolean getRead() {
        return read;
    }

    public void setRead(Boolean read) {
        this.read = read;
    }

    public Boolean getClicked() {
        return clicked;
    }

    public void setClicked(Boolean clicked) {
        this.clicked = clicked;
    }

    public Boolean getUnsubscribed() {
        return unsubscribed;
    }

    public void setUnsubscribed(Boolean unsubscribed) {
        this.unsubscribed = unsubscribed;
    }

    public Boolean getClosed() {
        return closed;
    }

    public void setClosed(Boolean closed) {
        this.closed = closed;
    }

    public Boolean getReplied() {
        return replied;
    }

    public void setReplied(Boolean replied) {
        this.replied = replied;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReplyType() {
        return replyType;
    }

    public void setReplyType(String replyType) {
        this.replyType = replyType;
    }

    public MessageData getPartLast() {
        return partLast;
    }

    public void setPartLast(MessageData partLast) {
//        boolean isByBot = ChatBotMessagesUserCasesKt.isByBotWithActions(partLast);
//        if (!isByBot) {
//            this.partLast = partLast;
//        }
        this.partLast = partLast;
    }

    public Integer getPartsCount() {
        return partsCount;
    }

    public void setPartsCount(Integer partsCount) {
        this.partsCount = partsCount;
    }

    public Object getAssignee() {
        return assignee;
    }

    public void setAssignee(Object assignee) {
        this.assignee = assignee;
    }

    public Integer getUnreadPartsCount() {
        return unreadPartsCount;
    }

    public void setUnreadPartsCount(Integer unreadPartsCount) {
        this.unreadPartsCount = unreadPartsCount;
    }

    public Admin getLastAdmin() {
        return lastAdmin;
    }

    public void setLastAdmin(Admin lastAdmin) {
        this.lastAdmin = lastAdmin;
    }

    public Admin getLastSender() {
        return lastSender;
    }

    public void setLastSender(Admin lastSender) {
        this.lastSender = lastSender;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public List<Object> getTags() {
        return tags;
    }

    public void setTags(List<Object> tags) {
        this.tags = tags;
    }

    public Integer getUserUnreadCount() {
        return userUnreadCount;
    }

    public void setUserUnreadCount(Integer userUnreadCount) {
        this.userUnreadCount = userUnreadCount;
    }

    public String getRecipientType() {
        return recipientType;
    }

    public void setRecipientType(String recipientType) {
        this.recipientType = recipientType;
    }

    public Boolean getAllowUserReplies() {
        if (allowUserReplies == null) {
            return false;
        }
        return allowUserReplies;
    }

    public void setAllowUserReplies(Boolean allowUserReplies) {
        this.allowUserReplies = allowUserReplies;
    }

    public JsonObject getSourceJsonData() {
        return sourceJsonData;
    }

    public void setSourceJsonData(JsonObject sourceJsonData) {
        this.sourceJsonData = sourceJsonData;
    }

    public boolean isChatBotFinished() {
        return isChatBotFinished;
    }

    public void setChatBotFinished(boolean chatBotFinished) {
        isChatBotFinished = chatBotFinished;
    }

    public Long getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(Long expirationTime) {
        this.expirationTime = expirationTime;
    }
}
