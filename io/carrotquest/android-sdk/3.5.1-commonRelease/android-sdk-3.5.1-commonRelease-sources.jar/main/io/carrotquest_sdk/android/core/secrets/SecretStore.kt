package io.carrotquest_sdk.android.core.secrets

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.domain.use_cases.user.AUTH_EXTERNAL_ID_KEY
import io.carrotquest_sdk.android.domain.use_cases.user.AUTH_SECRET_KEY
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.wss.jwt.jwtTokenKey
import io.carrotquest_sdk.android.lib.wss.jwt.refreshTokenKey
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * Единственная точка записи и чтения секретов SDK в prefs `io.carrotquest.utils` (CAR-78139).
 *
 * Секреты — ключи из [secretKeys]: JWT-пара, легаси CarrotToken, отложенный unsubscribe-токен
 * и креды повторной авторизации. Они хранятся как `enc1:` + payload, зашифрованный
 * [SecretCipher] (ключ в Android Keystore, API 23+). Всё остальное в prefs не трогается.
 *
 * Как сюда попадают: `SharedPreferencesLib.saveString/getString/saveStringWithLong` маршрутизируют
 * секретные ключи по имени, а `UserIdentityStore` кладёт зашифрованные значения в свой editor через
 * [putInto] — так атомарность «userId + токены + таймстемпы одной транзакцией» сохраняется.
 *
 * Инварианты:
 *  - сбой шифра никогда не ломает сессию: нечитаемое значение читается как отсутствующее
 *    (SDK уходит в штатный token-less recovery), незашифровавшееся — пишется открытым текстом
 *    с WARN; ничего не удаляется;
 *  - plaintext из версий ≤3.5.0 читается как есть и перешифровывается в [ensureEncrypted] на setup;
 *  - пустая строка не шифруется: `""` означает «очищено» (контракт clearTokens);
 *  - Keystore инициализируется на setup с ограниченным ожиданием ниже порога ANR — зависший
 *    keystored у OEM не должен превращаться в ANR на старте. Таймаут НЕ окончателен: инициализация
 *    продолжается в фоне, и следующее обращение подхватит готовый ключ. Пока ключа нет, записи
 *    ложатся plaintext (дошифруются на следующем setup), а зашифрованные значения нечитаемы —
 *    на холодном старте это означает новую анонимную сессию (компромисс, см. бюджеты ниже);
 *  - работает без Hilt и до setup (пуш-путь поднимает процесс без инициализации SDK).
 *
 * Кеш расшифрованных значений самопроверяющийся: рядом с plain хранится raw из prefs, и при
 * чтении они сравниваются. Любая запись мимо стора (тесты делают `edit().clear()`) меняет raw и
 * автоматически промахивается — явная инвалидация не нужна и не может «забыться».
 *
 * Порядок локов: `UserIdentityStore.lock` → [lock]. Стор никогда не зовёт UserIdentityStore и
 * SharedPreferencesLib обратно — рекурсии и дедлоков нет.
 */
internal object SecretStore {

    private const val TAG = "SecretStore"
    const val ENC_PREFIX = "enc1:"

    /**
     * Бюджеты ожидания инициализации Keystore (обычно она занимает единицы–десятки мс, при первой
     * генерации ключа — до сотен). Запись может лечь plaintext и дошифроваться на следующем setup,
     * поэтому ждёт недолго. Чтение зашифрованного значения без ключа — потеря сессии (SDK завёл бы
     * нового анонима поверх старых токенов), поэтому ждёт дольше, но строго меньше порога ANR по
     * вводу (5 с): ожидание идёт на главном потоке в setup. Оба отсчитываются от старта
     * инициализации, так что суммарная блокировка за процесс не превышает большего из них.
     *
     * Осознанный компромисс (CAR-78139, решение 2026-10-27): keystored, зависший дольше 4 с, стоит
     * сессии — SDK заведёт нового анонима, в логе WARN, в диагностике plaintext-fallback. ANR для
     * хоста дороже редкой потери сессии на неисправном устройстве. Отложенный connect до прихода
     * ключа — отдельной задачей, если такие устройства проявятся в поддержке.
     */
    private const val DEFAULT_WAIT_WRITE_MS = 3_000L
    private const val DEFAULT_WAIT_READ_MS = 4_000L

    /** Allowlist секретных ключей. Остальные ключи prefs стор не касается. */
    @JvmStatic
    val secretKeys: Set<String> = setOf(
        jwtTokenKey,
        refreshTokenKey,
        SharedPreferenceKeys.CARROT_TOKEN,
        SharedPreferenceKeys.PENDING_UNSUB_TOKEN,
        AUTH_SECRET_KEY,
        AUTH_EXTERNAL_ID_KEY,
    )

    private sealed class CipherState {
        /** Инициализация ещё не запускалась (до setup). */
        object Unresolved : CipherState()
        /** Инициализация идёт на потоке cq-keystore; ожидание в пределах бюджета истекло или не требовалось. */
        class Pending(val task: FutureTask<SecretCipher?>, val startedAt: Long) : CipherState()
        class Available(val cipher: SecretCipher) : CipherState()
        /** Keystore сломан на этот процесс (фабрика бросила или вернула null). */
        object Unavailable : CipherState()
    }

    private val lock = Any()

    // key -> (raw из prefs, расшифрованное значение). Только под lock.
    private val cache = HashMap<String, Pair<String, String>>()

    // Ключи/причины, по которым WARN уже написан (один раз за процесс). Только под lock.
    private val warned = HashSet<String>()

    @Volatile
    private var cipherState: CipherState = CipherState.Unresolved

    // Фабрика прод-шифра; тесты подменяют через resetForTest.
    @Volatile
    private var cipherFactory: () -> SecretCipher? = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) KeystoreSecretCipher.create() else null
    }

    @Volatile
    private var cipherSupported: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M

    // Хотя бы одна запись за процесс легла открытым текстом (шифр отказал).
    @Volatile
    private var fallbackHappened = false

    @Volatile
    private var keystoreInitMs: Long = -1

    @Volatile
    private var waitWriteMs: Long = DEFAULT_WAIT_WRITE_MS

    @Volatile
    private var waitReadMs: Long = DEFAULT_WAIT_READ_MS

    @JvmStatic
    fun isSecret(key: String?): Boolean = key != null && key in secretKeys

    /** Значение по контракту `SharedPreferencesLib.getString`: `""`, если нет или нечитаемо. */
    @JvmStatic
    fun get(context: Context, key: String): String {
        return try {
            val raw = prefs(context).getString(key, "") ?: ""
            when {
                raw.isEmpty() -> ""
                // Легаси plaintext (≤3.5.0) до миграции, или plaintext-fallback.
                !raw.startsWith(ENC_PREFIX) -> raw
                else -> decryptCached(key, raw)
            }
        } catch (t: Throwable) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "get '$key' failed: $t")
            ""
        }
    }

    /** Запись своим editor; null — удаление (контракт `putString(key, null)`). */
    @JvmStatic
    fun put(context: Context, key: String, value: String?) {
        try {
            val editor = prefs(context).edit()
            if (value == null) editor.remove(key) else putInto(editor, key, value)
            editor.apply()
        } catch (t: Throwable) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "put '$key' failed: $t")
        }
    }

    /**
     * Кладёт зашифрованное значение в ЧУЖОЙ editor — для путей, где секрет должен уйти на диск
     * одной транзакцией с другими полями (persist тройки, токен + таймстемп). `apply()` — за
     * вызывающим.
     */
    @JvmStatic
    fun putInto(editor: SharedPreferences.Editor, key: String, value: String) {
        if (value.isEmpty()) {
            // Под lock — барьер относительно ensureEncrypted: очистка не может быть «воскрешена»
            // миграцией, прочитавшей старое значение (её apply под тем же lock уходит раньше).
            synchronized(lock) { editor.putString(key, "") }
            return
        }
        // API 21–22: Keystore AES нет, plaintext — штатный режим, не сбой (без WARN).
        val enc = if (cipherSupported) encryptOrNull(key, value) else null
        if (enc != null) {
            val stored = ENC_PREFIX + enc
            editor.putString(key, stored)
            synchronized(lock) { cache[key] = stored to value }
        } else {
            // Шифр отказал — значение нужнее, чем его защита: пишем открытым текстом и помечаем режим.
            editor.putString(key, value)
            if (cipherSupported) {
                fallbackHappened = true
                warnOnce("encrypt:$key", "keystore encrypt failed for '$key' — stored in plaintext")
            }
        }
    }

    /**
     * Гарантия на setup: все секреты на диске зашифрованы. Plaintext из версий ≤3.5.0 (или из
     * plaintext-fallback прошлого процесса) перешифровывается одной транзакцией.
     *
     * Идемпотентно и дёшево: шесть чтений из in-memory map prefs; Keystore трогается только если
     * нашлось что шифровать. Флага «миграция сделана» нет намеренно — роль флага играют сами
     * данные (префикс [ENC_PREFIX]): флаг мог бы врать после kill между записями, после записи в
     * plaintext-fallback или после даунгрейда. Kill посреди шифрования оставляет всё plaintext —
     * читаемо, следующий setup дошифрует.
     */
    @JvmStatic
    fun ensureEncrypted(context: Context) {
        try {
            var encrypted = 0
            if (cipherSupported) {
                val prefs = prefs(context)
                val pending = plaintextSecretKeys(prefs)
                val hasEncrypted = secretKeys.any { (prefs.getString(it, "") ?: "").startsWith(ENC_PREFIX) }
                // Шифр поднимаем здесь, на setup: диагностика честная сразу, генерация ключа —
                // на старте, а не посреди первого запроса. Бюджет — по тому, что на кону: есть
                // зашифрованная сессия → ждём как для чтения.
                synchronized(lock) { resolveCipher(if (hasEncrypted) waitReadMs else waitWriteMs) }
                if (pending.isNotEmpty()) encrypted = encryptInPlace(prefs, pending)
                // Всё на диске зашифровано и ключ есть → прошлый plaintext-fallback исчерпан.
                if (cipherState is CipherState.Available && plaintextSecretKeys(prefs).isEmpty()) {
                    fallbackHappened = false
                }
            }
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "secret store ready: mode=${modeName()}, encrypted=$encrypted, keystore init $keystoreInitMs ms",
            )
        } catch (t: Throwable) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "ensureEncrypted failed: $t")
        }
    }

    /** Секретные ключи, чьи значения лежат открытым текстом (непустые и без [ENC_PREFIX]). */
    private fun plaintextSecretKeys(prefs: SharedPreferences): List<String> =
        secretKeys.filter { key ->
            val raw = prefs.getString(key, "") ?: ""
            raw.isNotEmpty() && !raw.startsWith(ENC_PREFIX)
        }

    /**
     * Шифрует значения [keys] на месте одной транзакцией. Целиком под [lock] — от чтения до apply,
     * что сужает окно гонки с параллельной записью через [putInto], но не закрывает его: apply()
     * чужого editor идёт уже вне lock. На практике вызывается только из setup до старта сервиса,
     * когда параллельных писателей нет. @return сколько ключей зашифровано.
     */
    private fun encryptInPlace(prefs: SharedPreferences, keys: List<String>): Int = synchronized(lock) {
        val editor = prefs.edit()
        var encrypted = 0
        for (key in keys) {
            val raw = prefs.getString(key, "") ?: ""
            if (raw.isEmpty() || raw.startsWith(ENC_PREFIX)) continue
            val enc = encryptOrNull(key, raw)
            if (enc != null) {
                val stored = ENC_PREFIX + enc
                editor.putString(key, stored)
                cache[key] = stored to raw
                encrypted++
            } else {
                fallbackHappened = true
                warnOnce("encrypt:$key", "keystore encrypt failed for '$key' — left in plaintext")
            }
        }
        if (encrypted > 0) editor.apply()
        encrypted
    }

    /** Режим для SdkDiagnostics. Keystore НЕ трогает: getDiagnostics до setup — без побочных эффектов. */
    @JvmStatic
    fun modeName(): String = mode().wire

    private fun mode(): SecretStorageMode = when {
        !cipherSupported -> SecretStorageMode.PLAINTEXT_FALLBACK
        fallbackHappened -> SecretStorageMode.PLAINTEXT_FALLBACK
        else -> when (cipherState) {
            is CipherState.Available -> SecretStorageMode.KEYSTORE
            // Ключ ещё не ответил: запись прямо сейчас легла бы plaintext.
            is CipherState.Pending, is CipherState.Unavailable -> SecretStorageMode.PLAINTEXT_FALLBACK
            is CipherState.Unresolved -> SecretStorageMode.UNKNOWN
        }
    }

    // --- внутренности ---

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(SharedPreferencesLib.NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE)

    private fun decryptCached(key: String, raw: String): String = synchronized(lock) {
        cache[key]?.let { (cachedRaw, plain) -> if (cachedRaw == raw) return plain }
        val cipher = resolveCipher(waitReadMs)
        if (cipher == null) {
            // Ключ ещё поднимается (Pending): промах НЕ кешируем — следующее чтение подхватит ключ.
            // Unavailable — sticky, кешируем, чтобы не ходить в Keystore на каждый запрос.
            if (cipherState is CipherState.Unavailable) cache[key] = raw to ""
            warnOnce("unreadable:$key", "secret '$key' unreadable — treated as absent")
            return ""
        }
        val plain = runCatching { cipher.decrypt(raw.substring(ENC_PREFIX.length)) }.getOrNull()
        if (plain == null) {
            // Битое/чужое значение: кешируем промах, повторных попыток и логов на каждый запрос
            // не будет. Значение НЕ удаляем — штатный поток его перезапишет.
            cache[key] = raw to ""
            warnOnce("unreadable:$key", "secret '$key' unreadable — treated as absent")
            return ""
        }
        cache[key] = raw to plain
        plain
    }

    private fun encryptOrNull(key: String, value: String): String? = synchronized(lock) {
        resolveCipher(waitWriteMs)?.let { c -> runCatching { c.encrypt(value) }.getOrNull() }
    }

    /**
     * Под [lock]. Поднимает шифр, ожидая инициализацию не дольше [waitMs] от её старта. Таймаут не
     * окончателен: состояние остаётся [CipherState.Pending], поток cq-keystore продолжает работу,
     * и следующее обращение (со своим бюджетом) подхватит результат. Окончательны только
     * [CipherState.Available] и [CipherState.Unavailable] (фабрика бросила / вернула null).
     */
    private fun resolveCipher(waitMs: Long): SecretCipher? {
        if (!cipherSupported) return null
        val pending: CipherState.Pending = when (val s = cipherState) {
            is CipherState.Available -> return s.cipher
            is CipherState.Unavailable -> return null
            is CipherState.Pending -> s
            is CipherState.Unresolved -> startInit()
        }
        var initFailed = false
        val cipher: SecretCipher? = try {
            val remaining = waitMs - (System.currentTimeMillis() - pending.startedAt)
            when {
                pending.task.isDone -> pending.task.get()
                remaining > 0 -> pending.task.get(remaining, TimeUnit.MILLISECONDS)
                else -> return null // бюджет исчерпан — ждём следующего обращения
            }
        } catch (t: TimeoutException) {
            warnOnce(
                "init-timeout",
                "keystore init is taking longer than $waitMs ms — secrets unavailable until it completes",
            )
            return null
        } catch (t: Throwable) {
            initFailed = true
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "keystore init failed (${t.javaClass.simpleName}) — secrets stay in plaintext for this process",
            )
            null
        }
        if (cipher == null && !initFailed) {
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "keystore unavailable — secrets stay in plaintext for this process",
            )
        }
        cipherState = if (cipher != null) CipherState.Available(cipher) else CipherState.Unavailable
        return cipher
    }

    /** Под [lock]. Стартует инициализацию на daemon-потоке — IPC в keystored у части OEM может висеть. */
    private fun startInit(): CipherState.Pending {
        val task = FutureTask<SecretCipher?> {
            val t0 = System.currentTimeMillis()
            try {
                cipherFactory()
            } finally {
                keystoreInitMs = System.currentTimeMillis() - t0 // длительность самой инициализации
            }
        }
        Thread(task, "cq-keystore").apply { isDaemon = true }.start()
        return CipherState.Pending(task, System.currentTimeMillis()).also { cipherState = it }
    }

    private fun warnOnce(reason: String, message: String) {
        val first = synchronized(lock) { warned.add(reason) }
        if (first) SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG, message)
    }

    /**
     * Только для тестов. [cipher] != null — шифр подставлен напрямую (Keystore в Robolectric нет);
     * null + [cipherSupported] = false — модель API 21–22; null + true — ленивый резолв через [factory].
     */
    internal fun resetForTest(
        cipher: SecretCipher? = null,
        cipherSupported: Boolean = cipher != null,
        factory: () -> SecretCipher? = { null },
        waitWriteMs: Long = DEFAULT_WAIT_WRITE_MS,
        waitReadMs: Long = DEFAULT_WAIT_READ_MS,
    ) {
        synchronized(lock) {
            cache.clear()
            warned.clear()
            cipherState = if (cipher != null) CipherState.Available(cipher) else CipherState.Unresolved
            this.cipherSupported = cipherSupported
            cipherFactory = factory
            this.waitWriteMs = waitWriteMs
            this.waitReadMs = waitReadMs
            fallbackHappened = false
            keystoreInitMs = -1
        }
    }
}
