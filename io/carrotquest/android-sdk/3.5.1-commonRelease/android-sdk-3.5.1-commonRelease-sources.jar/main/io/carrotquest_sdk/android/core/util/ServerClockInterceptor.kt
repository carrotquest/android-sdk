package io.carrotquest_sdk.android.core.util

import okhttp3.Interceptor
import okhttp3.Response

/**
 * Снимает заголовок `Date` с каждого ответа API в якорь [ServerClock] (CAR-77064): первый якорь
 * появляется уже на `/connect`, до первого RTS-кадра, и сгорание бота не зависит от часов
 * устройства даже при холодном открытии сгоревшего диалога. Запрос не меняет, ошибки не глотает.
 */
internal class ServerClockInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())
        ServerClock.syncHttpDate(response.header("Date"))
        return response
    }
}
