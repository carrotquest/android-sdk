package io.carrotquest_sdk.android.presentation.chat

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.SdkColors

/**
 * Плашка read-only закрытого диалога внизу ленты вместо поля ввода (CAR-77491): подпись
 * «В закрытый диалог писать нельзя» + кнопка «Начать новый диалог». Показывается, когда диалог
 * финально закрыт и апп включил messenger_restrict_reply_to_closed_conversation. Пилюля кнопки —
 * в стиле SupplementTicketButton, чтобы нижние контролы выглядели одинаково.
 */
@Composable
internal fun ClosedDialogPlate(
    accentColor: Color,
    isDark: Boolean,
    onStartNewConversation: () -> Unit,
    // Сгорание бота (CAR-77064) переиспользует плашку с другим текстом; в режиме «одно окно»
    // кнопки нет — бот перезапустится в этом же диалоге, как только сервер его закроет.
    titleRes: Int = R.string.cq_sdk_dialog_closed_plate,
    showButton: Boolean = true,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(titleRes),
            color = SdkColors.secondaryText(isDark),
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 8.dp),
        )
        if (showButton) {
            OutlinedButton(
                onClick = onStartNewConversation,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, SdkColors.ticketPillBorder(isDark, accentColor)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = SdkColors.ticketPillContent(isDark, accentColor),
                ),
            ) {
                Text(
                    text = stringResource(R.string.cq_sdk_dialog_closed_start_new),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}
