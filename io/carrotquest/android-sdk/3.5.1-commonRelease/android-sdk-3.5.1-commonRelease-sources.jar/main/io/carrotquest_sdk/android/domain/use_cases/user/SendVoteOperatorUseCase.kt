package io.carrotquest_sdk.android.domain.use_cases.user

import android.text.TextUtils
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageMetaData
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessage
import io.carrotquest_sdk.android.core.constants.MessageStatus
import org.json.JSONObject
import java.util.Locale

// suspend-ядра голосования (ветка remove_rx, фаза 3). Потребляются только DialogPresenter.

suspend fun sendVoteOperator(messageId: String, vote: Int, comment: String = ""): Boolean {
    val bodyMetaDataObject = JsonObject()
    bodyMetaDataObject.addProperty("vote", vote)
    if (!TextUtils.isEmpty(comment)) {
        bodyMetaDataObject.addProperty("comment", comment)
    }
    val response = CarrotInternal.getService().carrotLib
        .conversationPartsSuspend(messageId, bodyMetaDataObject)
    return response.status == 200
}

suspend fun wrongVoting(messageId: String): Boolean {
    val message = getMessage(messageId) ?: return false
    message.status = MessageStatus.WARNING.name.lowercase(Locale.getDefault())
    MessagesRepository.getInstance().updateMessage(message)
    return true
}

/**
 * Локальное применение оценки/комментария к сообщению — надёжное «echo» для UI: серверная копия
 * vote-части нестабильна (reload часто приходит без meta_data.vote), поэтому пишем в кэш сами.
 * Мержим в существующий meta_data, а не заменяем его: иначе при отправке оценки терялся бы
 * comment (и наоборот), а карточка откатывалась к пустому полю комментария.
 */
private suspend fun applyVote(messageId: String, vote: Int, comment: String? = null): Boolean {
    val message = getMessage(messageId) ?: return false
    // Без meta_data оценка не была бы видна до серверного echo — создаём объект.
    val meta = message.messageMetaData ?: MessageMetaData().also { message.messageMetaData = it }
    meta.vote = vote
    if (comment != null) meta.comment = comment

    val sourceJson = message.sourceJsonData
    val metaJson = sourceJson.optJSONObject(F.META_DATA) ?: JSONObject()
    metaJson.put(F.VOTE, vote)
    if (comment != null) metaJson.put(F.COMMENT, comment)
    sourceJson.put(F.META_DATA, metaJson) // put заменяет значение по ключу — remove не нужен

    MessagesRepository.getInstance().updateMessage(message)
    return true
}

suspend fun doneVoting(messageId: String, vote: Int): Boolean = applyVote(messageId, vote)

suspend fun doneVotingComment(messageId: String, vote: Int, comment: String): Boolean =
    applyVote(messageId, vote, comment)
