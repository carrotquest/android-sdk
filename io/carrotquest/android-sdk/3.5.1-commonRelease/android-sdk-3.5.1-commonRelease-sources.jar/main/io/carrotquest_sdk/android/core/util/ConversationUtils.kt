package io.carrotquest_sdk.android.core.util

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation

private const val RECIPIENT_TYPE_WEB = "web"

// Белый список «своих» recipient_type для счётчика непрочитанных, поп-апов и реалтайм-новых диалогов.
// Receiver nullable (защита): поле с сервера может отсутствовать, а Java-геттер даёт platform-тип —
// non-null receiver бросил бы NullPointerException на проверке параметра. null — «не свой».
fun String?.recipientTypeIsRight(): Boolean =
    this == "all" || this == "sdk" || this == "sdk_a"

// Диалог предназначен веб-виджету (recipient_type = web: лид-бот сайта и т.п.). Для мобильного SDK
// такой диалог не существует — не показываем в списке, не продолжаем кнопкой «Написать», не
// уведомляем (CAR-78107, как iOS: `recipientType != "web"`). null и неизвестные значения — не web.
fun String?.isWebRecipientType(): Boolean = this == RECIPIENT_TYPE_WEB

fun DataConversation.isWebConversation(): Boolean = recipientType.isWebRecipientType()
