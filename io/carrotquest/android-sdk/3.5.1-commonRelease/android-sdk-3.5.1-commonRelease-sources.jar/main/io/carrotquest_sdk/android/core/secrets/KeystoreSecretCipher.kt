package io.carrotquest_sdk.android.core.secrets

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.annotation.RequiresApi
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES/GCM-шифр на ключе из Android Keystore (API 23+). Payload: Base64(IV ‖ ciphertext ‖ tag),
 * IV 12 байт генерирует сам Keystore (randomized encryption), тег 128 бит возвращает `doFinal`.
 *
 * Ключ намеренно БЕЗ `setUserAuthenticationRequired` / `setUnlockedDeviceRequired` / StrongBox:
 * пуш-путь читает токены на заблокированном экране, а смена экрана блокировки не должна
 * инвалидировать ключ. Alias общий для UID приложения — коллизия с ключом хоста маловероятна,
 * но ключ с чужими параметрами даст `encrypt == null` → SecretStore уйдёт в plaintext-fallback.
 *
 * Любой сбой — null (контракт [SecretCipher]): нет провайдера, `KeyPermanentlyInvalidatedException`,
 * `AEADBadTagException` после restore из бэкапа с чужим ключом, битый Base64.
 */
@RequiresApi(Build.VERSION_CODES.M)
internal class KeystoreSecretCipher internal constructor(private val key: SecretKey) : SecretCipher {

    override fun encrypt(plain: String): String? = try {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        if (iv == null || iv.size != IV_LEN) {
            null
        } else {
            val body = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(iv + body, Base64.NO_WRAP)
        }
    } catch (t: Throwable) {
        null
    }

    override fun decrypt(payload: String): String? = try {
        val bytes = Base64.decode(payload, Base64.NO_WRAP)
        if (bytes.size <= IV_LEN + TAG_BYTES) {
            null
        } else {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, bytes, 0, IV_LEN))
            String(cipher.doFinal(bytes, IV_LEN, bytes.size - IV_LEN), Charsets.UTF_8)
        }
    } catch (t: Throwable) {
        null
    }

    companion object {
        const val ALIAS = "cq_sdk_secrets"
        private const val PROVIDER = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_LEN = 12
        private const val TAG_BITS = 128
        private const val TAG_BYTES = TAG_BITS / 8

        /**
         * Поднимает существующий ключ или генерирует новый (первый запуск после обновления —
         * десятки–сотни мс в TEE). null при любом Throwable — вызывающий уходит в plaintext-fallback.
         */
        fun create(): KeystoreSecretCipher? = try {
            val keyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }
            val existing = keyStore.getKey(ALIAS, null) as? SecretKey
            val key = existing ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER).run {
                init(
                    KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build(),
                )
                generateKey()
            }
            KeystoreSecretCipher(key)
        } catch (t: Throwable) {
            null
        }
    }
}
