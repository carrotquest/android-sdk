package io.carrotquest_sdk.android.lib.network

import retrofit2.HttpException

// Признаки ошибок бэка (cqapi messages/exceptions.py): имя класса в meta.error и текст в
// meta.error_message. Стабильного кода нет, а форму meta задаёт api_tools вне репозитория бэка —
// поэтому, как веб, матчим и класс, и текст, без учёта регистра. Два случая различаем, потому что
// реакция разная (веб: isReopenRestrictedError vs botExpiration.shouldExpireOnError):
//  • ConversationReopenRestrictedError — апп запретил писать в закрытые диалоги (CAR-77491):
//    reply и meta_data (кнопка бота) в финально закрытый диалог → 400, диалог становится read-only.
//  • ConversationAlreadyClosedError — кнопка бота нажата в диалоге, уже закрытом сгоревшим
//    ботом (CAR-77064): реагируем как на сгорание.
private val REOPEN_RESTRICTED_MARKERS = listOf(
    "conversationreopenrestricted",
    "restricts reopening closed conversations",
)
private val ALREADY_CLOSED_MARKERS = listOf(
    "conversationalreadyclosed",
    "conversation_already_closed",
    "conversation is already closed",
)

/** Апп запрещает писать в закрытые диалоги, сервер отверг отправку (HTTP 400, CAR-77491). */
internal fun Throwable.isConversationReopenRestrictedError(): Boolean =
    closedErrorKind() == ClosedErrorKind.REOPEN_RESTRICTED

/** Диалог уже закрыт сгоревшим ботом, ответ боту отвергнут (HTTP 400, CAR-77064). */
internal fun Throwable.isConversationAlreadyClosedError(): Boolean =
    closedErrorKind() == ClosedErrorKind.ALREADY_CLOSED

/**
 * Сервер отверг реплику/ответ боту, потому что диалог закрыт (любой из двух случаев). Данные не
 * записаны, поэтому такую ошибку показываем не как «не удалось отправить», а как состояние
 * диалога; в очередь ресенда сообщение не кладём.
 */
internal fun Throwable.isConversationClosedError(): Boolean = closedErrorKind() != null

private enum class ClosedErrorKind { REOPEN_RESTRICTED, ALREADY_CLOSED }

// Тело читаем один раз на вызов и матчим оба набора маркеров: запрет аппа первичен (как в вебе).
private fun Throwable.closedErrorKind(): ClosedErrorKind? {
    val body = errorBody400()?.lowercase() ?: return null
    return when {
        REOPEN_RESTRICTED_MARKERS.any { body.contains(it) } -> ClosedErrorKind.REOPEN_RESTRICTED
        ALREADY_CLOSED_MARKERS.any { body.contains(it) } -> ClosedErrorKind.ALREADY_CLOSED
        else -> null
    }
}

// Тело ответа 400 или null, если это не 400 / не HTTP-ошибка.
private fun Throwable.errorBody400(): String? = when (this) {
    is ReplySendException -> serverBody.takeIf { httpCode == 400 }
    is HttpException -> if (code() == 400) errorBodySafe() else null
    else -> null
}

// errorBody().string() одноразовый: второй вызов (несколько матчеров на одну ошибку, диагностика)
// получил бы пустую строку. Читаем через peek, не потребляя источник; на ошибке чтения — пусто,
// диагностика не должна подменять исходную ошибку.
private fun HttpException.errorBodySafe(): String = try {
    response()?.errorBody()?.source()?.peek()?.readUtf8().orEmpty()
} catch (t: Exception) {
    ""
}
