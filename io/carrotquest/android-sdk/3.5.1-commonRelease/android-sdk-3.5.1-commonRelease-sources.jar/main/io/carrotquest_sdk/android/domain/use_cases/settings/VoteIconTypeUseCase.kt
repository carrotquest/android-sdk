package io.carrotquest_sdk.android.domain.use_cases.settings

import com.google.gson.JsonParser

/** Вид иконок в карточке оценки оператора; значения совпадают с настройкой аппа messenger_vote_icon. */
enum class VoteIconType { EMOJI, STARS }

/**
 * Настройка messenger_vote_icon из /connect (CAR-77291): "stars" → звёзды, иначе эмодзи.
 * Читается из sourceData настроек (strangler-паттерн, как messenger_vote): старый бэкенд поле не
 * отдаёт, неизвестное значение тоже возможно — в обоих случаях эмодзи, как в вебе (getVoteIconType).
 */
fun getVoteIconType(): VoteIconType = parseVoteIconType(getSettings()?.sourceData)

/** Чистая часть [getVoteIconType]: путь app/settings/messenger_vote_icon. Покрыта ParseVoteIconTypeTest. */
internal fun parseVoteIconType(sourceData: String?): VoteIconType = runCatching {
    val json = sourceData?.takeIf { it.isNotBlank() } ?: return@runCatching VoteIconType.EMOJI
    val raw = JsonParser.parseString(json).takeIf { it.isJsonObject }?.asJsonObject
        ?.getAsJsonObject("app")
        ?.getAsJsonObject("settings")
        ?.get("messenger_vote_icon")
        ?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }
        ?.asString
    if (raw == "stars") VoteIconType.STARS else VoteIconType.EMOJI
}.getOrDefault(VoteIconType.EMOJI)
