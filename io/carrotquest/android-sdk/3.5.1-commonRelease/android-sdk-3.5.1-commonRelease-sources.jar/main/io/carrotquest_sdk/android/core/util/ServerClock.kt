package io.carrotquest_sdk.android.core.util

import android.os.SystemClock
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Серверные часы (CAR-77064): оценка текущего серверного времени, не зависящая от часов устройства.
 *
 * Якорь — пара «серверное время, монотонное время устройства» ([SystemClock.elapsedRealtime]):
 * «сейчас» = серверное время якоря + сколько монотонного времени прошло с него. Монотонные часы не
 * трогает ни ручной перевод времени, ни смена пояса, ни автокоррекция по сети, и они идут во сне
 * устройства. Веб считает поправку от `Date.now()` и наследует скачки часов — у Android это
 * проявляется чаще (поездки, NTP после офлайна), поэтому здесь якорь монотонный.
 *
 * Источники: `created` реплик из RTS-событий (conversation_parts_batch, message_conversation_started)
 * и заголовок `Date` ответов API ([ServerClockInterceptor]) — он даёт первый якорь ещё до первого
 * RTS-кадра. Оба с точностью до секунды. До первого якоря «сейчас» берётся с часов устройства.
 *
 * Метке нельзя верить безусловно: после переподключения RTS переигрывает пропущенные реплики, их
 * `created` — серверное «сейчас» минус возраст реплики; такая метка увела бы часы в прошлое и
 * отложила сгорание бота. Заголовок `Date` тоже отстаёт: прод-nginx отдаёт его на 14–35 с позади
 * реального времени (часы нод API и RTS разошлись), и разрешённый ему откат оценки назад отодвигал
 * сгорание на те же секунды — пользователь успевал продолжить сгоревшую ветку (QA CAR-77343).
 * Поэтому фильтр один для всех источников — монотонность серверного времени: принимаем только
 * метку, которая СДВИГАЕТ оценку вперёд (отставшая — всегда позади оценки). Из двух честных
 * измерений выигрывает то, что доставилось быстрее, — оно точнее. Обратной коррекции нет: дрейф
 * монотонных часов за дни работы приложения — доли секунды, а поздняя метка на сгорание бота
 * влияет не критично (сгорит чуть раньше, запрос всё равно перехватит сервер 400).
 */
object ServerClock {

    private class Anchor(val serverMs: Long, val elapsedMs: Long)

    @Volatile
    private var anchor: Anchor? = null

    // Часы устройства и монотонные часы; подменяются в юнит-тестах.
    internal var wallClockMs: () -> Long = { System.currentTimeMillis() }
    internal var elapsedMs: () -> Long = { SystemClock.elapsedRealtime() }

    /** Серверное «сейчас» в миллисекундах. */
    @JvmStatic
    fun nowMs(): Long {
        val a = anchor ?: return wallClockMs()
        return a.serverMs + (elapsedMs() - a.elapsedMs)
    }

    /** Был ли хоть один якорь (иначе «сейчас» — часы устройства). */
    @JvmStatic
    fun isSynced(): Boolean = anchor != null

    /**
     * Якорь по `created` реплики из RTS (unix-секунды строкой, как отдаёт бэк).
     * Пустое/нечисловое значение игнорируется.
     */
    @JvmStatic
    fun syncCreated(created: String?) {
        val seconds = created?.trim()?.toDoubleOrNull() ?: return
        if (seconds <= 0.0) return
        syncServerMs((seconds * 1000).toLong())
    }

    /**
     * Якорь по заголовку `Date` HTTP-ответа (RFC 1123, GMT). Нераспознанное значение игнорируется.
     * Тот же фильтр монотонности, что у RTS-меток: заголовок даёт первый якорь до первого
     * RTS-кадра и может только подвинуть оценку вперёд. Откат назад по нему запрещён — на проде
     * `Date` отстаёт на десятки секунд и перебивал бы точную RTS-метку (см. описание класса).
     */
    @JvmStatic
    fun syncHttpDate(dateHeader: String?) {
        val ms = parseHttpDate(dateHeader) ?: return
        syncServerMs(ms)
    }

    /**
     * Якорь по серверному времени в миллисекундах. Synchronized: метки приходят с потоков OkHttp и RTS.
     * Принимаем только метку, сдвигающую оценку вперёд (см. фильтр отставших меток в описании класса).
     */
    @JvmStatic
    @Synchronized
    fun syncServerMs(serverMs: Long) {
        val elapsed = elapsedMs()
        val current = anchor
        if (current != null) {
            val estimate = current.serverMs + (elapsed - current.elapsedMs)
            if (serverMs <= estimate) return
        }
        anchor = Anchor(serverMs, elapsed)
    }

    /** Сброс якоря: deInit SDK (смена стенда в testapp) и тесты. */
    @JvmStatic
    fun reset() {
        anchor = null
    }

    // SimpleDateFormat не потокобезопасен — экземпляр на вызов; заголовок приходит не чаще ответа.
    internal fun parseHttpDate(value: String?): Long? {
        val text = value?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val format = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("GMT")
            isLenient = false
        }
        return try {
            format.parse(text)?.time?.takeIf { it > 0 }
        } catch (e: ParseException) {
            null
        }
    }
}
