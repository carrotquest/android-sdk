package io.carrotquest_sdk.android.lib.network.responses.bot

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData

@Keep
class ChatBotData {
    @SerializedName(F.ID)
    var id: String? = null
    @SerializedName(F.ALLOW_USER_REPLIES)
    var allow: Boolean? = null
    @SerializedName(F.START_BRUNCH)
    var startBrunch: MessageData? = null
    // Тайм-аут автозакрытия диалога ботом в секундах; null — автозакрытие выключено (CAR-77064).
    @SerializedName(F.CLOSE_DELAY)
    var closeDelay: Long? = null
}