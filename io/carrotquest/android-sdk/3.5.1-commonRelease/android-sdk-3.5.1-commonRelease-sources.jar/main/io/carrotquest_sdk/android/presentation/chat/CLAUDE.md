# Compose Chat UI (presentation/chat)

Conventions from the root `CLAUDE.md` apply (Russian internal comments, `cq_sdk_*` resources, no new deps).

Files in this directory:

| File | Responsibility |
|------|---------------|
| `ChatViewModel.kt` | State management, message mapping, bot answer tracking |
| `ChatScreen.kt` | Top-level screen composable |
| `MessageList.kt` | LazyColumn (reverseLayout=true), sticky date chip, auto-scroll |
| `MessageBubble.kt` | Incoming/outgoing bubble, sender avatar |
| `MessageAttachments.kt` | `MessageImages` (grid inside bubble), `FileCard` (standalone below bubble) |
| `BotOptionsGroupItem.kt` | Bot reply buttons with crossfade animation |
| `VoteCardItem.kt` | Conversation rating |
| `MessageMapper.kt` | MessageData → ChatListItem mapping |
| `ChatListItem.kt` | Sealed hierarchy of list items |
| `MessageContent.kt` | Sealed hierarchy of message content types |

### Key design decisions

**Bot answer state**: `localBotAnswers: mutableMapOf<String, String>()` in ViewModel
preserves optimistic UI (answered state visible immediately) until server confirms.
Merge logic: `!item.isAnswered` guard ensures server `replied=true` wins.

**Bot reply ordering**: optimistic `created` from the device clock can run ahead of the server
`created` of the next question → reply lands above it. Anchor optimistic `created` to the server
timeline and use a transient `sortKey = maxId + 1`; `MessageMapper` tie-breaks on `sortKey ?: id`.

**Auto-scroll**: `LaunchedEffect(firstItemKey)` where `firstItemKey` is the ID of the first
list item regardless of type. Always scroll for outgoing messages; proximity threshold
`firstVisibleItemIndex <= 3` for incoming/bot messages.

**Sticky date chip**: `derivedStateOf { visibleIndices }` — floating chip is hidden while
the corresponding `DateDivider` item is within the visible viewport.

**Attachment layout**:
- Images: rendered **inside** the bubble (`MessageImages`, fills bubble width); three images sit in a
  single horizontal row (no 1+2 layout)
- Files: rendered **outside/below** the bubble as standalone `FileCard` components
- `FileCard` design: rounded rect (12dp), icon in circle, filename + "EXT · size" subtitle

**AnimatedContent for bot buttons**: pass the full `item` (or at minimum `item.isAnswered`)
as `targetState`, NOT a derived Boolean. ClassCastException occurs on exit animation
when a derived value is used.
