package io.carrotquest_sdk.android.presentation.chat

/**
 * Чистая reducer-логика: накладывает оптимистичные локальные состояния (ответы боту, голос,
 * форма контактов) поверх элементов, построенных [MessageMapper], и добавляет typing-индикатор.
 *
 * Вынесено из ChatViewModel.rebuildList ради детерминированного юнит-тестирования: функция не
 * зависит от корутин/синглтонов/БД. Подтверждённые сервером оверрайды возвращаются отдельными
 * множествами — вызывающий код удаляет их из локальных map-ов (побочный эффект снаружи).
 */
internal object ChatStateReducer {

    data class OverrideResult(
        val items: List<ChatListItem>,
        // id → серверный Rated, которым нужно ЗАМЕНИТЬ локальный Loading-оверрайд (пин на сессию,
        // см. ниже). Вызывающий сохраняет это в localVoteStates, а не удаляет оверрайд.
        val voteUpgrades: Map<String, VoteState.Rated>,
        // id → состояние формы контактов, которым нужно ЗАПИНИТЬ локальный оверрайд на сессию
        // (по аналогии с voteUpgrades). Вызывающий сохраняет это в localContactStates, а не удаляет.
        val contactUpgrades: Map<String, ContactInputState>,
    )

    fun applyLocalOverrides(
        mapped: List<ChatListItem>,
        botAnswers: Map<String, String>,
        voteStates: Map<String, VoteState>,
        contactStates: Map<String, ContactInputState>,
        typing: ChatListItem.TypingIndicator?,
    ): OverrideResult {
        // Выбранная в этой сессии опция бота — применяем ВСЕГДА (даже если маппер уже пометил
        // группу isAnswered=true), иначе selectedOptionId теряется и выбранный чип исчезает.
        val withBotAnswers = if (botAnswers.isEmpty()) mapped else mapped.map { item ->
            if (item is ChatListItem.BotOptionsGroup) {
                val selectedId = botAnswers[item.messageId]
                if (selectedId != null) item.copy(isAnswered = true, selectedOptionId = selectedId) else item
            } else item
        }

        // Локальное состояние голоса. Когда сервер подтвердил Rated, пока ждали (Loading), НЕ снимаем
        // оверрайд, а ПИНим его как Rated на всю сессию (voteUpgrades). Причина: серверная копия
        // vote-сообщения нестабильна — последующий reload/WSS-обновление часто приходит БЕЗ оценки
        // (vote не персистится в читаемом messageMetaData.vote / гонка с getMessages), и если снять
        // оверрайд, карточка откатывается к выбору эмодзи (баг оценки оператора). Запиненный Rated
        // переживает такие откаты.
        //
        // Комментарий (CAR-77291) — второй шаг того же жизненного цикла: локальный CommentSending
        // пинится серверным Rated только когда тот пришёл С комментарием; Rated без комментария в этот
        // момент — устаревшее echo первого запроса, его игнорируем. Запиненный Rated без комментария
        // апгрейдится до Rated с комментарием (пришёл из БД/RTS), обратно не даунгрейдится.
        // Правило одно: сервер побеждает, только если он строго «полнее» локального состояния.
        val voteUpgrades = mutableMapOf<String, VoteState.Rated>()
        val withVoteOverrides = if (voteStates.isEmpty()) withBotAnswers else withBotAnswers.map { item ->
            if (item is ChatListItem.VoteCard) {
                val local = voteStates[item.messageId]
                val serverRated = item.voteState as? VoteState.Rated
                val serverHasComment = serverRated?.comment != null
                val pinServer = serverRated != null && when (local) {
                    is VoteState.Loading -> true
                    is VoteState.CommentSending -> serverHasComment
                    is VoteState.Rated -> local.comment == null && serverHasComment
                    else -> false
                }
                when {
                    local == null -> item
                    pinServer -> {
                        voteUpgrades[item.messageId] = serverRated!! // пин серверного Rated на сессию
                        item
                    }
                    else -> item.copy(voteState = local)
                }
            } else item
        }

        // Локальное состояние формы контактов. Когда сервер подтвердил ответ (replied=true → маппер
        // вернул Submitted), пока держали локальный Submitting, НЕ снимаем оверрайд, а ПИНим Submitted
        // на всю сессию (contactUpgrades). Причина та же, что у голоса: серверная копия нестабильна —
        // «Thank you» синтезируется на клиенте из messageMetaData.replied, а последующий
        // getMessages→setData нередко приходит БЕЗ replied (гонка с записью conversationParts / бэк
        // не эхоит флаг на этой части). Если снять оверрайд, карточка откатывается к исходному инпуту.
        val contactUpgrades = mutableMapOf<String, ContactInputState>()
        val withContactOverrides = if (contactStates.isEmpty()) withVoteOverrides else withVoteOverrides.map { item ->
            if (item is ChatListItem.Message) {
                val content = item.content as? MessageContent.ContactInputContent
                val local = contactStates[item.id]
                when {
                    local is ContactInputState.Submitting && content?.state is ContactInputState.Submitted -> {
                        contactUpgrades[item.id] = content.state // пин Submitted на сессию
                        item
                    }
                    local != null && content != null -> item.copy(content = content.copy(state = local))
                    else -> item
                }
            } else item
        }

        // Typing-индикатор всегда в начале списка (reverseLayout=true → визуально снизу).
        val withTyping = typing?.let { listOf(it) + withContactOverrides } ?: withContactOverrides
        return OverrideResult(withTyping, voteUpgrades, contactUpgrades)
    }
}
