package io.carrotquest_sdk.android.presentation.chat.input

import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState
import io.carrotquest_sdk.android.presentation.chat.ContactInputType
import io.carrotquest_sdk.android.presentation.chat.QuoteAttachment

/**
 * Декларативное состояние нижнего бара ввода — единый источник истины для [MessageInput].
 *
 * Заполняется [MessageInputViewModel]: часть полей приходит из DialogPresenter через
 * IDialogView-бридж (hint, тип ввода, видимость прикрепления и т.п.), часть — из
 * оптимистичных UI-событий (text).
 */
data class MessageInputState(
    val visible: Boolean = false,
    val enabled: Boolean = false,
    val text: String = "",
    val hint: String? = null,
    val maxLength: Int? = null,
    // Тип поля = тип клавиатуры + правило валидации. Переиспользуем тип формы контакта в теле чата
    // (бот property_field email/phone/name/custom — та же семантика). NORMAL-чат = TEXT.
    val inputType: ContactInputType = ContactInputType.TEXT,
    // Видимость кнопки прикрепления. НЕ выводится из режима: презентер прячет её и в обычном
    // режиме, когда поле непустое (показывается кнопка отправки), — поэтому это отдельное поле.
    val attachVisible: Boolean = true,
    val sendVisible: Boolean = true,
    val sendEnabled: Boolean = false,
    // null — блок префикса телефона скрыт; non-null — показан с этими флагом и кодом.
    val phonePrefix: PhonePrefixUi? = null,
    // Режим ответа боту в поле (BOT_INPUT: бот попросил телефон/email/имя/произвольный текст).
    // Ответ боту — только текст, как в вебе, где BotAnswerField ЗАМЕНЯЕТ обычный инпут целиком:
    // скрепка, микрофон и лента выбранных вложений скрыты, вложения не делают отправку доступной,
    // активная запись голоса сворачивается. Сами выбранные вложения не теряются — вернутся в
    // обычном режиме (на вебе стор вложений тоже переживает поле бота).
    val botInput: Boolean = false,
    // Seam: выбранные, но не отправленные вложения. Лента чипов и мультифайл — отдельным этапом.
    val attachments: List<PendingAttachment> = emptyList(),
    // Настройка аппа messenger_enable_audio_messages: false — записывать голосовые нельзя,
    // кнопки микрофона нет (вместо неё обычная кнопка отправки). На прослушивание уже присланных
    // голосовых не влияет — это состояние только инпута.
    val voiceAvailable: Boolean = true,
    // Голосовое сообщение (Ф2): Idle — обычный бар; Recording — идёт запись; Preview — записано,
    // ждём прослушивание/отправку/удаление. UI (бар записи/превью) рисуется по этому состоянию.
    val voiceState: VoiceState = VoiceState.Idle,
    // Блок согласия над баром (режим BOT_INPUT запроса перс. данных). null/пустой — не показывать.
    // Обязательные чекбоксы гейтят sendEnabled (см. recomputeSendEnabled).
    val consent: ConsentUiState? = null,
    // Ответ на сообщение (цитирование): чип «Ответ на сообщение» в пилюле. null — обычный ввод.
    // На sendEnabled НЕ влияет (ответ с пустым текстом всё равно нельзя отправить).
    val replyTo: ReplyPreviewUi? = null,
) {
    // Согласие позволяет отправку. Отдельно от sendEnabled: тот требует ещё и непустой
    // текст/вложения, а голосовой отправке нужен только гейт согласия.
    val consentOk: Boolean get() = consent?.allRequiredChecked ?: true
}

/**
 * Состояние записи голосового. [Recording.amplitudes] — нормализованные пики [0..1] (живая волна,
 * ограниченное окно); [Preview.waveform] — волна записанного файла (из WaveformExtractor).
 */
sealed class VoiceState {
    data object Idle : VoiceState()
    data class Recording(
        val elapsedSec: Int = 0,
        val amplitudes: List<Float> = emptyList(),
    ) : VoiceState()
    data class Preview(
        val filePath: String,
        val durationSec: Int,
        val waveform: List<Float> = emptyList(),
        val isPlaying: Boolean = false,
        // Прогресс воспроизведения [0..1] для анимации волны (как в баббле чата).
        val progress: Float = 0f,
    ) : VoiceState()
}

/** Префикс телефона (код страны) для бот-ввода типа phone. flag/code — уже форматированные строки. */
data class PhonePrefixUi(
    val flag: String,
    val code: String,
)

/**
 * Превью цитируемого сообщения для чипа «Ответ на сообщение» (CAR-75966). [snippet] — уже
 * очищенный от HTML однострочный текст; при пустом тексте показывается лейбл по [attachment].
 * По Figma миниатюры в чипе нет.
 */
data class ReplyPreviewUi(
    val messageId: String,
    val snippet: String?,
    val attachment: QuoteAttachment? = null,
)