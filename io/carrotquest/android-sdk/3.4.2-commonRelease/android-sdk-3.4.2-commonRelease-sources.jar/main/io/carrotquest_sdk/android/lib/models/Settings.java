package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class Settings {
    //VK
    @SerializedName(F.MESSENGER_ICON_VK_SHOW)
    private boolean isShowVK;
    @SerializedName(F.MESSENGER_ICON_VK_TEXT)
    private String textLinkVK;
    //Viber
    @SerializedName(F.MESSENGER_ICON_VIBER_SHOW)
    private boolean isShowViber;
    @SerializedName(F.MESSENGER_ICON_VIBER_TEXT)
    private String textLinkViber;
    //FB
    @SerializedName(F.MESSENGER_ICON_FACEBOOK_SHOW)
    private boolean isShowFB;
    @SerializedName(F.MESSENGER_ICON_FACEBOOK_TEXT)
    private String textLinkFB;
    //Telegram
    @SerializedName(F.MESSENGER_ICON_TELEGRAM_SHOW)
    private boolean isShowTelegram;
    @SerializedName(F.MESSENGER_ICON_TELEGRAM_TEXT)
    private String textLinkTelegram;
    //Instagram
    @SerializedName(F.MESSENGER_ICON_INSTAGRAM_SHOW)
    private boolean isShowInstagram;
    @SerializedName(F.MESSENGER_ICON_INSTAGRAM_TEXT)
    private String textLinkInstagram;
    //WhatsApp
    @SerializedName(F.MESSENGER_ICON_WHATSAPP_SHOW)
    private boolean isShowWhatsapp;
    @SerializedName(F.MESSENGER_ICON_WHATSAPP_TEXT)
    private String textLinkWhatsapp;

    @SerializedName(F.MESSENGER_COLLAPSED_COLOR)
    private String appColor;
    @SerializedName(F.MESSENGER_WELCOME_MESSAGE)
    private String welcomeMessage;
    @SerializedName(F.MESSENGER_AVATAR)
    private String messengerAvatar;
    @SerializedName(F.MESSENGER_SHOW_POWERED_BY)
    private boolean showPoweredBy;
    @SerializedName(F.MESSENGER_SHOW_KB_LINK_IN_WELCOME_MESSAGE)
    private boolean showKbLinkInWelcomeMessage;

    @SerializedName(F.MESSENGER_OFFLINE_MESSAGE)
    private String offlineMessage;
    @SerializedName(F.MESSENGER_ONLINE_MESSAGE)
    private String onlineMessage;
    @SerializedName(F.MESSENGER_SHOW_OFFLINE_MESSAGE)
    private boolean showOfflineMessage = true;

    @SerializedName(F.MESSENGER_THEME)
    private String theme;
    @SerializedName(F.MESSENGER_NAME)
    private String messengerName;

    @SerializedName(F.LOCALE)
    private String locale;

    @SerializedName(F.MESSENGER_PATTERN)
    private String messengerPattern;

    // Дефолт true: если апп не прислал ключ (старый бэкенд), поведение прежнее — кнопка
    // «Написать» создаёт новый диалог. Инициализатор отрабатывает, т.к. Gson создаёт объект
    // неявным no-arg конструктором (тот же приём, что у showOfflineMessage).
    @SerializedName(F.MESSENGER_ENABLE_NEW_CONVERSATION_BUTTON)
    private boolean enableNewConversationButton = true;

    // Доступность записи голосовых: false — апп выключил функционал, кнопку микрофона в инпуте
    // не показываем (прослушивание уже присланных голосовых остаётся всегда). Дефолт true —
    // прежнее поведение для бэкенда/аппа, который ключ не прислал.
    @SerializedName(F.MESSENGER_ENABLE_AUDIO_MESSAGES)
    private boolean enableAudioMessages = true;

    // Запрет писать в финально закрытый диалог (CAR-77491): true — закрытый диалог read-only,
    // вместо поля ввода плашка «Создать новый диалог». Nullable намеренно: null = бэкенд ключ не
    // прислал (старая версия) — трактуется как false, но по наличию ключа SDK понимает, что
    // бэкенд (и RTS-сервер, релиз которого идёт раньше) уже умеют канал conversation_closed.
    @SerializedName(F.MESSENGER_RESTRICT_REPLY_TO_CLOSED_CONVERSATION)
    private Boolean restrictReplyToClosedConversation = null;
    // Возможность писать оператору: false — апп скрыл кнопку «Написать» и поле ввода
    // (веб: messenger_show_write_button_and_input). Дефолт true — прежнее поведение,
    // если ключ не пришёл.
    @SerializedName(F.MESSENGER_SHOW_WRITE_BUTTON_AND_INPUT)
    private boolean showWriteButtonAndInput = true;


    public boolean isShowVK() {
        return isShowVK;
    }

    public void setShowVK(boolean showVK) {
        isShowVK = showVK;
    }

    public String getTextLinkVK() {
        return textLinkVK;
    }

    public void setTextLinkVK(String textLinkVK) {
        this.textLinkVK = textLinkVK;
    }

    public boolean isShowViber() {
        return isShowViber;
    }

    public void setShowViber(boolean showViber) {
        isShowViber = showViber;
    }

    public String getTextLinkViber() {
        return textLinkViber;
    }

    public void setTextLinkViber(String textLinkViber) {
        this.textLinkViber = textLinkViber;
    }

    public boolean isShowFB() {
        return isShowFB;
    }

    public void setShowFB(boolean showFB) {
        isShowFB = showFB;
    }

    public String getTextLinkFB() {
        return textLinkFB;
    }

    public void setTextLinkFB(String textLinkFB) {
        this.textLinkFB = textLinkFB;
    }

    public boolean isShowTelegram() {
        return isShowTelegram;
    }

    public void setShowTelegram(boolean showTelegram) {
        isShowTelegram = showTelegram;
    }

    public String getTextLinkTelegram() {
        return textLinkTelegram;
    }

    public void setTextLinkTelegram(String textLinkTelegram) {
        this.textLinkTelegram = textLinkTelegram;
    }

    public boolean isShowInstagram() {
        return isShowInstagram;
    }
    public void setShowInstagram(boolean showInstagram) {
        isShowInstagram = showInstagram;
    }
    public String getTextLinkInstagram() {
        return textLinkInstagram;
    }

    public boolean isShowWhatsapp() {
        return isShowWhatsapp;
    }
    public void setShowWhatsapp(boolean showWhatsapp) {
        isShowWhatsapp = showWhatsapp;
    }
    public String getTextLinkWhatsapp() {
        return textLinkWhatsapp;
    }

    public String getAppColor() {
        return appColor;
    }

    public void setAppColor(String appColor) {
        this.appColor = appColor;
    }

    public String getWelcomeMessage() {
        return welcomeMessage;
    }

    public void setWelcomeMessage(String welcomeMessage) {
        this.welcomeMessage = welcomeMessage;
    }

    public String getMessengerAvatar() {
        return messengerAvatar;
    }

    public void setMessengerAvatar(String messengerAvatar) {
        this.messengerAvatar = messengerAvatar;
    }

    public boolean isShowPoweredBy() {
        return showPoweredBy;
    }

    public void setShowPoweredBy(boolean showPoweredBy) {
        this.showPoweredBy = showPoweredBy;
    }

    public boolean isShowKbLinkInWelcomeMessage() {
        return showKbLinkInWelcomeMessage;
    }

    public void setShowKbLinkInWelcomeMessage(boolean showKbLinkInWelcomeMessage) {
        this.showKbLinkInWelcomeMessage = showKbLinkInWelcomeMessage;
    }

    public String getOfflineMessage() {
        return offlineMessage;
    }

    public void setOfflineMessage(String offlineMessage) {
        this.offlineMessage = offlineMessage;
    }

    public String getOnlineMessage() {
        return onlineMessage;
    }

    public void setOnlineMessage(String onlineMessage) {
        this.onlineMessage = onlineMessage;
    }

    public boolean isShowOfflineMessage() {
        return showOfflineMessage;
    }

    public void setShowOfflineMessage(boolean showOfflineMessage) {
        this.showOfflineMessage = showOfflineMessage;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getMessengerName() {
        return messengerName;
    }

    public void setMessengerName(String messengerName) {
        this.messengerName = messengerName;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getMessengerPattern() {
        return messengerPattern;
    }

    public void setMessengerPattern(String messengerPattern) {
        this.messengerPattern = messengerPattern;
    }

    public boolean isEnableNewConversationButton() {
        return enableNewConversationButton;
    }

    public void setEnableNewConversationButton(boolean enableNewConversationButton) {
        this.enableNewConversationButton = enableNewConversationButton;
    }

    public boolean isEnableAudioMessages() {
        return enableAudioMessages;
    }

    public void setEnableAudioMessages(boolean enableAudioMessages) {
        this.enableAudioMessages = enableAudioMessages;
    }

    /** Ключ messenger_restrict_reply_to_closed_conversation пришёл от бэкенда (любым значением). */
    public boolean hasRestrictReplyToClosedConversation() {
        return restrictReplyToClosedConversation != null;
    }

    /** Запрет писать в закрытый диалог; отсутствие ключа = false. */
    public boolean isRestrictReplyToClosedConversation() {
        return Boolean.TRUE.equals(restrictReplyToClosedConversation);
    }

    public void setRestrictReplyToClosedConversation(Boolean restrictReplyToClosedConversation) {
        this.restrictReplyToClosedConversation = restrictReplyToClosedConversation;
    }

    public boolean isShowWriteButtonAndInput() {
        return showWriteButtonAndInput;
    }

    public void setShowWriteButtonAndInput(boolean showWriteButtonAndInput) {
        this.showWriteButtonAndInput = showWriteButtonAndInput;
    }
}
