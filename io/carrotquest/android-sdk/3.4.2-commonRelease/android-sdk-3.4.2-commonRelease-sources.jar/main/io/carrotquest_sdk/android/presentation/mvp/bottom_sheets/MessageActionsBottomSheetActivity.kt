package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.HtmlCompat
import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.sendErrorMessages
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val ANIM_ENTER_MS = 300
private const val ANIM_EXIT_MS = 250

class MessageActionsBottomSheetActivity : AppCompatActivity() {

    companion object {
        private const val ARG_MESSAGE_ID = "message_id"
        private const val ARG_IS_ERROR = "is_error"
        private const val ARG_QUOTABLE = "quotable"

        /** Результат «Ответить»: id сообщения, на которое отвечаем (RESULT_OK + этот extra). */
        const val RESULT_REPLY_MESSAGE_ID = "reply_message_id"

        fun intentForMessage(context: Context, messageId: String, isQuotable: Boolean = false): Intent =
            Intent(context, MessageActionsBottomSheetActivity::class.java)
                .putExtra(ARG_MESSAGE_ID, messageId)
                .putExtra(ARG_QUOTABLE, isQuotable)

        fun intentForError(context: Context, messageId: String): Intent =
            Intent(context, MessageActionsBottomSheetActivity::class.java)
                .putExtra(ARG_MESSAGE_ID, messageId)
                .putExtra(ARG_IS_ERROR, true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0) // анимацию окна отключаем — делаем сами в Compose

        val messageId = intent.getStringExtra(ARG_MESSAGE_ID) ?: ""
        val isError = intent.getBooleanExtra(ARG_IS_ERROR, false)
        val isQuotable = intent.getBooleanExtra(ARG_QUOTABLE, false)
        val isDark = getThemeUseCase(this) == ThemeSdk.DARK
        // «Копировать» есть смысл показывать только при непустом тексте: у сообщений из одних
        // файлов/картинок шторка состоит из «Ответить» (тот же резолв текста, что в onClick копии).
        // У статьи body — это её ID (не текст) — копировать нечего.
        val message = MessagesRepository.getInstance().findMessageById(messageId)
        val hasCopyableText = message?.type != ResponseFields.ARTICLE &&
            !(message?.messageMetaData?.answerBody?.takeIf { it.isNotBlank() }
                ?: message?.body).isNullOrBlank()

        setContent {
            MessageActionsSheet(
                messageId = messageId,
                isError = isError,
                isQuotable = isQuotable,
                showCopy = isError || hasCopyableText,
                isDark = isDark,
                onReply = {
                    setResult(RESULT_OK, Intent().putExtra(RESULT_REPLY_MESSAGE_ID, messageId))
                },
                onFinish = { finish() }
            )
        }
    }

    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}

@Composable
private fun MessageActionsSheet(
    messageId: String,
    isError: Boolean,
    isQuotable: Boolean,
    showCopy: Boolean,
    isDark: Boolean,
    onReply: () -> Unit,
    onFinish: () -> Unit
) {
    val context = LocalContext.current
    val surfaceColor = SdkColors.pageBackground(isDark)
    val textColor = SdkColors.title(isDark)
    val scope = rememberCoroutineScope()

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    val dismiss: () -> Unit = {
        scope.launch {
            visible = false
            delay(ANIM_EXIT_MS.toLong())
            onFinish()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Скрим — только fade, без слайда
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(ANIM_ENTER_MS)),
            exit = fadeOut(tween(ANIM_EXIT_MS))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SdkColors.scrim)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = dismiss
                    )
            )
        }

        // Шторка — слайд снизу вверх
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically(tween(ANIM_ENTER_MS, easing = FastOutSlowInEasing)) { it } +
                    fadeIn(tween(ANIM_ENTER_MS)),
            exit = slideOutVertically(tween(ANIM_EXIT_MS, easing = FastOutSlowInEasing)) { it } +
                    fadeOut(tween(ANIM_EXIT_MS)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(surfaceColor)
                    .navigationBarsPadding()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                // Drag handle
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(top = 12.dp, bottom = 4.dp)
                        .size(32.dp, 4.dp)
                        .clip(CircleShape)
                        .background(textColor.copy(alpha = 0.18f))
                )

                Spacer(modifier = Modifier.height(8.dp))

                // «Ответить» — только для quotable-сообщений (тип из белого списка бэкенда,
                // не удалено, серверный id). Сам ответ строит DialogFragment по результату.
                if (isQuotable) {
                    SheetAction(
                        iconRes = R.drawable.cq_ic_reply,
                        label = stringResource(R.string.cq_reply_action),
                        textColor = textColor,
                        iconTint = textColor,
                        onClick = {
                            onReply()
                            dismiss()
                        }
                    )
                }

                if (isError) {
                    SheetAction(
                        iconRes = R.drawable.ic_cq_refresh,
                        label = stringResource(R.string.repeat),
                        textColor = textColor,
                        iconTint = textColor,
                        onClick = {
                            val message = MessagesRepository.getInstance().findMessageById(messageId)
                            if (message != null) {
                                // Переотправка упавшего сообщения; статус обновится реактивно
                                // через MessagesRepository → ChatViewModel.
                                sendErrorMessages(listOf(message))
                            } else {
                                Toast.makeText(context, R.string.cq_lib_something_wrong, Toast.LENGTH_SHORT).show()
                            }
                            dismiss()
                        }
                    )
                }

                if (showCopy) SheetAction(
                    iconRes = R.drawable.ic_cq_content_copy_gray_24dp,
                    label = stringResource(R.string.copy_text_message),
                    textColor = textColor,
                    iconTint = textColor,
                    onClick = {
                        val message = MessagesRepository.getInstance().findMessageById(messageId)
                        // Текст для копирования резолвим так же, как MessageMapper рисует бабл:
                        // у ответа боту (chat_bot_user) текст лежит в answerBody, а body пустой,
                        // поэтому раньше такие сообщения не копировались. Для остальных типов
                        // answerBody == null и используется body.
                        val rawBody = message?.messageMetaData?.answerBody?.takeIf { it.isNotBlank() }
                            ?: message?.body
                        if (rawBody != null) {
                            // Приводим к тому же виду, что пользователь видит на экране:
                            // 1) :shortcode: → Unicode-эмодзи
                            // 2) HTML-теги → plain text (как в toAnnotatedHtml)
                            val plainText = HtmlCompat
                                .fromHtml(EmojiParser.parseToUnicode(rawBody), HtmlCompat.FROM_HTML_MODE_COMPACT)
                                .toString().trimEnd()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText(plainText, plainText))
                        } else {
                            Toast.makeText(context, R.string.copy_text_error_message, Toast.LENGTH_SHORT).show()
                        }
                        dismiss()
                    }
                )

                if (isError) {
                    SheetAction(
                        iconRes = R.drawable.ic_cq_delete_red_24dp,
                        label = stringResource(R.string.delete_message),
                        textColor = SdkColors.unreadBadge,
                        iconTint = SdkColors.unreadBadge,
                        onClick = {
                            val message = MessagesRepository.getInstance().findMessageById(messageId)
                            if (message != null) {
                                MessagesRepository.getInstance().removeMessage(message)
                            } else {
                                Toast.makeText(context, R.string.delete_message_error_message, Toast.LENGTH_SHORT).show()
                            }
                            dismiss()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun SheetAction(
    iconRes: Int,
    label: String,
    textColor: Color,
    iconTint: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            color = textColor,
            fontSize = 16.sp
        )
    }
}
