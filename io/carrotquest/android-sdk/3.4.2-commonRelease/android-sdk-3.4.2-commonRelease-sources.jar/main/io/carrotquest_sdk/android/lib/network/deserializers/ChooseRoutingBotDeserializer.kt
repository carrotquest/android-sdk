package io.carrotquest_sdk.android.lib.network.deserializers

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.JsonParseException
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.bot.ChatBotData
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil
import java.lang.reflect.Type
import io.carrotquest_sdk.android.lib.network.responses.utils.parseMessageActions

private const val TAG = "ChRoutBotDeserializer"
class ChooseRoutingBotDeserializer : JsonDeserializer<ChooseRoutingBotResponse> {

    override fun deserialize(
        json: JsonElement,
        typeOfT: Type?,
        context: JsonDeserializationContext?
    ): ChooseRoutingBotResponse {
        val response = ChooseRoutingBotResponse()

        if (!(GsonUtil.jsonElementNotNull(json.asJsonObject, F.META) && GsonUtil.jsonElementNotNull(
                json.asJsonObject,
                F.DATA
            ))
        ) {
            throw JsonParseException("meta is null or dataJsonElement is null")
        }

        val metaJsonElement = json.asJsonObject[F.META]
        val dataJsonElement = json.asJsonObject[F.DATA]

        if (metaJsonElement == null || dataJsonElement == null) {
            throw JsonParseException("(metaJsonElement == null) = ${metaJsonElement == null}; (dataJsonElement == null) = ${dataJsonElement == null}")
        }

        try {
            val meta = Gson().fromJson(metaJsonElement, Meta::class.java)
            val data = ChooseRoutingBotData()

            data.found = dataJsonElement.asJsonObject[F.FOUND].asBoolean
            data.sender =
                Gson().fromJson(dataJsonElement.asJsonObject[F.MESSAGE_SENDER], Admin::class.java)
            val botJson = dataJsonElement.asJsonObject[F.CHAT_BOT]
            data.bot = Gson().fromJson(botJson, ChatBotData::class.java)
            // actions стартовой ветки — тем же парсером, что у истории и WSS (parseMessageActions):
            // голый Gson ждёт placeholder на верхнем уровне экшена, а бэкенд кладёт его в
            // body_json.placeholder — у первой ветки с полем ввода терялся кастомный плейсхолдер
            // («Введите ответ»), и поле показывало общий хинт. Заодно проставляется messageId.
            if (botJson != null && botJson.isJsonObject) {
                val startBranchJson = botJson.asJsonObject[F.START_BRUNCH]
                val startBrunch = data.bot?.startBrunch
                if (startBrunch != null && startBranchJson != null && startBranchJson.isJsonObject) {
                    startBrunch.actions = parseMessageActions(startBranchJson.asJsonObject, startBrunch.id)
                }
            }

            response.meta = meta
            response.data = data
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
            return Gson().fromJson(json, ChooseRoutingBotResponse::class.java)
        }

        return response
    }
}