package io.carrotquest_sdk.android.core.util.files.download_files;

import android.os.Environment;
import androidx.annotation.NonNull;
import android.util.Pair;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.files.SavedFile;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

public class DownloadUtil {
    private static final String TAG = "DownloadUtil";
    public static final String BASE_URL = BuildConfig.BASE_FILES_URL;

    public static Observable<File> downloadFile(String messageId, String attachmentId, String url, long size) {
        String fileName = url.substring(url.lastIndexOf('/') + 1);
        fileName = getFreeName(fileName);
        File outputFile = new File(getDownloadDirectory(), fileName);
        
        DownloadProgressListener listener = (bytesRead, done) -> { };
        DownloadAPI api = new DownloadAPI(BASE_URL, listener);

        return api.downloadFile(url, outputFile).map(s -> outputFile);
    }

    static DisposableObserver<InputStream> download(String messageId, String url, long size, Observer<Integer> processObserver) {
        String fileName = url.substring(url.lastIndexOf('/') + 1);
        fileName = getFreeName(fileName);

        File outputFile = new File(getDownloadDirectory(), fileName);

        DownloadProgressListener listener = (bytesRead, done) -> {
            int progress = (int) ((bytesRead * 100) / size);
            if (progress > 100) progress = 100;
            if (progress < 0) progress = 0;

            processObserver.onNext(progress);
        };

        DownloadAPI api = new DownloadAPI(BASE_URL, listener);
        return api.downloadFile(url, outputFile, processObserver);
    }

    public static Observable<Pair<String, String>> downloadFilesToCash(ArrayList<String> urls, String baseUrl) {
        Observable<Pair<String, String>> res = Observable.empty();

        DownloadAPI api = new DownloadAPI(baseUrl);
        for (String url : urls) {
            if (url != null && !url.isEmpty()) {
                String fileNameUrl = url.substring(baseUrl.length());
                String fileName = fileNameUrl.substring(fileNameUrl.lastIndexOf('/') + 1);
                
                File folder = new File(CarrotInternal.getLibComponent().getContextSdk().getExternalFilesDir(null), "cq_sdk_cache");

                if (!folder.exists() && !folder.mkdirs()) {
                    Log.e(TAG, "Failed to create directory: " + folder.getAbsolutePath());
                    continue;
                }

                fileName = getFreeName(folder, fileName);
                File outputFile = new File(folder, fileName);
                
                try {
                    if (outputFile.createNewFile()) {
                        res = res.mergeWith(
                                api.downloadFile(url, outputFile)
                                        .doOnError(throwable -> Log.e(TAG, throwable.toString()))
                                        .map(s -> new Pair<>(url, s))
                        );
                    }
                } catch (IOException e) {
                    Log.e(TAG, e);
                }
            }
        }

        return res;
    }

    static void cancelDownload(Disposable observer) {
        if (observer != null && !observer.isDisposed()) {
            observer.dispose();
        }
    }

    private static File getDownloadDirectory() {
        File dir = CarrotInternal.getLibComponent().getContextSdk().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) {
            dir = new File(CarrotInternal.getLibComponent().getContextSdk().getFilesDir(), Environment.DIRECTORY_DOWNLOADS);
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    public static String getFreeName(String fileName) {
        return getFreeName(getDownloadDirectory(), fileName);
    }

    public static String getFreeName(File directory, String fileName) {
        File file = new File(directory, fileName);
        if (!file.exists()) {
            return fileName;
        }

        String[] parts = stripExtension(fileName);
        String name = parts[0];
        String ext = parts[1];

        int suffix = 1;
        while (new File(directory, name + " (" + suffix + ")" + ext).exists()) {
            suffix++;
        }
        return name + " (" + suffix + ")" + ext;
    }

    private static String[] stripExtension(String str) {
        if (str == null) return new String[]{"", ""};
        int pos = str.lastIndexOf(".");
        if (pos == -1) return new String[]{str, ""};
        return new String[]{str.substring(0, pos), str.substring(pos)};
    }

    private static class DownloadAPI {
        private static final String TAG = "DownloadAPI";
        private static final int DEFAULT_TIMEOUT = 15;
        private final Retrofit retrofit;

        DownloadAPI(String baseUrl, DownloadProgressListener listener) {
            DownloadProgressInterceptor interceptor = new DownloadProgressInterceptor(listener);
            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(interceptor)
                    .retryOnConnectionFailure(true)
                    .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(client)
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()))
                    .build();
        }

        DownloadAPI(String baseUrl) {
            OkHttpClient client = new OkHttpClient.Builder()
                    .retryOnConnectionFailure(true)
                    .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(client)
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()))
                    .build();
        }

        DisposableObserver<InputStream> downloadFile(@NonNull String url, final File file, Observer<Integer> processObserver) {
            return retrofit.create(DownloadService.class)
                    .download(url)
                    .subscribeOn(Schedulers.io())
                    .map(ResponseBody::byteStream)
                    .observeOn(Schedulers.computation())
                    .doOnNext(stream -> saveFile(stream, file))
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnComplete(() -> {
                        CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
                        SavedFile savedFile = new SavedFile(String.valueOf(System.currentTimeMillis()));
                        savedFile.localUri = file.getAbsolutePath();
                        savedFile.url = url;
                        db.savedFileDao().insert(savedFile);
                    })
                    .doOnDispose(() -> {
                        processObserver.onError(new Exception("Cancel"));
                        if (file.exists()) file.delete();
                        cleanUpDatabase(url);
                    })
                    .subscribeWith(new DisposableObserver<InputStream>() {
                        @Override public void onNext(InputStream inputStream) {}
                        @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); }
                        @Override public void onComplete() {}
                    });
        }

        Observable<String> downloadFile(@NonNull String url, final File file) {
            return retrofit.create(DownloadService.class)
                    .download(url)
                    .subscribeOn(Schedulers.io())
                    .map(ResponseBody::byteStream)
                    .observeOn(Schedulers.computation())
                    .doOnNext(stream -> saveFile(stream, file))
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnDispose(() -> {
                        if (file.exists()) {
                            file.delete();
                        }
                        cleanUpDatabase(url);
                    })
                    .map(inputStream -> file.getAbsolutePath());
        }

        private void cleanUpDatabase(String url) {
            CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
            SavedFile savedFile = db.savedFileDao().getByURL(BASE_URL + url);
            if (savedFile != null) {
                db.savedFileDao().delete(savedFile.url);
            }
        }

        private void saveFile(InputStream stream, File file) {
            try {
                File parent = file.getParentFile();
                if (parent != null && !parent.exists()) {
                    parent.mkdirs();
                }
                
                if (!file.exists() && !file.createNewFile()) {
                    Log.e(TAG, "File not saved: " + file.getAbsolutePath());
                    return;
                }

                try (OutputStream output = new FileOutputStream(file)) {
                    byte[] buffer = new byte[8 * 1024];
                    int read;
                    while ((read = stream.read(buffer)) != -1) {
                        output.write(buffer, 0, read);
                    }
                    output.flush();
                } finally {
                    stream.close();
                }
            } catch (IOException e) {
                Log.e(TAG, e);
            }
        }
    }

    public static MessagesResponse replaceFilesLocalUrl(MessagesResponse response) {
        if (response == null || response.getData() == null) return response;

        CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
        for (int i = 0; i < response.getData().size(); i++) {
            if (response.getData().get(i).getAttachments() == null) continue;

            for (int j = 0; j < response.getData().get(i).getAttachments().size(); j++) {
                String url = response.getData().get(i).getAttachments().get(j).getUrl();
                SavedFile savedFile = db.savedFileDao().getByURL(url);

                if (savedFile != null && new File(savedFile.localUri).exists() && 
                    !response.getData().get(i).getAttachments().get(j).getMimeType().contains("image")) {
                    
                    response.getData().get(i).getAttachments().get(j).setUrl(savedFile.localUri);
                    response.getData().get(i).getAttachments().get(j).setType("loaded");
                    response.getData().get(i).getAttachments().get(j).setStatus("loaded");

                    response = replaceFileLocalUrlInSource(response, savedFile);
                }
            }
        }
        return response;
    }

    public static MessagesResponse replaceFileLocalUrlInSource(MessagesResponse response, SavedFile savedFile) {
        if (response == null || response.getSourceData() == null || !response.getSourceData().isJsonArray()) {
            return response;
        }

        JsonArray jsonArray = response.getSourceData().getAsJsonArray();
        for (JsonElement jsonMessage : jsonArray) {
            if (jsonMessage.isJsonObject()) {
                JsonElement attachments = jsonMessage.getAsJsonObject().get(F.ATTACHMENTS);
                if (attachments != null && attachments.isJsonArray()) {
                    for (JsonElement attachment : attachments.getAsJsonArray()) {
                        if (attachment.isJsonObject() && attachment.getAsJsonObject().has(F.URL) &&
                            savedFile.url.equals(attachment.getAsJsonObject().get(F.URL).getAsString())) {

                            attachment.getAsJsonObject().addProperty(F.URL, savedFile.localUri);
                            attachment.getAsJsonObject().addProperty(F.TYPE, "loaded");
                            attachment.getAsJsonObject().addProperty(F.STATUS, "loaded");
                        }
                    }
                }
            }
        }
        return response;
    }
}
