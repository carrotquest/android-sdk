package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.managers.UserPresenceService
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.lib.wss.Channel
import io.carrotquest_sdk.android.lib.wss.IWssService
import io.carrotquest_sdk.android.lib.wss.response.WssResponse
import io.carrotquest_sdk.android.lib.wss.utils.CloseReason
import io.reactivex.Observer
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

private const val tag = "JwtWssService"
class JwtWssService(private val context: Context, private val rtsHost: String): IWssService {
    private val backgroundManager = BackgroundManager.getInstance()
    private val networkManager = NetworkManager.getInstance(context)
    private val compositeDisposable = CompositeDisposable()

    private val sockets = ArrayList<JwtClientWebSocket>()

    init {
        backgroundManager.addObserver({
            run {
                changeStateSockets()
            }
        }, { t -> Log.e(tag, t) }, {})

        networkManager.addObserver({
            run {
                changeStateSockets()
            }
        }, { t -> Log.e(tag, t) }, {})

        // Подписываемся на обновление JWT токена.
        // Когда токен обновляется (обычно каждые 30 минут), нам нужно
        // переподключить сокеты, так как старое соединение авторизовано старым токеном.
        compositeDisposable.add(
            JwtTokenRefreshService.getInstance().updateJwtTokenObservable
                .subscribeOn(Schedulers.io())
                .subscribe({
                    Log.d(tag, "JWT updated, reconnecting sockets...")
                    reconnectSockets()
                }, { t ->
                    Log.e(tag, "JWT update observer error: $t")
                })
        )
    }

    override fun startSocket(
        appId: String?,
        channels: MutableList<Channel>?,
        observers: MutableList<Observer<WssResponse>>?
    ) {
        if (appId != null && !channels.isNullOrEmpty() && observers != null) {
            //connect
            val clientWebSocket = JwtClientWebSocket(
                appId,
                ArrayList(channels.toList()),
                rtsHost,
                observers
            )
            clientWebSocket.connect()
            sockets.add(clientWebSocket)
        }
    }

    override fun stopSocket(appId: String?) {
        val filteredSockets = sockets.filter { s -> s.getAppId() == appId }

        if (filteredSockets.isNotEmpty()) {
            filteredSockets.forEach { s ->
                s.stop(reason = CloseReason.NONE)
            }
            //?
            sockets.removeAll(filteredSockets.toSet())
        }
    }

    override fun deInit() {
        compositeDisposable.clear()
        for (socket in sockets) {
            socket.stop(reason = CloseReason.DEINIT)
        }

        NetworkManager.getInstance(context).deInit()
        BackgroundManager.getInstance().deInit()
    }

    private fun reconnectSockets() {
        val hasInternetConnect = networkManager.hasConnect
        val isForeground = backgroundManager.lastStateIsForeground()

        if (hasInternetConnect && isForeground) {
            sockets.forEach { s ->
                // Принудительно закрываем и открываем заново,
                // чтобы JwtClientWebSocket.connect() подхватил новый токен из репозитория.
                s.stop(reason = CloseReason.NONE)
                s.connect()
            }
        }
    }

    private fun changeStateSockets() {
        val hasInternetConnect = networkManager.hasConnect
        val isForeground = backgroundManager.lastStateIsForeground()
        if(hasInternetConnect && isForeground) {
            sockets.forEach { s ->
                if(!s.isConnected()) {
                    s.connect()
                }
            }
            UserPresenceService.getInstance().run()
        } else {
            val closeReason = if(!isForeground) CloseReason.APP_TO_BACKGROUND else CloseReason.INTERNET_DISAPPEARED
            sockets.forEach { s ->
                if(s.isConnected()) {
                    s.stop(reason = closeReason)
                }
            }
            UserPresenceService.getInstance().stop()
        }
    }
}
