package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.repositories.IUserRepository
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlocking
import okhttp3.Interceptor
import okhttp3.Response

internal class TokenRefreshInterceptor(
    private val userRepository: IUserRepository
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())

        if (response.code != 401 || chain.request().url.toString().contains("refresh")) {
            return response
        }

        response.close()

        val oldToken = chain.request().url.queryParameter(F.AUTH_TOKEN)
        val newToken = refreshJwtTokenBlocking(oldToken)
        if (newToken == null) {
            // Refresh провален — refresh-токен мёртв. Сигналим клиенту, что сессия истекла,
            // возвращаем оригинальный 401 (без бесконечных retry).
            SdkStateManager.notifySessionExpired()
            return chain.proceed(chain.request())
        }

        userRepository.getUser()?.let { user ->
            user.token = newToken
            userRepository.saveUser(user)
        }

        val newUrl = chain.request().url.newBuilder()
            .setQueryParameter(F.AUTH_TOKEN, newToken)
            .build()
        return chain.proceed(chain.request().newBuilder().url(newUrl).build())
    }
}
