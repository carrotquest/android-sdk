package io.carrotquest_sdk.android.domain.use_cases.popup

import com.google.gson.GsonBuilder
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.PopUpDeserializer
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.markConversationAsReadById
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.presentation.container.SdkContainerActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper
import io.carrotquest_sdk.android.presentation.mvp.popup.view.IPopUp
import io.carrotquest_sdk.android.presentation.mvp.popup.view.PopupAlertDialog
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.disposables.Disposable


private var loadingDisposable: Disposable? = null

fun Observable<PopUpMessageEntity?>.showPopup() : Observable<PopUpMessageEntity> {
    return Observable.defer {
        this.flatMap {
            val loadWebViewObserver = getLoadWebViewObserver(it)
            loadingDisposable = SdkApp.getInstance().subscribeOnCurrentActivity({ activity ->
                if (activity is IPopUp) {
                    activity.setLoadWebViewObserver(loadWebViewObserver)
                }
            }, { t ->
                run {
                    Log.e("POPUP", "Error: $t")
                }
            })

            val currentActivity = SdkApp.getInstance().currentActivity
            currentActivity?.runOnUiThread {
                if (currentActivity !is DialogActivity
                    && currentActivity !is SdkContainerActivity
                    && !PopupAlertDialog.isShowing()
                ) {

                    val builder = PopupAlertDialog(currentActivity, R.style.popUpStyle)
                    val x = builder.show()
                    x.show()
                    builder.setData(it.id, it.sourceBodyJson, it.backgroundColor)

                    val id = it.id
                    PushNotificationHelper.getInstance().clearNotifications(id)

                    Observable.just(it.id)
                        .markConversationAsReadById()
                        .take(1)
                        .subscribe({ conversationId ->
                            SdkApp
                                .getInstance()
                                .database
                                .popUpDao()
                                .deleteById(conversationId)
                        }, { t ->
                            Log.e("showPopup().markConversationAsReadById()", t)
                        })
                } else {
                    //create and save conversation with popup
                    Observable.just(true)
                        .getConversation(it.id)
                        .subscribe({ conversationOptional ->
                            if (conversationOptional.value != null) {
                                ConversationsRepository.getInstance()
                                    .updateInfoAboutConversation(conversationOptional.value)
                                Log.d("", "")
                            }
                        }, {})
                }
            }
            return@flatMap Observable.just(it)
        }
    }
}

fun Observable<String>.showPopupByConversationId() : Observable<PopUpMessageEntity> {
    return Observable.defer {
        this.flatMap {conversationId->
            Observable.just(conversationId)
                .loadConversation()
                .map {
                    return@map getPopUpMessage(it)
                }
                .showPopup()

        }
    }
}

private fun getLoadWebViewObserver(popUpMessageEntity: PopUpMessageEntity): Observer<Boolean> = object : Observer<Boolean> {
    override fun onComplete() {

    }

    override fun onSubscribe(d: Disposable) {

    }

    override fun onNext(isShowed: Boolean) {
        Observable.just(popUpMessageEntity)
            .saveState(isShowed)
            .take(1)
            .doOnNext {
                dispose()
            }
            .doOnError { t ->
                dispose()
                Log.e("showPopup()/getLoadWebViewObserver()", t)
            }
            .subscribe()
    }

    override fun onError(e: Throwable) {

    }

    private fun dispose() {
        if (loadingDisposable != null && !(loadingDisposable?.isDisposed!!)) {
            loadingDisposable?.dispose()
        }
    }
}

private fun getPopUpMessage(conversation: DataConversation) : PopUpMessageEntity?{
    val messageData = conversation.partLast
    val jsonBody = messageData?.bodyJson?.asJsonObject
    if (jsonBody != null && conversation.id != null) {
        jsonBody.addProperty("id", conversation.id)
        jsonBody.addProperty("expiration_time", conversation.expirationTime)
        val gson = GsonBuilder()
            .registerTypeAdapter(PopUpMessage::class.java, PopUpDeserializer())
            .create()
        val p = gson.fromJson(jsonBody, PopUpMessage::class.java)

        return PopUpMessageEntity(
            id = p.id,
            sourceBodyJson = p.sourceJson,
            expirationTime = p.expirationTime,
            backgroundColor = p.backgroundColor
        )
    }

    return null
}