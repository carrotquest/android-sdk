package io.carrotquest_sdk.android.core.init

import android.content.Context
import android.content.IntentFilter
import android.os.Build
import android.text.TextUtils
import androidx.core.content.ContextCompat
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.connection.ConnectionManager
import io.carrotquest_sdk.android.core.connection.WssManager
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.utm.UtmUtil
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.data.settings.SettingsManager
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.findLastUnreadPopup
import io.carrotquest_sdk.android.domain.use_cases.popup.saveNewPopUp
import io.carrotquest_sdk.android.domain.use_cases.rts.saveRtsHost
import io.carrotquest_sdk.android.domain.use_cases.triggers.LoadTriggersUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.loadUserProps
import io.carrotquest_sdk.android.domain.use_cases.user.saveConnectedUserIdUseCase
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.utils.isFreedom
import io.carrotquest_sdk.android.lib.utils.saveDashlyTokenFlag
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushTapReceiver
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.observers.DisposableObserver
import io.reactivex.schedulers.Schedulers
import okhttp3.ResponseBody
import retrofit2.HttpException
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

internal object InitCoordinator {

    private const val TAG = "InitCoordinator"
    private const val INIT_TIMEOUT_SECONDS = 30L
    private const val MAX_INIT_RETRIES = 2
    private const val INITIAL_RETRY_DELAY_MS = 1_000L

    /**
     * Транзиентными считаем ошибки сети, timeout и 5xx/408 от сервера.
     * Всё остальное (4xx, IllegalArgumentException и т.д.) — ретраить бесполезно.
     */
    private fun isTransientError(e: Throwable): Boolean = when (e) {
        is IOException -> true
        is TimeoutException -> true
        is HttpException -> e.code() == 408 || e.code() in 500..599
        else -> false
    }

    /**
     * Все fire-and-forget подписки, запущенные во время init (popups, triggers, loadUserProps).
     * При deInit во время init все они отменяются через [abort].
     */
    private val disposables = CompositeDisposable()

    /**
     * Отменяет все активные init-подписки. Вызывать при deInit, чтобы fire-and-forget
     * задачи из doOnNext не продолжили выполняться на фоне уже "мёртвого" SDK.
     */
    fun abort() {
        disposables.clear()
    }

    fun connect(
        appId: String,
        apiKey: String,
        carrotLib: CarrotLib,
        userRepository: UserRepository,
        startSession: Boolean,
        callback: CarrotSDK.Callback<Boolean>?,
        onPushInit: Runnable,
        onRefreshTokenService: Runnable
    ): Disposable? {
        if (!SdkStateManager.onInitStarted()) {
            callback?.onResponse(true)
            return null
        }

        val referrer = try {
            UtmUtil.getReferrer(CarrotLib.getLibComponents().context)
        } catch (e: Exception) {
            Log.e(TAG, e)
            ""
        }

        // TODO FREEDOM удалить потом
        io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib.saveString(
            CarrotInternal.getLibComponent().contextSdk,
            "X_APP_ID_KEY",
            appId
        )

        val sdkVersion = CarrotSDK.getVersion() ?: ""

        return try {
            val context = CarrotInternal.getLibComponent().contextSdk
            val connectObservable = ConnectionManager.connect(
                apiKey, appId, sdkVersion, referrer, startSession, context, carrotLib, userRepository
            )

            val disposable = connectObservable
                .subscribeOn(Schedulers.io())
                .timeout(INIT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .retryWhen { errors ->
                    errors.zipWith(
                        Observable.range(1, MAX_INIT_RETRIES + 1),
                        BiFunction<Throwable, Int, Pair<Throwable, Int>> { err, attempt -> err to attempt }
                    ).flatMap { (err, attempt) ->
                        if (attempt > MAX_INIT_RETRIES || !isTransientError(err)) {
                            Observable.error<Long>(err)
                        } else {
                            val delayMs = INITIAL_RETRY_DELAY_MS shl (attempt - 1)
                            Log.d(TAG, "init retry #$attempt after ${delayMs}ms, cause=$err")
                            Observable.timer(delayMs, TimeUnit.MILLISECONDS)
                        }
                    }
                }
                .observeOn(AndroidSchedulers.mainThread())
                .filter { response ->
                    (response.data != null && response.data.app != null && !response.data.app.isBlocked)
                            || (response.meta.status != 200)
                }
                .doOnNext { response ->
                    val ctx = CarrotInternal.getLibComponent().contextSdk

                    SettingsManager.applyFromConnectResponse(response, ctx)

                    val user = response.data.user
                    saveConnectedUserIdUseCase(user.id, ctx)

                    val userEntity = UserEntity(
                        user.id, user.token, user.hasConversations,
                        user.isBanned, user.conversationsUnread
                    )

                    val hosts = response.data.realtimeServices.hosts
                    if (hosts.isNotEmpty()) {
                        for ((_, rtsHost) in hosts) {
                            if (rtsHost.isNotEmpty()) {
                                saveRtsHost(ctx, rtsHost)
                                break
                            }
                        }
                    }

                    disposables.add(downloadPopUps(userEntity))

                    io.carrotquest_sdk.android.data.repositories.UserRepository
                        .getInstance().saveUser(userEntity)
                    UtmUtil.sendSavedUtm(CarrotLib.getLibComponents().context)

                    // TODO FREEDOM удалить потом
                    if (isFreedom(appId)) {
                        saveDashlyTokenFlag()
                    }

                    disposables.add(loadTriggers())
                }
                .doOnError { t ->
                    Log.d(TAG, t.toString())
                    callback?.onFailure(t)
                }
                .subscribeWith(
                    createInitObserver(
                        appId, userRepository, callback,
                        needWssConnect = true, onPushInit, onRefreshTokenService
                    )
                )

            disposables.add(disposable)

            @Suppress("UNUSED_EXPRESSION")
            carrotLib.wssService

            initBroadcast(CarrotLib.getLibComponents().context)

            disposable
        } catch (e: Exception) {
            Log.e(TAG, "connectObservable getStackTrace: ${e.stackTrace.contentToString()}")
            null
        }
    }

    private fun loadTriggers(): Disposable =
        LoadTriggersUseCase().call()
            .take(1)
            .subscribeOn(Schedulers.io())
            .subscribe({}, { t -> Log.e(TAG, t.toString()) })

    private fun initBroadcast(context: Context) {
        val receiver = PushTapReceiver()
        val filter = IntentFilter("carrotquest.sdk.tap.push")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        }
    }

    private fun downloadPopUps(userEntity: UserEntity): Disposable =
        Observable.just(userEntity).findLastUnreadPopup()
            .take(1)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .delay(2, TimeUnit.SECONDS)
            .onErrorReturnItem(emptyList())
            .subscribe(
                { popUpsList ->
                    popUpsList?.forEach { p: PopUpMessage ->
                        disposables.add(
                            Observable.just(p).saveNewPopUp()
                                .take(1)
                                .subscribe({}, { t -> Log.e(TAG, t.toString()) })
                        )
                    }
                },
                { throwable -> Log.e(TAG, throwable.toString()) }
            )

    private fun createInitObserver(
        appId: String,
        userRepository: UserRepository,
        callback: CarrotSDK.Callback<Boolean>?,
        needWssConnect: Boolean,
        onPushInit: Runnable,
        onRefreshTokenService: Runnable
    ): DisposableObserver<ConnectResponse> = object : DisposableObserver<ConnectResponse>() {

        override fun onNext(connectResponse: ConnectResponse) {
            if (SdkStateManager.isInit()) return
            try {
                try {
                    userRepository.saveUser(connectResponse.data.user)
                } catch (e: Exception) {
                    Log.d("saveUserTag", "error: $e")
                }
                onPushInit.run()
                initComplete(appId, connectResponse, userRepository, needWssConnect, onRefreshTokenService)
                try {
                    callback?.onResponse(TextUtils.isEmpty(connectResponse.meta.error))
                    return
                } catch (e: Exception) {
                    Log.e(TAG, e)
                    return
                }
            } catch (e: Exception) {
                initError(e)
                return
            }
        }

        override fun onError(e: Throwable) {
            initError(e)
            callback?.onFailure(e)
        }

        override fun onComplete() {
            SdkStateManager.onInitAborted()
        }
    }

    private fun initComplete(
        appId: String,
        connectResponse: ConnectResponse,
        userRepository: UserRepository,
        needWssConnect: Boolean,
        onRefreshTokenService: Runnable
    ) {
        userRepository.saveUser(connectResponse.data.user)
        SdkStateManager.onReady()

        onRefreshTokenService.run()
        if (needWssConnect) {
            WssManager.start(appId, connectResponse.data.user.id)
        }

        disposables.add(
            Observable.just(true).loadUserProps(connectResponse.data.user.id)
                .take(1)
                .subscribe({}, { t -> Log.e(TAG, t.toString()) })
        )
    }

    private fun initError(e: Throwable) {
        SdkStateManager.onFailed(e)
        Log.e(TAG, e)
        if (e is HttpException) {
            val responseBody: ResponseBody? = e.response()?.errorBody()
            try {
                if (responseBody != null) {
                    try {
                        Log.e(TAG, responseBody.string())
                    } catch (ioException: IOException) {
                        Log.e(TAG, responseBody.toString())
                    }
                }
            } catch (e1: Exception) {
                Log.e(TAG, e1)
            }
        }
    }
}
