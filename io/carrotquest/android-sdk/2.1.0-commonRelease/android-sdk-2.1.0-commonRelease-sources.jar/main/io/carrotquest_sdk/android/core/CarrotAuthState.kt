package io.carrotquest_sdk.android.core

sealed class CarrotAuthState {
    object Idle : CarrotAuthState()
    object Authenticating : CarrotAuthState()
    data class Authenticated(val userId: String) : CarrotAuthState()
    data class Failed(val error: Throwable) : CarrotAuthState()
}
