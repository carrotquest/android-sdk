package io.carrotquest_sdk.android.core.auth

import io.carrotquest_sdk.android.core.CarrotAuthState
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.models.User
import io.reactivex.observers.DisposableObserver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

internal object AuthManager {

    private const val TAG = "AuthManager"

    private val _state: MutableStateFlow<AuthState> = MutableStateFlow(AuthState.Idle)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    private val _publicState: MutableStateFlow<CarrotAuthState> = MutableStateFlow(CarrotAuthState.Idle)
    val publicState: StateFlow<CarrotAuthState> = _publicState.asStateFlow()

    fun isAuthenticating(): Boolean = _state.value is AuthState.Authenticating

    @Synchronized
    fun onAuthenticating() {
        val current = _state.value
        if (current is AuthState.Authenticating) {
            Log.e(TAG, "onAuthenticating() ignored: already authenticating")
            return
        }
        _state.value = AuthState.Authenticating
        _publicState.value = CarrotAuthState.Authenticating
    }

    @Synchronized
    fun onAuthenticated(userId: String) {
        val current = _state.value
        if (current !is AuthState.Authenticating) {
            Log.e(TAG, "onAuthenticated() ignored, unexpected state: $current")
            return
        }
        _state.value = AuthState.Authenticated(userId)
        _publicState.value = CarrotAuthState.Authenticated(userId)
    }

    @Synchronized
    fun onFailed(error: Throwable) {
        val current = _state.value
        if (current !is AuthState.Authenticating) {
            Log.e(TAG, "onFailed() ignored, unexpected state: $current")
            return
        }
        _state.value = AuthState.Failed(error)
        _publicState.value = CarrotAuthState.Failed(error)
    }

    @Synchronized
    fun onDeInit() {
        _state.value = AuthState.Idle
        _publicState.value = CarrotAuthState.Idle
    }

    suspend fun auth(id: String, userAuthKey: String): Result<String> {
        onAuthenticating()
        return suspendCancellableCoroutine { cont ->
            val service = CarrotInternal.getService()
            if (service == null) {
                val error = IllegalStateException("SDK not initialized. Call setup() first.")
                onFailed(error)
                cont.resume(Result.failure(error))
                return@suspendCancellableCoroutine
            }
            service.authUser(id, userAuthKey, object : DisposableObserver<User>() {
                override fun onNext(user: User) {
                    val userId = user.id ?: ""
                    onAuthenticated(userId)
                    if (!cont.isCompleted) cont.resume(Result.success(userId))
                }

                override fun onError(e: Throwable) {
                    onFailed(e)
                    if (!cont.isCompleted) cont.resume(Result.failure(e))
                }

                override fun onComplete() {}
            })
        }
    }

    suspend fun hashedAuth(id: String, hash: String): Result<String> {
        onAuthenticating()
        return suspendCancellableCoroutine { cont ->
            val service = CarrotInternal.getService()
            if (service == null) {
                val error = IllegalStateException("SDK not initialized. Call setup() first.")
                onFailed(error)
                cont.resume(Result.failure(error))
                return@suspendCancellableCoroutine
            }
            service.hashedAuth(id, hash, object : DisposableObserver<User>() {
                override fun onNext(user: User) {
                    val userId = user.id ?: ""
                    onAuthenticated(userId)
                    if (!cont.isCompleted) cont.resume(Result.success(userId))
                }

                override fun onError(e: Throwable) {
                    onFailed(e)
                    if (!cont.isCompleted) cont.resume(Result.failure(e))
                }

                override fun onComplete() {}
            })
        }
    }
}
