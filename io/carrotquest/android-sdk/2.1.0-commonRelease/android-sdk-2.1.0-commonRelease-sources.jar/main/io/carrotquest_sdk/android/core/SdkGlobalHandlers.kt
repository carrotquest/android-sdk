package io.carrotquest_sdk.android.core

import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.functions.Consumer
import io.reactivex.plugins.RxJavaPlugins
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Глобальные охранники для SDK: Rx undeliverable-ошибки и uncaught-exceptions в фоновых
 * потоках. Цель — не дать ошибке, возникшей внутри SDK, уронить хост-приложение.
 *
 * Ставятся один раз (через [ensureInstalled]) при первой инициализации SDK. Раньше жили
 * в `SdkApp.onCreate()`, но этот onCreate срабатывает только если хост явно прописал
 * `SdkApp` в своём манифесте — а большинство интеграторов этого не делают. В итоге
 * охранники не ставились вообще. Теперь вызов идёт из `CarrotSDK.setup*()`, что
 * гарантирует установку при старте SDK. Оставшийся вызов из `SdkApp.onCreate()`
 * остаётся страховкой.
 */
object SdkGlobalHandlers {

    private const val TAG = "CarrotSDK-Crash"
    private const val SDK_PACKAGE_PREFIX = "io.carrotquest_sdk.android"

    private val installed = AtomicBoolean(false)

    @JvmStatic
    fun ensureInstalled() {
        if (!installed.compareAndSet(false, true)) return
        installRxErrorHandler()
        installUncaughtExceptionGuard()
    }

    /**
     * Оборачивает вызов из публичного API так, чтобы исключения внутри SDK не могли
     * достичь хост-кода. Крэши приложения-клиента по вине SDK — главный враг; глобальный
     * uncaught-handler ловит не все случаи (например, когда хост обернул вызов в свой
     * try/catch(Throwable) и сам получает нашу ошибку). Этот wrapper гарантирует, что
     * публичные методы SDK никогда не пробрасывают исключение наружу.
     */
    @JvmStatic
    fun safeVoid(tag: String, block: Runnable) {
        try {
            block.run()
        } catch (t: Throwable) {
            Log.e(TAG, "[$tag] swallowed: $t")
        }
    }

    @JvmStatic
    fun <T> safeCall(tag: String, default: T, block: java.util.concurrent.Callable<T>): T {
        return try {
            block.call()
        } catch (t: Throwable) {
            Log.e(TAG, "[$tag] swallowed: $t")
            default
        }
    }

    /**
     * RxJava отправляет сюда ошибки, которые некому доставить: subscribe без onError,
     * ошибки после dispose, фоновые сбои внутри операторов. Логируем и, если ошибка
     * явно не из SDK, делегируем предыдущему handler'у — чтобы не ломать чужой
     * Rx-pipeline в хост-приложении.
     */
    private fun installRxErrorHandler() {
        val previous = RxJavaPlugins.getErrorHandler()
        RxJavaPlugins.setErrorHandler(Consumer { throwable ->
            if (throwable == null) return@Consumer
            val cause = throwable.cause ?: throwable
            Log.e(TAG, "rx undeliverable: $cause")
            if (previous != null && !isFromSdk(throwable)) {
                try {
                    previous.accept(throwable)
                } catch (_: Throwable) {
                    // previous handler бросил — глушим, иначе зациклимся
                }
            }
        })
    }

    /**
     * Uncaught-exceptions фоновых потоков (Timer, WSS, executors внутри SDK). Если стек
     * указывает на SDK — глушим с логом, чтобы не уронить хост. Иначе отдаём предыдущему
     * handler'у, чтобы не подавить легитимные краши клиентского кода.
     */
    private fun installUncaughtExceptionGuard() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, ex ->
            val fromSdk = try {
                isFromSdk(ex)
            } catch (_: Throwable) {
                false
            }
            if (fromSdk) {
                Log.e(TAG, "swallowed uncaught SDK exception in thread ${thread.name}: $ex")
                return@setDefaultUncaughtExceptionHandler
            }
            previous?.uncaughtException(thread, ex)
        }
    }

    /**
     * Проверяет весь stack trace (а не первые N фреймов) и всю цепочку причин. В
     * Rx/coroutine стеках SDK-фрейм часто оказывается далеко от верхушки из-за слоя
     * операторов.
     */
    private fun isFromSdk(ex: Throwable?): Boolean {
        var t: Throwable? = ex
        while (t != null) {
            for (frame in t.stackTrace) {
                if (frame.className.startsWith(SDK_PACKAGE_PREFIX)) return true
            }
            t = t.cause
        }
        return false
    }
}
