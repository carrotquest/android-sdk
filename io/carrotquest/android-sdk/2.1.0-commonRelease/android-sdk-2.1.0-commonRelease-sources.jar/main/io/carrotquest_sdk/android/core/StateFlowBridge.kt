package io.carrotquest_sdk.android.core

import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Consumer
import io.reactivex.subjects.BehaviorSubject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val TAG = "StateFlowBridge"

private val bridgeScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

internal fun attachInitSubject(subject: BehaviorSubject<Boolean>) {
    bridgeScope.launch {
        SdkStateManager.publicState.collect { state ->
            try {
                subject.onNext(state is CarrotState.Ready)
            } catch (t: Throwable) {
                Log.e(TAG, "attachInitSubject.onNext failed: $t")
            }
        }
    }
}

fun addCarrotStateObserver(consumer: Consumer<CarrotState>): Disposable {
    // SupervisorJob: exception в одном observer'е не отменяет остальных.
    val job = SupervisorJob()
    CoroutineScope(Dispatchers.Main + job).launch {
        SdkStateManager.publicState.collect { state ->
            // Клиентский callback может кинуть что угодно — ловим, чтобы не уронить корутину
            // и не отменить подписку для будущих событий.
            try {
                consumer.accept(state)
            } catch (t: Throwable) {
                Log.e(TAG, "addCarrotStateObserver consumer failed: $t")
            }
        }
    }
    return object : Disposable {
        @Volatile private var disposed = false
        override fun dispose() { job.cancel(); disposed = true }
        override fun isDisposed(): Boolean = disposed
    }
}

/**
 * Java-friendly подписка на событие "session expired" — refresh-токен протух и восстановить
 * сессию без повторной авторизации невозможно. Клиенту обычно нужно `Carrot.deInit()` + `setup()`.
 */
fun addSessionExpiredObserver(onExpired: Runnable): Disposable {
    val job = SupervisorJob()
    CoroutineScope(Dispatchers.Main + job).launch {
        SdkStateManager.sessionExpired.collect {
            try {
                onExpired.run()
            } catch (t: Throwable) {
                Log.e(TAG, "addSessionExpiredObserver callback failed: $t")
            }
        }
    }
    return object : Disposable {
        @Volatile private var disposed = false
        override fun dispose() { job.cancel(); disposed = true }
        override fun isDisposed(): Boolean = disposed
    }
}
