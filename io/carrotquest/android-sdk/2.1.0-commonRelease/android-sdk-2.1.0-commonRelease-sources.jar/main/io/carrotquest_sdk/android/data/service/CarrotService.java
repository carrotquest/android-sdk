package io.carrotquest_sdk.android.data.service;


import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil;
import io.carrotquest_sdk.android.core.util.huawei.HuaweiUtilsKt;
import io.carrotquest_sdk.android.domain.use_cases.user.GetAuthedUserIdUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.user.GetUserAgentUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.user.SaveAuthedUserIdUseCaseKt;
import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.lib.utils.AndroidUtils;
import io.carrotquest_sdk.android.lib.wss.jwt.JwtTokenRefreshService;
import io.carrotquest_sdk.android.core.SdkStateManager;
import io.carrotquest_sdk.android.core.connection.ConnectionManager;
import io.carrotquest_sdk.android.core.connection.WssManager;
import io.carrotquest_sdk.android.core.auth.AuthManager;
import io.carrotquest_sdk.android.core.init.InitCoordinator;
import io.carrotquest_sdk.android.core.init.OperationQueue;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.main.CarrotSDK;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadManager;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationTypingResponse;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;
import io.carrotquest_sdk.android.data.user.UserStateHolder;
import io.carrotquest_sdk.android.domain.entities.UserEntity;
import io.carrotquest_sdk.android.presentation.mvp.utils.ViewUtilsKt;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;
import okhttp3.ResponseBody;
import retrofit2.HttpException;

public class CarrotService implements ICarrotService {
    private static final String TAG = "CarrotService";
    private static final long UNSUBSCRIBE_PUSH_TIMEOUT_SECONDS = 5L;

    @Inject
    UserRepository userRepository;
    @Inject
    Gson gson;

    private static CarrotService instance;
    public static CarrotService getInstance() {
        if(instance == null) {
            instance = new CarrotService();
        }
        return instance;
    }

    /**
     * Идентификатор аппа
     */
    private String appId;

    private Disposable disposableInit;

    /**
     * Общая библиотека для работы с API
     */
    public CarrotLib carrotLib;

    private CompositeDisposable allDisposables = new CompositeDisposable();

    private BehaviorSubject<Boolean> isInitBehaviorSubject;
    private boolean isUseEuServers = false;


    private Disposable disposableSendPush;
    private Disposable disposableAuth;

    public CarrotService(Context context, String appId, boolean useEuServers) {
        this.appId = appId;
        this.isUseEuServers = useEuServers;
        CarrotInternal.getLibComponent().inject(this);
        instance = this;

        this.isInitBehaviorSubject = BehaviorSubject.create();
        carrotLib = new CarrotLib(context, userRepository, isUseEuServers);
    }

    public CarrotService() {
        this.appId = CarrotSDK.getAppId();
        this.isUseEuServers = CarrotSDK.isUseEuApi();
        CarrotInternal.getLibComponent().inject(this);

        this.isInitBehaviorSubject = BehaviorSubject.create();
        carrotLib = new CarrotLib(CarrotInternal.getLibComponent().getContextSdk(), userRepository, isUseEuServers);
    }

    /**
     * Инициализация сервисов (вызов setup())
     *
     * @param apiKey Ключ
     * @param callback Колюек сигнализирующий об успешности коннекта
     */
    @Override
    public void init(@NonNull String apiKey, CarrotSDK.Callback<Boolean> callback, boolean startSession) {
        if (userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }
        try {
            userRepository.saveToken("");
        } catch (Exception exSaveToken) {
            Log.e(TAG, "save token error: " + exSaveToken);
        }
        if (carrotLib == null) {
            carrotLib = new CarrotLib(CarrotInternal.getLibComponent().getContextSdk(), userRepository, isUseEuServers);
        }
        disposableInit = InitCoordinator.INSTANCE.connect(
                appId, apiKey, carrotLib, userRepository, startSession, callback,
                this::initPushesService, this::startRefreshTokenService
        );
    }

    /**
     * Деинициализация сервисов (разлогирование, остановка RTS, etc.)
     */
    @Override
    public void deInit() {
        deInit(null);
    }

    public void deInit(Runnable onComplete) {
        // Синхронный teardown — нет race window с последующим setup()
        SdkStateManager.INSTANCE.onDeInit();
        AuthManager.INSTANCE.onDeInit();
        InitCoordinator.INSTANCE.abort();
        OperationQueue.INSTANCE.cancelAll();
        ConnectionManager.INSTANCE.reset();
        WssManager.INSTANCE.stop();
        JwtTokenRefreshService.Companion.getInstance().stop();

        deInitDisposables();

        // Сбрасываем репозитории — singleton'ы держали подписки на старый CarrotService
        // (typing-индикатор) и хранили stale-данные. Без этого после re-init typing
        // переставал работать, а в списке оставались сообщения предыдущего юзера.
        try {
            io.carrotquest_sdk.android.data.repositories.MessagesRepository.Companion.getInstance().deInit();
        } catch (Throwable t) {
            Log.e(TAG, "MessagesRepository.deInit failed: " + t);
        }
        try {
            io.carrotquest_sdk.android.data.repositories.ConversationsRepository.Companion.getInstance().deInit();
        } catch (Throwable t) {
            Log.e(TAG, "ConversationsRepository.deInit failed: " + t);
        }

        if (userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        // Захватываем userId ДО очистки локального состояния
        String userId = UserStateHolder.INSTANCE.currentId();
        String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());

        // Синхронная очистка локального состояния — не зависит от успеха unsubscribe
        userRepository.saveUser(new User());
        UserStateHolder.INSTANCE.clear();

        // Асинхронная отписка push с timeout — onComplete гарантированно стрельнёт
        unsubscribePush(userId, deviceId)
                .timeout(UNSUBSCRIBE_PUSH_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .subscribe(
                        result -> {
                            if (onComplete != null) onComplete.run();
                        },
                        error -> {
                            Log.e(TAG, "unsubscribePush: " + error.toString());
                            if (onComplete != null) onComplete.run();
                        }
                );
    }

    /**
     * @return Ининциализированы ли сервисы
     */
    @Override
    public boolean isInit() {
        return SdkStateManager.INSTANCE.isInit();
    }

    @Override
    public void authUser(String id, String userAuthKey) {
        authUser(id, userAuthKey, null);
    }


    @Override
    public void authUser(String id, String userAuthKey, DisposableObserver<User> userDisposableObserver) {
        OperationQueue.INSTANCE.enqueue(() -> performAuth(id, userAuthKey, userDisposableObserver));
    }

    @Override
    public void hashedAuth(String id, String hash, DisposableObserver<User> userDisposableObserver) {
        OperationQueue.INSTANCE.enqueue(() -> performHashedAuth(id, hash, userDisposableObserver));
    }

    @Override
    public void setUserProperty(List<UserProperty> userProperty) {
        OperationQueue.INSTANCE.enqueue(() -> setUserPropertySimple(userProperty));
    }

    public void setUserPropertySimple(List<UserProperty> userProperty) {
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        carrotLib.setProperty(UserStateHolder.INSTANCE.currentId(), userProperty)
                .take(1)
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NetworkResponse networkResponse) {
                        Log.d(TAG, "onNext setUserProperty");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void setUserProperty(List<UserProperty> userProperty, DisposableObserver<Boolean> observer) {
        String prefix = "Set user property: ";
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .setProperty(UserStateHolder.INSTANCE.currentId(), userProperty)
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        Log.d(TAG, prefix + "onSubscribe");
                    }

                    @Override
                    public void onNext(NetworkResponse networkResponse) {
                        observer.onNext(networkResponse != null);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, prefix + "error: " + e);
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {
                        Log.d(TAG, prefix + "onComplete");
                    }
                })
        );
    }

    @Override
    public void trackEvent(String eventName, String eventParams, DisposableObserver<NetworkResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() -> trackEventSimple(eventName, eventParams, observer));
    }

    public  void trackEventSimple(String eventName, String eventParams, DisposableObserver<NetworkResponse> observer) {
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        carrotLib.trackEvent(UserStateHolder.INSTANCE.currentId(), eventName, eventParams)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NetworkResponse response) {
                        observer.onNext(response);
                    }

                    @Override
                    public void onError(Throwable e) {
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void getConversations(String userId, DisposableObserver<UserConversations> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .getConservations(userId)
                .subscribeOn(Schedulers.io())
                .doOnError(throwable -> Log.e(TAG, throwable))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserConversations>() {
                    @Override public void onSubscribe(Disposable d) { allDisposables.add(d); }
                    @Override public void onNext(UserConversations userConversations) { observer.onNext(userConversations); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void getConversations(String userId, String after, DisposableObserver<UserConversations> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .getConservations(userId, after)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserConversations>() {
                    @Override public void onSubscribe(Disposable d) { allDisposables.add(d); }
                    @Override public void onNext(UserConversations userConversations) { observer.onNext(userConversations); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void getConversation(String conversationId, Observer<ConversationResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .getConservation(conversationId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ConversationResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(ConversationResponse conversation) { observer.onNext(conversation); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void startConversations(String userId, String messageText, DisposableObserver<StartConversationResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .startConversation(userId, messageText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<StartConversationResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(StartConversationResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void startConversations(String userId, File file, DisposableObserver<StartConversationResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .startConversation(userId, file)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<StartConversationResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(StartConversationResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void getMessage(String conversationId, String after, DisposableObserver<MessagesResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() -> {
            try {
                Observable<MessagesResponse> req = after.isEmpty()
                        ? carrotLib.getMessages(conversationId)
                        : carrotLib.getMessages(conversationId, after);
                req.subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Observer<MessagesResponse>() {
                            @Override public void onSubscribe(Disposable d) {}
                            @Override public void onNext(MessagesResponse r) { observer.onNext(r); }
                            @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                            @Override public void onComplete() {}
                        });
            } catch (Exception e) {
                Log.e(TAG, e.toString());
            }
        });
    }

    @Override
    public void reply(String conversationId, String messageText, boolean fromUser, String randomId, DisposableObserver<ReplyResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib
                .reply(conversationId, messageText, fromUser, randomId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ReplyResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(ReplyResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void replyFile(String conversationId, File file, String autoAssign, String randomId, DisposableObserver<ReplyFileResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib.replyFile(conversationId, file, autoAssign, randomId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .onErrorReturn(throwable -> {
                    ReplyFileResponse errorResponse = new ReplyFileResponse();
                    Meta meta = new Meta();
                    meta.setStatus(400);
                    meta.setError(throwable.getMessage());
                    errorResponse.setMeta(meta);
                    return errorResponse;
                })
                .subscribe(new Observer<ReplyFileResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(ReplyFileResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    @Override
    public void trackClickByPush(String conversationId, DisposableObserver<NetworkResponse> observer) {
        carrotLib.trackInteraction(conversationId, "clicked")
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull NetworkResponse response) {
                        observer.onNext(response);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        Log.e(TAG, e.toString());
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void markConversationAsRead(String conversationId, DisposableObserver<NetworkResponse> observer) {
        carrotLib.markRead(conversationId)
                .observeOn(AndroidSchedulers.mainThread())
                .doOnError(t -> {
                    Log.e("markReadError", t);
                })
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NetworkResponse emptyResponse) {
                        observer.onNext(emptyResponse);
                        io.carrotquest_sdk.android.data.repositories.ConversationsRepository.Companion.getInstance().removeUnreadConversation(conversationId);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void voteOperator(String messageId, Integer vote, String comment, DisposableObserver<NetworkResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() -> {
            JsonObject bodyMetaDataObject = new JsonObject();
            bodyMetaDataObject.addProperty("vote", vote);
            if (!TextUtils.isEmpty(comment)) {
                bodyMetaDataObject.addProperty("comment", comment);
            }
            carrotLib.conversationParts(messageId, bodyMetaDataObject)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NetworkResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(NetworkResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                });
        });
    }

    @Override
    public void voteOperator(String messageId, Integer vote, DisposableObserver<NetworkResponse> observer) {
        voteOperator(messageId, vote, "", observer);
    }

    @Override
    public void updateAutoReply(String messageId, boolean replied, DisposableObserver<NetworkResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() -> {
            JsonObject bodyMetaDataObject = new JsonObject();
            bodyMetaDataObject.addProperty("replied", replied);
            carrotLib.conversationParts(messageId, bodyMetaDataObject)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NetworkResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(NetworkResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                });
        });
    }

    public Observable<File> downloadF(String messageId, String attachmentId, String url, long size) {
        return DownloadUtil.downloadFile(messageId, attachmentId, url, size);
    }

    @Override
    public void downloadFile(String messageId, String url, long size, Observer<Integer> observer) {
        OperationQueue.INSTANCE.enqueue(() -> DownloadManager.startDownload(messageId, url, size, observer));
    }

    private Disposable typingDisposable;
    private Long startTypingTime = null;
    private Disposable typingDebounceDisposable;

    @Override
    public void setTyping(String conversationId, String messageBody) {
        if (!SdkStateManager.INSTANCE.isInit()) return;

        long currentTime = System.currentTimeMillis();
        long diffTime = currentTime - (startTypingTime == null ? 0L : startTypingTime);

        if(typingDebounceDisposable != null && !typingDebounceDisposable.isDisposed()) {
            typingDebounceDisposable.dispose();
        }

        typingDebounceDisposable = Observable.just(true)
                .debounce(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean ignored) {
                        carrotLib.setTyping(conversationId, messageBody)
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(new Observer<NetworkResponse>() {
                                    @Override public void onSubscribe(Disposable d) {}
                                    @Override public void onNext(NetworkResponse r) {
                                        if (typingDebounceDisposable != null) typingDebounceDisposable.dispose();
                                        if (typingDisposable != null) typingDisposable.dispose();
                                    }
                                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); }
                                    @Override public void onComplete() {}
                                });
                    }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); }
                    @Override public void onComplete() {}
                });
        allDisposables.add(typingDebounceDisposable);

        if (diffTime < 2000) {
            return;
        }

        if (typingDisposable != null && !typingDisposable.isDisposed()) {
            return;
        }

        startTypingTime = System.currentTimeMillis();

        typingDisposable = carrotLib.setTyping(conversationId, messageBody)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<NetworkResponse>() {
                    @Override
                    public void onNext(NetworkResponse r) {
                        if (typingDebounceDisposable != null) typingDebounceDisposable.dispose();
                        if (typingDisposable != null) typingDisposable.dispose();
                    }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); }
                    @Override public void onComplete() {}
                });
        allDisposables.add(typingDisposable);
    }

    @Override
    public void addInitObserver(Observer<Boolean> initObserver) {
        if(isInitBehaviorSubject != null) {
            isInitBehaviorSubject.subscribe(initObserver);
        }
    }

    @Override
    public String getSaveUserId() {
        return UserStateHolder.INSTANCE.currentId();
    }


    @Override
    public void chooseRoutingBot(String conversationId, DisposableObserver<ChooseRoutingBotResponse> observer) {
        OperationQueue.INSTANCE.enqueue(() ->
            carrotLib.chooseRoutingBot(conversationId)
                .take(1)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ChooseRoutingBotResponse>() {
                    @Override public void onSubscribe(Disposable d) {}
                    @Override public void onNext(ChooseRoutingBotResponse r) { observer.onNext(r); }
                    @Override public void onError(Throwable e) { Log.e(TAG, e.toString()); observer.onError(e); }
                    @Override public void onComplete() {}
                })
        );
    }

    private void initPushesService() {
        try {
            boolean isHuaweiDevice = HuaweiUtilsKt.isHuawei();
            if(isHuaweiDevice) {
                return;
            }

            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    return;
                }

                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(CarrotInternal.getLibComponent().getContextSdk());
                if (task.getResult() != null && notificationManager.areNotificationsEnabled()) {
                    String token = task.getResult();
                    String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
                    if(userRepository == null) {
                        userRepository = CarrotInternal.getLibComponent().getUserRepository();
                    }

                    sendPushToken(UserStateHolder.INSTANCE.currentId(), token, deviceId);
                }
            });

        }
        catch (IllegalStateException eIllegalState) {
            Log.d(TAG, eIllegalState.toString());
        }
        catch (Exception e) {
            Log.d(TAG, e.toString());
        }
    }

    public void sendPushToken(String userId, String token, String deviceId) {
        if (token == null || token.isEmpty()) return;
        OperationQueue.INSTANCE.enqueue(() -> {
            String sUserAgent = GetUserAgentUseCaseKt.getUserAgent();
            String deviceType = ViewUtilsKt.isTablet(CarrotInternal.getLibComponent().getContextSdk()) ? "tablet" : "phone";
            String device = HuaweiUtilsKt.isHuawei() ? "Huawei [huawei_push] 1.0.0" : "Android";
            String sdkVersion = CarrotSDK.getVersion();
            String browser = "sdk " + (sdkVersion != null ? sdkVersion : "");
            disposableSendPush = carrotLib
                    .sendPushToken(userId, token, deviceId, "mobile", deviceType, device, browser, sUserAgent)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(res -> Log.d(TAG, res.toString()), error -> Log.e(TAG, error));
        });
    }

    public Observable<Boolean> unsubscribePush(String userId, String deviceId) {
        return carrotLib
                .deletePushToken(userId, deviceId, "mobile")
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .doOnError(e->{
                    Log.e("unsubscribePush",e.toString());
                })
                .map(pushSubResponse -> pushSubResponse.getMeta().getStatus() == 200);
    }


    private PublishSubject<ConversationTypingResponse> adminTypingObservable = PublishSubject.create();
    public Observable<ConversationTypingResponse> adminTypingObservable(){
        return adminTypingObservable;
    }

    public void adminTyping(ConversationTypingResponse pair) {
        adminTypingObservable.onNext(pair);
    }

    public void startRefreshTokenService() {
        allDisposables.add(JwtTokenRefreshService.Companion.getInstance().getUpdateJwtTokenObservable().subscribe(s -> {
            Log.d("JWT", "getUpdateJwtTokenObservable onNext: " + s);
            WssManager.INSTANCE.start(appId, UserStateHolder.INSTANCE.currentId());
        }, throwable -> {
            Log.e("JWT", throwable.toString());
        }));
        JwtTokenRefreshService.Companion.getInstance().start();
    }

    /**
     * Единая точка записи данных аутентифицированного юзера: old UserRepository
     * (+ SharedPrefs + UserStateHolder), новый Kotlin UserRepository, SharedPrefs authed-id.
     * Обёрнуто в try-блоки по каждой записи, чтобы частичный сбой одного холдера не
     * порушил остальные — рассогласование лучше полного отказа auth.
     */
    private void persistAuthedUser(User tempUser, String authedId) {
        try {
            userRepository.saveUser(tempUser);
        } catch (Exception e) {
            Log.e(TAG, "persistAuthedUser.userRepository: " + e);
        }
        try {
            UserEntity userEntity = new UserEntity(
                    tempUser.getId(),
                    tempUser.getToken(),
                    tempUser.hasConversations,
                    tempUser.isBanned(),
                    tempUser.getConversationsUnread()
            );
            io.carrotquest_sdk.android.data.repositories.UserRepository.Companion
                    .getInstance().saveUser(userEntity);
        } catch (Exception e) {
            Log.e(TAG, "persistAuthedUser.kotlinRepo: " + e);
        }
        try {
            SaveAuthedUserIdUseCaseKt.saveAuthedUserIdUseCase(
                    authedId, tempUser.getId(),
                    CarrotInternal.getLibComponent().getContextSdk()
            );
        } catch (Exception e) {
            Log.e(TAG, "persistAuthedUser.saveAuthedId: " + e);
        }
    }

    private void performAuth(String id, String userAuthKey, DisposableObserver<User> getAuthUserObserver) {
        if (SdkStateManager.INSTANCE.isInit()) {
            if(userRepository == null) {
                userRepository = CarrotInternal.getLibComponent().getUserRepository();
            }

            String connectedUserId = GetAuthedUserIdUseCaseKt.getConnectedUserIdUseCase(CarrotInternal.getLibComponent().getContextSdk());
            List<String> authedUserIds = GetAuthedUserIdUseCaseKt.getAuthedUserIdUseCase(CarrotInternal.getLibComponent().getContextSdk());
            if(authedUserIds != null && authedUserIds.size() == 2) {
                String authedId = authedUserIds.get(0);
                String authedUserId = authedUserIds.get(1);

                if(authedId.equals(id)) {
                    //Если пытаемся авторизоваться с тем же id, который хранится в хранилище
                    if(connectedUserId != null && connectedUserId.equals(authedUserId)) {
                        //Если id, который вернулся после инициализации не NULL и совпадает с тем userId,
                        // который уже хранится в хранилище, то авторизация по сути не нужна
                        if (getAuthUserObserver != null) {
                            User user = userRepository.getUser();
                            getAuthUserObserver.onNext(user);
                        }
                        return;
                    }
                }
            }

            disposableAuth = carrotLib.auth(id, userAuthKey)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(response -> {
                                if (response.getData() != null && response.getData().getUser() != null) {
                                    User tempUser = response.getData().getUser();
                                    if (TextUtils.isEmpty(tempUser.getToken()) && !TextUtils.isEmpty(response.getData().getAuthToken())) {
                                        tempUser.setToken(response.getData().getAuthToken());
                                    }
                                    persistAuthedUser(tempUser, id);
                                } else if(response.getData() != null && "not_need".equals(response.getData().getResult())) {
                                    try {
                                        SaveAuthedUserIdUseCaseKt.saveAuthedUserIdUseCase(id, UserStateHolder.INSTANCE.currentId(), CarrotInternal.getLibComponent().getContextSdk());
                                    } catch (Exception e) {
                                        Log.e(TAG, e);
                                    }
                                }

                                User user = userRepository.getUser();
                                getConversations(user.getId(), new DisposableObserver<UserConversations>() {
                                    @Override
                                    public void onNext(UserConversations userConversations) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onNext(user);
                                        }

                                        WssManager.INSTANCE.start(appId, user.getId());
                                    }

                                    @Override
                                    public void onError(Throwable e) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onError(e);
                                        }
                                    }

                                    @Override
                                    public void onComplete() {

                                    }
                                });

                                initPushesService();
                            },
                            e -> {
                                authError(e);
                                if (getAuthUserObserver != null) {
                                    getAuthUserObserver.onError(e);
                                }
                            });

        }
    }

    private void performHashedAuth(String id, String hash, DisposableObserver<User> getAuthUserObserver) {
        if (SdkStateManager.INSTANCE.isInit()) {
            if(userRepository == null) {
                userRepository = CarrotInternal.getLibComponent().getUserRepository();
            }

            String connectedUserId = GetAuthedUserIdUseCaseKt.getConnectedUserIdUseCase(CarrotInternal.getLibComponent().getContextSdk());
            List<String> authedUserIds = GetAuthedUserIdUseCaseKt.getAuthedUserIdUseCase(CarrotInternal.getLibComponent().getContextSdk());
            if(authedUserIds != null && authedUserIds.size() == 2) {
                String authedId = authedUserIds.get(0);
                String authedUserId = authedUserIds.get(1);

                if(authedId.equals(id)) {
                    //Если пытаемся авторизоваться с тем же id, который хранится в хранилище
                    if(connectedUserId != null && connectedUserId.equals(authedUserId)) {
                        //Если id, который вернулся после инициализации не NULL и совпадает с тем userId,
                        // который уже хранится в хранилище, то авторизация по сути не нужна
                        if (getAuthUserObserver != null) {
                            User user = userRepository.getUser();
                            getAuthUserObserver.onNext(user);
                        }
                        return;
                    }
                }
            }

            disposableAuth = carrotLib.hashedAuth(id, hash)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(response -> {
                                if (response.getData() != null && response.getData().getUser() != null) {
                                    User tempUser = response.getData().getUser();
                                    if (TextUtils.isEmpty(tempUser.getToken()) && !TextUtils.isEmpty(response.getData().getAuthToken())) {
                                        tempUser.setToken(response.getData().getAuthToken());
                                    }
                                    persistAuthedUser(tempUser, id);
                                } else if(response.getData() != null && "not_need".equals(response.getData().getResult())) {
                                    try {
                                        SaveAuthedUserIdUseCaseKt.saveAuthedUserIdUseCase(id, UserStateHolder.INSTANCE.currentId(), CarrotInternal.getLibComponent().getContextSdk());
                                    } catch (Exception e) {
                                        Log.e(TAG, e);
                                    }
                                }

                                User user = userRepository.getUser();
                                getConversations(user.getId(), new DisposableObserver<UserConversations>() {
                                    @Override
                                    public void onNext(UserConversations userConversations) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onNext(user);
                                        }

                                        WssManager.INSTANCE.start(appId, user.getId());
                                    }

                                    @Override
                                    public void onError(Throwable e) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onError(e);
                                        }
                                    }

                                    @Override
                                    public void onComplete() {

                                    }
                                });

                                initPushesService();
                            },
                            e -> {
                                authError(e);
                                if (getAuthUserObserver != null) {
                                    getAuthUserObserver.onError(e);
                                }
                            });

        }
    }

    private void authError(Throwable e) {
        if (e instanceof HttpException) {
            ResponseBody responseBody = ((HttpException) e).response().errorBody();
            try {
                String body = responseBody != null ? responseBody.string() : "";
                //ErrorResponse response = gson.fromJson(body, ErrorResponse.class);
                //Log.e(TAG, response.errorMessage);
            } catch (NullPointerException npe) {
                Log.e(TAG, npe);
            } catch (Exception e1) {
                Log.e(TAG, e1);
            }
        }
        Log.e(TAG, e);
    }


    private void deInitDisposables() {
        if(disposableInit != null && !disposableInit.isDisposed()) {
            disposableInit.dispose();
        }

        if(disposableSendPush != null && !disposableSendPush.isDisposed()) {
            disposableSendPush.dispose();
        }

        if(disposableAuth != null && !disposableAuth.isDisposed()) {
            disposableAuth.dispose();
        }

        if(allDisposables != null && !allDisposables.isDisposed()) {
            allDisposables.dispose();
            allDisposables = new CompositeDisposable();
        }

        adminTypingObservable.onComplete();
        adminTypingObservable = PublishSubject.create();
    }

    @Override
    public void setUserConsentContact(String contacts, String userId, String partId, Observer<Boolean> observer) {
        Disposable d = carrotLib.setUserConsentContact(contacts, partId, userId).subscribe(networkResponse -> observer.onNext(networkResponse.getMeta().getError() == null),
                t -> observer.onNext(false));

        allDisposables.add(d);
    }

    @Override
    public void setUserConsentDataProcessing(Boolean dataProcessing, String userId, Observer<Boolean> observer) {
        Disposable d = carrotLib.setUserConsentDataProcessing(dataProcessing, userId).subscribe(networkResponse -> observer.onNext(networkResponse.getMeta().getError() == null),
                t -> observer.onNext(false));

        allDisposables.add(d);
    }

//    @Override
//    public void setUserConsentContact(String userId, String params) {
//        Disposable d = carrotLib.setUserConsent(userId, params).subscribe(new Consumer<NetworkResponse>() {
//            @Override
//            public void accept(NetworkResponse networkResponse) throws Exception {
//                Log.i(TAG, "");
//            }
//
//        }, new Consumer<Throwable>() {
//            @Override
//            public void accept(Throwable t) throws Exception {
//                Log.e(TAG, t.toString());
//            }
//        });
//
//     allDisposables.add(d);
//    }
}
