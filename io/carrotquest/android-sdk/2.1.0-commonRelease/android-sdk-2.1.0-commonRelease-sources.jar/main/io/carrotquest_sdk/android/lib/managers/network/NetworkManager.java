package io.carrotquest_sdk.android.lib.managers.network;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import io.carrotquest_sdk.android.lib.managers.IStateManager;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class NetworkManager implements IStateManager {
    private final static String CONNECTIVITY_ACTION = "android.net.conn.CONNECTIVITY_CHANGE";

    private static final String TAG = "NetworkManager";

    // Пингуем оба адреса: если хотя бы один отвечает 200 — считаем, что интернет есть.
    // Так не выпадаем в "no internet" из-за того, что один из хостов заблокирован/недоступен
    // (например, google.com через VPN).
    private final static String[] URLS_FOR_PING = {"https://www.google.com/", "https://ya.ru/"};
    private final static int MAX_PING_COUNT = 5;
    private final static int PING_TIME_OUT = 2000;   //MS
    private final static int MAX_RETRY_DELAY = 600;  //SEC
    // Лимит на retry-цикл: после него останавливаемся и ждём следующий connectivity
    // event от BroadcastReceiver. С backoff до 10 минут это ≈ час попыток, после чего
    // бессмысленно продолжать жечь батарею и трафик.
    private final static int MAX_RETRY_ATTEMPTS = 30;
    private int retryTime = 10; //SEC
    private int currentTry = 0;

    private PublishSubject<Boolean> connectSubject;
    private NetworkStateReceiver networkStateReceiver;

    private Disposable disposableNetworkState;
    // Активная подписка retry-цикла. Храним, чтобы dispose() прежнюю при новом
    // onConnect() — иначе receiver плодит параллельные пинг-loop'ы.
    private Disposable onConnectDisposable;

    private Context context;
    private CompositeDisposable compositeDisposable;

    private boolean hasInternet = false;

    @SuppressLint("StaticFieldLeak")
    private static NetworkManager instance;

    public static NetworkManager getInstance(Context _context) {
        if (instance == null) {
            instance = new NetworkManager();
            instance.context = _context;
            instance.compositeDisposable = new CompositeDisposable();
            instance.connectSubject = PublishSubject.create();
            instance.networkStateReceiver = new NetworkStateReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction(CONNECTIVITY_ACTION);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    instance.context.registerReceiver(instance.networkStateReceiver, filter, android.content.Context.RECEIVER_EXPORTED);
                } else {
                    instance.context.registerReceiver(instance.networkStateReceiver, filter);
                }
            } catch (Exception e) {
                Log.e("NetworkManager", "hasConnect check failed", e);
            }
            // Первичная проверка связи. Дальше ping-loop'ы запускаются только через
            // onConnect() из BroadcastReceiver'а. Раньше пинг стартовал на КАЖДЫЙ
            // getInstance() в новом потоке — получалась лавина параллельных пингов.
            instance.onConnect();
        }

        return instance;
    }

    /**
     * Принудительно перезапускает ping-цикл проверки интернета. Нужен для случаев,
     * когда приложение долго пробыло в background/Doze: фоновый retry-цикл
     * исчерпал MAX_RETRY_ATTEMPTS, выставил {@code hasInternet = false} и больше
     * не запускается до следующего CONNECTIVITY_CHANGE broadcast'а — а его при
     * выходе из Doze может не прийти, если сеть формально не менялась. Активити
     * чата вызывает revalidate() в onResume, чтобы оживить флаг.
     */
    public void revalidate() {
        onConnect();
    }

    void onConnect() {
        // Сбрасываем retry-счётчик и backoff — начинаем новый цикл по событию от
        // BroadcastReceiver. Предыдущую подписку обязательно dispose, иначе два
        // (а то и больше) retry-loop'а работают параллельно.
        currentTry = 0;
        retryTime = 10;
        if (onConnectDisposable != null && !onConnectDisposable.isDisposed()) {
            onConnectDisposable.dispose();
        }

        Observable<Boolean> connectObservable = Observable.create(emitter -> emitter.onNext(ping()));

        connectObservable
                .retryWhen(throwableObservable ->
                        // zipWith с range(1..MAX+1) ограничивает число повторов: когда
                        // range исчерпан, zipWith завершается, retryWhen получает
                        // onComplete → ошибка из исходного Observable НЕ пробрасывается
                        // дальше. Внутри flatMap делаем delay по текущему retryTime,
                        // который обновляется внутри ping().
                        throwableObservable
                                .zipWith(Observable.range(1, MAX_RETRY_ATTEMPTS), (err, i) -> i)
                                .flatMap(i -> Observable.timer(retryTime, TimeUnit.SECONDS))
                )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<Boolean>(){

                    @Override
                    public void onSubscribe(Disposable d) {
                        onConnectDisposable = d;
                        if (compositeDisposable != null && !compositeDisposable.isDisposed()) {
                            compositeDisposable.add(d);
                        }
                    }

                    @Override
                    public void onNext(Boolean hasConnect) {
                        hasInternet = hasConnect;
                        connectSubject.onNext(hasConnect);
                    }

                    @Override
                    public void onError(Throwable e) {
                        hasInternet = false;
                        connectSubject.onNext(false);
                        Log.e(TAG, "retry exhausted: " + e);
                    }

                    @Override
                    public void onComplete() {
                        // Лимит попыток исчерпан. Не спамим сеть — ждём следующего
                        // connectivity event от receiver'а, он снова вызовет onConnect().
                        hasInternet = false;
                        connectSubject.onNext(false);
                    }
                });
    }

    void offConnect() {
        hasInternet = false;
        connectSubject.onNext(false);
    }

    @Override
    public void addObserver(Consumer<Boolean> observer, Consumer<Throwable> errorConsumer, Action complete) {
        if(compositeDisposable == null || compositeDisposable.isDisposed()) {
            compositeDisposable = new CompositeDisposable();
        }

        if(connectSubject.hasComplete()) {
            connectSubject = PublishSubject.create();
        }

        try {
            compositeDisposable.add(connectSubject.subscribe(observer, errorConsumer, complete));
        }catch (Exception e) {
            Log.e(TAG, e.toString());
        }
    }

    @Override
    public void deInit() {
        if (networkStateReceiver != null) {
            try {
                context.unregisterReceiver(networkStateReceiver);
            }
            catch (Exception e) {
                Log.e(TAG, e.toString());
            }
        }
        connectSubject.onComplete();
        compositeDisposable.dispose();
        instance = null;
    }

    public static boolean isAirplaneModeOn() {
        return Settings.System.getInt(instance.context.getContentResolver(),
                Settings.System.AIRPLANE_MODE_ON, 0) != 0;

    }

    /**
     * Проверяет доступность интернета через {@link #URLS_FOR_PING}.
     * Считаем, что интернет есть, если хотя бы один URL ответил 200.
     *
     * @return true если хоть один URL ответил 200; false если все URL'ы ответили не 200.
     * @throws Exception если ни один URL не удалось открыть (триггерит retryWhen в onConnect).
     */
    private Boolean ping() throws Exception {
        currentTry++;

        boolean anyAttemptThrew = false;
        for (String urlStr : URLS_FOR_PING) {
            try {
                if (pingHost(urlStr)) {
                    currentTry = 0;
                    retryTime = 10;
                    hasInternet = true;
                    return true;
                }
                // pingHost вернул false (не-200) — пробуем следующий URL.
            } catch (Exception e) {
                anyAttemptThrew = true;
            }
        }

        //Увеличиваем интервал между попытками соединения
        if (retryTime < MAX_RETRY_DELAY && currentTry % 10 == 0) {
            retryTime += 10;
            //Если полдключения так и нет, а мы все еще хотим достучаться,
            // то надо перезаписаться на поток данных, увеличив при этом интервал проверок
            if (disposableNetworkState != null && !disposableNetworkState.isDisposed()) {
                disposableNetworkState.dispose();
                onConnect();
                anyAttemptThrew = false;
            }
        }

        if (anyAttemptThrew) {
            throw new Exception("network not available");
        }

        return false;
    }

    /**
     * Делает до {@link #MAX_PING_COUNT}-1 попыток открыть {@code urlStr}.
     *
     * @return true если сервер вернул любой HTTP-ответ — это уже доказывает, что
     *         DNS работает и до хоста есть сетевой маршрут. Принимаем не только
     *         200, но и редиректы (301/302 — google.com в некоторых регионах) и
     *         клиентские/серверные ошибки.
     * @throws Exception если все попытки упали с IOException — соединение не
     *         удалось установить (DNS-фейл, no route, timeout).
     */
    private boolean pingHost(String urlStr) throws Exception {
        Exception lastException = null;
        int attempt = 1;
        while (attempt < MAX_PING_COUNT) {
            attempt++;
            try {
                URL url = new URL(urlStr);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Connection", "close");
                urlConnection.setConnectTimeout(PING_TIME_OUT);
                urlConnection.connect();
                return urlConnection.getResponseCode() > 0;
            } catch (Exception e) {
                lastException = e;
            }
        }
        throw lastException;
    }

    public boolean getHasConnect() {
        return hasInternet;
    }

    /**
     * Синхронно проверяет, есть ли у устройства активное сетевое подключение
     * с capability INTERNET. В отличие от {@link #getHasConnect()} это не
     * прогретый асинхронным ping'ом кэш, а живое состояние из системы —
     * корректно отражает выключение сети, авиарежим, выход из Doze. Ping всё
     * равно нужен (есть сеть ≠ интернет работает), но эта проверка позволяет
     * быстро отсечь "сеть точно отключена" без ожидания HTTP-таймаута.
     */
    public boolean isNetworkAvailable() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.net.Network active = cm.getActiveNetwork();
                if (active == null) return false;
                android.net.NetworkCapabilities caps = cm.getNetworkCapabilities(active);
                return caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
            } else {
                NetworkInfo info = cm.getActiveNetworkInfo();
                return info != null && info.isConnected();
            }
        } catch (Exception e) {
            Log.e(TAG, "isNetworkAvailable check failed: " + e);
            return false;
        }
    }

    public String getConnectionType() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();

        if(info == null) {
            return "";
        }

        if(info.getType() == ConnectivityManager.TYPE_WIFI) {
            return "WIFI";
        }

        if(info.getType() == ConnectivityManager.TYPE_MOBILE) {
            return "MOBILE";
        }

        if(info.getType() == ConnectivityManager.TYPE_VPN) {
            return "VPN";
        }

        return "OTHER";

    }
}
