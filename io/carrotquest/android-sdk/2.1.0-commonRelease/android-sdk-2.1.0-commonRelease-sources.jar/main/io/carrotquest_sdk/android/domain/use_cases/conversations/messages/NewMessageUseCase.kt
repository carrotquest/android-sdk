package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversations
import io.reactivex.Observable

fun <T> Observable<T>.addNewMessage(message: MessageData) : Observable<MessageData> {
    val tag = "Observable.addNewMessage()"
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(true)
                    .getConversations()
                    .take(1)
                    .doOnNext { conversations ->
                        val foundConversations = conversations.find { x -> x != null && x.id == message.conversation }
                        if (foundConversations != null) {
                            if(foundConversations.partLast == null ||
                                    (foundConversations.partLast.id != message.id
                                            && foundConversations.partLast.id != message.randomId
                                            && foundConversations.partLast.randomId != message.id
                                            && foundConversations.partLast.randomId != message.randomId) ) {
                                val isOpened = ConversationsRepository.getInstance().getOpenedConversationId() == foundConversations.id
                                val unreadPartsCount = if (isOpened) {
                                    foundConversations.unreadPartsCount
                                } else {
                                    foundConversations.unreadPartsCount + 1
                                }

                                // lastAdmin обновляем только для сообщений от оператора:
                                // у user-сообщений messageFrom = null, иначе затрём
                                // существующего оператора и карточка потеряет имя/аватар.
                                val isFromAdmin = message.direction == ResponseFields.ADMIN_2_USER
                                        && message.messageFrom != null

                                foundConversations.unreadPartsCount = unreadPartsCount
                                foundConversations.partsCount += 1
                                foundConversations.lastUpdate = message.created
                                if (isFromAdmin) {
                                    foundConversations.lastAdmin = message.messageFrom
                                }

                                val sourceConversation = foundConversations.sourceJsonData
                                if (sourceConversation != null) {
                                    sourceConversation.remove(F.PART_LAST)
                                    val jsonPartLastString = message.sourceJsonData.toString()
                                    val jsonPartLast = JsonParser().parse(jsonPartLastString).asJsonObject
                                    sourceConversation.add(F.PART_LAST, jsonPartLast)

                                    if (isFromAdmin) {
                                        sourceConversation.remove(F.LAST_ADMIN)
                                        val adminJson = Gson().toJson(message.messageFrom)
                                        sourceConversation.add(F.LAST_ADMIN, JsonParser().parse(adminJson).asJsonObject)
                                    }

                                    foundConversations.sourceJsonData = sourceConversation
                                }

                                ConversationsRepository.getInstance().updateConversation(message.conversation, foundConversations)
                            }
                        } else {
                            //add new conversation
                            CarrotInternal.getService().carrotLib.getConservation(message.conversation)
                                    .doOnNext { x ->
                                        val conversation = x.data
                                        if(conversation != null && conversation.id != null) {
                                            ConversationsRepository.getInstance()
                                                .addConversation(conversation)
                                        }
                                    }
                                    .doOnError {

                                    }
                                    .subscribe()
                        }

                        MessagesRepository.getInstance().replaceMessageTyping(message)
                    }
                    .doOnError {
                        Log.e(tag, it.toString())
                    }
                    .flatMap {
                        Observable.just(message)
                    }
        }
    }
}