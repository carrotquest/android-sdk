package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.presentation.ui.LoadingContent
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationListItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListUiState
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel.ListViewModel

// ── Главный экран (только контент, без шапки) ─────────────────────────────────

@Composable
fun ListContentScreen(
    viewModel: ListViewModel,
    theme: SimpleTheme,
    accentColor: Color,
    onConversationClick: (id: String) -> Unit,
    onNewConversationClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val headerData by viewModel.headerData.collectAsState()
    val isDark = theme == SimpleTheme.DARK
    val navBarHeight = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val showPoweredBy = headerData.showPoweredBy

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            when (val state = uiState) {
                is ListUiState.Loading -> LoadingContent(accentColor)
                is ListUiState.Empty -> EmptyState(isDark, navBarHeight, showPoweredBy)
                is ListUiState.Content -> ConversationListContent(
                    recentItems = state.recentItems,
                    historyItems = state.historyItems,
                    isDark = isDark,
                    accentColor = accentColor,
                    bottomPadding = navBarHeight,
                    showPoweredBy = showPoweredBy,
                    onItemClick = onConversationClick,
                    onToggleGroup = { viewModel.toggleGroup(it) },
                    onPagination = { viewModel.onPagination() }
                )
                is ListUiState.Error -> ListErrorContent(
                    errorType = state.type,
                    isDark = isDark,
                    onRetry = { viewModel.loadData() }
                )
            }

            if (uiState is ListUiState.Content || uiState is ListUiState.Empty) {
                WriteButtonTray(
                    accentColor = accentColor,
                    isDark = isDark,
                    navBarHeight = navBarHeight,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth(),
                    showPoweredBy = showPoweredBy,
                    appName = headerData.appName,
                    onClick = onNewConversationClick
                )
            }
        }
    }
}

// ── Список диалогов ───────────────────────────────────────────────────────────

@Composable
private fun ConversationListContent(
    recentItems: List<ConversationListItem>,
    historyItems: List<ConversationListItem>,
    isDark: Boolean,
    accentColor: Color,
    bottomPadding: Dp,
    showPoweredBy: Boolean = false,
    onItemClick: (String) -> Unit,
    onToggleGroup: (String) -> Unit,
    onPagination: () -> Unit
) {
    val listState = rememberLazyListState()
    val reachedEnd by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            lastVisible >= listState.layoutInfo.totalItemsCount - 3
        }
    }

    LaunchedEffect(reachedEnd) {
        if (reachedEnd) onPagination()
    }

    // Fix: когда диалог переходит из истории в recent (оператор написал), он попадает в
    // начало списка. Если пользователь уже смотрит на верх — проскролливаем, чтобы новое
    // сообщение осталось видно. Если пользователь пролистал вниз — не дёргаем, пусть
    // уходит под шапку, иначе сбросится контекст чтения.
    val density = LocalDensity.current
    val scrollThresholdPx = remember(density) { with(density) { 20.dp.toPx() }.toInt() }
    val firstRecentKey = recentItems.firstOrNull()?.let { listItemKey(it) }
    LaunchedEffect(firstRecentKey) {
        if (firstRecentKey == null) return@LaunchedEffect
        val nearTop = listState.firstVisibleItemScrollOffset <= scrollThresholdPx
        if (nearTop) {
            listState.animateScrollToItem(0)
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            top = 8.dp,
            bottom = 88.dp + bottomPadding + if (showPoweredBy) PoweredByHeight else 0.dp
        )
    ) {
        items(items = recentItems, key = { listItemKey(it) }) { item ->
            ListItemRow(item = item, isDark = isDark, accentColor = accentColor, onItemClick = onItemClick, onToggleGroup = onToggleGroup)
        }

        if (historyItems.isNotEmpty()) {
            item(key = "history_header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HorizontalDivider(
                        modifier = Modifier.weight(1f),
                        thickness = 1.dp,
                        color = SdkColors.divider(isDark)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.list_history_section),
                        color = SdkColors.sectionLabel,
                        fontSize = 12.sp
                    )
                }
            }
            items(items = historyItems, key = { listItemKey(it) }) { item ->
                ListItemRow(item = item, isDark = isDark, accentColor = accentColor, onItemClick = onItemClick, onToggleGroup = onToggleGroup)
            }
        }
    }
}

private fun listItemKey(item: ConversationListItem): String = when (item) {
    is ConversationListItem.Single -> "single_${item.conversation.id}"
    is ConversationListItem.Group  -> "group_${item.operatorId}"
}

@Composable
private fun ListItemRow(
    item: ConversationListItem,
    isDark: Boolean,
    accentColor: Color,
    onItemClick: (String) -> Unit,
    onToggleGroup: (String) -> Unit
) {
    when (item) {
        is ConversationListItem.Single ->
            ConversationCard(item = item.conversation, isDark = isDark, accentColor = accentColor, onClick = { onItemClick(item.conversation.id) })
        is ConversationListItem.Group ->
            ConversationGroupItem(group = item, isDark = isDark, accentColor = accentColor, onItemClick = onItemClick, onToggle = { onToggleGroup(item.operatorId) })
    }
}
