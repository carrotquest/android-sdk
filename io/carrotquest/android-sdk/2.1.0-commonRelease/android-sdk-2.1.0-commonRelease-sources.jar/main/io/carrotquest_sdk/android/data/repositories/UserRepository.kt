package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.data.user.UserStateHolder
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject

class UserRepository {
    private val _subject: BehaviorSubject<UserEntity> = BehaviorSubject.create()

    companion object {
        private var instance: UserRepository? = null
        fun getInstance(): UserRepository {
            if (instance == null) instance = UserRepository()
            return instance!!
        }
    }

    fun getUser(): Observable<UserEntity?> = _subject.map { it }

    fun getUserSync(): UserEntity? = UserStateHolder.current()

    fun saveUser(user: UserEntity) {
        UserStateHolder.update(user)
        _subject.onNext(user)
    }
}
