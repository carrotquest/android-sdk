package io.carrotquest_sdk.android.lib.network.responses.utils

import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParseException
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageMetaData
import io.carrotquest_sdk.android.lib.network.responses.messages.Placeholder
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil
import org.json.JSONException
import org.json.JSONObject
import java.util.Locale

fun convertJsonToMessageData(json : JsonElement): MessageData {
    val message = MessageData()
    if (!GsonUtil.jsonElementNotNull(json, F.ID)) {
        throw JsonParseException("message ID is null")
    }

    message.id = json.asJsonObject[F.ID].asString

    if (GsonUtil.jsonElementNotNull(json, F.CREATED)) {
        message.created = json.asJsonObject[F.CREATED].asString
    }

    if (GsonUtil.jsonElementNotNull(json, F.CONVERSATION)) {
        message.conversation = json.asJsonObject[F.CONVERSATION].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.BODY)) {
        message.body = json.asJsonObject[F.BODY].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.BODY_JSON) && json.asJsonObject[F.BODY_JSON].isJsonObject) {
        message.bodyJson = json.asJsonObject[F.BODY_JSON].asJsonObject
    }
    if (GsonUtil.jsonElementNotNull(json, F.DIRECTION)) {
        message.direction = json.asJsonObject[F.DIRECTION].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.READ)) {
        message.read = json.asJsonObject[F.READ].asBoolean
    }
    if (GsonUtil.jsonElementNotNull(json, F.TYPE)) {
        message.type = json.asJsonObject[F.TYPE].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.REMOVED)) {
        message.removed = json.asJsonObject[F.REMOVED].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.EXPIRATION_TIME)) {
        message.expiraionTime = json.asJsonObject[F.EXPIRATION_TIME].asLong
    }


    /* if(jsonElementNotNull(partLastJsonObject, F.SENT_VIA)) {
                partLast.setSentVia(partLastJsonObject.get(F.SENT_VIA).getAsString());
            }*/
    if (GsonUtil.jsonElementNotNull(json, F.SENT_VIA)) {
        val sentVia: String = json.asJsonObject.get(F.SENT_VIA).asString
        message.sentVia = sentVia
        if ("message_manual" == sentVia && message.body != null) {
            val startIndex: Int = message.body.indexOf("https://files.carrotquest.io")
            val endIndex: Int = message.body.indexOf(" style=") - 1
            if (startIndex >= 0 && endIndex >= 0 && endIndex > startIndex) {
                val path: String = message.body.substring(startIndex, endIndex)
                if (URLUtil.isValidUrl(path)) {
                    val attachment = Attachment()
                    attachment.url = path
                    attachment.id = message.id
                    attachment.type = message.type
                    attachment.created = message.created
                    attachment.filename = "file"
                    val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(path).lowercase(Locale.ROOT))
                    attachment.mimeType = mimeType
                    message.attachments.add(attachment)
                }
            }
            val startBodyIndex: Int = message.body.indexOf("<p>")
            val endBodyIndex: Int = message.body.indexOf("<", 2)
            if (startBodyIndex >= 0 && endBodyIndex >= 0 && endBodyIndex > startBodyIndex) {
                message.body = message.body.substring(startBodyIndex, endBodyIndex)
            } else {
                message.body = ""
            }
        }
    }

    if (GsonUtil.jsonElementNotNull(json, F.REPLY_TYPE)) {
        message.replyType = json.asJsonObject[F.REPLY_TYPE].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.RANDOM_ID)) {
        message.randomId = json.asJsonObject[F.RANDOM_ID].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.CONVERSATION_TYPE)) {
        message.conversationType = json.asJsonObject[F.CONVERSATION_TYPE].asString
    }

    if (GsonUtil.jsonElementNotNull(json, F.ACTIONS)) {
        val actions = ArrayList<ActionMessage>()
        val actionsJsonArray = json.asJsonObject[F.ACTIONS].asJsonArray
        for (actionJsonElement in actionsJsonArray) {
            if (actionJsonElement is JsonObject) {
                val actionMessage = ActionMessage()
                if (actionJsonElement.has(F.ID)) {
                    actionMessage.id = actionJsonElement[F.ID].asString
                }
                if (actionJsonElement.has(F.BODY)) {
                    actionMessage.body = actionJsonElement[F.BODY].asString
                }
                if (actionJsonElement.has(F.TYPE)) {
                    actionMessage.type = actionJsonElement[F.TYPE].asString
                }
                if (actionJsonElement.has(F.NEXT_BRANCH_ID)) {
                    actionMessage.nextBranchId = actionJsonElement[F.NEXT_BRANCH_ID].asString
                }
                if (actionJsonElement.has(F.BODY_JSON)) {
                    actionMessage.bodyJson = actionJsonElement[F.BODY_JSON]
                }


                if(actionJsonElement.has(F.BODY_JSON)) {
                    val actionBodyJson = actionJsonElement[F.BODY_JSON].asJsonObject
                    if (actionBodyJson.has(F.PLACEHOLDER)) {
                        val placeholderJson = actionBodyJson[F.PLACEHOLDER].asJsonObject
                        if (placeholderJson.has(F.TYPE) && placeholderJson.has(F.VALUE)) {
                            val type = if(placeholderJson.has(F.TYPE) && !placeholderJson[F.TYPE].isJsonNull) {
                                placeholderJson[F.TYPE].asString
                            } else {
                                ""
                            }

                            val v = if(placeholderJson.has(F.VALUE) && !placeholderJson[F.VALUE].isJsonNull) {
                                placeholderJson[F.VALUE].asString
                            } else {
                                ""
                            }

                            val placeholder = Placeholder(
                                type,
                                v
                            )
                            actionMessage.placeholder = placeholder
                        }
                    }
                }

                actionMessage.messageId = message.id
                actions.add(actionMessage)
            }
        }
        message.actions = actions
    }

    try {
        message.sourceJsonData = JSONObject(Gson().toJson(json))
    } catch (e: JSONException) {
        e.printStackTrace()
    }

    if (GsonUtil.jsonElementNotNull(json, F.ATTACHMENTS)) {
        val attachmentsJsonArray = json.asJsonObject.getAsJsonArray(F.ATTACHMENTS)
        if (attachmentsJsonArray != null) {
            val attachments = ArrayList<Attachment>()
            for (attachmentJsonObject in attachmentsJsonArray) {
                val attachment = Attachment()
                val joAttachment = attachmentJsonObject.asJsonObject
                if (GsonUtil.jsonElementNotNull(joAttachment, F.ID)) {
                    attachment.id = joAttachment[F.ID].asString
                } else {
                    throw JsonParseException("Attachment ID is null")
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.TYPE)) {
                    attachment.type = joAttachment[F.TYPE].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.FILENAME)) {
                    attachment.filename = joAttachment[F.FILENAME].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.CREATED)) {
                    attachment.created = joAttachment[F.CREATED].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.MIME_TYPE)) {
                    attachment.mimeType = joAttachment[F.MIME_TYPE].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.SIZE)) {
                    attachment.size = joAttachment[F.SIZE].asLong
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.URL)) {
                    attachment.url = joAttachment[F.URL].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.STATUS)) {
                    attachment.status = joAttachment[F.STATUS].asString
                }
                attachments.add(attachment)
            }
            message.attachments = attachments
        }
    }

    val messageMetaData = MessageMetaData()
    messageMetaData.replied = false
    messageMetaData.loading = false
    if (json.asJsonObject.has(F.FROM)) {
        if (json.asJsonObject[F.FROM].isJsonObject) {
            val adminFrom = Admin()
            val fromJsonElement = json.asJsonObject[F.FROM].asJsonObject
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.ID)) {
                adminFrom.id = fromJsonElement[F.ID].asString
            }
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.NAME)) {
                adminFrom.name = fromJsonElement[F.NAME].asString
            }
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.TYPE)) {
                adminFrom.type = fromJsonElement[F.TYPE].asString
            }
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.AVATAR)) {
                adminFrom.avatar = fromJsonElement[F.AVATAR].asString
            }
            message.messageFrom = adminFrom
        } else {
            val adminFrom = Admin()
            adminFrom.id = json.asJsonObject[F.FROM].asString
            message.messageFrom = adminFrom
            if (json.asJsonObject[F.META_DATA] != null && json.asJsonObject[F.FROM].isJsonObject) {
                messageMetaData.comment = json.asJsonObject[F.FROM].asJsonObject[F.COMMENT].toString()
                messageMetaData.vote = json.asJsonObject[F.FROM].asJsonObject[F.VOTE].toString().toInt()
            }
        }
        if (json.asJsonObject[F.META_DATA] != null) {
            if (json.asJsonObject.has(F.REPLIED)) {
                messageMetaData.replied = json.asJsonObject[F.REPLIED].asBoolean
            }
            if (json.asJsonObject.has(F.LOADING)) {
                messageMetaData.loading = json.asJsonObject[F.LOADING].asBoolean
            }
        }
    }

    message.messageMetaData = messageMetaData

    return message
}