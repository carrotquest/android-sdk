package io.carrotquest_sdk.android.domain.use_cases.conversation.files

import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment

fun getAttachment(messageId: String, attachmentId: String): Attachment? {
    val message = MessagesRepository.getInstance().getDataSingle()
        .firstOrNull { m->m.id == messageId }

    if(message == null) {
        return  null
    }

    return message.attachments.firstOrNull { a->a.id == attachmentId }
}

fun getAttachments(messageId: String, ): List<Attachment>? {
    val message = MessagesRepository.getInstance().getDataSingle()
        .firstOrNull { m->m.id == messageId }

    if(message == null) {
        return  null
    }

    return message.attachments
}