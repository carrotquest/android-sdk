package io.carrotquest_sdk.android.data.service;

import androidx.annotation.NonNull;

import java.io.File;
import java.util.List;

import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.core.main.CarrotSDK;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.observers.DisposableObserver;

public interface ICarrotService {
    void init(@NonNull String apiKey, CarrotSDK.Callback<Boolean> callback, boolean startSession);
    void deInit();
    boolean isInit();

    void authUser(String id, String userAuthKey);
    void authUser(String id, String userAuthKey, DisposableObserver<User> userDisposableObserver);

    void hashedAuth(String id, String hash, DisposableObserver<User> userDisposableObserver);

    void setUserProperty(List<UserProperty> userProperty);
    void setUserProperty(List<UserProperty> userProperty, DisposableObserver<Boolean> observer);

    void trackEvent(String eventName, String eventParams, DisposableObserver<NetworkResponse> observer);

    void getConversations(String userId, DisposableObserver<UserConversations> observer);
    void getConversations(String userId, String after, DisposableObserver<UserConversations> observer);

    void getConversation(String conversationId, Observer<ConversationResponse> observer);

    void startConversations(String userId, String messageText, DisposableObserver<StartConversationResponse> observer);
    void startConversations(String userId, File file, DisposableObserver<StartConversationResponse> observer);

    void getMessage(String conversationId, String after, DisposableObserver<MessagesResponse> observer);

    void reply(String conversationId, String messageText, boolean fromUser, String randomId, DisposableObserver<ReplyResponse> observer);
    void replyFile(String conversationId, File file, String autoAssign, String randomId, DisposableObserver<ReplyFileResponse> observer);

    void markConversationAsRead(String conversationId, DisposableObserver<NetworkResponse> observer);

    void voteOperator(String messageId, Integer vote, String comment, DisposableObserver<NetworkResponse> observer);
    void voteOperator(String messageId, Integer vote, DisposableObserver<NetworkResponse> observer);

    void updateAutoReply(String messageId, boolean replied, DisposableObserver<NetworkResponse> observer);

    void downloadFile(String messageId, String url, long size, Observer<Integer> observer);

    void setTyping(String conversationId, String messageBody);

    void addInitObserver(Observer<Boolean> initObserver);

    void trackClickByPush(String conversationId, DisposableObserver<NetworkResponse> observer);

    void chooseRoutingBot(String conversationId, DisposableObserver<ChooseRoutingBotResponse> observer);

    String getSaveUserId();

    void setUserConsentContact(String contacts, String partId, String userId, Observer<Boolean> observer);
    void setUserConsentDataProcessing(Boolean dataProcessing, String userId, Observer<Boolean> observer);
}
