package io.carrotquest_sdk.android.lib;

import com.google.gson.JsonObject;

import java.util.List;

import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse;
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse;
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse;
import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by alond on 02.01.18.
 */

public interface CarrotApi {

    @FormUrlEncoded
    @POST("connect")
    Observable<ConnectResponse>
    connect(
            @Field("start_session_random_id") String sessionId,
            @Field("api_key") String apiKey,
            @Field("start_session") Boolean startSession,
            @Field("include_auto_events") Boolean includeAutoEvents,
            @Field("include_js_scripts") Boolean includeJsScripts,
            @Field("include_push_domain") Boolean includePushDomain,
            @Field("browser") String browser,
            @Field("os") String os,
            @Field("device") String device,
            @Field("device_type") String deviceType,
            @Field("token_type") String tokenType,
            @Field("referrer") String referrer
    );

    @FormUrlEncoded
    @POST("connect")
    Observable<ConnectResponse>
    connect(
            @Field("start_session_random_id") String sessionId,
            @Field("api_key") String apiKey,
            @Field("start_session") Boolean startSession,
            @Field("include_auto_events") Boolean includeAutoEvents,
            @Field("include_js_scripts") Boolean includeJsScripts,
            @Field("include_push_domain") Boolean includePushDomain,
            @Field("browser") String browser,
            @Field("os") String os,
            @Field("device") String device,
            @Field("device_type") String deviceType,
            @Field("token_type") String tokenType
    );



    //====================-УДАЛИТЬ ПОСЛЕ ТОГО КАК НА ФРИДОМЕ ВСЕ ПЕРЕЙДУД-==========================
    @FormUrlEncoded
    @POST("connect")
    Observable<ConnectResponse>
    connectForFreedom(
            @Field("start_session_random_id") String sessionId,
            @Field("api_key") String apiKey,
            @Field("start_session") Boolean startSession,
            @Field("include_auto_events") Boolean includeAutoEvents,
            @Field("include_js_scripts") Boolean includeJsScripts,
            @Field("include_push_domain") Boolean includePushDomain,
            @Field("browser") String browser,
            @Field("os") String os,
            @Field("device") String device,
            @Field("device_type") String deviceType,
            @Field("token_type") String tokenType,
            @Field("referrer") String referrer,
            @Field("cq_auth_token") String oldToken
    );

    @FormUrlEncoded
    @POST("connect")
    Observable<ConnectResponse>
    connectForFreedom(
            @Field("start_session_random_id") String sessionId,
            @Field("api_key") String apiKey,
            @Field("start_session") Boolean startSession,
            @Field("include_auto_events") Boolean includeAutoEvents,
            @Field("include_js_scripts") Boolean includeJsScripts,
            @Field("include_push_domain") Boolean includePushDomain,
            @Field("browser") String browser,
            @Field("os") String os,
            @Field("device") String device,
            @Field("device_type") String deviceType,
            @Field("token_type") String tokenType,
            @Field("cq_auth_token") String oldToken
    );
    //==============================================================================================

    @FormUrlEncoded
    @POST("users/app_auth/")
    Observable<AuthResponse> auth(
            @Field("user_id") String userId,
            @Field("hash") String hash,
            @Field("token_type") String tokenType
    );


    @POST("auth/jwt/refresh")
    Observable<RefreshResponse> refresh(
            @Query("update_refresh_token") Boolean updateRefreshToken
    );

    @FormUrlEncoded
    @POST("users/{user_id}/events")
    Observable<NetworkResponse> trackEvent(
            @Path("user_id") String userId,
            @Field("event") String event
    );

    @FormUrlEncoded
    @POST("users/{user_id}/events")
    Observable<NetworkResponse> trackEvent(
            @Path("user_id") String userId,
            @Field("event") String event,
            @Field("params") String params
    );

    @FormUrlEncoded
    @POST("users/{user_id}/props")
    Observable<NetworkResponse> sendProps(
            @Path("user_id") String userId,
            @Field("operations") String operations
    );

    @GET("users/{user_id}")
    Observable<User> getUser(
            @Path("user_id") String userId,
            @Query("by_user_id") Boolean byUserId
    );

    @GET("users/{user_id}")
    Observable<UserResponse> loadUser(
            @Path("user_id") String userId,
            @Query("by_user_id") Boolean byUserId
    );


    @GET("users/{user_id}/conversations")
    Observable<UserConversations> getConversations(
            @Path("user_id") String userId
    );

    @GET("users/{user_id}/conversations")
    Observable<UserConversations> getConversations(
            @Path("user_id") String userId,
            @Query("after") String after,
            @Query("paginate_including") Boolean paginateIncluding,
            @Query("paginate_direction") String paginateDirection
    );

    @GET("conversations/{conversationId}")
    Observable<ConversationResponse> getConversation(@Path("conversationId") String conversationId);

    @FormUrlEncoded
    @POST("users/{user_id}/startconversation")
    Observable<StartConversationResponse> startConversation(
            @Path("user_id") String userId,
            @Field("body") String messageText
    );

   @Multipart
   @POST("users/{user_id}/startconversation")
   Observable<StartConversationResponse> startConversationWithFile(
           @Path("user_id") String userId,
           @Part("boundary") RequestBody requestFile,
           @Part("filename") RequestBody filename,
           @Part MultipartBody.Part file);

    @GET("conversations/{conversation_id}/parts")
    Observable<MessagesResponse> getMessages(
            @Path("conversation_id") String conversationId
    );

    @GET("conversations/{conversation_id}/parts")
    Observable<MessagesResponse> getMessages(
            @Path("conversation_id") String conversationId,
            @Query("paginate_position") String paginatePosition,
            @Query("paginate_including") Boolean paginateIncluding,
            @Query("paginate_direction") String paginateDirection
    );

    @GET("conversations/{conversation_id}/parts")
    Observable<MessagesResponse> getMessages(
        @Path("conversation_id") String conversationId,
        @Query("paginate_position") String paginatePosition,
        @Query("count") Integer count,
        @Query("paginate_including") Boolean paginateIncluding,
        @Query("paginate_direction") String paginateDirection
    );

    @FormUrlEncoded
    @POST("conversations/{conversation_id}/reply")
    Observable<ReplyResponse> reply(
            @Path("conversation_id") String conversationId,
            @Field("body") String messageText,
            @Field("from_user") boolean fromUser,
            @Field("random_id") String randomId
    );

    @FormUrlEncoded
    @POST("users/{userId}/pushes_subscribe")
    Observable<PushSubResponse> sendPushToken(@Path("userId") String userId,
                                              @Field("token") String token,
                                              @Field("type") String type,
                                              @Field("device_guid") String deviceId,
                                              @Field("device") String device,
                                              @Field("device_type") String deviceType,
                                              @Field("os") String os,
                                              @Field("browser") String browser,
                                              @Field("user_agent") String userAgent);

    @FormUrlEncoded
    @POST("users/{userId}/pushes_unsubscribe")
    Observable<PushSubResponse> deletePushToken(@Path("userId") String userId,
                                       @Query("device_guid") String deviceId,
                                       @Field("type") String type);

    @Multipart
    @POST("conversations/{conversationId}/replyfile")
    Observable<ReplyFileResponse> replyFile(
            @Path("conversationId") String conversationId,
            @Part("boundary") RequestBody requestFile,
            @Part MultipartBody.Part file,
            @Part("random_id") RequestBody random_id,
            @Part("auto_assign") RequestBody auto_assign,
            @Part("filename") RequestBody fileName);

    @POST("conversations/{conversationId}/markread")
    Observable<NetworkResponse> markRead(@Path("conversationId") String conversationId);


    @FormUrlEncoded
    @POST("conversationparts/{messageId}/meta_data")
    Observable<NetworkResponse> conversationParts(@Path("messageId") String messageId,
                                                  @Field("meta_data") JsonObject meta_data);


    @FormUrlEncoded
    @POST("conversations/{conversationId}/settyping")
    Observable<NetworkResponse> setTyping(@Path("conversationId") String conversationId,
                                                @Field("body") String messageBody,
                                                @Field("from_user") boolean fromUser);

    @FormUrlEncoded
    @POST("users/{user_id}/setpresence")
    Observable<NetworkResponse> setPresence(@Path("user_id") String userId,
                                            @Field("presence") String presence);

    @FormUrlEncoded
    @POST("users/$self_user/setpresence")
    Observable<NetworkResponse> setPresenceCurrentScreen(
            @Field("presence") String presence,
            @Field("current_sdk_page") String currentScreen);

    @FormUrlEncoded
    @POST("conversationparts/{part_id}/meta_data")
    Observable<NetworkResponse> setMetaData(@Path("part_id") String partId,
                                            @Field("meta_data") String metaData);

    @FormUrlEncoded
    @POST("messages/trackinteraction")
    Observable<NetworkResponse> trackinteraction(@Field("conversation_id") String conversationId,
                                                 @Field("type") String type);

    @GET("chatbots/routing/choose")
    Observable<ChooseRoutingBotResponse> chooseRoutingBot( @Query("conversation") String conversationId);

    @FormUrlEncoded
    @POST("chatbots/routing/start")
    Observable<NetworkResponse> startRoutingBot(
            @Field("chat_bot") String botId,
            @Field("initial_answer_action") String buttonActionId,
            @Field("initial_answer_body") String buttonActionText,
            @Field("random_id") String randomId,
            @Field("conversation") String conversationId
    );

    @FormUrlEncoded
    @POST("chatbots/routing/start")
    Observable<NetworkResponse> startRoutingBot(
            @Field("chat_bot") String botId,
            @Field("initial_answer_action") String buttonActionId,
            @Field("initial_answer_body") String buttonActionText,
            @Field("random_id") String randomId
    );


    @FormUrlEncoded
    @POST("utils/logs")
    Observable<NetworkResponse> sendLog(
            @Field("message_type") String messageType,
            @Field("message") String message,
            @Field("data") String data
    );

    @GET("triggers/trigger_types")
    Observable<TriggersResponse> getTriggers();

    @FormUrlEncoded
    @POST("users/$self_user/triggers")
    Observable<NetworkResponse> sendTrigger(
            @Field("trigger_types") List<String> triggerIds
    );

    @FormUrlEncoded
    @POST("users/$self_user/user_consent")
    Observable<NetworkResponse> setUserConsentContact(@Field("contacts") String contacts,
                                                      @Field("part") String partId,
                                                      @Query("request_user") String userId);

    @FormUrlEncoded
    @POST("users/$self_user/user_consent")
    Observable<NetworkResponse> setUserConsentDataProcessing(@Field("data_processing") boolean dataProcessing,
                                                             @Query("request_user") String userId);
}
