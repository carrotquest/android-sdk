package io.carrotquest_sdk.android.lib.wss.jwt

import com.neovisionaries.ws.client.WebSocket
import com.neovisionaries.ws.client.WebSocketException
import com.neovisionaries.ws.client.WebSocketFactory
import io.carrotquest_sdk.android.domain.use_cases.user.getUserAgent
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.e
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType
import io.carrotquest_sdk.android.lib.wss.Channel
import io.carrotquest_sdk.android.lib.wss.response.WssResponse
import io.carrotquest_sdk.android.lib.wss.utils.CloseReason
import io.carrotquest_sdk.android.lib.wss.utils.SocketListener
import io.carrotquest_sdk.android.lib.wss.utils.getRtsConnectUrl
import io.reactivex.Observer
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import java.io.IOException
import java.net.URI
import java.net.URISyntaxException
import java.util.Locale

private const val tag = "JwtClientWebSocket"

class JwtClientWebSocket(
    private val appId: String,
    private val channels: ArrayList<Channel>,
    private val rtsHost: String,
    private val observers: MutableList<Observer<WssResponse>>
) {
    private var isConnected = false
    private val socketListener = SocketListener(appId)
    private var webSocket: WebSocket? = null

    private var refreshTokenDisposable: Disposable? = null

    fun isConnected(): Boolean {
        return isConnected
    }

//    init {
//        socketListener.setObservers(observers)
//    }

    fun connect(){
        socketListener.setObservers(observers)

        val isActualJwtToken = isActualJwtToken()
        if(!isActualJwtToken) {
            val b = BehaviorSubject.create<String>()
            refreshTokenDisposable = b
                .take(1)
                .subscribeOn(Schedulers.io())
                .subscribe { token ->
                    if (token.isNotEmpty()) {
                        connect()
                        val userRepository = CarrotLib.getLibComponents().userRep
                        val user = userRepository.user
                        user.token = token
                        userRepository.saveUser(user)
                    }
                }
            refreshJwtToken(b)

            return
        }



        Thread {
            try {
                val jwtToken = getJwtToken()
                if (jwtToken.isEmpty()) {
                    e(tag, "jwtToken is empty. rts service isn/'t connect")
                    return@Thread
                }

                val url = getRtsConnectUrl(rtsHost, appId, channels, jwtToken)
                val userAgent = getUserAgent()

                val factory = WebSocketFactory()

                webSocket = factory.createSocket(URI(url))
                webSocket?.addHeader("Authorization", "Token $jwtToken")
                webSocket?.addHeader("User-Agent", "Token $userAgent")
                webSocket?.addListener(socketListener)

                webSocket?.connect()
                isConnected = true

                LogToElk.getInstance()
                    .write(appId, "Rts connect", MessageToElkType.RTS_CONNECT, HashMap())
            } catch (e: WebSocketException) {
                isConnected = false
                e(tag, "WebSocketException: $e")

                val params = HashMap<String, Any>()
                params["web_socket_exception"] = e.toString()
                LogToElk.getInstance()
                    .write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params)
            } catch (e: IOException) {
                isConnected = false
                e(tag, "IOException: $e")

                val params = HashMap<String, Any>()
                params["io_exception"] = e.toString()
                LogToElk.getInstance()
                    .write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params)
            } catch (e: URISyntaxException) {
                isConnected = false
                e(tag, "URISyntaxException: $e")

                val params = HashMap<String, Any>()
                params["uri_syntax_exception"] = e.toString()
                LogToElk.getInstance()
                    .write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params)
            } catch (e: Exception) {
                isConnected = false
                e(tag, "Just exception: $e")

                val params = HashMap<String, Any>()
                params["exception"] = e.toString()
                LogToElk.getInstance()
                    .write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params)
            }

        }.start()
    }


    private fun stop(){
        Thread {
            socketListener.setObservers(ArrayList())
            webSocket?.disconnect()
            isConnected = false
        }.start()
    }

    fun getAppId(): String {
        return this.appId
    }

    fun stop(reason: CloseReason) {
        stop()

        if (reason != CloseReason.NONE) {
            val params = java.util.HashMap<String, Any>()
            params["reason"] = reason.name.lowercase(Locale.getDefault())
            LogToElk.getInstance()
                .write(appId, "Rts disconnect", MessageToElkType.RTS_DISCONNECT, params)
        }
    }
}