package io.carrotquest_sdk.android.data.network.wss_responses

import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.core.constants.Flags
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsAllHelper
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage.DirectionMessage
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.util.concurrent.TimeUnit

class   ConversationPartsBatchRtsMessage: IRtsMessage {

    private val tag = "ConversationPartsBatchRtsMessage"

    lateinit var conversation: DataConversation
    lateinit var randomId: String
    lateinit var parts: ArrayList<MessageData>

    private var conversationClosed = false
    private var userRepository: UserRepository = CarrotInternal.getLibComponent().userRepository
    private var messagesRepository: MessagesRepository = MessagesRepository.getInstance()
    private var conversationsRepository: ConversationsRepository =
        ConversationsRepository.getInstance()

    override fun process() {


        //Обновляем диалог в базе
        var isConvUpdate = false
        val partLast = conversation.partLast

        if (partLast != null && !partLast.actions.isNullOrEmpty()) {
            val actions = partLast.actions
            val nArray = ArrayList<ActionMessage>()
            for (action in actions) {
                action.messageId = partLast.id
                nArray.add(action)
            }
            if (nArray.isNotEmpty()) {
                isConvUpdate = true
            }
            partLast.actions = nArray
        }

        val conversationId = conversation.id
        if(conversationId != null) {
            val foundConv =
                ConversationsRepository.getInstance().getConversationById(conversationId)
            if (foundConv != null) {
                ConversationsRepository.getInstance()
                    .updateConversation(foundConv.id, conversation)
                isConvUpdate = true
            } else {
                conversation.randomId = randomId
                ConversationsRepository.getInstance().addConversation(conversation)
            }

            if (!isConvUpdate) {
                ConversationsRepository.getInstance()
                    .updateConversation(conversationId, conversation)
            }
        }

        this.parts.forEach { m ->
            createAndSaveMessage(m)
        }
    }

    private fun createAndSaveMessage(message: MessageData) {
        if ((message.read == null || !message.read)
            && (!conversationClosed)
        ) {
            if (fromAdminToUser(message) || isInputBotAction(message) || isButtonsBotAction(message)) {
                val user: User = userRepository.user
                if (message.conversation != conversationsRepository.getOpenedConversationId() && Flags.NEW_CONVERSATION_ID_ARG != conversationsRepository.getOpenedConversationId()) {
                    val conversationsUnread = java.util.ArrayList(user.conversationsUnread)
                    conversationsUnread.remove(message.conversation)
                    conversationsUnread.add(message.conversation)
                    user.conversationsUnread = conversationsUnread
                    user.hasConversations = true
                }
                userRepository.saveUser(user)
                if (message.bodyJson != null && message.bodyJson.isJsonObject) {
                    if (message.bodyJson.asJsonObject.has("is_first_branch")) {
                        if (!message.bodyJson.asJsonObject.get("is_first_branch").asBoolean) {
                            messagesRepository.addWssMessage(message)
                            logMessage(
                                "RTS: add message to repository. Its first brunch from bot.",
                                message
                            )
                        }
                    } else {
                        messagesRepository.addWssMessage(message)
                        logMessage("RTS: add message to repository", message)
                    }
                }

                messagesRepository.updateMessage(message)
                logMessage("RTS: update message to repository.", message)
            } else {
                val x = Single.just(true)
                    .delay(2, TimeUnit.SECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe { _: Boolean? ->
                        messagesRepository.updateMessage(message)

                        logMessage("RTS: update message to repository.", message)
                    }
            }
        }

        var directionMessage = DirectionMessage.USER_TO_ADMIN
        if (ResponseFields.ADMIN_2_USER == message.direction) {
            directionMessage = DirectionMessage.ADMIN_TO_USER
        }

        var messageType = IncomingMessage.MessageType.TEXT
        if (message.attachments != null && message.attachments.size > 0) {
            messageType = IncomingMessage.MessageType.ATTACHMENT
        }

        val incomingMessage = IncomingMessage(
            IncomingMessage.IncomingMessageSourceType.RTS,
            message.id,
            message.conversation,
            message.body,
            directionMessage,
            messageType
        )
        NotificationsAllHelper.getInstance().pushMessage(incomingMessage)
    }

    private fun isInputBotAction(message: MessageData): Boolean {
        if ("message_chat_bot" == message.sentVia && message.actions != null && message.actions.size > 0) {
            val firstAction: ActionMessage = message.actions[0]
            return "property_field" == firstAction.type
        }
        return false
    }

    private fun isButtonsBotAction(message: MessageData): Boolean {
        if ("message_chat_bot" == message.sentVia && message.actions != null && message.actions.size > 0) {
            val firstAction: ActionMessage = message.actions[0]
            return "button" == firstAction.type || "meet" == firstAction.type
        }
        return false
    }

    private fun fromAdminToUser(message: MessageData): Boolean {
        return message.direction != null
                && ResponseFields.ADMIN_2_USER == message.direction.lowercase()
    }

    private fun logMessage(title: String, message: MessageData) {
        val params = HashMap<String, Any>()
        params["log_message_id"] = message.id
        params["log_conversation_id"] = message.conversation
        params["log_body"] = message.body

        LogToElk.getInstance().write(
            Carrot.getAppId(),
            title,
            MessageToElkType.RTS_MESSAGE_ADDED_TO_REPO,
            params
        )
    }
}