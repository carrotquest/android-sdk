package io.carrotquest_sdk.android.lib.managers

import android.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.reactivex.Observable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.concurrent.TimeUnit

class UserPresenceService private constructor() {

    private var isRun = false
    private var disposable: Disposable? = null
    private var firstDisposable: Disposable? = null
    private var offlineDisposable: Disposable? = null


    companion object {
        private const val TAG = "UserPresenceService"
        private var instance: UserPresenceService? = null
        fun getInstance(): UserPresenceService {
            if (instance == null) {
                instance = UserPresenceService()
            }
            return instance!!
        }
    }

    fun run() {
        if (isRun) {
            stop()
        } else {
            sendEventAboutStop()
        }
        isRun = true

        val userId = CarrotLib.getLibComponents().userRep.user.id
        if(userId != null && userId.isNotEmpty()) {
            firstDisposable =
                CarrotLib.getLibComponents().carrotApi.setPresence(userId, F.ONLINE_USER)
                    .take(1)
                    .subscribeOn(Schedulers.io())
                    .onErrorReturn {
                        val errorResult = NetworkResponse()
                        val meta= Meta()
                        meta.status = 400
                        errorResult.meta = meta
                        return@onErrorReturn errorResult
                    }
                    .subscribe({

                    }, {
                    })
        }
        disposable = Observable
                .interval(30, TimeUnit.SECONDS, Schedulers.newThread())
                .subscribe({
                    if(userId != null && userId.isNotEmpty()) {
                        val d = CarrotLib.getLibComponents().carrotApi.setPresence(userId, F.ONLINE_USER)
                            .take(1)
                            .subscribeOn(Schedulers.io())
                            .onErrorReturn {
                                val errorResult = NetworkResponse()
                                val meta= Meta()
                                meta.status = 400
                                errorResult.meta = meta
                                return@onErrorReturn errorResult
                            }
                            .subscribe({

                            }, {
                                Log.e(TAG, "$it")
                            })
                    }
                }, {
                    Log.e(TAG, it.toString())
                })
    }

    private fun sendEventAboutStop() {
        val userId = CarrotLib.getLibComponents().userRep.user.id
        offlineDisposable = CarrotLib.getLibComponents().carrotApi
            .setPresence(userId, F.OFFLINE_IDLE_USER)
            .take(1)
            .onErrorReturn {
                val errorRes = NetworkResponse()
                errorRes.meta = Meta()
                errorRes.meta.errorMessage = it.message
                errorRes.meta.error = it.toString()
                errorRes.meta.status = 400
                errorRes
            }
            .subscribe({
                if (offlineDisposable != null && !offlineDisposable?.isDisposed!!) {
                    offlineDisposable?.dispose()
                }

            }, {
                Log.e(TAG, "$it")
            })
    }

    fun stop() {
        isRun = false
        if (disposable != null && !disposable?.isDisposed!!) {
            disposable?.dispose()
        }

        if (firstDisposable != null && !firstDisposable?.isDisposed!!) {
            firstDisposable?.dispose()
        }
    }
}