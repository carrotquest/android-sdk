package io.carrotquest_sdk.android.domain.use_cases.agreements

import com.google.gson.JsonObject
import io.carrotquest_sdk.android.data.service.CarrotService
import io.carrotquest_sdk.android.lib.CarrotLib
import io.reactivex.observers.DisposableObserver

data class TrackContacts(
    val email: String?,
    val phone: String?,
)

/**
 * Запрос на создание свойства и события о разрешении сбора контактных данных
 */
fun allowTrackContactsUseCase(contacts: TrackContacts, partId: String) {
    val userId = CarrotLib.getLibComponents().userRep.user.id ?: ""
    if(userId.isEmpty()) {
        return
    }

    val jsContacts = JsonObject()
    val hasPhone = contacts.phone != null
    if (hasPhone) {
        jsContacts.addProperty("phone", contacts.phone)
    }

    val hasEmail = contacts.email != null
    if (hasEmail) {
        jsContacts.addProperty("email", contacts.email)
    }


    CarrotService.getInstance()
        .setUserConsentContact(jsContacts.toString(), userId, partId, object : DisposableObserver<Boolean>() {
            override fun onNext(result: Boolean) {
                if(result) {
                    if(hasPhone) {
                        updateAppSettings("phone_storage_is_allowed", true)
                    }

                    if(hasEmail) {
                        updateAppSettings("email_storage_is_allowed", true)
                    }
                }
            }

            override fun onError(e: Throwable) {
            }

            override fun onComplete() {
            }
        })

}