package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.wss.utils.shPrefTagKey

fun clearRtsDataIfNeed(context: Context = CarrotLib.getLibComponents().getContext(), appId: String) {
    val jwtToken = getJwtToken()

    if (jwtToken.isEmpty()) {
        val oldToken = SharedPreferencesLib.getString(context, "CarrotToken")
        if (oldToken.isNotEmpty() &&
            (oldToken.contains("usersdkandroid") || oldToken.contains("sdk_user_android"))) {
            SharedPreferencesLib.clearPreference(context, shPrefTagKey + appId)
            SharedPreferencesLib.clearPreference(context, shPrefTagKey + appId)

        }
    }
}