package io.carrotquest_sdk.android.core.util.sentry;

import android.content.Context;

import io.carrotquest_sdk.android.BuildConfig;
//import io.sentry.Sentry;



public class SentryCQ_SDK {
    private static SentryCQ_SDK instance;

    private SentryCQ_SDK(Context context, String dsn) {
//        SentryAndroid.init(context, options -> {
//            options.setDsn(dsn);
//            options.setRelease(BuildConfig.VERSION_SDK_NAME);
//            options.setBeforeSend((event, hint) -> {
//                if(hint instanceof String && hint.equals("cq_sdk")) {
//                    return event;
//                }
//                return null;
//            });
//        });
    }

    public static void init(Context context) {
        if (instance == null) {
            instance = new SentryCQ_SDK(context, "https://03dfe81a4f434f11b3c54d94c88b4bfb@sentry.io/1463162");
        }
    }
}
