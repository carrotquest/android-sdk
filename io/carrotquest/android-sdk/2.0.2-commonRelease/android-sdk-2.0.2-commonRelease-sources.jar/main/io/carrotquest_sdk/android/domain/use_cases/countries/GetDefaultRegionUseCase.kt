package io.carrotquest_sdk.android.domain.use_cases.countries

import java.util.Locale


class GetDefaultRegionUseCase {
    fun call(settingsLocale: String): String {
        try {
            val currentLocale = Locale.getDefault()
            val countryCode = currentLocale.country // Получение кода страны
            if (countryCode.length != 2) { //Что-то тут не чисто. Попробуем взять из настроек аппа
                if (settingsLocale.length > 2 && settingsLocale.contains("-")) {
                    val localeParts = settingsLocale.split("-")
                    return localeParts.last()
                } else if (settingsLocale.length == 2) {
                    return settingsLocale
                } else {
                    return "us"
                }
            } else {
                return countryCode
            }
        } catch (e: Exception) {
            return "us"
        }
    }
}