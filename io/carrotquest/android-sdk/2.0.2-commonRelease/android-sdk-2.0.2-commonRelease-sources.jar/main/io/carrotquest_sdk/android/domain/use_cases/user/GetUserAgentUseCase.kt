package io.carrotquest_sdk.android.domain.use_cases.user

import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.util.huawei.isHuawei
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.isDashly

fun getUserAgent(): String {
    val isDashly = isDashly()
    val nameSDK = if(isDashly) {
        "DashlySDK"
    } else {
        "CarrotquestSDK"
    }

    val versionSDK = BuildConfig.VERSION_SDK_NAME
    val os = if(isHuawei()) {
        "Huawei [huawei_push] 1.0.0"
    } else {
        "Android"
    }

    val osVersion = Build.VERSION.RELEASE

    val deviceName = getDeviceName()

    val appName = getAppName()
    val appVersion = getAppVersion()
    val appVersionCode = getAppVersionCode()
    val packageName = getPackageName()

    //<SDKName>/<SDKVersion> (os=<OSName>; osVersion=<OSVersion>; deviceName=<DeviceModel>) <AppName>/<AppVersion> (build=<buildNumber>; bundleID=<bundleID>)
    //CarrotquestSDK/2.14.0-beta15 (os=iOS; osVersion=18.5; deviceName=iPhone12,1(iPhone 11)) UltimateTestSDK/2.14.0 (build=14 bundleID=io.cq.sdk.ultimate-test-app.UltimateTestSDK)
    val originalUserAgentStr = "$nameSDK/$versionSDK (os=$os; osVersion=$osVersion; deviceName=$deviceName) $appName/$appVersion (build=$appVersionCode bundleID=$packageName)"

    return sanitizeUserAgent(originalUserAgentStr)
}

private fun getDeviceName(): String {
    val manufacturer = Build.MANUFACTURER
    val model = Build.MODEL
    if (model.startsWith(manufacturer, ignoreCase = true)) {
        return model
    }

    return "$manufacturer $model"
}

private fun getAppName(): String {
    val context = CarrotLib.getLibComponents().context
    val applicationInfo = context.applicationInfo
    return context.packageManager.getApplicationLabel(applicationInfo).toString()
}

private fun getAppVersion(): String {
    val context = CarrotLib.getLibComponents().context
    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    val versionName = packageInfo.versionName

    return versionName?:"-"
}

private fun getAppVersionCode(): String {
    val context = CarrotLib.getLibComponents().context
    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    val versionCode = PackageInfoCompat.getLongVersionCode(packageInfo)

    return versionCode.toString()
}

private fun getPackageName(): String {
    val context = CarrotLib.getLibComponents().context
    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    val packageName = packageInfo.packageName

    return packageName
}


private fun sanitizeUserAgent(userAgent: String): String {
    val transliterationMap = mapOf(
        "А" to "A", "Б" to "B", "В" to "V", "Г" to "G", "Д" to "D", "Е" to "E",
        "Ё" to "E", "Ж" to "Zh", "З" to "Z", "И" to "I", "Й" to "Y", "К" to "K",
        "Л" to "L", "М" to "M", "Н" to "N", "О" to "O", "П" to "P", "Р" to "R",
        "С" to "S", "Т" to "T", "У" to "U", "Ф" to "F", "Х" to "Kh", "Ц" to "Ts",
        "Ч" to "Ch", "Ш" to "Sh", "Щ" to "Shch", "Ъ" to "-", "Ы" to "Y", "Ь" to "-",
        "Э" to "E", "Ю" to "Yu", "Я" to "Ya",
        "а" to "a", "б" to "b", "в" to "v", "г" to "g", "д" to "d", "е" to "e",
        "ё" to "e", "ж" to "zh", "з" to "z", "и" to "i", "й" to "y", "к" to "k",
        "л" to "l", "м" to "m", "н" to "n", "о" to "o", "п" to "p", "р" to "r",
        "с" to "s", "т" to "t", "у" to "u", "ф" to "f", "х" to "kh", "ц" to "ts",
        "ч" to "ch", "ш" to "sh", "щ" to "shch", "ъ" to "-", "ы" to "y", "ь" to "-",
        "э" to "e", "ю" to "yu", "я" to "ya"
    )

    return userAgent.map { char ->
        when {
            char.isASCII() -> char.toString() // Оставляем допустимые символы
            transliterationMap.containsKey(char.toString()) -> transliterationMap[char.toString()]
            else -> "_" // Замена для всех остальных
        }
    }.joinToString("")
}

// Расширение для проверки символа на принадлежность к ASCII
private fun Char.isASCII() = this in '\u0020'..'\u007E'
