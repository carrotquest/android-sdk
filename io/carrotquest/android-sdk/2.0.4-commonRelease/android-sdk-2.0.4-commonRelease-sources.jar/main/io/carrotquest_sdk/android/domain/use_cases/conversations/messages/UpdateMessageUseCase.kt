package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.JsonObject
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.Observable
import java.util.*


private const val tag = "updateMessageUseCase"
fun Observable<String>.updateAutoReplayLoading(value: Boolean) : Observable<String> {
    return Observable.defer {
        this.flatMap {messageId->
            this.getMessage(messageId)
                    .take(1)
                    .doOnNext {
                        val message = it.value
                        if(message != null) {
                            message.messageMetaData?.loading = value
                            MessagesRepository.getInstance().updateMessage(message)
                        }
                    }
                    .subscribe()

            return@flatMap Observable.just(messageId)
        }
    }
}

fun Observable<String>.updateAutoReplayReplied(value: Boolean) : Observable<String> {
    return Observable.defer {
        this.flatMap {messageId->
            this.getMessage(messageId)
                    .take(1)
                    .doOnNext {
                        val message = it.value
                        if(message != null) {
                            message.messageMetaData?.replied = value
                            MessagesRepository.getInstance().updateMessage(message)
                        }
                    }
                    .doOnError {
                        Log.e("${tag}_updateAutoReplayReplied", it.message)
                    }
                    .subscribe()

            return@flatMap Observable.just(messageId)
        }
    }
}

fun Observable<String>.updateAutoReplayLocal(value: MessageData) : Observable<String> {
    return Observable.defer {
        this.flatMap {messageId->
            MessagesRepository.getInstance().updateMessage(message = value)
            return@flatMap Observable.just(messageId)
        }
    }
}

fun Observable<String>.updateAutoReplay(messageId: String, replied: Boolean) : Observable<Boolean> {
    return Observable.defer {
        this.flatMap {messageId->
            val bodyMetaDataObject = JsonObject()
            bodyMetaDataObject.addProperty("replied", replied)
            return@flatMap CarrotInternal.getService().carrotLib.conversationParts(messageId, bodyMetaDataObject)
                    .take(1)
                    .map { x->x.status == 200}

            //return@flatMap Observable.just(messageId)
        }
    }
}

fun Observable<String>.updateStatusMessage(message: Optional<MessageData>, status: String) : Observable<String> {
    return Observable.defer {
        this.flatMap { conversationId ->
            val m = message.value
            if (m != null) {
                m.status = status
                MessagesRepository.getInstance().updateMessage(m)
            }
            return@flatMap Observable.just(conversationId)
        }
                .doOnError {
                    Log.e("${tag}_updateStatusMessage", it.toString())
                }
                .take(1)
    }
}

fun Observable<String>.updateConversationMessage(message: Optional<MessageData>) : Observable<String> {
    return Observable.defer {
        this.flatMap { conversationId ->
            val m = message.value
            if (m != null) {
                m.conversation = conversationId

                val sourceObject = m.sourceJsonData
                if(sourceObject != null) {
                    if(sourceObject.has(F.STATUS)) {
                        sourceObject.remove(F.STATUS)
                    }
                    sourceObject.put(F.STATUS, MessageStatus.LOADED.name.lowercase(Locale.getDefault()))
                }
                m.sourceJsonData = sourceObject

                MessagesRepository.getInstance().updateMessage(m)
            }

            return@flatMap Observable.just(conversationId)
        }
    }
}


fun Observable<String>.updateMessage(message: Optional<MessageData>) : Observable<String> {
    return Observable.defer {
        this.flatMap { conversationId ->
            val m = message.value
            if (m != null) {
                m.conversation = conversationId
                MessagesRepository.getInstance().updateMessage(m)
            }

            return@flatMap Observable.just(conversationId)
        }
    }
}