package io.carrotquest_sdk.android.lib.managers.network;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import io.carrotquest_sdk.android.lib.managers.IStateManager;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class NetworkManager implements IStateManager {
    private final static String CONNECTIVITY_ACTION = "android.net.conn.CONNECTIVITY_CHANGE";

    private static final String TAG = "NetworkManager";

    private final static String URL_FOR_PING = "https://www.google.com/"; //BuildConfig.CARROT_URL;
    private final static int MAX_PING_COUNT = 5;
    private final static int PING_TIME_OUT = 2000;   //MS
    private final static int MAX_RETRY_DELAY = 600;  //SEC
    private int retryTime = 10; //SEC
    private int currentTry = 0;

    private PublishSubject<Boolean> connectSubject;
    private NetworkStateReceiver networkStateReceiver;

    private Disposable disposableNetworkState;

    private Context context;
    private CompositeDisposable compositeDisposable;

    private boolean hasInternet = false;

    @SuppressLint("StaticFieldLeak")
    private static NetworkManager instance;

    public static NetworkManager getInstance(Context _context) {
        if (instance == null) {
            instance = new NetworkManager();
            instance.context = _context;
            instance.compositeDisposable = new CompositeDisposable();
            instance.connectSubject = PublishSubject.create();
            instance.networkStateReceiver = new NetworkStateReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction(CONNECTIVITY_ACTION);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    instance.context.registerReceiver(instance.networkStateReceiver, filter, android.content.Context.RECEIVER_EXPORTED);
                } else {
                    instance.context.registerReceiver(instance.networkStateReceiver, filter);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        try {
            Runnable r = () -> {
                try {
                    instance.ping();
                } catch (Exception e) {
                    Log.e("NetWorkManager", e.toString());
                }
            };
            Thread t = new Thread(r);
            t.start();
        } catch (Exception e) {
            Log.d("error start timer", e.toString());
        }

        return instance;
    }

    void onConnect() {
        Observable<Boolean> connectObservable = Observable.create(emitter -> emitter.onNext(ping()));

        connectObservable
                .retryWhen(throwableObservable -> throwableObservable.delay(retryTime, TimeUnit.SECONDS))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                //.delay(2, TimeUnit.SECONDS)
                .subscribe(new Observer<Boolean>(){

                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Boolean hasConnect) {
                        hasInternet = hasConnect;
                        connectSubject.onNext(hasConnect);
                    }

                    @Override
                    public void onError(Throwable e) {
                        hasInternet = false;
                        connectSubject.onNext(false);
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    void offConnect() {
        hasInternet = false;
        connectSubject.onNext(false);
    }

    @Override
    public void addObserver(Consumer<Boolean> observer, Consumer<Throwable> errorConsumer, Action complete) {
        if(compositeDisposable == null || compositeDisposable.isDisposed()) {
            compositeDisposable = new CompositeDisposable();
        }

        if(connectSubject.hasComplete()) {
            connectSubject = PublishSubject.create();
        }

        try {
            compositeDisposable.add(connectSubject.subscribe(observer, errorConsumer, complete));
        }catch (Exception e) {
            Log.e(TAG, e.toString());
        }
    }

    @Override
    public void deInit() {
        if (networkStateReceiver != null) {
            try {
                context.unregisterReceiver(networkStateReceiver);
            }
            catch (Exception e) {
                Log.e(TAG, e.toString());
            }
        }
        connectSubject.onComplete();
        compositeDisposable.dispose();
        instance = null;
    }

    public static boolean isAirplaneModeOn() {
        return Settings.System.getInt(instance.context.getContentResolver(),
                Settings.System.AIRPLANE_MODE_ON, 0) != 0;

    }

    /**
     * Возвращет флаг доступа до URL_FOR_PING = @URL_FOR_PING;
     *
     * @return Доступен ли URL
     */
    private Boolean ping() throws Exception {

        boolean needNewThrow = false;
        currentTry++;

        int currentTryPingCount = 1;
        while (currentTryPingCount < MAX_PING_COUNT) {
            try {
                currentTryPingCount++;
                URL url = new URL(URL_FOR_PING);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Connection", "close");
                urlConnection.setConnectTimeout(PING_TIME_OUT);
                urlConnection.connect();
                int code = urlConnection.getResponseCode();
                if (code == HttpURLConnection.HTTP_OK) {
                    currentTry = 0;
                    retryTime = 10;
                    hasInternet = true;
                    return true;
                } else {
                    return false;
                }
            } catch (IOException ioExc) {
                needNewThrow = true;
            } catch (Exception e) {
                needNewThrow = true;
            }
        }

        //Увеличиваем интервал между попытками соединения
        if (retryTime < MAX_RETRY_DELAY && currentTry % 10 == 0) {
            retryTime += 10;
            //Если полдключения так и нет, а мы все еще хотим достучаться,
            // то надо перезаписаться на поток данных, увеличив при этом интервал проверок
            if (disposableNetworkState != null && !disposableNetworkState.isDisposed()) {
                disposableNetworkState.dispose();
                onConnect();
                needNewThrow = false;
            }
        }

        if (needNewThrow) {
            throw new Exception("network not available");
        }


        return true;
    }

    public boolean getHasConnect() {
        return hasInternet;
    }

    public String getConnectionType() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();

        if(info == null) {
            return "";
        }

        if(info.getType() == ConnectivityManager.TYPE_WIFI) {
            return "WIFI";
        }

        if(info.getType() == ConnectivityManager.TYPE_MOBILE) {
            return "MOBILE";
        }

        if(info.getType() == ConnectivityManager.TYPE_VPN) {
            return "VPN";
        }

        return "OTHER";

    }
}
