package io.carrotquest_sdk.android.presentation.mvp.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick

class PushTapReceiver: BroadcastReceiver() {

    companion object {
        const val conversationIdExtraKey = "conversationIdExtraKey"
        const val conversationTypeExtraKey = "conversationTypeExtraKey"
        const val linkExtraKey = "linkExtraKey"
    }

    override fun onReceive(p0: Context, p1: Intent) {
        //Отправим событие для статистики (событие Клик на пуш)
        val conversationId: String? = if (p1.hasExtra(conversationIdExtraKey)) {
            p1.getStringExtra(conversationIdExtraKey)
        } else {
            ""
        }
        val conversationType: String? = if (p1.hasExtra(conversationTypeExtraKey)) {
            p1.getStringExtra(conversationTypeExtraKey)
        } else {
            ""
        }
        if (conversationId != null && conversationType != null && conversationType == "sdk_push") {
            trackClick(conversationId, object : CarrotSDK.Callback<Boolean> {
                override fun onResponse(result: Boolean?) {

                }

                override fun onFailure(t: Throwable?) {
                }
            })
        }

        val link: String? = if (p1.hasExtra(linkExtraKey)) {
            p1.getStringExtra(linkExtraKey)
        } else {
            ""
        }

        if (link == null || link.isEmpty()) {
            val pm = CarrotInternal.getLibComponent().contextSdk.packageManager
            val intent =
                pm.getLaunchIntentForPackage(CarrotInternal.getLibComponent().contextSdk.packageName)

            intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent?.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            intent?.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            CarrotInternal.getLibComponent().contextSdk.startActivity(intent)
        } else {
            val intent = Intent(Intent.ACTION_VIEW)
            if (!link.contains("://")) {
                intent.data = Uri.parse("https://$link")
            } else {
                intent.data = Uri.parse(link)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            p0.startActivity(intent)
        }
    }
}