package io.carrotquest_sdk.android.presentation.mvp.notifications

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.domain.use_cases.popup.getPopUpEntity
import io.carrotquest_sdk.android.domain.use_cases.popup.showPopup
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackUtm
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import java.util.concurrent.TimeUnit

class PushTapActivity : AppCompatActivity() {
    private val compositeDisposable = CompositeDisposable()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_push_tap)

        createIntentAndStartActivity()
    }

    override fun onDestroy() {
        if(!compositeDisposable.isDisposed) {
            compositeDisposable.dispose()
            compositeDisposable.clear()
        }

        super.onDestroy()
    }

    private fun createIntentAndStartActivity() {
        //Отправим событие для статистики (событие Клик на пуш)
        val conversationId: String? = if (intent.hasExtra(PushTapReceiver.conversationIdExtraKey)) {
            intent.getStringExtra(PushTapReceiver.conversationIdExtraKey)
        } else {
            ""
        }
        val conversationType: String? =
            if (intent.hasExtra(PushTapReceiver.conversationTypeExtraKey)) {
                intent.getStringExtra(PushTapReceiver.conversationTypeExtraKey)
            } else {
                ""
            }
        if (conversationId != null && conversationType != null && conversationType == "sdk_push") {
            Carrot(this)
            trackClick(conversationId, object : CarrotSDK.Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                    finish()
                }

                override fun onFailure(t: Throwable?) {
                    finish()
                }

            })
        }

        val link: String? = if (intent.hasExtra(PushTapReceiver.linkExtraKey)) {
            intent.getStringExtra(PushTapReceiver.linkExtraKey)
        } else {
            ""
        }


        if (link.isNullOrEmpty()) {
            val pm = this.packageManager
            val intent =
                pm.getLaunchIntentForPackage(this.packageName)

            if (conversationType == "block_popup_small") {
                SharedPreferencesLib.saveString(this, "need_show_popup_conv_id", conversationId)
                //PushNotificationHelper.getInstance().clearNotificationsByConversationType("block_popup_small")
                clearPopupNotifications()


                if (conversationId != null) {
                    compositeDisposable.add(Observable.just(conversationId)
                        .getPopUpEntity(conversationId)
                        .take(1)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(Consumer { popUpOpt ->
                            if (popUpOpt.value != null) {
                                Observable.just(popUpOpt.value)
                                    .subscribeOn(Schedulers.io())
                                    .delay(2, TimeUnit.SECONDS)
                                    .showPopup()
                                    .take(1)
                                    .subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe()
                            }
                        })
                    )
                }
            }

            intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent?.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            intent?.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            intent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent?.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            this.overridePendingTransition(0, 0)

            this.startActivity(intent)
        } else {
            val intent = Intent(Intent.ACTION_VIEW)
            if (!link.contains("://")) {
                intent.data = Uri.parse("https://$link")
            } else {
                intent.data = Uri.parse(link)
            }


            //Trac UTMs
            trackUtm(link)

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            this.overridePendingTransition(0, 0)
            try {
                this.startActivity(intent)
            } catch (e: Exception) {
                val pm = this.packageManager
                val intentX =
                    pm.getLaunchIntentForPackage(this.packageName)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                this.overridePendingTransition(0, 0)
                this.startActivity(intentX)
            }
        }
    }

    private fun clearPopupNotifications() {
        val ob = this.getSystemService(Context.NOTIFICATION_SERVICE)
        if(ob !is NotificationManager) {
            return
        }

        val notificationManager =
            this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (notification in notificationManager.activeNotifications) {
                if (notification != null
                    && notification.tag != null
                    && notification.tag.contains("block_popup_small")
                ) {
                    notificationManager.cancel(notification.tag, notification.id)
                }
            }
        }
    }
}