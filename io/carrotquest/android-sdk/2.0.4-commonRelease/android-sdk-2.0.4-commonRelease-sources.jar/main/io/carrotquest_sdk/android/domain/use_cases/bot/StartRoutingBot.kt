package io.carrotquest_sdk.android.domain.use_cases.bot

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers

fun <T> Observable<T>.startRoutingBot(botId: String,
                                      answerActionId: String,
                                      answerActionText: String,
                                      randomId: String?,
                                      conversationId: String?) : Observable<Boolean> {

    if(answerActionId.isEmpty() || answerActionText.isEmpty()) {
        return Observable.just(false)
    }

    if(!conversationId.isNullOrEmpty() && !conversationId.contains("routing")) {
        return Observable.defer {
            return@defer this.flatMap {
                CarrotInternal.getService().carrotLib
                    .startRoutingBot(
                        botId,
                        answerActionId,
                        answerActionText,
                        randomId,
                        conversationId
                    )
                    .take(1)
                    .subscribeOn(Schedulers.io())
                    .onErrorReturn { t ->
                        return@onErrorReturn NetworkResponse("$t")
                    }
                    .map { x ->
                        val result = x.meta != null && x.meta?.status == 200
                        return@map result
                    }
            }
        }
    } else {
        return Observable.defer {
            return@defer this.flatMap {
                CarrotInternal.getService().carrotLib
                    .startRoutingBot(botId, answerActionId, answerActionText, randomId)
                    .take(1)
                    .subscribeOn(Schedulers.io())
                    .take(1)
                    .map { x ->
                        x.meta != null && x.meta?.status == 200
                    }
            }
        }
    }
}

