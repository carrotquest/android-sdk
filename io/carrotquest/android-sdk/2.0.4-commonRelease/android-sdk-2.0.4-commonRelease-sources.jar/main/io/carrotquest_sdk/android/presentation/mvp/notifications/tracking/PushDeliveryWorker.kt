package io.carrotquest_sdk.android.presentation.mvp.notifications.tracking

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository


class PushDeliveryWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        Log.d("PushDeliveryWorker", "doWork")
        val conversationId = inputData.getString("CONVERSATION_ID") ?: return Result.failure()

        Log.d("PushDeliveryWorker", "conversationId: $conversationId")
        return try {
            val context = CarrotInternal.getLibComponent().contextSdk

            Carrot.setupWithoutConnect(context)
            val response = CarrotInternal.getService().carrotLib.markRead(conversationId).blockingFirst()

            Log.d("PushDeliveryWorker", "response.status: ${response.status}")
            if(response.status != 200) {
                Result.retry()
            } else {
                ConversationsRepository.getInstance().removeUnreadConversation(conversationId)
                PushStorage.removePushId(applicationContext, conversationId)

                Result.success()
            }
        } catch (e: Exception) {
            Log.d("PushDeliveryWorker", "Exception: $e")
            Log.e("PushDeliveryWorker", e)
            Result.retry()
        }
    }
}