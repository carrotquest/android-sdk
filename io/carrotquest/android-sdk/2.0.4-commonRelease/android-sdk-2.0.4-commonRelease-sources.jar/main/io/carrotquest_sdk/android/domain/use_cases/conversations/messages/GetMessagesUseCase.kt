package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.getErrorMessages
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.sendErrorMessages
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.reactivex.Observable

private const val tag = "getMessagesUseCase"

fun Observable<DataConversation>.getMessages() : Observable<Optional<MessagesResponse>> {
    return Observable.defer {
        return@defer this.flatMap {
            if(it.id == null) {
                return@flatMap Observable.just(Optional<MessagesResponse>(null))
            }

            CarrotInternal
                    .getService()
                    .carrotLib
                    .getMessages(it.id)
                    .flatMap { messageResponse ->
                        if (messageResponse.meta == null) {
                            Log.e(tag, "Error Get messages: messageResponse.meta is NULL")
                           return@flatMap Observable.just(Optional<MessagesResponse>(null))
                        } else if (messageResponse.meta.error != null) {
                            Log.e(tag, "Error Get messages: ${messageResponse.meta.error}")
                            return@flatMap Observable.just(Optional<MessagesResponse>(null))
                        } else {
                            if (messageResponse.meta != null && messageResponse.meta.nextAfter != null) {
                                MessagesRepository.getInstance().setCurrentAfter(messageResponse.meta.nextAfter)
                            }

                            val resp = DownloadUtil.replaceFilesLocalUrl(messageResponse)

                            val errorMessages = getErrorMessages(it.id)
                            if(errorMessages.isNotEmpty()) {
                                sendErrorMessages(errorMessages)
                            }

                            MessagesRepository.getInstance().setData(resp)
                            return@flatMap Observable.just(Optional(resp))
                        }
                    }
        }
    }
}