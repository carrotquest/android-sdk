package io.carrotquest_sdk.android.presentation.mvp.popup.presenter

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.data.network.js_interface.pop_up.IJSPopUpPresenter
import io.carrotquest_sdk.android.domain.use_cases.agreements.TrackContacts
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowDataProcessingUseCase
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowTrackContactsUseCase
import io.carrotquest_sdk.android.domain.use_cases.popup.expirationSubscribe
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.models.UserProperty
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.popup.view.IPopUp
import io.carrotquest_sdk.android.presentation.mvp.utils.jsonUtils.prepareJsonSettings
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.net.URLDecoder
import java.util.concurrent.TimeUnit

class PopUpPresenter(private var view: IPopUp?) : IJSPopUpPresenter {
    private val tag = this.javaClass.name
    private val compositeDisposable = CompositeDisposable()

    private var currentTopOffsetInput = 0
    private var conversationId: String? = null

    fun onResume(id: String, blocksJson: String, backColor: String) {
        conversationId = id

        if(backColor.isNotEmpty()) {
            view?.updateBackground(backColor)
        }

        val providerName = when (BuildConfig.FLAVOR) {
            "common" -> "Carrot quest"
            "us" -> "Dashly"
            else -> ""
        }
        val providerIcon = when (BuildConfig.FLAVOR) {
            "common" -> R.drawable.ic_cq_logo_carrot
            "us" -> R.drawable.ic_logo_dashly
            else -> R.drawable.ic_logo_dashly
        }

        view?.updatePoweredBy(providerName, providerIcon)

        compositeDisposable.add(
                Observable.just(true)
                        .getSettings()
                        .observeOn(AndroidSchedulers.mainThread())

                        .take(1)
                        .subscribe({ settings ->
                            if (settings != null) {
                                if(settings.showPoweredBy) {
                                    view?.showPoweredBy()
                                }

                                val jsonObject = JsonObject()
                                val joConnect = prepareJsonSettings(JsonParser.parseString(settings.sourceData) as JsonObject, view?.getContext())

                                if (providerName.isNotEmpty()) {
                                    joConnect.addProperty("provider_name", providerName)
                                }

                                jsonObject.add("appSettings", joConnect)


                                if(blocksJson.isNotEmpty()) {
                                    val blocksJsonObject = JsonParser.parseString(blocksJson) as JsonObject
                                    jsonObject.add("bodyJson", blocksJsonObject)
                                }

                                val initJson = "javascript:window.webView.initPopup($jsonObject)"
                                view?.showContent(initJson)

                            }
                        }, { t ->
                            Log.e(javaClass.name, t)
                        })
        )
        
        subscribeOnExpiration(id)
    }

    fun onDestroy() {
        if (!compositeDisposable.isDisposed) {
            compositeDisposable.dispose()
        }
        view = null
    }

    fun onTabCloseButton() {
        view?.closePopUp()
    }

    /**
     * Вьюха загрузилась. Можно вызывать initPopUp()
     */
    fun onLoaded(initJson: String) {
        view?.executeJs(initJson)
    }

    /**
     * JSInterface методы
     */

    /**
     * Говорит о том что попап готов и возвращет его размеры
     */
    override fun popUpIsReady(width: Int, height: Int) {
        Log.d(tag, "popUpIsReady")
        view?.setHeight(height - 10)
    }

    override fun close() {
        view?.closePopUp()
    }

    override fun openLink(url: String) {
        view?.openLink(url)
        //view?.closePopUp()
        if(conversationId != null) {
            trackClick(conversationId!!, object: CarrotSDK.Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                }

                override fun onFailure(t: Throwable?) {
                }
            })
        }
    }

    override fun trackEvent(eventName: String) {
        Carrot.trackEvent(URLDecoder.decode(eventName, "UTF-8"))
    }

    override fun setUserProperty(props: String) {
        val json = JsonParser.parseString(URLDecoder.decode(props, "UTF-8")).asJsonObject

        val keys = json.keySet()
        if (keys.isNotEmpty()) {
            keys.forEach { key ->
                val value = json[key].asString
                Carrot.setUserProperty(UserProperty(key, value))
            }
        }
    }

    override fun setTopOffsetCurrentInputBar(topOffset: Int) {
        this.currentTopOffsetInput = topOffset
    }

    override fun allowDataProcessing() {
        allowDataProcessingUseCase()
    }

    override fun allowTrackContacts(dataJson: String, replyId: String) {
        val jsData = Gson().fromJson(dataJson, JsonObject::class.java)
        val email = if(jsData.has("email")) {
            jsData.get("email").asString
        } else {
            null
        }

        val phone = if(jsData.has("phone")) {
            jsData.get("phone").asString
        } else {
            null
        }

        val contacts = TrackContacts(
            email = email,
            phone = phone
        )

        allowTrackContactsUseCase(contacts, replyId)
    }

    fun onShowKeyboard() {
        view?.updateUpScroll(currentTopOffsetInput)
    }

    fun onHideKeyboard() {
        compositeDisposable.add(
                Observable.just(true)
                        .delay(100, TimeUnit.MILLISECONDS)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .take(1)
                        .subscribe({
                            view?.updateDownScroll()
                        },{

                        })

        )

    }


    private fun subscribeOnExpiration(id: String) {
        if(id.isNotEmpty()) {
            compositeDisposable.add(
            Observable.just(true)
                    .expirationSubscribe()
                    .take(1)
                    .subscribe({expirationPopUpId->
                        if(expirationPopUpId == id) {
                            close()
                        }
                    }, {}))
        }
    }
}