package io.carrotquest_sdk.android.lib.network.responses.tickets

import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Парсинг дат тикета (created/due_date): ISO-строки вида
 * "2026-07-15T14:28:28.152521+0300" — с дробной частью до микросекунд и смещением таймзоны.
 *
 * minSdk 21 без core library desugaring → java.time недоступен. SimpleDateFormat с шаблоном
 * SSS трактует ЛЮБУЮ длину дробной части как миллисекунды (152521 → +152.5 сек!), поэтому
 * дробную часть предварительно обрезаем/дополняем ровно до 3 знаков.
 *
 * Внутри вложенного conversation даты — обычные unix-секунды, этот парсер к ним не относится.
 */
internal object TicketDates {

    // Дробная часть секунд произвольной длины (бэк шлёт 6 знаков, может со временем измениться)
    private val FRACTION_REGEX = Regex("""\.(\d+)""")

    /**
     * ISO-строка → epoch millis. null/пустая строка/не-ISO мусор → null (не бросаем:
     * дата в тикете — вторичная информация, её отсутствие не должно ронять парсинг списка).
     */
    fun parseIsoToMillis(raw: String?): Long? {
        if (raw.isNullOrBlank()) return null

        val normalized = normalizeFraction(raw.trim())
        // Смещение: и "+0300", и "+03:00" (X появился только в API 24+, поэтому ZZZZZ не используем;
        // Z переваривает "+0300", вариант с двоеточием приводим к нему). ISO-литерал "Z" (UTC)
        // SimpleDateFormat-буква Z НЕ понимает — нормализуем в "+0000": бэк так пока не шлёт,
        // но дефолтный DRF-рендер отдаёт именно Zulu, и молчаливый null уронил бы дедлайн,
        // время в стадии и ключ цикла закрытия.
        val withOffset = normalized
            .replace(ZULU_SUFFIX_REGEX, "+0000")
            .let { value ->
                COLON_OFFSET_REGEX.replace(value) { m ->
                    "${m.groupValues[1]}${m.groupValues[2]}${m.groupValues[3]}"
                }
            }

        for (pattern in PATTERNS) {
            val format = SimpleDateFormat(pattern, Locale.US)
            if (!pattern.endsWith("Z")) {
                // Строка без смещения — считаем UTC (бэк так не шлёт, но не гадаем по локали устройства)
                format.timeZone = TimeZone.getTimeZone("UTC")
            }
            val position = ParsePosition(0)
            val date = format.parse(withOffset, position)
            // Требуем полного разбора строки — иначе "2026-07-15T14:28:28мусор" пройдёт как валидная
            if (date != null && position.index == withOffset.length) {
                return date.time
            }
        }
        return null
    }

    // "+03:00" → "+0300"
    private val COLON_OFFSET_REGEX = Regex("""([+-])(\d{2}):(\d{2})$""")

    // "…T08:58:25Z" / "…z" → UTC
    private val ZULU_SUFFIX_REGEX = Regex("""[zZ]$""")

    private val PATTERNS = listOf(
        "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
        "yyyy-MM-dd'T'HH:mm:ssZ",
        "yyyy-MM-dd'T'HH:mm:ss.SSS",
        "yyyy-MM-dd'T'HH:mm:ss"
    )

    /** Обрезает/дополняет дробную часть секунд ровно до 3 знаков (миллисекунды). */
    private fun normalizeFraction(value: String): String =
        FRACTION_REGEX.replace(value) { match ->
            val digits = match.groupValues[1]
            "." + digits.take(3).padEnd(3, '0')
        }
}
