package io.carrotquest_sdk.android.presentation.tickets

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.coroutines.SdkCoroutineExceptionHandler
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.repositories.TicketsRepository
import io.carrotquest_sdk.android.domain.entities.TicketEntity
import io.carrotquest_sdk.android.domain.use_cases.tickets.refreshTickets
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel.MessagePreviewBuilder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * VM вкладки «Тикеты» (отдельная от ListViewModel — не раздуваем список диалогов).
 * Источник правды — TicketsRepository (сортировку/счётчики ведёт он), VM только маппит
 * в UI-модели и триггерит загрузки.
 */
class TicketsViewModel(application: Application) : AndroidViewModel(application) {

    private val ticketsRepository = TicketsRepository.getInstance()

    // Выбранная вкладка живёт в VM (activity-scoped), а не в rememberSaveable: контент списка
    // при переходе в диалог/тикет покидает композицию, и remember-состояние теряется —
    // «назад» из тикета обязан возвращать на вкладку «Тикеты»
    private val _selectedTab = MutableStateFlow(ListTab.MESSAGES)
    internal val selectedTab: StateFlow<ListTab> = _selectedTab

    internal fun selectTab(tab: ListTab) {
        _selectedTab.value = tab
        // Открытие вкладки — точка обновления (как в вебе) и второй шанс после
        // неудачной стартовой загрузки (in-flight guard в use-case схлопнет дубли)
        if (tab == ListTab.TICKETS) loadTickets()
    }

    /** Бейдж таба «Тикеты» — счётчик непрочитанных тикет-диалогов. */
    val unreadCount: StateFlow<Int> = ticketsRepository.unreadTicketsCountFlow

    /**
     * Фиче-флаг тикет-системы: tickets_unread из настроек (null = выключено).
     * Триггер ЗАГРУЗКИ списка (реактивно — настройки приходят после connect, позже
     * первого рендера); видимость табов гейтит не он, а [showTabs].
     */
    val ticketsEnabled: StateFlow<Boolean> = SettingsRepository.getInstance()
        .settingsChangesFlow()
        .map { it.ticketsUnread != null }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /**
     * Видимость табов «Сообщения/Тикеты»: только при непустой истории тикетов. Тикет создаёт
     * оператор, а не юзер — пустой список значит «фича юзера не касается», экран остаётся
     * прежним (без табов). Loading/Empty/Error-состояний у вкладки нет: пока список не
     * загружен (или загрузка упала — кэша нет), табы просто скрыты; появятся реактивно
     * от загрузки/RTS ticket.created.
     */
    val showTabs: StateFlow<Boolean> = ticketsRepository.ticketsFlow
        .map { it.isNotEmpty() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val tickets: StateFlow<List<TicketCardUiItem>> = ticketsRepository.ticketsFlow
        .map { list -> list.map { it.toCardItem() } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Загрузка списка; зовётся при включении фичи и выборе вкладки. */
    fun loadTickets() {
        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            // refreshTickets резолвит userId из настроек (UserRepository при холодном
            // старте мог ещё не сохранить пользователя — гонка connect-флоу)
            refreshTickets()
        }
    }

    private fun TicketEntity.toCardItem(): TicketCardUiItem {
        val ctx = getApplication<Application>()
        val (previewText, _) = MessagePreviewBuilder.build(
            partLast,
            MessagePreviewBuilder.Strings(
                file = ctx.getString(R.string.file_str),
                image = ctx.getString(R.string.image_str),
                images = ctx.getString(R.string.images_str),
                files = ctx.getString(R.string.files_str),
                deleted = ctx.getString(R.string.list_message_deleted),
                popup = ctx.getString(R.string.list_message_popup),
                vote = ctx.getString(R.string.list_message_vote),
                botButtons = ctx.getString(R.string.list_message_bot_buttons),
                botAnswerField = ctx.getString(R.string.list_message_bot_answer_field),
                botCalendly = ctx.getString(R.string.list_message_bot_calendly),
            )
        )
        return TicketCardBuilder.build(
            ticket = this,
            inProgressLabel = ctx.getString(R.string.ticket_in_progress),
            previewText = previewText
        )
    }
}
