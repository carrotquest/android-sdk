package io.carrotquest_sdk.android.presentation.mvp.dialog.presenter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.InputType
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentKind
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState
import io.carrotquest_sdk.android.domain.use_cases.agreements.RequestedContactField
import io.carrotquest_sdk.android.domain.use_cases.agreements.TrackContacts
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowDataProcessingUseCase
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowTrackContactsUseCase
import io.carrotquest_sdk.android.domain.use_cases.agreements.buildConsentState
import android.text.TextUtils
import androidx.core.graphics.toColorInt
import io.carrotquest_sdk.android.Callback
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.files.SavedFile
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.bot.loadRoutingBot
import io.carrotquest_sdk.android.domain.use_cases.bot.startRoutingBot
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.clearDraftAttachmentsUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.clearDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftAttachmentsUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.saveDraftAttachmentsUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.saveDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversations.TAG
import io.carrotquest_sdk.android.domain.use_cases.conversations.conversationsFlow
import io.carrotquest_sdk.android.domain.use_cases.conversations.createConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.getLastConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.markConversationAsRead
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.buildAttachmentsCachedJson
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.createMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.createWelcomeMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.loadGapPage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.loadMessagesAround
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.paginationMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.removeWelcomeMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.saveMessage
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.saveErrorMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.selectBotBrunch
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.toRepliedToSnapshot
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplay
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplayLoading
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplayLocal
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateConversationMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateStatusMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.notPopup
import io.carrotquest_sdk.android.domain.use_cases.conversations.openConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.removeTypingIndicator
import io.carrotquest_sdk.android.domain.use_cases.conversations.updateOpenedConversationId
import io.carrotquest_sdk.android.domain.use_cases.countries.GetSavedCountryRegionUseCase
import io.carrotquest_sdk.android.domain.use_cases.countries.getCountryEntityByRegion
import io.carrotquest_sdk.android.domain.use_cases.settings.getLastSettings
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettingsSuspend
import io.carrotquest_sdk.android.domain.use_cases.user.doneVoting
import io.carrotquest_sdk.android.domain.use_cases.user.doneVotingComment
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.domain.use_cases.user.sendVoteOperator
import io.carrotquest_sdk.android.domain.use_cases.user.setUserProperty
import io.carrotquest_sdk.android.domain.use_cases.user.wrongVoting
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.e
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtToken
import io.carrotquest_sdk.android.presentation.chat.MessageMapper
import io.carrotquest_sdk.android.presentation.chat.RoutingTemplateState
import io.carrotquest_sdk.android.presentation.chat.input.AttachmentUploadState
import io.carrotquest_sdk.android.presentation.chat.input.MAX_ATTACHMENTS
import io.carrotquest_sdk.android.presentation.chat.input.PendingAttachment
import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.IDialogView
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.InputMod
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import retrofit2.HttpException
import java.io.File
import io.carrotquest_sdk.android.lib.network.auth.IdentityMismatchException
import java.io.IOException
import java.io.UnsupportedEncodingException
import java.net.URLDecoder
import java.util.Date
import java.util.Locale
import javax.inject.Inject

// Таймаут ожидания готовности SDK (Ready) при загрузке сообщений после cold-start-offline:
// при возврате сети SDK переинициализируется, ждём сессию, затем грузим.
private const val AWAIT_READY_TIMEOUT_MS = 15_000L

class DialogPresenter : BasePresenter() {

    @set:Inject
    internal var db: CarrotSdkDB? = null

    private val tag = "DialogPresenter"
    // Корутинная замена compositeDisposable (ветка remove_rx, фаза 7). На Main: колбэки во
    // вьюху безопасны; await не блокирует. Для разовых action-корутин (отправка, голосование и т.п.).
    private var presenterScope = sdkScope(SdkDispatchers.main)
    // Отдельный скоуп для ДОЛГОЖИВУЩИХ подписок (commonSubscribes/init* потоки). Сбрасывается
    // при ре-ините/новом диалоге (resetSubscriptions) — это заменяет compositeDisposable.dispose()
    // и не отменяет разовые корутины из presenterScope.
    private var subscriptionsScope = sdkScope(SdkDispatchers.main)
    private fun resetSubscriptions() {
        subscriptionsScope.cancel()
        subscriptionsScope = sdkScope(SdkDispatchers.main)
    }

    // Подписки на менеджеры сети/фона. Их collect живёт на скоупе менеджера (до deInit SDK),
    // поэтому презентер ОБЯЗАН отписаться в onDestroy, иначе держит view (утечка на каждое
    // открытие чата). Раньше это был Rx Disposable под compositeDisposable.
    private var networkCancellable: Cancellable? = null
    private var backgroundCancellable: Cancellable? = null

    private val viewModel = DialogViewModel.getInstance()

    private var isPagination = false

    private var isNewDialog = false

    private val mainInputType =
        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE

    fun onCreate() {
        loadMessages()
    }

    override fun attachView(view: IBaseView) {
        super.attachView(view)
        loadSettings()

        getViewInterface()?.let { dialogActivity ->
            val savedRegion = GetSavedCountryRegionUseCase().call()
            val savedCountry =
                getCountryEntityByRegion(savedRegion, PhoneNumberUtil.createInstance(dialogActivity.getCurrentContext()))
            setPhoneRegion(savedCountry)
        }
    }

    private var selectedCountry: CountryEntity? = null
    private fun setPhoneRegion(country: CountryEntity) {
        selectedCountry = country

        val flag = country.flag
        val prefix = "+${country.countryCode}"

        if (flag != null) {
            getViewInterface()?.updatePhoneRegionFlag(flag)
            getViewInterface()?.updatePhoneRegionPrefix(prefix)

            val currentConversationId = viewModel.getCurrentConversationId()
            if(currentConversationId.isNotEmpty()) {
                presenterScope.launch {
                    val conversation = getConversationSuspend(currentConversationId)
                    if (conversation != null) {
                        updateInput(conversation)
                    }
                }
            }
        }
    }

    private fun loadSettings() {
        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect
        if (hasInternet) {
            presenterScope.launch {
                try {
                    applyAccentColor(getSettingsSuspend())
                } catch (error: Throwable) {
                    Log.e(tag, error)
                }
            }
        } else {
            // Офлайн берём те же кэшированные настройки. Раньше эта ветка разбирала цвет по-своему:
            // originalAppColor!! и без try/catch. Поле nullable, и запись настроек по частям
            // (RTS app_online_changed / updateAppUserFlags) его теряла → NPE без сообщения прямо
            // в fragment-транзакции, т.е. краш хост-аппа при переоткрытии диалога офлайн.
            // Теперь у обеих ветвей один разбор цвета и одинаковая защита.
            try {
                applyAccentColor(getLastSettings())
            } catch (error: Throwable) {
                Log.e(tag, error)
            }
        }
    }

    /**
     * Акцентный цвет из настроек: originalAppColor — «сырой» цвет аппа, его надо скорректировать
     * под тему; appColor уже скорректирован (см. SettingsManager), поэтому берётся как есть.
     * Пустое/отсутствующее значение молча пропускаем — "#null".toColorInt() кидал бы исключение.
     */
    private fun applyAccentColor(settings: SettingsEntity?) {
        val originalColor = settings?.originalAppColor
        val color = if (originalColor.isNullOrEmpty()) {
            settings?.appColor
        } else {
            AppColorUtils.getCorrectAccentColor(
                CarrotInternal.getLibComponent().contextSdk,
                originalColor,
            )
        }
        if (color.isNullOrEmpty()) return
        getViewInterface()?.updateAppColor(("#$color").toColorInt())
    }

    fun onCreateWebView(convId: String) {
        // Сеть проверяем синхронно через ConnectivityManager (isNetworkAvailable),
        // а не через асинхронный кэш hasConnect: кэш врёт после Doze/долгого
        // background. Если сети физически нет — сразу показываем оверлей,
        // иначе вечный лоадер. Когда сеть вернётся, observer в initSubscribes
        // дёрнет loadMessages и обновит UI.
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        if (NetworkManager.isAirplaneModeOn()) {
            getViewInterface()?.showErrorAirplaneMode()
            resetSubscriptions()
            return
        }
        if (!networkManager.isNetworkAvailable()) {
            getViewInterface()?.showErrorNoInternet()
            return
        }
        // Немедленно синхронно восстанавливаем состояние UI из кеша (phone prefix и тип ввода),
        // не дожидаясь асинхронной цепочки getConversation. Это исключает мигание phone_prefix
        // при повторном входе в диалог: к моменту появления экрана UI уже в нужном состоянии.
        ConversationsRepository.getInstance().getConversationById(convId)?.let { updateInput(it) }
        loadConversationAndUpdateInput(convId)
    }

    private fun loadConversationAndUpdateInput(convId: String) {
        presenterScope.launch {
            try {
                val conversation = getConversationSuspend(convId)
                // Подсказку здесь НЕ сбрасываем: каждая ветка updateInput с видимым полем ставит её
                // сама (updateHint/applyBotPropertyFieldInput), а KEEP_BOT_INPUT обязана сохранить
                // текущую. Безусловный updateHint(null) для нового диалога (беседы нет, updateInput
                // не зовётся) приходил ПОСЛЕ ответа choose и затирал кастомный плейсхолдер
                // стартовой ветки с полем ввода — хинт мигал и сменялся дефолтным.
                if (conversation != null) {
                    updateInput(conversation)
                }
                getViewInterface()?.setInputMod(currentInputMod)
            } catch (t: Throwable) {
                Log.e(TAG, t)
            }
        }
    }

    fun retry() {
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        when {
            NetworkManager.isAirplaneModeOn()        -> getViewInterface()?.showErrorAirplaneMode()
            !networkManager.isNetworkAvailable()     -> getViewInterface()?.showErrorNoInternet()
            else -> {
                // Ретраим ту операцию, которая реально падала. Голый loadMessages здесь ломался
                // для нового диалога: runUpdateMessages на пустом/last_conversation id выходит
                // сразу, ни один запрос не уходит — экран оставался в вечном Loading.
                val conversationId = viewModel.getCurrentConversationId()
                when {
                    pendingFirstMessage != null                  -> retryCreateConversation()
                    "last_conversation" == conversationId        -> onOpenLastDialog()
                    conversationId.isEmpty() && isNewDialog      -> initNewConversationSubscribes()
                    // Явный ретрай пользователя: сбой должен вернуть экран ошибки, а не пустой/кэшный диалог.
                    else                                         -> loadMessages(needHardUpdate = true, showErrorOnFailure = true)
                }
            }
        }
    }

    // Backend-ошибку (HTTP, напр. 403) НЕ путаем с отсутствием сети: при живой сети показываем
    // «Что-то пошло не так» (GENERIC). Оверлей «нет интернета»/«авиарежим» — только когда сеть
    // реально недоступна (или это сетевой IOException). Иначе backend-403 маскировался под offline.
    //
    // hideLoading() вызываем ЗДЕСЬ (а не на каждом call-site): иначе следующий, кто добавит ветку
    // ошибки, забудет снять спиннер и вернёт «вечный лоадер поверх оверлоя ошибки».
    private fun showErrorForThrowable(t: Throwable?) {
        getViewInterface()?.hideLoading()
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        when {
            NetworkManager.isAirplaneModeOn()                  -> getViewInterface()?.showErrorAirplaneMode()
            t is HttpException                                 -> getViewInterface()?.showErrorSomething()
            // Барьер идентичности: клиентский отказ при живой сети. Наследует IOException (OkHttp
            // другого не разрешает), поэтому ветка обязана стоять ДО общей IOException-ветки —
            // иначе снова «Нет соединения» при живом интернете (симптом инцидента «залипший токен»).
            t is IdentityMismatchException                     -> getViewInterface()?.showErrorSomething()
            !networkManager.isNetworkAvailable()               -> getViewInterface()?.showErrorNoInternet()
            t is IOException                                   -> getViewInterface()?.showErrorNoInternet()
            else                                               -> getViewInterface()?.showErrorSomething()
        }
    }

    fun onDestroy() {
        selectedCountry = null
        viewModel.updateCurrentConversationId("")

        super.detachView()

        // Отписка от менеджеров сети/фона — иначе их collect держит view до deInit SDK (утечка).
        networkCancellable?.cancel()
        networkCancellable = null
        backgroundCancellable?.cancel()
        backgroundCancellable = null

        presenterScope.cancel()
        presenterScope = sdkScope(SdkDispatchers.main)
        subscriptionsScope.cancel()
        subscriptionsScope = sdkScope(SdkDispatchers.main)
    }

    fun getViewInterface(): IDialogView? {
        return if(super.getView() is IDialogView) {super.getView() as IDialogView} else null
    }

    fun onOpenDialog() {
        isNewDialog = false
        // DialogViewModel — синглтон: needStartRoutingBot переживает закрытие диалога.
        // Сбрасываем ДО подписок, чтобы новая сессия стартовала с чистого состояния,
        // а не с протухшего значения прошлой (актуальное выставит commonSubscribes).
        viewModel.setNeedStartRoutingBot(false)
        initSubscribes()

        getViewInterface()?.updateHint(null)
        getViewInterface()?.updateMaxLengthInput(null)
        getViewInterface()?.setKeyboardType(mainInputType)
    }

    fun onOpenNewDialog() {
        isNewDialog = true
        // См. onOpenDialog: сбрасываем протухший синглтон-флаг прошлой сессии.
        viewModel.setNeedStartRoutingBot(false)
        initNewConversationSubscribes()
        viewModel.updateCurrentConversationId("")
    }

    // Виды согласий, данные в текущей сессии (после отправки). Дублирует серверный флаг
    // *_is_allowed, но флипается мгновенно: allowDataProcessingUseCase проставляет флаг в кэш с
    // задержкой ~1с, поэтому без этого набора блок мог бы кратко вернуться на следующем updateInput.
    private val consentGivenKinds = mutableSetOf<ConsentKind>()

    // Строит и прокидывает блок согласия для текущего режима инпута. requestedField=NONE — обычный
    // ввод (только согласие на обработку перс. данных, если включено и ещё не дано); EMAIL/PHONE —
    // запрос контакта ботом (плюс строка подтверждения хранения контакта). buildConsentState сам
    // скрывает уже данные согласия по серверным флагам; данные в этой сессии убираем дополнительно.
    private fun pushInputConsent(requestedField: RequestedContactField) {
        val allLines = buildConsentState(requestedField).lines
        val lines = allLines.filter { it.kind !in consentGivenKinds }
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.NETWORK, "UserConsent") {
            "pushInputConsent requested=$requestedField built=${allLines.map { it.kind }} " +
                "shown=${lines.map { it.kind }} sessionGiven=$consentGivenKinds"
        }
        getViewInterface()?.setConsent(ConsentUiState(lines).takeIf { it.isVisible })
    }

    // Сохраняет факт согласия после успешной отправки. Кнопка отправки гейтится allRequiredChecked,
    // поэтому к моменту отправки обязательные чекбоксы отмечены, а неявное согласие = сама отправка —
    // значит сохраняем все показанные (ещё не данные) виды согласий. Идемпотентно за сессию.
    private fun saveConsentsForSend(requestedField: RequestedContactField, contactValue: String?, partId: String) {
        val lines = buildConsentState(requestedField).lines
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.NETWORK, "UserConsent") {
            "saveConsentsForSend requested=$requestedField kinds=${lines.map { it.kind }} " +
                "alreadyGiven=$consentGivenKinds hasContactValue=${contactValue != null} partId=$partId"
        }
        lines.forEach { line ->
            if (!consentGivenKinds.add(line.kind)) return@forEach // уже сохраняли в этой сессии
            // При провале сохранения возвращаем строку согласия в текущей сессии: kind убираем из
            // набора, чтобы блок снова показался (иначе оптимистичный дедуп прятал его до конца
            // сессии, а серверный флаг так и оставался false — «согласие потерялось молча»).
            val onResult: (Boolean) -> Unit = { ok ->
                if (!ok) {
                    consentGivenKinds.remove(line.kind)
                    pushInputConsent(requestedField)
                }
            }
            when (line.kind) {
                ConsentKind.DATA_PROCESSING -> allowDataProcessingUseCase(onResult)
                ConsentKind.EMAIL_SUBSCRIPTION ->
                    contactValue?.let { allowTrackContactsUseCase(TrackContacts(email = it, phone = null), partId, onResult) }
                ConsentKind.PHONE_SUBSCRIPTION ->
                    contactValue?.let { allowTrackContactsUseCase(TrackContacts(email = null, phone = it), partId, onResult) }
            }
        }
        // Прячем блок сразу (не ждём серверный флаг), учитывая только что данные согласия.
        pushInputConsent(requestedField)
    }

    private fun updateInput(conversation: DataConversation) {
        val conversationId = conversation.id
        if (conversationId == null) {
            return
        }

        val lastPart = conversation.partLast
        val isAllowUserReply = conversation.replyType == "text"
        // property_field может быть НЕ первым в actions (например, в part'е chat_bot_user, где бот
        // дозадаёт вопрос в рамках идущего диалога) — ищем по всему массиву, а не только actions[0].
        val botPropertyFieldAction = lastPart?.actions?.firstOrNull { it.type == "property_field" }

        val branch = resolveInputBranch(
            conversationType = conversation.type,
            lastPartType = lastPart?.type,
            isAllowUserReply = isAllowUserReply,
            hasPropertyField = botPropertyFieldAction != null,
            isChatBotFinished = conversation.isChatBotFinished,
            isBotInputMode = currentInputMod == InputMod.BOT_INPUT,
            routingTemplate = routingTemplateState,
        )

        Log.d(
            "CQ_BotInput",
            "updateInput convId=$conversationId convType=${conversation.type} branch=$branch " +
                "lastPartType=${lastPart?.type} replyType=${lastPart?.replyType} " +
                "actions=[${lastPart?.actions?.joinToString(",") { it.type ?: "?" } ?: ""}] " +
                "allowUserReply=$isAllowUserReply hasPropertyField=${botPropertyFieldAction != null} " +
                "chatBotFinished=${conversation.isChatBotFinished} routingTemplate=$routingTemplateState " +
                "curMod=$currentInputMod"
        )

        when (branch) {
            InputBranch.HIDE_POPUP -> {
                getViewInterface()?.hideInput()
                return
            }
            // Первая ветка запрашивает данные (телефон/email/имя/произвольное) вместо кнопок: тот же
            // bot-input, что и для серверных бот-вопросов, но экшен берём из шаблона — в серверном
            // partLast его нет (шаблон в репозиторий не попадает). Ответ уйдёт в routing/start
            // через sendActionBot (needStartRoutingBot).
            InputBranch.ROUTING_TEMPLATE_PROPERTY_FIELD -> {
                applyRoutingTemplatePropertyField(conversationId, routingTemplateState!!.propertyField!!)
            }
            // Стартовая ветка routing-бота внизу ленты — актуальный промпт, серверный partLast
            // (например, reply_admin закрытого диалога) устарел. Прерывание запрещено → поля нет,
            // как в вебе при reply_type='no'. Режим сбрасываем: протухший BOT_INPUT иначе
            // заблокировал бы показ поля следующей веткой (KEEP_BOT_INPUT).
            InputBranch.ROUTING_TEMPLATE_HIDDEN -> {
                currentInputMod = InputMod.NORMAL
                getViewInterface()?.hideInput()
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
                getViewInterface()?.setConsent(null)
            }
            // Та же стартовая ветка, но бота можно прервать текстом — свободный ввод.
            InputBranch.ROUTING_TEMPLATE_ALLOWED -> {
                currentInputMod = InputMod.ALLOW_USER_REPLIES
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
                pushInputConsent(RequestedContactField.NONE)
            }
            // Обычный диалог — простой текстовый ввод.
            InputBranch.PLAIN -> {
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.setKeyboardType(mainInputType)
                pushInputConsent(RequestedContactField.NONE)
                return
            }
            InputBranch.BOT_PROPERTY_FIELD -> {
                // "phone_mask" трактуется как phone только при свободном текстовом ответе (replyType=="text").
                val phoneTypes = if (isAllowUserReply) setOf("phone", "phone_mask") else setOf("phone")
                applyBotPropertyFieldInput(conversationId, botPropertyFieldAction!!, lastPart?.replyType, phoneTypes)
            }
            InputBranch.REPLY_ADMIN -> {
                currentInputMod = InputMod.NORMAL
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                if (!isAllowUserReply) {
                    getViewInterface()?.hidePhonePrefix()
                    getViewInterface()?.updateMaxLengthInput(null)
                }
                pushInputConsent(RequestedContactField.NONE)
            }
            InputBranch.ALLOW_USER_REPLY -> {
                currentInputMod = InputMod.ALLOW_USER_REPLIES
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
                pushInputConsent(RequestedContactField.NONE)
            }
            InputBranch.KEEP_BOT_INPUT -> Unit
            InputBranch.CHAT_BOT_FINISHED -> {
                currentInputMod = InputMod.ALLOW_USER_REPLIES
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
                pushInputConsent(RequestedContactField.NONE)
            }
            InputBranch.HIDE -> {
                getViewInterface()?.hideInput()
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
                getViewInterface()?.setConsent(null)
            }
        }

        // Видимость скрепки следует за режимом ЗДЕСЬ, а не только в loadConversationAndUpdateInput:
        // updateInput зовётся и синхронно из кэша, и из подписок — без этого вызова бот-режим
        // (телефон/email/имя) показывал скрепку, хотя ответ файлы не подразумевает.
        getViewInterface()?.setInputMod(currentInputMod)
    }

    // Настраивает поле ввода для бот-вопроса с property_field (phone/email/name/custom).
    private fun applyBotPropertyFieldInput(
        conversationId: String,
        action: ActionMessage,
        replyType: String?,
        phoneTypes: Set<String>
    ) {
        currentInputMod = InputMod.BOT_INPUT
        currentAction = action
        getViewInterface()?.showInput(conversationId)

        val (hint, maxLength) = botAnswerHint(action, replyType, phoneTypes)
        val keyboardType = keyboardTypeFor(replyType)

        Log.d("CQ_BotInput", "applyBotPropertyFieldInput replyType=$replyType actionType=${action.type} keyboardType=$keyboardType phonePrefix=${keyboardType == InputType.TYPE_CLASS_PHONE} hint=$hint")

        if (keyboardType == InputType.TYPE_CLASS_PHONE) {
            getViewInterface()?.showPhonePrefix()
        } else {
            getViewInterface()?.hidePhonePrefix()
        }
        getViewInterface()?.updateMaxLengthInput(maxLength)
        getViewInterface()?.updateHint(hint)
        getViewInterface()?.setKeyboardType(keyboardType)
        getViewInterface()?.showSendButton()
        getViewInterface()?.disableSendButton()

        // Блок согласия над баром: тип запрашиваемого поля определяем по keyboardType — так строка
        // подписки (email/phone) совпадает с реально показанным режимом бара (email-клавиатура /
        // phone-префикс). pushInputConsent зовём ПОСЛЕ showInput (он сбросил consent в null выше).
        val requestedField = when (keyboardType) {
            InputType.TYPE_CLASS_PHONE -> RequestedContactField.PHONE
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> RequestedContactField.EMAIL
            else -> RequestedContactField.NONE
        }
        // Запоминаем, что именно ПОКАЗАЛИ: при сохранении согласия ключуемся на это поле, а не на
        // повторный fetch беседы (partLast.replyType к моменту отправки может отличаться от
        // показанного: псевдо-id routing_* → null, phone_mask → расхождение показ/сохранение).
        currentRequestedField = requestedField
        pushInputConsent(requestedField)
    }

    // hint + maxLength для бот-ввода. maxLength != null только для phone (длина примера номера).
    private fun botAnswerHint(
        action: ActionMessage,
        replyType: String?,
        phoneTypes: Set<String>
    ): Pair<String, Int?> {
        val ctx = CarrotInternal.getLibComponent().contextSdk
        val placeholder = action.placeholder
        if (placeholder != null) {
            if (placeholder.type == "custom") return placeholder.value to null
            return when (placeholder.type) {
                in phoneTypes -> phoneExampleHint()
                "email" -> ctx.getString(R.string.bot_answer_email_hint) to null
                "name" -> ctx.getString(R.string.bot_answer_name_hint) to null
                else -> ctx.getString(R.string.bot_answer_hint) to null
            }
        }
        return when (replyType) {
            "phone" -> phoneExampleHint()
            "email" -> ctx.getString(R.string.bot_answer_email_hint) to null
            "name" -> ctx.getString(R.string.bot_answer_name_hint) to null
            else -> ctx.getString(R.string.bot_answer_hint) to null
        }
    }

    // Подсказка-пример телефона для выбранной страны + длина (maxLength). Без страны — общий хинт.
    private fun phoneExampleHint(): Pair<String, Int?> {
        val ctx = CarrotInternal.getLibComponent().contextSdk
        val country = selectedCountry ?: return ctx.getString(R.string.bot_answer_phone_hint) to null
        val example = PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
            .getExampleNumberForType(country.region.uppercase(), PhoneNumberUtil.PhoneNumberType.MOBILE)
            ?.nationalNumber?.toString()
        return (example ?: ctx.getString(R.string.bot_answer_phone_hint)) to example?.length
    }

    private fun keyboardTypeFor(replyType: String?): Int = when (replyType) {
        "phone" -> InputType.TYPE_CLASS_PHONE
        "email" -> InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        else -> mainInputType
    }


    // Новый диалог стартовал без сети — бутстрап (настройки/welcome/routing-bot) отложен
    // до появления интернета (network observer ниже).
    private var newDialogBootstrapPending = false

    // Существующий диалог открыт без сети — бутстрап (initDoneConversationSubscribes)
    // отложен до появления интернета (observer в initSubscribes).
    private var existingDialogBootstrapPending = false

    private fun initNewConversationSubscribes() {
        resetSubscriptions()

        // Live-проверка через ConnectivityManager, как в initSubscribes: асинхронный кэш
        // hasConnect может застревать в false после долгого офлайна (ping-цикл замирает,
        // исчерпав MAX_RETRY_ATTEMPTS) — и бутстрап нового диалога молча не запускался
        // даже при живой сети (вечный спиннер).
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)

        // Observer регистрируем всегда (chicken-and-egg — как в initSubscribes): при
        // офлайн-старте нового диалога возврат сети должен ре-бутстрапить диалог.
        // loadMessages здесь бесполезен — на пустом conversationId он не грузит ничего.
        networkCancellable?.cancel()
        networkCancellable = networkManager.addObserver { hasInternet ->
            if (hasInternet) {
                val curId = viewModel.getCurrentConversationId()
                if (newDialogBootstrapPending && curId.isEmpty()) {
                    getViewInterface()?.hideLoadError()
                    initNewConversationSubscribes()
                } else if (curId.isNotEmpty()) {
                    // Диалог уже стал реальным (createConversation успел) — ведём себя как
                    // observer initSubscribes: снимаем оверлей и догружаем сообщения.
                    getViewInterface()?.hideLoadError()
                    loadMessages()
                }
            } else {
                if (NetworkManager.isAirplaneModeOn()) {
                    getViewInterface()?.showErrorAirplaneMode()
                } else {
                    getViewInterface()?.showErrorNoInternet()
                }
            }
        }

        if (!networkManager.isNetworkAvailable()) {
            // Раньше: молчаливый no-op — ни подписок, ни ошибки, вечный спиннер.
            newDialogBootstrapPending = true
            showErrorForThrowable(null)
            return
        }
        newDialogBootstrapPending = false

        commonSubscribes()
        subscriptionsScope.launch {
            val settings = try {
                getSettingsSuspend()
            } catch (e: Throwable) {
                showErrorForThrowable(e)
                return@launch
            }
            if (settings == null) {
                getViewInterface()?.showErrorSomething()
                return@launch
            }

            // UI-reset через 100мс — параллельно welcome/routing-bot (как и было).
            launch {
                delay(100)
                getViewInterface()?.hideLoadError()
                getViewInterface()?.hideLoading()
                getViewInterface()?.enableInput()
                // Новый диалог: беседы ещё нет, поэтому updateInput (единственный, кто зовёт
                // showInput) не отрабатывает, а visible по умолчанию false → Compose-инпут скрыт
                // и первое сообщение отправить нечем. Явно показываем поле для пустого диалога.
                // Если сработает routing-бот с allow=false — тело чата покажет его стартовую ветку,
                // и onRoutingTemplateStateChanged скроет инпут (сеть отвечает медленнее этих 100мс,
                // поэтому финальное состояние корректно).
                getViewInterface()?.showInput(viewModel.getCurrentConversationId())
                // Согласие на обработку перс. данных — перед первым сообщением в пустом диалоге.
                pushInputConsent(RequestedContactField.NONE)
            }

            // Welcome-сообщение. Второй запрос chooseRoutingBot отсюда убран: commonSubscribes
            // выше уже спросил бэкенд (с ретраем) и выставил needStartRoutingBot по found==true —
            // документированному источнику истины. Этот дубль писал тот же флаг по своему
            // предикату (bot != null && found != false) и, отвечая последним (delay 1с), мог
            // переписать результат ретрая.
            launch {
                try {
                    createWelcomeMessage(settings)
                } catch (t: Throwable) {
                    Log.e(TAG, t)
                }
            }
        }
    }

    private fun initSubscribes() {
        resetSubscriptions()

        // Observers регистрируем всегда — даже если сейчас сети нет. Иначе
        // chicken-and-egg: при оффлайн-старте мы бы не подписались на network
        // changes, и при появлении сети ничего бы не сработало (вечный лоадер
        // или непропадающий оверлей). Сетевое состояние проверяем синхронно
        // через ConnectivityManager (isNetworkAvailable) — это live-состояние,
        // не асинхронный кэш hasConnect (который может застревать в false
        // после долгого Doze).
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)

        if (networkManager.isNetworkAvailable()) {
            existingDialogBootstrapPending = false
            initDoneConversationSubscribes()
        } else {
            // Сеть отключена физически — показываем оверлей сразу, чтобы не
            // висел лоадер. Настройки берём из кэша, чтобы шапка/цвета жили.
            // Бутстрап (getConversation/getMessages/commonSubscribes/updateInput)
            // не поднялся — отложен до появления сети (observer ниже).
            existingDialogBootstrapPending = true
            loadSettings()
            getViewInterface()?.showErrorNoInternet()
        }

        // Перед повторной подпиской отменяем прежнюю, чтобы не плодить collect'ы.
        networkCancellable?.cancel()
        networkCancellable = networkManager.addObserver { hasInternet ->
            if (hasInternet) {
                // Сеть подтверждена ping'ом — снимаем оверлей "нет интернета"
                // (если он был показан при оффлайн-старте) и догружаем сообщения.
                getViewInterface()?.hideLoadError()
                if (existingDialogBootstrapPending) {
                    // Диалог открывался офлайн: подписки/инпут так и не подняты, голый
                    // loadMessages их не создаст — повторяем полный бутстрап.
                    existingDialogBootstrapPending = false
                    initDoneConversationSubscribes()
                } else {
                    loadMessages()
                }
            } else {
                if (NetworkManager.isAirplaneModeOn()) {
                    getViewInterface()?.showErrorAirplaneMode()
                } else {
                    getViewInterface()?.showErrorNoInternet()
                }
            }
        }

        backgroundCancellable?.cancel()
        backgroundCancellable = BackgroundManager.getInstance().addObserver { isForeground ->
            if (isForeground) {
                //println("ISOPENPICKER = $isOpenPicker")
                if(!isOpenPicker) {
                    loadMessages(needHardUpdate = true)
                }
                //loadMessages(needHardUpdate = false)
            }
        }
    }

    private fun initDoneConversationSubscribes() {
        resetSubscriptions()
        val conversationId = viewModel.getCurrentConversationId()
        subscriptionsScope.launch {
            // 1. Грузим диалог (+ side-effect openConversation для не-popup), отмечаем прочитанным.
            val conversation = try {
                val c = getConversationSuspend(conversationId)
                if (c == null) {
                    showErrorForThrowable(null)
                } else if (c.type != ConversationType.BLOCK_POPUP_BIG.stringValue
                    && c.type != ConversationType.BLOCK_POPUP_SMALL.stringValue
                ) {
                    subscriptionsScope.launch {
                        openConversation(conversationId)
                    }
                }
                markConversationAsRead(c)
            } catch (e: Throwable) {
                onOpenNewDialog()
                return@launch
            } ?: return@launch

            // 2. Грузим сообщения диалога. На ошибке ВСЕГДА гасим лоадер (иначе вечный спиннер
            //    поверх оверлоя ошибки) и показываем ошибку с учётом её типа (backend vs offline).
            val messages = try {
                getMessages(conversation)
            } catch (t: Throwable) {
                showErrorForThrowable(t)
                return@launch
            }
            if (messages == null) {
                showErrorForThrowable(null)
                return@launch
            }

            // 3. Дожидаемся настроек, гасим лоадеры (с задержкой 1с, параллельно) и поднимаем подписки.
            val settings = try {
                getSettingsSuspend()
            } catch (e: Throwable) {
                showErrorForThrowable(e)
                return@launch
            }
            if (settings == null) {
                showErrorForThrowable(null)
                return@launch
            }
            launch {
                delay(1000)
                getViewInterface()?.hideLoadError()
                getViewInterface()?.hideLoading()
                getViewInterface()?.enableInput()
            }
            commonSubscribes()
        }
    }

    private fun commonSubscribes() {
        subscribeConversationUpdates()
        requestRoutingBot()
    }

    // Непрерывные коллекторы сессии диалога. Регистрируются ровно один раз на цикл подписок
    // (после resetSubscriptions) — обе читают currentConversationId динамически на каждой эмиссии,
    // поэтому смена id (материализация routing-диалога) перерегистрации НЕ требует.
    private fun subscribeConversationUpdates() {
        // Непрерывная подписка: на каждое добавление сообщений отмечаем диалог прочитанным.
        subscriptionsScope.launch {
            MessagesRepository.getInstance().newMessagesFlow.collect {
                try {
                    val conv = getConversationSuspend(viewModel.getCurrentConversationId())
                    markConversationAsRead(conv)
                } catch (t: Throwable) {
                    Log.e(tag, t)
                }
            }
        }

        // Непрерывная подписка на список диалогов: обновляем input текущего.
        subscriptionsScope.launch {
            conversationsFlow().map { it.notPopup() }.collect { conversations ->
                // Бросок updateInput не должен убивать коллектор: он единственный, и без него
                // инпут перестал бы обновляться до конца сессии диалога (handler скоупа молча
                // съел бы исключение вместе с подпиской).
                try {
                    val curId = viewModel.getCurrentConversationId()
                    val currentConversation = conversations.find { x -> x.id == curId }
                    Log.d("CQ_BotInput", "conversationsFlow emit: size=${conversations.size} curId=$curId found=${currentConversation != null} lastPartType=${currentConversation?.partLast?.type}")
                    if (currentConversation != null) {
                        updateInput(currentConversation)
                    }
                } catch (t: Throwable) {
                    Log.e(tag, t)
                }
            }
        }
    }

    private fun requestRoutingBot() {
        // Разовый запрос routing-бота — ЕДИНСТВЕННЫЙ в диалоге: и флаг needStartRoutingBot,
        // и решение тела чата «дерево бота vs дефолтное приветствие» берутся из этого ответа
        // (тело получает его через setRoutingBotResolved). Раньше тело спрашивало бэкенд само,
        // и при сетевом флейке ответы расходились: здесь ретрай узнавал «бот есть», а запрос
        // тела падал навсегда (повторять было некому) → в чате оставалось дефолтное приветствие.
        subscriptionsScope.launch {
            // Транзиентный сбой ретраим: этот запрос взводит needStartRoutingBot и вешает
            // ожидание нового диалога ниже. Если бы он молча падал, кнопки первой ветки
            // остались бы видимыми при флаге false — клик ушёл бы в meta_data по шаблонному
            // id → 400.
            var data: ChooseRoutingBotData? = null
            for (attempt in 1..3) {
                data = loadRoutingBot(viewModel.getCurrentConversationId())
                if (data != null) break
                delay(1000L * attempt)
            }
            if (data == null) {
                // Все попытки упали — состояние бота неизвестно, флаг НЕ трогаем
                // (протухший true безопаснее ложного false: startRoutingBot сработает,
                // а вот ложный false ломает старт бота необратимо для сессии).
                Log.d("CQ_BotInput", "commonSubscribes: chooseRoutingBot failed after retries, keep needStartRoutingBot=${viewModel.needStartRoutingBot()}")
                // Тело чата: резолвим (разрешаем дефолтное приветствие) ТОЛЬКО при живой сети —
                // это деградация «бэкенд не отвечает». В офлайне молчим: возврат сети
                // перезапустит бутстрап (network observer) и мы спросим бэкенд снова, иначе
                // приветствие подменило бы дерево включённого welcome-бота.
                val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
                if (networkManager.isNetworkAvailable()) {
                    getViewInterface()?.setRoutingBotResolved(null)
                }
                return@launch
            }
            getViewInterface()?.setRoutingBotResolved(data)
            val needStartRoutingBot = data.found == true
            viewModel.setNeedStartRoutingBot(needStartRoutingBot)
            if (needStartRoutingBot) {
                data?.bot?.id?.let { viewModel.setRoutingBotId(it) }
                // Разового hideInput по allow здесь больше нет: его перебивал любой следующий
                // updateInput по серверному partLast (reply_admin закрытого диалога → showInput).
                // Видимость поля решает updateInput по состоянию шаблона в ленте
                // (onRoutingTemplateStateChanged ← ChatViewModel.routingTemplateState).
                // Диалог с роутинг-ботом — ждём сохранения нового диалога, чтобы переключить
                // currentConversationId с временного randomId на реальный серверный id и повторить
                // choose по нему (requestRoutingBot). Новый диалог создаётся на сервере
                // (POST routing/start) ТОЛЬКО когда пользователь отвечает боту, а это происходит
                // в пользовательском темпе — часто сильно позже choose (человек сперва читает
                // первое сообщение). Раньше тут стоял жёсткий таймаут 5с: не успел ответить за 5с —
                // ожидание сдавалось, повторный запрос не вызывался → ответ бота не
                // подхватывался («ничего не приходит в ответ»). Поэтому ждём нужный диалог весь
                // lifecycle подписки (subscriptionsScope отменяется в onDestroy/resetSubscriptions).
                //
                // Ждём только пока диалога ещё нет (новый диалог, id пуст). При повторных вызовах
                // requestRoutingBot (id уже известен) ждать нечего — иначе корутина повисла бы до
                // onDestroy. Матчим по randomId: к моменту эмиссии currentConversationId уже равен
                // сгенерированному randomId (см. onSelectBotBrunch), поэтому берём именно наш диалог,
                // а не первый попавшийся.
                if (viewModel.getCurrentConversationId().isEmpty()) {
                    try {
                        val repo = ConversationsRepository.getInstance()
                        val isOurNewConversation: (DataConversation) -> Boolean = {
                            val cur = viewModel.getCurrentConversationId()
                            cur.isNotEmpty() && cur == it.randomId
                        }
                        // newConversationFlow — SharedFlow(replay=0): эмиссия могла пройти до first().
                        // Подстрахуемся — сперва проверим уже сохранённые диалоги.
                        // Дополнительно слушаем conversationsChangesFlow: randomId может появиться
                        // у УЖЕ добавленной конверсации (started-канал добавил её без random_id,
                        // parts_batch донёс его позже через updateConversation) — newConversationFlow
                        // в этом случае не переэмитится, и без второго источника матч не случится
                        // никогда (reply уходил на псевдо-id routing_* → 404).
                        val c = repo.getConversationsSync().find(isOurNewConversation)
                            ?: merge(
                                repo.newConversationFlow,
                                repo.conversationsChangesFlow()
                                    .mapNotNull { list -> list.find(isOurNewConversation) },
                            ).first()
                        viewModel.setNeedStartRoutingBot(false)
                        viewModel.updateCurrentConversationId(c.id)
                        // Открытый диалог — теперь реальный id (не полагаемся на порядок каналов
                        // RTS: message_conversation_started может прийти позже первого parts_batch,
                        // и его сообщения ушли бы в нотификации как «чужой» диалог).
                        updateOpenedConversationId(c.id)
                        // Только повторный choose по реальному id: непрерывные коллекторы
                        // (subscribeConversationUpdates) читают currentConversationId динамически и
                        // уже живут — полный commonSubscribes() здесь дублировал их до конца
                        // сессии диалога (двойной markConversationAsRead/updateInput на событие).
                        requestRoutingBot()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        Log.e(TAG, t)
                    }
                }
            }
        }
    }

    // Шторка действий над сообщением переехала в DialogFragment.openMessageActions: запуск через
    // launcher ради результата «Ответить» (цитирование, CAR-75966).

    // ── Прыжок к цитируемому сообщению (CAR-75966) ────────────────────────────

    private var isJumpLoading = false

    /**
     * Грузит окно вокруг [messageId] (paginate_direction=around) и регистрирует разрыв истории.
     * true — оригинал загружен, вызывающий (DialogFragment) запускает скролл+подсветку.
     * suspend, а не fire-and-forget: результат нужен вызывающему.
     */
    suspend fun jumpToMessage(messageId: String): Boolean {
        if (isJumpLoading) return false
        isJumpLoading = true
        return try {
            val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
            if (conversation == null) {
                SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                    "jump aborted: no conversation"
                }
                false
            } else {
                loadMessagesAround(conversation, messageId)
            }
        } catch (t: Throwable) {
            Log.e(tag, t)
            false
        } finally {
            isJumpLoading = false
        }
    }

    private var isGapLoading = false

    /**
     * Одна страница середины диалога (маркер разрыва показался на экране). [fromTail] — юзер
     * подошёл к разрыву со стороны хвоста → заполняем с нижнего края (before), иначе с верхнего.
     */
    fun loadGapMessages(fromTail: Boolean) {
        if (isGapLoading) return
        isGapLoading = true
        presenterScope.launch {
            try {
                val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
                if (conversation != null) loadGapPage(conversation, fromTail)
            } catch (t: Throwable) {
                // Сетевая ошибка — маркер остаётся; следующая материализация/страница повторит.
                Log.e(tag, t)
            } finally {
                isGapLoading = false
            }
        }
    }

    fun paginationMessages() {
        if (MessagesRepository.getInstance().getCurrentAfter().isEmpty()) return
        if (!isPagination) {
            isPagination = true
            getViewInterface()?.showLoadingOlderMessages()
            presenterScope.launch {
                try {
                    val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
                    if (conversation != null) paginationMessages(conversation)
                    isPagination = false
                    getViewInterface()?.hideLoadingOlderMessages()
                } catch (e: Throwable) {
                    getViewInterface()?.showErrorSomething()
                    isPagination = false
                    getViewInterface()?.hideLoadingOlderMessages()
                }
            }
        }
    }

    fun setContactDetails(messageId: String, type: String, value: String) {
        // Согласие дано в момент тапа (инлайн-кнопка гейтится чекбоксами) — фиксируем ДО
        // отправки свойства и вне отменяемой корутины (симметрично sendActionBot): выход из
        // диалога во время setUserProperty терял согласие.
        val requested = when (type) {
            "email" -> RequestedContactField.EMAIL
            "phone" -> RequestedContactField.PHONE
            else    -> RequestedContactField.NONE
        }
        saveConsentsForSend(requested, contactValue = value, partId = messageId)

        presenterScope.launch {
            val res = try {
                val message = getMessage(messageId) ?: return@launch
                updateAutoReplayLoading(message.id, false)
                val user = getCurrentUser() ?: return@launch
                setUserProperty(user.id, type, value)
            } catch (e: Throwable) {
                // Ошибка отправки контакта — помечаем сообщение как WARNING.
                val m = runCatching { getMessage(messageId) }.getOrNull()
                if (m?.id != null) {
                    runCatching {
                        updateStatusMessage(m, MessageStatus.WARNING.name.lowercase(Locale.getDefault()))
                    }
                }
                return@launch
            }

            updateAutoReplay(messageId, res)
            val message = getMessage(messageId)
            if (message?.messageMetaData != null) {
                val meta = message.messageMetaData
                meta?.replied = res
                meta?.loading = false
                message.messageMetaData = meta
                updateAutoReplayLocal(message)
            }
        }
    }

    fun sendVote(messageId: String, vote: Int) {
        presenterScope.launch {
            val res = try {
                sendVoteOperator(messageId, vote)
            } catch (e: Throwable) {
                wrongVoting(messageId)
                return@launch
            }
            if (res) {
                try {
                    doneVoting(messageId, vote)
                } catch (t: Throwable) {
                    Log.e(tag, t)
                }
            } else {
                wrongVoting(messageId)
            }
        }
    }

    fun sendCommentVote(messageId: String, vote: Int, comment: String) {
        presenterScope.launch {
            val res = try {
                sendVoteOperator(messageId, vote, comment)
            } catch (e: Throwable) {
                wrongVoting(messageId)
                return@launch
            }
            if (res) {
                doneVotingComment(messageId, vote)
            } else {
                wrongVoting(messageId)
            }
        }
    }

    fun onGoToLink(link: String, context: Context) {
        if (viewModel.getCurrentConversationId().isNotEmpty()
            && viewModel.getCurrentConversationId() != "last_conversation"
        ) {
            trackClick(viewModel.getCurrentConversationId(), object : Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                }

                override fun onFailure(t: Throwable?) {
                }
            })
        }
        // Ссылки без схемы (например, "google.com" из HTML <a href>) ACTION_VIEW не открывает —
        // достраиваем https://, иначе ловим ActivityNotFoundException.
        val uri = Uri.parse(link)
        val safeUri = if (uri.scheme.isNullOrEmpty()) Uri.parse("https://${link.trim()}") else uri
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = safeUri
        try {
            context.startActivity(intent)
        } catch (e: android.content.ActivityNotFoundException) {
            Log.e(tag, "No activity to open link: $safeUri")
        }
    }

    fun onResume() {
        // Перезапустить ping-цикл NetworkManager: если за ночь в Doze фоновый
        // retry исчерпал лимит и hasInternet застрял в false, тут флаг оживёт.
        NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).revalidate()

        val conversationId = viewModel.getCurrentConversationId()
        updateOpenedConversationId(conversationId)

        presenterScope.launch {
            delay(1000)
            val context = getViewInterface()?.getCurrentContext()
            val lastLoadTime = if(context != null) {
                SharedPreferencesLib.getLong(context, "last_load_messages_time_key")
            } else {
                0
            }

            val needHard = if(lastLoadTime == 0L) {
                true
            } else {
                Date().after(Date(lastLoadTime + (10 * 60 * 1000)))
            }
            if(!isOpenPicker) {
                loadMessages(needHardUpdate = needHard)
            } else {
                isOpenPicker = false
            }
        }
    }

    fun onPause() {
        removeTypingIndicator()
        updateOpenedConversationId("")
    }

    private var selectBotBrunchInProcess = false
    fun onSelectBotBrunch(
        messageId: String,
        branchId: String,
        branchLinkId: String,
        answerBody: String,
        href: String,
        context: Context
    ) {
        if(selectBotBrunchInProcess) {
            return
        }

        selectBotBrunchInProcess = true
        Log.d("CQ_BotInput", "onSelectBotBrunch msgId=$messageId branchId=$branchId answerBody='$answerBody' needStartRoutingBot=${viewModel.needStartRoutingBot()} convId=${viewModel.getCurrentConversationId()}")
        if (viewModel.needStartRoutingBot()) {
            val botId = viewModel.getRoutingBotId()
            // Ответ на стартовую ветку: шаблон становится частью диалога — до любых добавлений
            // сообщений, иначе оптимистичный ответ «вытеснил» бы неотвеченный шаблон из ленты.
            getViewInterface()?.markRoutingTemplateAnswered()

            val convId = viewModel.getCurrentConversationId().ifEmpty { null }
            val randomId = if (convId.isNullOrEmpty()) {
                "routing_${System.currentTimeMillis() / 1000}"
            } else {
                convId
            }

            updateOpenedConversationId(randomId)
            viewModel.updateCurrentConversationId(randomId)

            presenterScope.launch {
                try {
                    startRoutingBot(botId, branchId, answerBody, randomId, convId)
                    viewModel.setNeedStartRoutingBot(false)
                    delay(1000)
                    selectBotBrunchInProcess = false
                } catch (t: Throwable) {
                    Log.e(TAG, t)
                    selectBotBrunchInProcess = false
                }
            }
        } else {
            presenterScope.launch {
                try {
                    val mess = getMessage(messageId)
                    // mess есть и ветка уже выбрана (answerActionId != null) — ничего не делаем.
                    if (mess != null && mess.messageMetaData.answerActionId != null) {
                        selectBotBrunchInProcess = false
                    } else {
                        // showErrorSomething только когда сообщения нет в репозитории (как в оригинале).
                        val showErrorOnFail = mess == null
                        try {
                            selectBotBrunch(messageId, branchId, answerBody)
                        } catch (error: Throwable) {
                            Log.e(tag, error.toString())
                            if (showErrorOnFail) getViewInterface()?.showErrorSomething()
                        }
                        selectBotBrunchInProcess = false
                    }
                } catch (t: Throwable) {
                    Log.e(tag, t.toString())
                    selectBotBrunchInProcess = false
                }
            }
        }

        if (href != null && href.isNotEmpty() && href.lowercase() != "undefined") {
            try {
                val decodedUrl = URLDecoder.decode(href, "UTF-8")
                onGoToLink(decodedUrl, context)
            } catch (e: UnsupportedEncodingException) {
                //e.printStackTrace()
            }
        }
    }

    /**
     * Выбор кнопки быстрого ответа (quick_reply) в реплике админа, отправленной через public API.
     * В отличие от бот-кнопок (onSelectBotBrunch → meta_data части) ответ уходит ОБЫЧНОЙ репликой
     * пользователя: body = текст кнопки, meta_data = полезная нагрузка кнопки как есть. Ровно так
     * же делает веб-виджет (ChatBotButtons.handle: POST /conversations/{id}/reply). Схлопывание
     * группы кнопок уже сделано локально в ChatViewModel, ответ покажет оптимистичный бабл.
     */
    fun onQuickReplySelected(answerBody: String, metaData: String?, href: String, context: Context) {
        val conversationId = resolvePseudoConversationId(viewModel.getCurrentConversationId())
        if (conversationId.isEmpty() || isPseudoConversationId(conversationId)) {
            // quick_reply приходит только в существующем диалоге; псевдо-id бэкенд не знает (404).
            Log.e(tag, "onQuickReplySelected: no real conversation id ($conversationId)")
            return
        }
        sendNormalMessage(answerBody, conversationId, metaData = metaData, clearInput = false)

        if (href.isNotEmpty() && href.lowercase() != "undefined") {
            try {
                onGoToLink(URLDecoder.decode(href, "UTF-8"), context)
            } catch (e: UnsupportedEncodingException) {
                Log.e(tag, e.toString())
            }
        }
    }

    private var isOpenPicker = false
    fun onOpenPicker(height: Int) {
        isOpenPicker = true
        getViewInterface()?.openFilePicker()
    }

    // ── Мультиаттачи (upload-on-select) ─────────────────────────────────────────
    // staged[clientId] = серверный attachment (null пока грузится) — источник истины для
    // attachments_cached при отправке (Ф1.5). jobs[clientId] = фоновая загрузка (для отмены).
    // Доступ только из presenterScope (main) — гонок нет, обычные map ок.
    private val stagedAttachments = LinkedHashMap<String, Attachment?>()
    private val attachmentJobs = HashMap<String, Job>()

    // Сериализует сетевые upload-запросы вложений. КОСТЫЛЬ: бэкенд сортирует вложения сообщения по
    // id (а не по порядку в attachments_cached — для веб-запроса порядок сохраняется, для мобильного
    // нет; см. задачу на бэк). При параллельной загрузке id присваиваются в порядке ЗАВЕРШЕНИЯ →
    // картинки в доставленном сообщении перемешиваются. Грузим по очереди (чипы появляются сразу),
    // чтобы id шли в порядке выбора и сортировка по id на бэке совпала с превью. Убрать, когда бэкенд
    // начнёт уважать порядок attachments_cached — тогда вернуть параллельную загрузку.
    private val uploadMutex = kotlinx.coroutines.sync.Mutex()

    /** Выбраны файлы в пикере: валидируем каждый (лимит/размер/тип → боттомшит) и грузим в фоне. */
    fun onFilesPicked(uris: List<Uri>) {
        val activity = getViewInterface()?.getCurrentContext() as? android.app.Activity ?: return
        val helper = FilePickerHelper(activity)
        presenterScope.launch {
            for (uri in uris) {
                if (stagedAttachments.size >= MAX_ATTACHMENTS) {
                    helper.showErrorBottomSheet(
                        activity.getString(R.string.error_attachment_limit_title),
                        activity.getString(R.string.error_attachment_limit_message, MAX_ATTACHMENTS),
                    )
                    break
                }
                val file = withContext(SdkDispatchers.io) { helper.getFile(uri) }
                val path = file.absolutePath
                if (!helper.fileTypeIsCorrect(path)) {
                    helper.showErrorBottomSheet(
                        activity.getString(R.string.incorrect_file_type_title),
                        activity.getString(
                            R.string.incorrect_file_type_message,
                            FilePickerHelper.mAllowFileTypes.joinToString(", "),
                        ),
                    )
                    continue
                }
                val sizeOk = file.length() in 1 until (FilePickerHelper.maxSize * 1024L * 1024L)
                if (!sizeOk) {
                    val isImage = helper.fileIsImage(path)
                    helper.showErrorBottomSheet(
                        activity.getString(
                            if (isImage) R.string.error_image_size_title else R.string.error_file_size_title
                        ),
                        activity.getString(R.string.error_file_size_message, FilePickerHelper.maxSize),
                    )
                    continue
                }
                stageAndUpload(file, path, helper, activity)
            }
        }
    }

    private fun stageAndUpload(file: File, path: String, helper: FilePickerHelper, activity: android.app.Activity) {
        val clientId = java.util.UUID.randomUUID().toString()
        val localUri = "file://$path"
        val pending = if (helper.fileIsImage(path)) {
            PendingAttachment.ImageAttachment(clientId, localUri)
        } else {
            PendingAttachment.FileAttachment(clientId, localUri, file.name, attachmentMetaLabel(path, file.length()))
        }
        stagedAttachments[clientId] = null
        getViewInterface()?.addPendingAttachment(pending)

        val job = presenterScope.launch {
            try {
                // withLock — сериализация запросов: следующий файл грузится только после предыдущего,
                // поэтому id идут в порядке выбора (см. uploadMutex). Чип уже показан выше.
                val att = withContext(SdkDispatchers.io) {
                    uploadMutex.withLock { CarrotInternal.getService().carrotLib.uploadAttachmentSuspend(file) }
                }
                stagedAttachments[clientId] = att
                getViewInterface()?.updatePendingAttachmentState(clientId, AttachmentUploadState.UPLOADED)
                // Маппинг localUri→серверный url: после отправки сообщение покажет локальный файл сразу.
                att.url?.let { url -> saveLocalFileMapping(file.absolutePath, url) }
                persistAttachmentDraft() // драфт: переживёт случайное закрытие диалога
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                val body = (t as? retrofit2.HttpException)?.response()?.errorBody()?.string()
                Log.e(tag, "attachment upload failed: $t; body=$body")
                stagedAttachments.remove(clientId)
                getViewInterface()?.removePendingAttachment(clientId)
                helper.showErrorBottomSheet(
                    activity.getString(R.string.error_attachment_upload_failed_title),
                    activity.getString(R.string.error_attachment_upload_failed_message),
                )
            } finally {
                attachmentJobs.remove(clientId)
            }
        }
        attachmentJobs[clientId] = job
    }

    /** Отмена загрузки/удаление вложения (тап по прогрессу или крестику). Чип убирает VM (фрагмент). */
    fun onRemoveAttachment(clientId: String) {
        attachmentJobs.remove(clientId)?.cancel()
        stagedAttachments.remove(clientId)
        persistAttachmentDraft() // обновляем драфт (или чистим, если вложений не осталось)
    }

    // Сохраняем драфт вложений (только УЖЕ загруженные refs) для текущего диалога; пусто → чистим.
    private fun persistAttachmentDraft() {
        val convId = viewModel.getCurrentConversationId()
        val json = buildAttachmentsCachedJson(stagedAttachments.values.filterNotNull().toList())
        if (json == null) clearDraftAttachmentsUseCase(convId)
        else saveDraftAttachmentsUseCase(json, convId)
    }

    /**
     * Восстанавливает чипы из драфта при открытии диалога (вызывается из showInput). Только если
     * staging пуст (защита от дубля при повторных showInput). Парсим сохранённый JSON в Attachment,
     * чипы поднимаем сразу UPLOADED (превью — из серверного url), ref кладём в staged для attachments_cached.
     */
    fun restoreAttachmentDraft(conversationId: String) {
        if (stagedAttachments.isNotEmpty()) return
        val json = getDraftAttachmentsUseCase(conversationId) ?: return
        val refs = try {
            com.google.gson.Gson().fromJson(json, Array<Attachment>::class.java)?.toList().orEmpty()
        } catch (t: Throwable) {
            Log.e(tag, "restoreAttachmentDraft parse failed: $t")
            clearDraftAttachmentsUseCase(conversationId)
            return
        }
        for (att in refs) {
            val clientId = java.util.UUID.randomUUID().toString()
            stagedAttachments[clientId] = att
            val isImage = att.mimeType?.startsWith("image/") == true || att.type == "image"
            val pending = if (isImage) {
                PendingAttachment.ImageAttachment(clientId, att.url ?: "", AttachmentUploadState.UPLOADED)
            } else {
                PendingAttachment.FileAttachment(
                    clientId,
                    att.url ?: "",
                    att.filename ?: "",
                    attachmentMetaLabel(att.filename ?: "", att.size),
                    AttachmentUploadState.UPLOADED,
                )
            }
            getViewInterface()?.addPendingAttachment(pending)
        }
    }

    private suspend fun saveLocalFileMapping(localPath: String, url: String) {
        val savedFile = SavedFile(System.currentTimeMillis().toString())
        savedFile.localUri = localPath
        savedFile.url = url
        if (db == null) db = CarrotInternal.getLibComponent().sdkDataBase
        withContext(SdkDispatchers.io) { db?.savedFileDao()?.insert(savedFile) }
    }

    // Подпись файла-чипа: «PDF · 50 KB» (латинские единицы — нейтрально к языку).
    private fun attachmentMetaLabel(path: String, sizeBytes: Long): String {
        val dot = path.lastIndexOf('.')
        val ext = if (dot in 0 until path.length - 1) path.substring(dot + 1).uppercase(Locale.getDefault()) else ""
        val size = humanReadableSize(sizeBytes)
        return if (ext.isEmpty()) size else "$ext · $size"
    }

    private fun humanReadableSize(bytes: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        return when {
            bytes >= mb -> String.format(Locale.getDefault(), "%.1f MB", bytes / mb)
            bytes >= kb -> "${(bytes / kb).toInt()} KB"
            else -> "$bytes B"
        }
    }

    private fun isCorrectPhone(text: String, typeReply: String): Boolean {
        if(selectedCountry == null || typeReply != "phone") {
            return true
        }

        val phone = if (currentInputMod == InputMod.BOT_INPUT) {
            "+${selectedCountry?.countryCode}$text"
        } else {
            text
        }

        return PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
            .isPossibleNumber(phone, selectedCountry!!.region.uppercase())
    }


    fun onInputText(text: String) {
        //Отправляем на сервер событие о том, что пользователь печатает
        // Псевдо-id (routing_*) не существует на бэкенде — settyping с ним отвечает 400.
        val conversationId = resolvePseudoConversationId(viewModel.getCurrentConversationId())
        if (conversationId.isNotEmpty() && !isPseudoConversationId(conversationId)) {
            CarrotInternal.getService().setTyping(conversationId, text)
        }

        saveDraftMessageUseCase(text, conversationId)

        presenterScope.launch {
            val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
            // Телефон-валидацию применяем ТОЛЬКО когда реально вводим бот-поле телефона (BOT_INPUT).
            // В свободном режиме (NORMAL) автоответ может иметь partLast.replyType=="phone", но это не
            // значит, что юзер обязан ввести телефон — он вправе отправить обычный текст (как на вебе).
            // Иначе кнопка отправки висела серой при partReplyType=="phone" даже для свободного текста.
            // Бот-поле телефона остаётся в BOT_INPUT и валидируется как раньше — sendActionBot не трогаем.
            val phoneIsCorrect = if (currentInputMod == InputMod.BOT_INPUT && conversation?.partLast?.replyType != null) {
                isCorrectPhone(text.trim(), conversation.partLast.replyType)
            } else {
                true
            }

            if (!TextUtils.isEmpty(text.trim()) && phoneIsCorrect) {
                // attach НЕ скрываем при наличии текста: его видимость определяется режимом
                // (setInputMod: NORMAL → виден, BOT_INPUT → скрыт). Механику hide/showAttachFileButton
                // сохраняем — она понадобится, чтобы прятать attach во время записи голоса.
                getViewInterface()?.enableSendButton()
                getViewInterface()?.showSendButton()
            } else {
                if (currentInputMod == InputMod.BOT_INPUT) {
                    getViewInterface()?.disableSendButton()
                    getViewInterface()?.showSendButton()
                    getViewInterface()?.hideAttachFileButton()
                } else {
                    getViewInterface()?.disableSendButton()
                    getViewInterface()?.showAttachFileButton()
                }
            }
        }
    }

    private var currentInputMod = InputMod.NORMAL

    // Активная стартовая ветка routing-бота в теле чата (ChatViewModel → DialogFragment → сюда).
    // null — шаблон не показан или уже не последний элемент ленты. Пока он последний, именно он —
    // фактический part_last беседы, и updateInput решает видимость поля по нему, а не по серверному
    // partLast (см. RoutingTemplateState, resolveInputBranch).
    private var routingTemplateState: RoutingTemplateState? = null

    fun onRoutingTemplateStateChanged(state: RoutingTemplateState?) {
        if (routingTemplateState == state) return
        routingTemplateState = state
        Log.d("CQ_BotInput", "routing template state → $state")
        val conversationId = viewModel.getCurrentConversationId()
        val conversation = ConversationsRepository.getInstance().getConversationById(conversationId)
        if (conversation != null) {
            // Пересчёт по единому правилу — иначе разовый hide/show перебил бы следующий updateInput
            // из conversationsFlow/loadConversationAndUpdateInput (в этом и был баг переоткрытия).
            updateInput(conversation)
            return
        }
        // Новый диалог: беседы ещё нет, updateInput не отработает — применяем решение напрямую.
        // Когда шаблон перестаёт быть последним (ответ боту), беседа уже создаётся на сервере и
        // дальше поле решает updateInput по её part'ам.
        when {
            state == null -> Unit
            state.propertyField != null -> {
                applyRoutingTemplatePropertyField(conversationId, state.propertyField)
                getViewInterface()?.setInputMod(currentInputMod)
            }
            // Прерывание разрешено — полноценный свободный ввод, как ветка ROUTING_TEMPLATE_ALLOWED
            // в updateInput (хинт, клавиатура, префикс, согласие), а не голый showInput.
            state.allowUserReplies -> {
                currentInputMod = InputMod.ALLOW_USER_REPLIES
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
                pushInputConsent(RequestedContactField.NONE)
                getViewInterface()?.setInputMod(currentInputMod)
            }
            else -> getViewInterface()?.hideInput()
        }
    }

    // Bot-input для запроса данных из стартовой ветки routing-бота. replyType у шаблона нет —
    // тип поля (телефон/email/имя/custom) берётся из action.placeholder (botAnswerHint/keyboardTypeFor
    // по нему и работают); phone_mask считаем телефоном, как веб по key_name.
    private fun applyRoutingTemplatePropertyField(conversationId: String, action: ActionMessage) {
        applyBotPropertyFieldInput(
            conversationId,
            action,
            replyType = when (action.placeholder?.type) {
                "phone", "phone_mask" -> "phone"
                "email" -> "email"
                else -> null
            },
            phoneTypes = setOf("phone", "phone_mask"),
        )
    }
    private var currentAction: ActionMessage? = null

    // Контактное поле, фактически показанное в BOT_INPUT (см. applyBotPropertyFieldInput).
    // NONE вне бот-режима.
    private var currentRequestedField = RequestedContactField.NONE

    /**
     * Псевдо-id конверсации, сгенерированный клиентом до создания диалога на бэкенде
     * (см. onSelectBotBrunch/sendActionBot). Бэкенд такой id не знает: reply → 404, settyping → 400.
     */
    private fun isPseudoConversationId(conversationId: String): Boolean =
        conversationId.startsWith("routing_")

    /**
     * Разовый перематч псевдо-id на реальный серверный id по randomId — только для сетевого
     * вызова, БЕЗ смены currentConversationId: подмена id и подъём подписок — зона
     * ответственности waiter'а в commonSubscribes (он матчит по randomId и сломается,
     * если currentConversationId поменять раньше него).
     */
    private fun resolvePseudoConversationId(conversationId: String): String {
        if (!isPseudoConversationId(conversationId)) return conversationId
        return ConversationsRepository.getInstance().getConversationsSync()
            .find { it.randomId == conversationId }?.id ?: conversationId
    }

    fun onTapSendMessage(textMessage: String, repliedToId: String? = null) {
        val conversationId = resolvePseudoConversationId(viewModel.getCurrentConversationId())
        if (currentInputMod == InputMod.BOT_INPUT && currentAction != null) {
            // Ответ боту цитату не несёт (бэкенд запрещает цитирование бот-сообщений) —
            // repliedToId сюда и не приходит (гейты во фрагменте), параметр игнорируем.
            sendActionBot(currentAction!!, textMessage)
            currentInputMod = InputMod.NORMAL
            currentRequestedField = RequestedContactField.NONE
            // Синхронизируем UI с новым режимом (вернёт скрепку), не дожидаясь следующего
            // updateInput от RTS — он может прийти с задержкой или не прийти вовсе.
            getViewInterface()?.setInputMod(currentInputMod)
        } else {
            // Мультиаттачи: забираем УЖЕ загруженные вложения (send заблокирован, пока что-то грузится),
            // строим attachments_cached и сразу очищаем ленту — одно сообщение несёт текст + вложения.
            val attachments = stagedAttachments.values.filterNotNull().toList()
            val attachmentsCached = buildAttachmentsCachedJson(attachments)
            if (attachments.isNotEmpty()) {
                stagedAttachments.clear()
                attachmentJobs.clear()
                getViewInterface()?.clearPendingAttachments()
                clearDraftAttachmentsUseCase(conversationId)
            }
            if (!TextUtils.isEmpty(conversationId)) {
                sendNormalMessage(textMessage, conversationId, attachments, attachmentsCached, repliedToId)
            } else {
                // Новый диалог: цитировать нечего (quotable-сообщений ещё нет), repliedToId не передаём.
                createConversation(textMessage, attachments, attachmentsCached)
            }
            // Обычный ввод: сохраняем согласие на обработку перс. данных (только оно показывается в
            // NONE-режиме). Отправка гейтится согласием, поэтому дошли сюда → согласие дано.
            saveConsentsForSend(RequestedContactField.NONE, contactValue = null, partId = conversationId)
        }
    }


    /**
     * Отправка голосового (Ф2): загружаем записанный WAV через тот же эндпоинт, что и вложения
     * (upload-on-send), помечаем type="voice" и шлём ОТДЕЛЬНЫМ сообщением (без текста). Оптимистично
     * рисуется плеером голосового (локальный файл через saveLocalFileMapping → волна/проигрывание сразу).
     */
    fun onSendVoice(file: File, durationSec: Int, repliedToId: String? = null) {
        val conversationId = viewModel.getCurrentConversationId()
        // Голос доступен только в обычном режиме → согласие здесь — обработка перс. данных (NONE).
        // Кнопка отправки гейтится consentOk, дошли сюда → согласие дано; фиксируем в момент тапа,
        // как в onTapSendMessage/sendActionBot.
        saveConsentsForSend(RequestedContactField.NONE, contactValue = null, partId = conversationId)
        // Новый диалог (первое сообщение — голос): кейс редкий, оставляем upload→createConversation
        // (бабл появляется после загрузки). Цитаты в новом диалоге не бывает.
        if (TextUtils.isEmpty(conversationId)) {
            sendVoiceAsNewConversation(file)
            return
        }

        // Голос уходит через /reply + attachments_cached (НЕ /replyfile) — replied_to
        // поддерживается: снапшот в optimistic, id отправит sendMessage (как у текста).
        val repliedTo = repliedToId?.let {
            // Фолбэк на «голый» id: после восстановления reply-драфта оригинал может быть
            // ещё не загружен (глубокая история) — replied_to всё равно должен уйти на сервер;
            // квоту в бабле дорисует серверное эхо.
            MessagesRepository.getInstance().findMessageById(it)?.toRepliedToSnapshot()
                ?: io.carrotquest_sdk.android.lib.network.responses.messages.RepliedTo(id = it)
        }
        if (repliedToId != null) {
            SdkLogger.log(SdkLogLevel.DEBUG, io.carrotquest_sdk.android.core.logging.SdkLogCategory.GENERAL, "Reply") {
                "onSendVoice: repliedToId=$repliedToId snapshot=${repliedTo != null}"
            }
        }

        // Существующий диалог: оптимистично показываем голосовой бабл СРАЗУ (локальный WAV, статус
        // «отправляется»), грузим в фоне, затем тем же сообщением шлём на сервер. Ошибка → статус
        // failed (ретрай/удаление через боттомшит действий). Без задержки до появления бабла.
        presenterScope.launch {
            val localAtt = Attachment().apply {
                type = "voice"
                url = file.absolutePath
                filename = file.name
                size = file.length()
                mimeType = "audio/wav"
                created = (System.currentTimeMillis() / 1000).toString()
            }
            val optimistic = createMessage(localAtt, conversationId, isFirst = false, status = MessageStatus.LOADING, repliedTo = repliedTo)
            saveMessage(optimistic)
            // Персистит упавший голос для ресенда: локальный путь WAV + attachments_cached
            // (если upload успел). Вызывается и на отмене корутины (уход с экрана во время
            // upload) — раньше этот путь терял голос вообще без следа.
            fun persistFailedVoice(attachmentsCached: String? = null) {
                optimistic.status = MessageStatus.WARNING.name.lowercase(Locale.getDefault())
                MessagesRepository.getInstance().updateMessage(optimistic)
                saveErrorMessage(optimistic, attachPath = file.absolutePath, attachmentsCached = attachmentsCached)
            }

            var uploadedCached: String? = null
            try {
                val att = withContext(SdkDispatchers.io) {
                    CarrotInternal.getService().carrotLib.uploadAttachmentSuspend(file)
                }
                att.type = "voice" // контракт голосового (на случай, если сервер вернул file/иной type)
                att.url?.let { url -> saveLocalFileMapping(file.absolutePath, url) }
                val attachmentsCached = buildAttachmentsCachedJson(listOf(att))
                uploadedCached = attachmentsCached
                // Обновляем ТО ЖЕ оптимистичное сообщение (id + статус LOADED) — без дубля.
                val sent = sendMessage(optimistic, attachmentsCached)
                if (sent.status == MessageStatus.LOADED.name.lowercase(Locale.getDefault())) {
                    // Доставлено. Файл НЕ удаляем: оптимистичное сообщение и SavedFile-маппинг
                    // ещё указывают на локальный путь (серверный URL прилетит только с эхом по
                    // RTS), поэтому удаление здесь оставляло плеер без источника — только что
                    // отправленное голосовое переставало воспроизводиться. WAV живёт до
                    // следующего старта SDK и подчищается orphan-sweep'ом (cleanupVoiceFiles):
                    // доставленное сообщение на него уже не ссылается записью очереди ресенда.
                } else {
                    // Серверная meta.error: onError внутри sendMessage сохранил запись без
                    // attach-меты — пересохраняем полноценно (путь + attachments_cached).
                    persistFailedVoice(attachmentsCached)
                }
            } catch (c: CancellationException) {
                persistFailedVoice(uploadedCached)
                throw c
            } catch (t: Throwable) {
                val body = (t as? retrofit2.HttpException)?.response()?.errorBody()?.string()
                Log.e(tag, "voice upload/send failed: $t; body=$body")
                persistFailedVoice(uploadedCached)
            }
        }
    }

    // Голос как ПЕРВОЕ сообщение нового диалога: грузим WAV, затем создаём беседу (оптимистичный
    // бабл createConversation покажет уже загруженное вложение).
    private fun sendVoiceAsNewConversation(file: File) {
        presenterScope.launch {
            try {
                val att = withContext(SdkDispatchers.io) {
                    CarrotInternal.getService().carrotLib.uploadAttachmentSuspend(file)
                }
                att.type = "voice"
                att.url?.let { url -> saveLocalFileMapping(file.absolutePath, url) }
                val attachmentsCached = buildAttachmentsCachedJson(listOf(att))
                createConversation("", listOf(att), attachmentsCached)
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                val body = (t as? retrofit2.HttpException)?.response()?.errorBody()?.string()
                Log.e(tag, "voice upload/send failed (new conversation): $t; body=$body")
                (getViewInterface()?.getCurrentContext() as? android.app.Activity)?.let { activity ->
                    FilePickerHelper(activity).showErrorBottomSheet(
                        activity.getString(R.string.error_attachment_upload_failed_title),
                        activity.getString(R.string.error_attachment_upload_failed_message),
                    )
                }
            }
        }
    }

    fun onCountrySelected(country: CountryEntity) {
        setPhoneRegion(country)
    }

    fun onChangeConversationId(conversationId: String) {
        viewModel.updateCurrentConversationId(conversationId)
        currentAction = null
        currentInputMod = InputMod.NORMAL
        routingTemplateState = null
    }

    private fun sendActionBot(action: ActionMessage, answer: String) {
        // Текстовый ответ на стартовую ветку routing-бота (property_field в первой ветке): шаблон
        // становится частью диалога ДО addMessage ниже — см. markRoutingTemplateAnswered.
        if (viewModel.needStartRoutingBot()) {
            getViewInterface()?.markRoutingTemplateAnswered()
        }
        fun upMessage(message: MessageData): MessageData {
            message.status =
                MessageStatus.LOADED.name.lowercase()
            val jsonSource = message.sourceJsonData
            if (jsonSource.has(F.STATUS)) {
                jsonSource.remove(F.STATUS)
            }
            jsonSource.put(
                F.STATUS,
                MessageStatus.LOADED.name.lowercase()
            )

            message.sourceJsonData = jsonSource
            MessagesRepository.getInstance().updateMessage(message)

            viewModel.getRoutingBotId()

            return message
        }

        // Ключуемся на фактически показанное поле (currentRequestedField), а НЕ на повторный
        // fetch беседы: getConversationSuspend по псевдо-id routing_* возвращал null и ранний
        // return хоронил и отправку, и сохранение согласия; а partLast.replyType к этому моменту
        // мог отличаться от показанного (phone_mask). Префикс страны добавляем ровно тогда, когда
        // он был показан юзеру (PHONE-режим).
        val requested = currentRequestedField
        val trueAnswer =
            if (selectedCountry != null && requested == RequestedContactField.PHONE) {
                "+${selectedCountry?.countryCode}$answer"
            } else {
                answer
            }

        // Согласие дано в момент тапа Send (кнопка гейтится чекбоксами) — фиксируем СРАЗУ и вне
        // отменяемой корутины: раньше save стоял после suspend-отправки ответа в presenterScope,
        // и выход из диалога в это окно терял согласие (сами POST'ы уходят в serviceScope).
        saveConsentsForSend(requested, contactValue = trueAnswer, partId = action.messageId ?: "")

        // Ответ на часть типа chat_bot_user бэкенд кладёт в meta_data.answer_body ЭТОЙ ЖЕ части,
        // и MessageMapper рисует по нему исходящий пузырь (id = id части). Оптимистичное
        // reply_user-сообщение давало ВТОРОЙ пузырь с локальным id-таймстампом — схлопнуть их
        // было нечем (дедуп везде по id/randomId). Поэтому для таких частей вместо оптимистичного
        // сообщения ставим локальный оверрайд на самой части — ровно как для кнопок бота
        // (ChatViewModel.localBotAnswers). Оптимистичное сообщение остаётся в двух случаях:
        //  • старт routing-бота — ответ уходит в НОВЫЙ диалог, а часть-вопрос это шаблон
        //    chooseRoutingBot, которого в MessagesRepository нет;
        //  • части других типов (auto_reply/chat_bot_admin/reply_admin с property_field) —
        //    там маппер ответ из answer_body не рисует вовсе, пузырь взять больше неоткуда.
        // Ставим ДО отменяемой корутины, как saveConsentsForSend: выход из диалога в это окно
        // не должен проглотить показ ответа.
        val partId = action.messageId
        val part = partId?.let { MessagesRepository.getInstance().findMessageById(it) }
        val answerRenderedOnPart = !viewModel.needStartRoutingBot() &&
            !partId.isNullOrEmpty() &&
            MessageMapper.rendersUserAnswerOnPart(part?.type)
        if (answerRenderedOnPart) {
            getViewInterface()?.setBotTextAnswer(partId, trueAnswer)
        }

        presenterScope.launch {
            // Драфт мог быть сохранён и под псевдо-id, и под реальным: onInputText пишет по
            // resolvePseudoConversationId(current), но маппинг randomId->id появляется асинхронно —
            // часть ввода до создания беседы ложится под псевдо-ключ, после — под реальный.
            // Очистка только сырого current промахивалась мимо реального ключа, и следующий
            // showInput (RTS updateInput следующей ветки бота) возвращал отправленный ответ
            // (телефон/email) обратно в поле ввода. Чистим ОБА ключа.
            val rawConvId = viewModel.getCurrentConversationId()
            val resolvedConvId = resolvePseudoConversationId(rawConvId)
            clearDraftMessageUseCase(rawConvId)
            if (resolvedConvId != rawConvId) {
                clearDraftMessageUseCase(resolvedConvId)
            }
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Draft") {
                "bot answer sent: draft cleared (raw=$rawConvId resolved=$resolvedConvId)"
            }
            getViewInterface()?.clearInput()

            // createMessage зовём в ОБОИХ случаях: помимо оптимистичного сообщения он двигает
            // partLast беседы (applyOutgoingToConversation) — без этого следующий эмит
            // conversationsFlow снова увидел бы part с property_field и вернул бы бар в
            // BOT_INPUT, дав ответить на тот же вопрос второй раз.
            val message = createMessage(
                trueAnswer,
                viewModel.getCurrentConversationId(),
                isFirst = false,
                status = MessageStatus.LOADING
            )

            if (!answerRenderedOnPart) {
                // Порядок сообщений: якорь к серверному таймлайну (sortCreated/sortKey) уже
                // проставлен внутри createMessage (anchorSortKeys) — он единый для всех путей
                // оптимистичной отправки и, в отличие от прежнего локального якоря, не подменяет
                // created (время отображения) и работает при пустом репозитории (новый диалог).
                // В ветке оверрайда якорить нечего: пузырь наследует created/sortKey части-вопроса.

                // Оптимистичная отрисовка: текстовый ответ боту (поле ввода в BOT_INPUT) кладём в
                // репозиторий сразу, как делает sendNormalMessage. Иначе сообщение появлялось только
                // после перезахода в диалог — upMessage()→updateMessage() это no-op, пока сообщения
                // нет в списке (MessagesRepository.updateMessage).
                MessagesRepository.getInstance().addMessage(message)
            }

            if (viewModel.needStartRoutingBot()) {
                val botId = viewModel.getRoutingBotId()
                // convId читаем ДО подмены currentConversationId на randomId (как в onSelectBotBrunch),
                // иначе convId всегда равен randomId и ветка с существующим id мертва.
                val convId = viewModel.getCurrentConversationId().ifEmpty { null }
                val randomId = convId ?: "routing_${System.currentTimeMillis() / 1000}"
                // Как в onSelectBotBrunch: псевдо-id становится «открытым» диалогом — по нему
                // PushNotificationHelper (lastOpened == conv.randomId) гасит нотификации на
                // сообщения бота в этот же, ещё не созданный диалог. Без этого текстовый ответ
                // на первую ветку получал системные нотификации на каждую реплику бота.
                updateOpenedConversationId(randomId)
                viewModel.updateCurrentConversationId(randomId)
                try {
                    // Текст ответа — как initial_answer_body в вебе (BotAnswerField). Раньше уходил
                    // action.body, а у property_field он пуст → use case выходил без запроса, ответ
                    // на первую ветку с полем ввода никуда не отправлялся.
                    val started = startRoutingBot(botId, action.id, trueAnswer, randomId, convId)
                    Log.d("CQ_BotInput", "sendActionBot: routing/start actionId=${action.id} started=$started")
                    viewModel.setNeedStartRoutingBot(false)
                    val jsonSource = message.sourceJsonData
                    if (jsonSource.has(F.CREATED)) {
                        jsonSource.remove(F.CREATED)
                    }
                    message.sourceJsonData = jsonSource
                    upMessage(message)
                } catch (t: Throwable) {
                    // Отмену корутины (закрытие диалога во время сетевого вызова) не глотаем
                    // и не логируем как ошибку — пробрасываем дальше.
                    if (t is CancellationException) throw t
                    Log.e(TAG, t)
                }
            } else {
                try {
                    selectBotBrunch(action.messageId, action.id, trueAnswer)
                    // В ветке оверрайда upMessage бессмыслен: сообщения нет в репозитории →
                    // updateMessage это no-op, а его матч по randomId теоретически мог бы
                    // зацепить чужое оптимистичное сообщение той же секунды.
                    if (!answerRenderedOnPart) upMessage(message)
                } catch (error: Throwable) {
                    // Отмену корутины не глотаем — пробрасываем дальше.
                    if (error is CancellationException) throw error
                    Log.e(tag, error.toString())
                    // Локальный пузырь остаётся (текст ответа не теряем), но молча делать вид,
                    // что ответ доставлен, нельзя — показываем ошибку. Раньше на этом пути
                    // оптимистичное сообщение навсегда зависало в статусе loading.
                    if (answerRenderedOnPart) getViewInterface()?.showErrorSendMessage()
                }
            }
        }
    }

    private fun sendNormalMessage(
        textMessage: String,
        conversationId: String,
        attachments: List<Attachment> = emptyList(),
        attachmentsCached: String? = null,
        repliedToId: String? = null,
        metaData: String? = null,
        // Ответ кнопкой быстрого ответа набранный текст не трогает (как в вебе): инпут и драфт
        // чистим только когда отправляем именно содержимое поля ввода.
        clearInput: Boolean = true,
    ) {
        if (clearInput) {
            clearDraftMessageUseCase(conversationId)
            getViewInterface()?.clearInput()
        }

        // Снапшот цитаты из загруженного оригинала — optimistic-бабл сразу рисуется с квотой,
        // идентичной будущему серверному эху; id уходит в form-поле replied_to (sendMessage).
        val repliedTo = repliedToId?.let {
            // Фолбэк на «голый» id: после восстановления reply-драфта оригинал может быть
            // ещё не загружен (глубокая история) — replied_to всё равно должен уйти на сервер;
            // квоту в бабле дорисует серверное эхо.
            MessagesRepository.getInstance().findMessageById(it)?.toRepliedToSnapshot()
                ?: io.carrotquest_sdk.android.lib.network.responses.messages.RepliedTo(id = it)
        }
        if (repliedToId != null) {
            SdkLogger.log(SdkLogLevel.DEBUG, io.carrotquest_sdk.android.core.logging.SdkLogCategory.GENERAL, "Reply") {
                "sendNormalMessage: repliedToId=$repliedToId snapshot=${repliedTo != null}"
            }
        }

        presenterScope.launch {
            try {
                // Именно параметр, не viewModel: currentConversationId может оставаться псевдо-id
                // (routing_*), а сюда уже передан перематченный реальный id (onTapSendMessage).
                val newMessage = createMessage(textMessage, conversationId, repliedTo)
                // Оптимистично показываем вложения сразу (url у них уже серверный → рендерятся).
                if (attachments.isNotEmpty()) newMessage.attachments = ArrayList(attachments)
                sendMessage(newMessage, attachmentsCached, metaData)
                getViewInterface()?.enableInput()
            } catch (t: Throwable) {
                Log.e(tag, t)
                getViewInterface()?.enableInput()
                getViewInterface()?.showErrorSendMessage()
                return@launch
            }

            try {
                val conversation = getConversationSuspend(conversationId)
                val messages = if (conversation != null) getMessages(conversation) else null
                if (messages != null) {
                    for (message in messages.data) {
                        MessagesRepository.getInstance().removeExpirationMessage(messageId = message.id)
                    }
                }
            } catch (t: Throwable) {
                Log.e(tag, t)
            }
        }
    }

    // Первое сообщение нового диалога, у которого упал POST startconversation. Авто-ресенд
    // (sendErrorMessages) такие сообщения не умеет — у них ещё нет conversationId, reply
    // не применим. Храним параметры, чтобы «Повторить» с error-screen пересоздал беседу.
    private data class PendingFirstMessage(
        val text: String,
        val attachments: List<Attachment>,
        val attachmentsCached: String?,
        val messageId: String,
    )

    private var pendingFirstMessage: PendingFirstMessage? = null

    private fun retryCreateConversation() {
        val pending = pendingFirstMessage ?: return
        pendingFirstMessage = null
        // Прежний упавший бабл убираем — createConversation создаст свежий оптимистичный.
        MessagesRepository.getInstance().removeMessage(pending.messageId)
        createConversation(pending.text, pending.attachments, pending.attachmentsCached)
    }

    private suspend fun onCreateConversationFailed(
        firstMessage: MessageData,
        textMessage: String,
        attachments: List<Attachment>,
        attachmentsCached: String?,
        error: Throwable?,
    ) {
        pendingFirstMessage =
            PendingFirstMessage(textMessage, attachments, attachmentsCached, firstMessage.id)
        // Снимаем LOADING с бабла — иначе на нём вечный спиннер отправки.
        updateStatusMessage(firstMessage, MessageStatus.WARNING.name.lowercase(Locale.getDefault()))
        getViewInterface()?.enableInput()
        // showErrorForThrowable, а не showErrorSomething: офлайн-падение должно показывать
        // «нет интернета», GENERIC — только для реальных backend-ошибок.
        showErrorForThrowable(error)
    }

    private fun createConversation(
        textMessage: String,
        attachments: List<Attachment> = emptyList(),
        attachmentsCached: String? = null,
    ) {
        clearDraftMessageUseCase("")
        getViewInterface()?.clearInput()

        presenterScope.launch {
            val firstMessage = try {
                removeWelcomeMessage()
                val m = createMessage(textMessage, "", isFirst = true, status = MessageStatus.LOADING)
                if (attachments.isNotEmpty()) m.attachments = ArrayList(attachments)
                saveMessage(m)
            } catch (t: Throwable) {
                Log.e(tag, t)
                return@launch
            }

            // Очищаем прежние подписки (commonSubscribes и пр.) перед стартом нового диалога.
            resetSubscriptions()

            try {
                val nConversationId = createConversationSuspend(textMessage, attachmentsCached)
                if (!TextUtils.isEmpty(nConversationId)) {
                    pendingFirstMessage = null
                    viewModel.updateCurrentConversationId(nConversationId)
                    // Беседа создана — экран должен быть в Content (ретрай мог поставить Loading).
                    getViewInterface()?.hideLoading()
                    try {
                        val conv = getConversationSuspend(nConversationId)
                        commonSubscribes()
                        val convId = conv?.id!!
                        updateStatusMessage(firstMessage, MessageStatus.LOADED.name.lowercase(Locale.getDefault()))
                        updateConversationMessage(convId, firstMessage)
                        getViewInterface()?.enableInput()
                    } catch (t: Throwable) {
                        Log.e(tag, t.message)
                    }
                } else {
                    // Бэкенд не вернул id — не офлайн: покажем GENERIC, но дадим повторить.
                    onCreateConversationFailed(firstMessage, textMessage, attachments, attachmentsCached, null)
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                Log.e(tag, t)
                onCreateConversationFailed(firstMessage, textMessage, attachments, attachmentsCached, t)
            }
        }
    }

    private fun loadMessages(needHardUpdate: Boolean = false, showErrorOnFailure: Boolean = false) {
        val context = getViewInterface()?.getCurrentContext()
        if (context != null) {
            SharedPreferencesLib.saveLong(context, "last_load_messages_time_key", Date().time)
        }

        val tokenIsActual = if(context != null) {
            isActualJwtToken(context)
        } else {
            true
        }

        if(!tokenIsActual) {
            presenterScope.launch {
                val token = refreshJwtToken()
                if (token != null) {
                    // user.token уже синхронизирован внутри refreshJwtToken (saveRefreshedTokens).
                    runUpdateMessages(needHardUpdate, showErrorOnFailure)
                } else {
                    e("RetrofitModule", "refresh token error")
                    // refresh не удался (нет валидной сессии) — пробуем общий путь: он дождётся
                    // Ready (SDK переинициализируется при сети) и в любом случае снимет спиннер.
                    runUpdateMessages(needHardUpdate, showErrorOnFailure)
                }
            }
        } else {
            runUpdateMessages(needHardUpdate, showErrorOnFailure)
        }
    }

    // showErrorOnFailure=true — вызов инициирован пользователем/явной загрузкой (Retry) и на экране
    // ещё нет контента: сбой обязан привести к оверлею ошибки, а не к пустому/кэшному диалогу.
    // false (фоновый рефреш из observer'ов foreground/сети) — при уже показанном Content транзиентный
    // сбой контент НЕ рушим: просто снимаем спиннер и оставляем что было.
    private fun runUpdateMessages(needHardUpdate: Boolean, showErrorOnFailure: Boolean = false) {
        val conversationId = viewModel.getCurrentConversationId()
        if (conversationId.isEmpty() || "last_conversation" == conversationId) {
            // Загружать нечего, но экран мог быть переведён в Loading (ChatEvent.Retry ставит
            // его безусловно) — снимаем спиннер, иначе он вечный: setReady() зовём только мы.
            getViewInterface()?.hideLoading()
            return
        }

        presenterScope.launch {
            try {
                // Self-heal после cold-start-offline: если сессия ещё не установлена (init не дошёл
                // до Ready), getConversation/getMessages ушли бы без авторизации → null → вечный
                // спиннер. При возврате сети SDK сам переинициализируется (CarrotSDK networkReconnect
                // → commonSetup); дожидаемся Ready с таймаутом, затем грузим.
                if (!SdkStateManager.isInit()) {
                    withTimeoutOrNull(AWAIT_READY_TIMEOUT_MS) { SdkStateManager.awaitReady() }
                }

                val conversation = getConversationSuspend(conversationId)
                val response = if (conversation != null) getMessages(conversation) else null
                if (response != null) {
                    val messages = ArrayList<MessageData>()
                    messages.addAll(response.data)
                    MessagesRepository.getInstance()
                        .addMessages(messages, hardUpdate = needHardUpdate)
                    getViewInterface()?.hideLoading()
                } else if (showErrorOnFailure) {
                    // Загрузка реально не удалась (offline/timeout/backend вернул null) — показываем
                    // ошибку, а не «успешный» пустой/кэшный диалог. showErrorForThrowable снимет спиннер.
                    showErrorForThrowable(null)
                } else {
                    getViewInterface()?.hideLoading()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                if (showErrorOnFailure) {
                    showErrorForThrowable(t)
                } else {
                    // Фоновый рефреш при показанном Content — не рушим контент, только снимаем спиннер.
                    Log.e(TAG, t)
                    getViewInterface()?.hideLoading()
                }
            }
        }
    }

    fun onOpenLastDialog() {
        // Live-проверка вместо кэша hasConnect (может застревать в false — см.
        // initNewConversationSubscribes); при офлайне и ошибке не молчим — иначе
        // вечный спиннер, который нечем снять («Повторить» ведёт сюда же).
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        if (!networkManager.isNetworkAvailable()) {
            showErrorForThrowable(null)
            return
        }

        presenterScope.launch {
            try {
                val conversation = getLastConversation()
                if (conversation != null && conversation.id != null && conversation.id != "") {
                    onChangeConversationId(conversation.id)
                    onOpenDialog()
                } else {
                    onOpenNewDialog()
                }
            } catch (t: CancellationException) {
                throw t
            } catch (t: Throwable) {
                Log.e(tag, t)
                showErrorForThrowable(t)
            }
        }
    }

    // Старый одиночный аттач (onOpenFile / sendMessageWithAttachment(file,date) /
    // createConversationByFile) удалён: путь мёртв после миграции на мультиаттачи
    // (OpenMultipleDocuments → onFilesPicked). Ошибки показывает Compose-боттомшит
    // (FilePickerHelper.showErrorBottomSheet → ErrorBottomSheetActivity).
}
