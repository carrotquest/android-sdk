package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib

private const val TAG = "TokenFlow"

/**
 * Асинхронный refresh JWT-токена (ветка remove_rx, фаза 5: Rx → suspend).
 * При успехе (status 200) — сохраняет новые access+refresh в SharedPrefs и ВОЗВРАЩАЕТ новый access.
 * При не-200 / ошибке — возвращает null (не бросаем — общий поток токена не должен рваться).
 * При 4xx — серверный отказ (протухший refresh): notifySessionExpired() (клиент должен deInit()+setup()).
 *
 * Для синхронного пути (HTTP interceptor / ConnectionManager) используй [refreshJwtTokenBlocking].
 */
suspend fun refreshJwtToken(): String? {
    val carrotApi = CarrotLib.getLibComponents().carrotApi
    // Поколение идентичности на момент СТАРТА запроса: если к ответу оно изменится,
    // пара будет отброшена CAS'ом в saveRefreshedTokens (CAR-77172).
    val expectedEpoch = io.carrotquest_sdk.android.data.user.UserIdentityStore.snapshot().epoch
    val needUpdateRefreshToken = !isActualRefreshToken()
    SdkLogger.log(
        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
        "refreshJwtToken(async): requesting /refresh (updateRefreshToken=$needUpdateRefreshToken). State: ${tokenStateSummary()}",
    )
    return try {
        val response = carrotApi.refresh(needUpdateRefreshToken)
        if (response.meta.status == 200) {
            val token = response.data.access
            // Идентичность могла смениться, пока запрос был в полёте: применяем пару только если
            // она принадлежит текущему юзеру (иначе откатили бы сессию на прежнего — см.
            // saveRefreshedTokens). Этот путь идёт БЕЗ refreshLock, так что гонка здесь реальнее всего.
            if (!saveRefreshedTokens(token, response.data.refresh, expectedEpoch)) {
                // Пара отбракована (принадлежит не текущей личности). Раньше возвращался уже
                // лежащий access — то есть ЧУЖОЙ токен как «успех», и вызывающие (таймер, RTS,
                // интерсептор) записывали его в user.token, цементируя рассинхрон личности и
                // токена. Теперь честный null: refresh не состоялся, лечить должен ремонт
                // идентичности (перевыпуск/re-auth), а не подмена токена.
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "refreshJwtToken(async): pair rejected (identity changed while refreshing) — reporting failure",
                )
                null
            } else {
                SdkLogger.log(
                    SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                    "refreshJwtToken(async): SUCCESS, new access=${maskToken(token)}",
                )
                token
            }
        } else {
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "refresh non-200: status=${response.meta.status}, error=${response.meta.error}",
            )
            if (response.meta.status in 400..499) {
                SdkStateManager.notifySessionExpired()
            }
            null
        }
    } catch (c: kotlinx.coroutines.CancellationException) {
        // Отмена корутины — не ошибка refresh: пробрасываем, иначе ломаем структурную
        // конкурентность и отмена выглядела бы как «refresh провален» (null).
        throw c
    } catch (e: Exception) {
        // Сетевая ошибка (IOException), TimeoutException и т.д. — логируем, токен не трогаем.
        SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "refreshJwtToken(async): error $e", throwable = e)
        null
    }
}