package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel

import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationListItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationUiItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListUiState

/**
 * Stateless builder: принимает готовый список [ConversationUiItem] (уже отсортированный
 * по lastUpdate) и возвращает [ListUiState]. Не зависит от Android-контекста и репозиториев —
 * поэтому легко покрывается юнит-тестами.
 */
internal object ConversationListBuilder {

    fun build(
        conversations: List<ConversationUiItem>,
        expandedGroupIds: Set<String>
    ): ListUiState {
        if (conversations.isEmpty()) return ListUiState.Empty

        val recent = conversations.filter { it.isRecent }
        val history = conversations.filter { !it.isRecent }

        val recentItems = recent.map { ConversationListItem.Single(it) }

        // Ключ группировки: admin id, а без него — имя. Веб (getOperatorName в
        // conversation-history/model.js) группирует только по имени, поэтому там боты
        // и триггеры тоже складываются в стопку — но тёзки-операторы слипаются.
        // Приоритет id чинит тёзок, а безоператорные диалоги (id нет) группируются
        // по имени: adminName уже несёт фолбэк на имя приложения (см. toUiItem),
        // так что боты/триггеры собираются под ним, как в вебе.
        val historyItems = history
            .groupBy { it.lastAdminId ?: it.adminName ?: "" }
            .flatMap { (groupKey, group) ->
                if (group.size == 1) {
                    listOf(ConversationListItem.Single(group.first()))
                } else {
                    listOf(
                        ConversationListItem.Group(
                            groupKey = groupKey,
                            conversations = group,
                            isExpanded = expandedGroupIds.contains(groupKey)
                        )
                    )
                }
            }

        return ListUiState.Content(recentItems, historyItems)
    }
}
