package io.carrotquest_sdk.android.presentation.chat

import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view.AvatarImage
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view.PoweredByBar
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view.PoweredByHeight
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import kotlinx.coroutines.launch

// Кнопка «вниз» появляется, когда низ списка прокручен дальше этого порога (и юзер скроллит вниз).
private val SCROLL_TO_BOTTOM_THRESHOLD = 100.dp

// «Юзер у низа» для автоскролла (новое сообщение / открытие клавиатуры): index 0 и оффсет в пределах
// порога. Если проскроллил выше — не дёргаем (читает историю), показываем кнопку «вниз».
private val AUTO_SCROLL_NEAR_BOTTOM_THRESHOLD = 120.dp

// Вертикальный паддинг строки typing-индикатора — как у обычного сообщения, чтобы плавающий аватар
// (40dp, якорится к низу бабла) не налезал на аватар сообщения выше (typing-строка не должна быть
// ниже аватара). Совпадает с MESSAGE_ROW_VPADDING.
private val TYPING_ROW_VPADDING = MESSAGE_ROW_VPADDING
// Высота бабла индикатора печати = как у однострочного текстового сообщения (строка 20 + 8+8 паддинг).
private val TYPING_BUBBLE_MIN_HEIGHT = 36.dp
// Отступ аватара от левого края экрана (совпадает с horizontal-паддингом строки сообщения).
private val AVATAR_START_PADDING = 16.dp

@Composable
fun MessageList(
    items: List<ChatListItem>,
    accentColor: Color,
    isDark: Boolean,
    isLoadingOlderMessages: Boolean = false,
    canLoadOlderMessages: Boolean = true,
    showPoweredBy: Boolean = false,
    appName: String = "",
    // Прыжок к цитируемому сообщению: скролл к id (снимается ScrolledToMessage) и подсветка строки.
    pendingScrollToMessageId: String? = null,
    highlightedMessageId: String? = null,
    // Гейт цитирования на уровне экрана (закрытый тикет — отвечать нельзя).
    quotingEnabled: Boolean = true,
    onEvent: (ChatEvent) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // reverseLayout=true → низ диалога = индекс 0; индекс/оффсет РАСТУТ при удалении от низа.
    val density = LocalDensity.current
    val thresholdPx = with(density) { SCROLL_TO_BOTTOM_THRESHOLD.toPx() }
    // Юзер «у низа» (общий гейт автоскролла). index <= 1 терпит сдвиг на 1, который даёт вставка
    // нового сообщения в index 0 (LazyColumn по ключам удерживает прежний элемент → index 0→1);
    // иначе автоскролл на сообщение оператора не срабатывал бы даже когда мы в самом низу.
    val nearBottomPx = with(density) { AUTO_SCROLL_NEAR_BOTTOM_THRESHOLD.toPx() }
    val isNearBottom = {
        listState.firstVisibleItemIndex <= 1 && listState.firstVisibleItemScrollOffset <= nearBottomPx
    }
    // Кнопка «вниз»: показываем, когда ушли от низа дальше порога (index>1 не считаем «далеко» —
    // это лишь сдвиг от вставки нового сообщения). Без привязки к направлению скролла, чтобы кнопка
    // была доступна, пока пользователь читает историю (и при приходе нового сообщения сверху).
    var showScrollToBottom by remember { mutableStateOf(false) }
    LaunchedEffect(listState, thresholdPx) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .collect { (index, offset) ->
                showScrollToBottom = index > 1 || offset > thresholdPx
            }
    }

    // reverseLayout=true: visibleItemsInfo.last() — визуально верхний элемент (высокий индекс).
    // Когда пользователь долистал до старых сообщений, запрашиваем следующую страницу.
    val shouldLoadOlder by remember(isLoadingOlderMessages, canLoadOlderMessages) {
        derivedStateOf {
            if (isLoadingOlderMessages || !canLoadOlderMessages) return@derivedStateOf false
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: return@derivedStateOf false
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisible >= total - 5
        }
    }
    LaunchedEffect(shouldLoadOlder) {
        if (shouldLoadOlder) onEvent(ChatEvent.LoadOlderMessages)
    }

    // Автоскролл при появлении нового сообщения (не typing-индикатора).
    // Typing indicator намеренно исключён: его появление/исчезновение не должно
    // влиять на позицию списка, иначе закрытие любого боттомшита, вернувшего onResume,
    // может вызвать removeTypingIndicator → смену firstItemKey → spurious scroll.
    val firstMessageKey = remember(items) {
        val first = items.firstOrNull { it !is ChatListItem.TypingIndicator }
        when (first) {
            is ChatListItem.Message         -> first.id
            is ChatListItem.BotOptionsGroup -> "bot_${first.messageId}"
            is ChatListItem.VoteCard        -> "vote_${first.messageId}"
            else                            -> null
        }
    }
    // Индекс последнего входящего элемента до первого OUTGOING (reverseLayout=true:
    // большой индекс = визуально выше). Скролл к нему показывает начало первой пачки бота.
    val firstIncomingGroupLastIndex = remember(items) {
        var lastIdx = -1
        for (i in items.indices) {
            when (val item = items[i]) {
                is ChatListItem.TypingIndicator, is ChatListItem.DateDivider,
                is ChatListItem.HistoryGapMarker -> continue
                is ChatListItem.BotOptionsGroup -> lastIdx = i
                is ChatListItem.VoteCard -> lastIdx = i
                is ChatListItem.Message -> when (item.direction) {
                    Direction.INCOMING -> lastIdx = i
                    Direction.OUTGOING -> break
                }
            }
        }
        if (lastIdx < 0) 0 else lastIdx
    }
    // Первичный показ диалога делаем один раз; дальше — реакция на НОВОЕ сообщение.
    var initialScrollDone by remember { mutableStateOf(false) }
    LaunchedEffect(firstMessageKey) {
        if (firstMessageKey == null) return@LaunchedEffect
        val first = items.firstOrNull { it !is ChatListItem.TypingIndicator }

        if (!initialScrollDone) {
            // Первичный показ: старый чат с историей → низ (0); свежий неотвеченный welcome-бот →
            // начало бот-блока (firstIncomingGroupLastIndex), чтобы читать приветствие сверху (кейс 4).
            val hasOutgoing = items.any { it is ChatListItem.Message && it.direction == Direction.OUTGOING }
            listState.animateScrollToItem(if (hasOutgoing) 0 else firstIncomingGroupLastIndex)
            initialScrollDone = true
            return@LaunchedEffect
        }

        // Новое сообщение. Бот (кнопки/оценка/бот-бабл) и своё исходящее → к низу ВСЕГДА (приходит
        // как реакция на действие юзера). Прочее входящее (оператор) → только если юзер у низа.
        val isNewOutgoing = first is ChatListItem.Message && first.direction == Direction.OUTGOING
        val isNewBot = when (first) {
            is ChatListItem.BotOptionsGroup -> true
            is ChatListItem.VoteCard        -> true
            is ChatListItem.Message         -> first.isBot
            else                            -> false
        }
        if (isNewOutgoing || isNewBot || isNearBottom()) {
            listState.animateScrollToItem(0)
        }
    }

    // Отдельный триггер для typing indicator: скроллим только когда он ПОЯВЛЯЕТСЯ.
    val hasTypingIndicator = remember(items) { items.firstOrNull() is ChatListItem.TypingIndicator }
    LaunchedEffect(hasTypingIndicator) {
        if (hasTypingIndicator && isNearBottom()) {
            listState.animateScrollToItem(0)
        }
    }

    // Скролл к цитируемому сообщению (тап по цитате / завершённый прыжок). items в ключах:
    // сразу после around-загрузки элемента может ещё не быть — доскроллим, когда появится.
    LaunchedEffect(pendingScrollToMessageId, items) {
        if (pendingScrollToMessageId == null) return@LaunchedEffect
        val idx = items.indexOfFirst { it is ChatListItem.Message && it.id == pendingScrollToMessageId }
        if (idx >= 0) {
            // reverseLayout: scrollOffset=0 прижал бы элемент к нижней кромке; отрицательный
            // оффсет поднимает его на ~40% вьюпорта — цитируемое сообщение видно в середине
            // экрана с контекстом вокруг. Список сам клампит, если история короче.
            val liftPx = listState.layoutInfo.viewportEndOffset * 2 / 5
            listState.animateScrollToItem(idx, -liftPx)
            onEvent(ChatEvent.ScrolledToMessage(pendingScrollToMessageId))
        }
    }

    // С reverseLayout=true visibleItemsInfo.last() — визуально верхний элемент.
    // Плавающий чип показывается только когда разделитель текущего дня ушёл за верхний край.
    // Если разделитель виден — чип скрывается, в списке показывается обычный DateDivider.
    val stickyDateLabel: DateLabel? by remember(items) {
        derivedStateOf {
            val visibleInfo = listState.layoutInfo.visibleItemsInfo
            val visibleIndices = visibleInfo.map { it.index }.toSet()
            val topIndex = visibleInfo.lastOrNull()?.index ?: return@derivedStateOf null
            for (i in topIndex until items.size) {
                val item = items.getOrNull(i) ?: break
                if (item is ChatListItem.DateDivider) {
                    return@derivedStateOf if (i in visibleIndices) null else item.dateLabel
                }
            }
            null
        }
    }

    // Плавающие аватары: аватар входящей стопки «прилипает» к нижней границе списка, пока
    // нижнее сообщение стопки ушло за край, и уезжает вниз вместе с верхним сообщением стопки.
    // Сам аватар не живёт в бабле (там лишь зарезервировано место) — рисуем его оверлеем,
    // вычисляя позицию по layoutInfo. Геометрия в px (layoutInfo даёт px).
    val avatarSizePx = with(density) { AVATAR_SIZE.roundToPx() }
    val avatarStartPx = with(density) { AVATAR_START_PADDING.roundToPx() }
    val msgBottomPadPx = with(density) { MESSAGE_ROW_VPADDING.roundToPx() }
    val typingBottomPadPx = with(density) { TYPING_ROW_VPADDING.roundToPx() }
    val floatingAvatars: List<FloatingAvatarData> by remember(items, avatarSizePx, msgBottomPadPx, typingBottomPadPx) {
        derivedStateOf {
            val info = listState.layoutInfo
            val visible = info.visibleItemsInfo.map { VisibleItem(it.index, it.offset, it.size) }
            computeFloatingAvatars(items, visible, info.viewportEndOffset, avatarSizePx, msgBottomPadPx, typingBottomPadPx)
        }
    }

    // Горизонтальные смещения строк от свайпа «ответить» (messageId → px): плавающий аватар
    // должен уезжать вместе со своей строкой, иначе он «отрывается» от бабла при свайпе.
    val swipeOffsets = remember { mutableStateMapOf<String, Int>() }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            reverseLayout = true,
            // Освобождаем место под плашкой Powered by: 10dp (зазор до сообщения) + высота
            // плашки + 10dp (зазор до поля ввода). Контент может прокручиваться сквозь — плашка
            // (с непрозрачным фоном) перекрывает.
            // Без плашки добавляем 8dp снизу: у MessageBubble vertical=8dp, поэтому зазор между
            // сообщениями = 16dp; у последнего (нижнего, reverseLayout) есть только свой низ 8dp,
            // и без этого паддинга он прижимался к полю ввода (зазор 8 < 16).
            contentPadding = PaddingValues(bottom = if (showPoweredBy) PoweredByHeight + 8.dp else 8.dp),
        ) {
            items.forEachIndexed { index, chatItem ->
                item(key = itemKey(chatItem)) {
                    when (chatItem) {
                        is ChatListItem.DateDivider     -> DateDividerItem(chatItem, isDark)
                        is ChatListItem.TypingIndicator -> TypingIndicatorItem(chatItem, isDark, accentColor)
                        is ChatListItem.Message         -> {
                            // reverseLayout=true: index 0 — низ экрана, index+1 — визуально выше.
                            val prevItem = items.getOrNull(index + 1)
                            val nextItem = items.getOrNull(index - 1)
                            // Скругление-«склейку» соседних входящих делаем только если это ОДИН
                            // отправитель: бот→оператор (разные отправители) визуально разделяем
                            // большим углом, иначе сообщения сливаются в одну группу.
                            val hasPrevIncoming = prevItem is ChatListItem.Message &&
                                prevItem.direction == Direction.INCOMING &&
                                prevItem.sender?.avatarUrl == chatItem.sender?.avatarUrl
                            val hasNextIncoming = nextItem is ChatListItem.Message &&
                                nextItem.direction == Direction.INCOMING &&
                                nextItem.sender?.avatarUrl == chatItem.sender?.avatarUrl
                            MessageBubble(
                                item = chatItem,
                                accentColor = accentColor,
                                isDark = isDark,
                                onEvent = onEvent,
                                hasPrevIncoming = hasPrevIncoming,
                                hasNextIncoming = hasNextIncoming,
                                isHighlighted = chatItem.id == highlightedMessageId,
                                quotingEnabled = quotingEnabled,
                                onSwipeOffset = { id, px ->
                                    if (px == 0) swipeOffsets.remove(id) else swipeOffsets[id] = px
                                },
                            )
                        }
                        is ChatListItem.HistoryGapMarker -> {
                            // Разрыв истории после прыжка к цитате: спиннер между окнами.
                            // Материализация item'а LazyColumn'ом = юзер доскроллил к разрыву →
                            // грузим страницу середины; границы меняются с каждой страницей и
                            // перезапускают эффект, пока окна не сомкнутся (маркер исчезнет).
                            LaunchedEffect(chatItem.lowerBoundId, chatItem.upperBoundId) {
                                // Сторона подхода: нижний видимый элемент новее маркера (индекс
                                // меньше в DESC-списке) → пользователь пришёл со стороны хвоста —
                                // заполняем разрыв before-страницами (сообщения лягут сразу над ним).
                                val fromTail = listState.firstVisibleItemIndex < index
                                onEvent(ChatEvent.LoadGapMessages(fromTail))
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = accentColor,
                                    strokeWidth = 2.dp,
                                )
                            }
                        }
                        is ChatListItem.BotOptionsGroup -> BotOptionsGroupItem(chatItem, accentColor, isDark,
                            onOptionSelected = { option -> onEvent(ChatEvent.BotOptionSelected(chatItem.messageId, option)) })
                        is ChatListItem.VoteCard        -> VoteCardItem(
                            item = chatItem,
                            isDark = isDark,
                            accentColor = accentColor,
                            onVoteSelected = { score -> onEvent(ChatEvent.VoteSelected(chatItem.messageId, score)) },
                            onCommentSend = { score, comment -> onEvent(ChatEvent.CommentVoteSent(chatItem.messageId, score, comment)) },
                        )
                    }
                }
            }
            // Спиннер в конце списка = визуально сверху (reverseLayout=true).
            if (isLoadingOlderMessages) {
                item(key = "loading_older_messages") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = accentColor,
                            strokeWidth = 2.dp,
                        )
                    }
                }
            }
        }

        // Плавающие аватары стопок входящих — поверх списка, у левого края.
        floatingAvatars.forEach { fa ->
            key(fa.key) {
                AvatarImage(
                    url = fa.avatarUrl,
                    accentColor = accentColor,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        // Чтение swipeOffsets внутри offset{} — deferred read: свайп двигает
                        // аватар без рекомпозиции оверлея.
                        .offset { IntOffset(avatarStartPx + (fa.anchorMessageId?.let { swipeOffsets[it] } ?: 0), fa.topY) }
                        .size(AVATAR_SIZE),
                )
            }
        }

        // Sticky date chip — всегда у верхнего края, текст меняется при смене дня
        if (stickyDateLabel != null) {
            DateChip(
                label = stickyDateLabel!!,
                isDark = isDark,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
                    .zIndex(1f),
            )
        }

        // Плашка Powered by — плавающая скруглённая пилюля по центру у нижнего края области
        // сообщений (поверх тела диалога, список прокручивается под ней). Подложка обворачивает
        // контент (не на всю ширину), скругление 10dp + лёгкая тень для «плавающего» вида.
        // Нижний отступ 10dp — зазор до поля ввода; зазор до сообщений задаётся contentPadding.
        if (showPoweredBy) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .zIndex(1f)
                    .padding(bottom = 10.dp),
            ) {
                PoweredByBar(
                    appName = appName,
                    modifier = Modifier
                        .background(SdkColors.pageBackground(isDark), RoundedCornerShape(10.dp))
                        .padding(horizontal = 14.dp),
                )
            }
        }

        // Плавающая кнопка «вниз» — правый нижний угол, над инпутом (и над плашкой Powered by,
        // если она есть). По тапу — скролл к самому свежему сообщению (index 0 при reverseLayout).
        AnimatedVisibility(
            visible = showScrollToBottom,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .zIndex(2f)
                .padding(
                    end = 16.dp,
                    bottom = 16.dp + if (showPoweredBy) PoweredByHeight + 20.dp else 0.dp,
                ),
        ) {
            // Дизайн как в веб-чате: нейтральный светло-серый круг с серым двойным шевроном
            // (не акцентный цвет — кнопка вспомогательная и не должна спорить с send/баблами).
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(SdkColors.background(isDark))
                    .clickable { scope.launch { listState.animateScrollToItem(0) } },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_cq_double_chevron_down),
                    contentDescription = stringResource(R.string.chat_scroll_to_bottom),
                    tint = SdkColors.sectionLabel,
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}

private fun itemKey(item: ChatListItem): Any = when (item) {
    is ChatListItem.DateDivider      -> "divider_${item.dateLabel}"
    is ChatListItem.TypingIndicator  -> "typing"
    is ChatListItem.Message          -> item.id
    is ChatListItem.BotOptionsGroup  -> "bot_${item.messageId}"
    is ChatListItem.VoteCard         -> "vote_${item.messageId}"
    // Ключ стабилен (не зависит от lowerBoundId): при сдвиге границы это тот же маркер.
    is ChatListItem.HistoryGapMarker -> "history_gap"
}

/** Данные одного плавающего аватара: ключ для стабильности, url и Y-смещение верхнего края (px). */
internal data class FloatingAvatarData(
    val key: String,
    val avatarUrl: String?,
    val topY: Int,
) {
    // id якорного сообщения (низ группы) — по нему аватар сдвигается вместе со свайпом строки.
    // Выводится из ключа (key = "avatar_${bottom.id}"), чтобы не менять конструктор (тесты).
    val anchorMessageId: String?
        get() = key.removePrefix("avatar_").takeIf { it != "typing" }
}

/**
 * Видимый элемент списка для расчёта аватаров — минимум из LazyListItemInfo, нужный геометрии.
 * Отдельный тип отвязывает чистое ядро [computeFloatingAvatars] от Compose ради юнит-тестов.
 */
internal data class VisibleItem(val index: Int, val offset: Int, val size: Int)

/** Элемент, у которого есть аватар оператора: входящее сообщение или typing-индикатор. */
private fun ChatListItem.isAvatarBearing(): Boolean =
    (this is ChatListItem.Message && direction == Direction.INCOMING) || this is ChatListItem.TypingIndicator

/**
 * URL аватара отправителя — ключ группировки плавающих аватаров. Группу рвём при смене url: бот и
 * оператор оба входящие, но РАЗНЫЕ отправители, и каждый должен показывать свой аватар (иначе у бота
 * аватар пропадал — выглядело как сообщение оператора). Ключуем именно по url (то, что реально
 * рисуется), а НЕ по имени: name приходит от бэкенда нестабильно (null/«Support» у одного отправителя)
 * и дробил бы стопку. Сравнение String?-ссылок — без аллокаций на hot-path рекомпозиции/скролла.
 */
private fun ChatListItem.avatarUrlOrNull(): String? = when (this) {
    is ChatListItem.Message         -> sender?.avatarUrl
    is ChatListItem.TypingIndicator -> avatarUrl
    else                            -> null
}

/**
 * Считает позиции плавающих аватаров. Чистая функция (без Compose) — на вход [visible] (срез
 * `layoutInfo.visibleItemsInfo`) и [viewportEndOffset]. reverseLayout=true → меньший индекс ниже
 * на экране, ось offset направлена СНИЗУ ВВЕРХ (индекс 0 = низ, offset=0). Переводим в экранный Y
 * (вниз от верха Box): screenY = viewportEndOffset - offset; vpEnd уже учитывает нижний паддинг.
 *
 * Группа = максимальный ран подряд идущих «аватарных» элементов (входящие + typing). На группу —
 * один аватар, привязанный к низу нижнего элемента группы, но:
 *  - пока нижний элемент виден → аватар на его дне (как при инлайне);
 *  - нижний ушёл за нижнюю границу → аватар прилипает к нижней границе списка;
 *  - верхнее сообщение группы доезжает до границы → аватар уезжает вниз вместе с ним.
 */
internal fun computeFloatingAvatars(
    items: List<ChatListItem>,
    visible: List<VisibleItem>,
    viewportEndOffset: Int,
    avatarSizePx: Int,
    msgBottomPadPx: Int,
    typingBottomPadPx: Int,
): List<FloatingAvatarData> {
    if (visible.isEmpty()) return emptyList()
    val infoByIndex = HashMap<Int, VisibleItem>(visible.size)
    for (info in visible) infoByIndex[info.index] = info
    val minVisible = visible.minOf { it.index }
    val maxVisible = visible.maxOf { it.index }
    val vpEnd = viewportEndOffset
    // Нижняя граница, к которой прилипает аватар (низ бабла новейшего сообщения).
    val contentBottomY = vpEnd - msgBottomPadPx

    fun bottomPad(item: ChatListItem): Int =
        if (item is ChatListItem.TypingIndicator) typingBottomPadPx else msgBottomPadPx
    // Низ/верх бабла элемента (без vertical-паддинга строки) в экранных Y.
    fun bubbleBottomY(info: VisibleItem, item: ChatListItem): Int = (vpEnd - info.offset) - bottomPad(item)
    fun bubbleTopY(info: VisibleItem, item: ChatListItem): Int = (vpEnd - (info.offset + info.size)) + bottomPad(item)

    val result = ArrayList<FloatingAvatarData>()
    var i = 0
    while (i < items.size) {
        if (!items[i].isAvatarBearing()) { i++; continue }
        // Группа = подряд идущие «аватарные» элементы ОДНОГО отправителя (по url аватара). Смена
        // отправителя (бот→оператор и т.п.) рвёт группу, чтобы у каждого был свой аватар.
        val groupAvatarUrl = items[i].avatarUrlOrNull()
        var end = i
        while (end < items.size && items[end].isAvatarBearing() && items[end].avatarUrlOrNull() == groupAvatarUrl) end++
        val bottomIdx = i        // визуально нижний (меньший индекс)
        val topIdx = end - 1     // визуально верхний (больший индекс)
        i = end

        // Группа [bottomIdx..topIdx] не пересекается с видимым диапазоном — пропускаем.
        if (topIdx < minVisible || bottomIdx > maxVisible) continue

        // Прилипшая позиция: низ контента, но не выше верха бабла верхнего элемента группы —
        // поэтому когда верхний элемент доезжает до низа, аватар уезжает вниз вместе с ним.
        // Если верхний ушёл за ВЕРХНИЙ край (нет в visible) — ограничение неактивно.
        val topInfo = infoByIndex[topIdx]
        val topBubbleTop = if (topInfo != null) bubbleTopY(topInfo, items[topIdx]) else Int.MIN_VALUE / 2
        val pinnedBottomY = maxOf(topBubbleTop + avatarSizePx, contentBottomY)

        val bottomInfo = infoByIndex[bottomIdx]
        // Нижний виден → аватар на его дне, но не ниже прилипшей позиции. Не виден (ушёл за низ) → прилип.
        val avatarBottomY = if (bottomInfo != null) {
            minOf(bubbleBottomY(bottomInfo, items[bottomIdx]), pinnedBottomY)
        } else {
            pinnedBottomY
        }

        val avatarTopY = avatarBottomY - avatarSizePx
        // Рисуем только если аватар попадает в видимую область.
        if (avatarBottomY <= 0 || avatarTopY >= vpEnd) continue

        val bottom = items[bottomIdx]
        val avatarUrl = when (bottom) {
            is ChatListItem.Message         -> bottom.sender?.avatarUrl
            is ChatListItem.TypingIndicator -> bottom.avatarUrl
            else                            -> null
        }
        val key = when (bottom) {
            is ChatListItem.Message         -> "avatar_${bottom.id}"
            is ChatListItem.TypingIndicator -> "avatar_typing"
            else                            -> "avatar_$bottomIdx"
        }
        result.add(FloatingAvatarData(key, avatarUrl, avatarTopY))
    }
    return result
}

@Composable
private fun DateDividerItem(item: ChatListItem.DateDivider, isDark: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        DateChip(label = item.dateLabel, isDark = isDark)
    }
}

@Composable
fun DateChip(label: DateLabel, isDark: Boolean, modifier: Modifier = Modifier) {
    val text = when (label) {
        is DateLabel.Today     -> stringResource(R.string.chat_date_today)
        is DateLabel.Yesterday -> stringResource(R.string.chat_date_yesterday)
        is DateLabel.Exact     -> label.formatted
    }
    Text(
        text = text,
        color = SdkColors.secondaryText(isDark),
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(SdkColors.dateChipBg(isDark))
            .padding(horizontal = 12.dp, vertical = 4.dp),
    )
}

@Composable
private fun TypingIndicatorItem(
    item: ChatListItem.TypingIndicator,
    isDark: Boolean,
    accentColor: Color,
) {
    Row(
        modifier = Modifier.padding(horizontal = AVATAR_START_PADDING, vertical = TYPING_ROW_VPADDING),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Аватар рисуется плавающим оверлеем (см. floating avatars в MessageList), здесь резерв места.
        Spacer(modifier = Modifier.width(AVATAR_SIZE + AVATAR_GAP))
        Box(
            modifier = Modifier
                .background(SdkColors.background(isDark), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 6.dp))
                // Высота как у однострочного текстового сообщения — точки центрируем по вертикали.
                .heightIn(min = TYPING_BUBBLE_MIN_HEIGHT)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            TypingDots(isDark = isDark)
        }
    }
}

@Composable
private fun TypingDots(isDark: Boolean) {
    val transition = rememberInfiniteTransition(label = "typing")

    // Каждая точка: ждёт delayMs, разгорается до 1f, гаснет до 0.15f, ждёт до конца цикла
    fun dotSpec(delayMs: Int): InfiniteRepeatableSpec<Float> = infiniteRepeatable(
        animation = keyframes {
            durationMillis = 900
            0.15f at 0
            if (delayMs > 0) 0.15f at delayMs
            1f at (delayMs + 200)
            0.15f at (delayMs + 400)
        },
        repeatMode = RepeatMode.Restart,
    )

    val a0 by transition.animateFloat(0.15f, 0.15f, dotSpec(0),   label = "dot0")
    val a1 by transition.animateFloat(0.15f, 0.15f, dotSpec(180), label = "dot1")
    val a2 by transition.animateFloat(0.15f, 0.15f, dotSpec(360), label = "dot2")

    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (alpha in listOf(a0, a1, a2)) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .background(SdkColors.secondaryText(isDark).copy(alpha = alpha), CircleShape),
            )
        }
    }
}
