package io.carrotquest_sdk.android.presentation.mvp.notifications

import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.isPopUpConversationType

/**
 * Куда ведёт тап по уведомлению. Чистая функция выбора вынесена из [PushNotificationHelper.showNotify],
 * чтобы правила маршрутизации проверялись юнит-тестами без Android-окружения.
 */
internal sealed class PushTapTarget {
    /** Открыть беседу в SdkContainerActivity (обычный чат / тикет). */
    data class OpenDialog(val conversationId: String) : PushTapTarget()

    /**
     * Прозрачная PushTapActivity: трекинг клика, запуск хост-приложения (в т.ч. для поп-апов —
     * с показом поп-апа поверх хоста) либо открытие ссылки со статистикой UTM.
     */
    data class PushTapScreen(
        val conversationId: String?,
        val conversationType: String?,
        val link: String?,
    ) : PushTapTarget()

    /** Открыть ссылку напрямую через ACTION_VIEW, минуя SDK. */
    data class ViewLink(val link: String) : PushTapTarget()
}

private const val SENT_VIA_CONVERSATION_NOTIFICATION = "conversation_notification"
private const val SENT_VIA_MESSAGE_AUTO = "message_auto"
private const val SENT_VIA_MESSAGE_MANUAL = "message_manual"

private fun isCampaignMessage(sentVia: String?): Boolean =
    sentVia.equals(SENT_VIA_MESSAGE_AUTO, ignoreCase = true) ||
        sentVia.equals(SENT_VIA_MESSAGE_MANUAL, ignoreCase = true)

/**
 * Правила выбора цели тапа по пушу.
 *
 * Поп-ап-беседы ([ConversationType.BLOCK_POPUP_SMALL] и прочие popup_* типы) без ссылки ВСЕГДА идут
 * в PushTapActivity независимо от `is_carrot`/`sent_via`: у такой беседы нет частей сообщений, и
 * открытие её как диалога давало пустой экран чата. PushTapActivity вместо этого открывает
 * хост-приложение и организует показ самого поп-апа поверх него.
 *
 * Остальные ветки — историческое поведение: ссылка открывается через PushTapActivity (с UTM), если
 * пуш от кампании/уведомления о беседе или не помечен `is_carrot`, иначе напрямую; пуш кампании без
 * ссылки с `is_carrot` открывает диалог, без `is_carrot` — просто хост-приложение; всё прочее —
 * диалог.
 */
internal fun resolvePushTapTarget(
    link: String?,
    sentVia: String?,
    conversationType: String?,
    isCarrot: Boolean?,
    conversationId: String?,
): PushTapTarget {
    if (link.isNullOrEmpty() && isPopUpConversationType(conversationType)) {
        return PushTapTarget.PushTapScreen(conversationId, conversationType, link = null)
    }

    if (!link.isNullOrEmpty()) {
        val viaPushTap = sentVia.equals(SENT_VIA_CONVERSATION_NOTIFICATION, ignoreCase = true) ||
            isCampaignMessage(sentVia) || isCarrot == null || !isCarrot
        return if (viaPushTap) {
            PushTapTarget.PushTapScreen(conversationId, conversationType, link)
        } else {
            PushTapTarget.ViewLink(link)
        }
    }

    if (isCampaignMessage(sentVia)) {
        return if ((isCarrot == null || isCarrot) && !conversationId.isNullOrEmpty()) {
            PushTapTarget.OpenDialog(conversationId)
        } else {
            PushTapTarget.PushTapScreen(conversationId, conversationType, link = null)
        }
    }

    return PushTapTarget.OpenDialog(conversationId ?: "")
}
