package io.carrotquest_sdk.android.lib.utils.loging

import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date

class LogToElk private constructor() {

    /**
     * Список идентификаторов аппов, для которых разрешено логирование в ELK
     * 2782 - тестовый апп
     * 61364- ЯСНО
     */
    private val allowApps = arrayOf("2782", "61364")

    // Скоуп для отправки лога (раньше cold Observable + subscribe; ветка remove_rx).
    private val scope = sdkScope(SdkDispatchers.io)

    // Отложенная отправка: хранит последний неотправленный лог, чтобы переотправить при
    // восстановлении сети (раньше — переподписка на тот же cold Observable). null = отправлено.
    // Доступ сериализован [sendMutex] (write и resend на двух корутинах) — иначе гонка/двойная отправка.
    @Volatile
    private var pendingSend: (suspend () -> NetworkResponse)? = null
    private val sendMutex = Mutex()

    init {
        NetworkManager.getInstance(CarrotLib.getLibComponents().context).addObserver { isConnect ->
            if (isConnect) {
                resend()
            }
        }
    }

    fun write(appId: String, message: String, messageType: MessageToElkType, params: HashMap<String, Any>) {
        // Проверка на то, что для аппа разрешена отправка логов
        if (allowApps.isEmpty()) {
            return
        }
        if (!allowApps.contains(appId)) {
            return
        }

        params["app_id"] = appId
        try {
            params["os"] = "Android"
            params["version_os"] = android.os.Build.VERSION.RELEASE
            params["user_id"] = io.carrotquest_sdk.android.data.user.UserStateHolder.currentId()
            // params["version_sdk"] = sdkVersion

            val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
            val currentDate = sdf.format(Date())
            params["event_time"] = currentDate

            params["connection_type"] =
                NetworkManager.getInstance(CarrotLib.getLibComponents().context).connectionType
        } catch (e: Exception) {
            params["add_params_error"] = e.toString()
        }

        val send: suspend () -> NetworkResponse = {
            try {
                CarrotLib.getLibComponents().carrotApi.sendLog(
                    messageType.name.lowercase(),
                    "Android_SDK: \$message",
                    JSONObject(params as Map<*, *>).toString()
                )
            } catch (throwable: Throwable) {
                val errorResponse = NetworkResponse()
                val meta = Meta()
                meta.status = 403
                meta.error = throwable.toString()
                errorResponse.meta = meta
                errorResponse
            }
        }

        scope.launch {
            sendMutex.withLock {
                pendingSend = send
                if (send().status == 200) {
                    pendingSend = null
                }
            }
        }
    }

    // Переотправка отложенного лога при восстановлении сети. На неуспех остаётся в pendingSend
    // и повторится при следующем reconnect (раньше чистился на любой ответ — гонка с write).
    private fun resend() {
        scope.launch {
            sendMutex.withLock {
                val send = pendingSend ?: return@withLock
                if (send().status == 200) {
                    pendingSend = null
                }
            }
        }
    }

    companion object {
        @Volatile
        private var instance: LogToElk? = null

        @JvmStatic
        fun getInstance(): LogToElk {
            if (instance == null) {
                instance = LogToElk()
            }
            return instance!!
        }
    }
}