package io.carrotquest_sdk.android.lib.network.deserializers

import com.google.gson.Gson
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketData
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketResponse
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketsResponse
import java.lang.reflect.Type

/**
 * Ответы тикет-эндпоинтов несовместимы с чистой Gson-рефлексией по двум причинам:
 * 1) формат зависит от версии API: v1 (стенд) — конверт {meta, data}, v3 может отдавать
 *    голый массив/объект — поддерживаем оба;
 * 2) внутри тикета `conversation.part_last.conversation` прод сериализует ОБЪЕКТОМ
 *    (в /parts и RTS то же поле — id строкой) → Gson падал на MessageData.conversation:
 *    String, обёртка глотала исключение, и список выглядел пустым при HTTP 200 —
 *    нормализуем объект в id до парсинга.
 * Битый тикет деградирует (без conversation → карточка без превью) или пропускается —
 * один сюрприз сериализатора не должен прятать весь список.
 */
internal class TicketsResponseDeserializer : JsonDeserializer<TicketsResponse> {

    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext
    ): TicketsResponse {
        val gson = Gson()
        val result = when {
            // v3: голый массив тикетов без конверта
            json.isJsonArray -> TicketsResponse(
                meta = okMeta(),
                data = json.asJsonArray.mapNotNull { parseTicketLenient(it, gson) }
            )
            json.isJsonObject -> {
                val obj = json.asJsonObject
                val meta = obj.get(F.META)?.takeIf { it.isJsonObject }
                    ?.let { gson.fromJson(it, Meta::class.java) } ?: okMeta()
                val data = obj.get(F.DATA)?.takeIf { it.isJsonArray }?.asJsonArray
                    ?.mapNotNull { parseTicketLenient(it, gson) } ?: emptyList()
                TicketsResponse(meta = meta, data = data)
            }
            else -> TicketsResponse()
        }
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.NETWORK, TAG) {
            val format = if (json.isJsonArray) "bare-array" else "envelope"
            "tickets response: format=$format count=${result.data?.size ?: "null"}"
        }
        return result
    }

    companion object {
        private const val TAG = "TicketsResponseDeserializer"
    }
}

/** Деталь тикета: голый объект тикета (v3) либо конверт {meta, data} (v1). */
internal class TicketResponseDeserializer : JsonDeserializer<TicketResponse> {

    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext
    ): TicketResponse {
        if (!json.isJsonObject) return TicketResponse()
        val gson = Gson()
        val obj = json.asJsonObject
        // Конверт: есть data (объект тикета) — «data» у самого тикета не бывает
        return if (obj.has(F.DATA)) {
            val meta = obj.get(F.META)?.takeIf { it.isJsonObject }
                ?.let { gson.fromJson(it, Meta::class.java) } ?: okMeta()
            TicketResponse(meta = meta, data = obj.get(F.DATA)?.let { parseTicketLenient(it, gson) })
        } else {
            TicketResponse(meta = okMeta(), data = parseTicketLenient(json, gson))
        }
    }
}

private const val LENIENT_TAG = "TicketParse"

/**
 * Толерантный парсинг одного тикета. part_last вынимаем из JSON и парсим боевым
 * RTS-парсером [convertJsonToMessageData] (он переваривает from-строку и прочие вариации
 * сериализации частей) — Gson-рефлексия MessageData на тикет-ответе падает: прод
 * сериализует part_last.conversation ОБЪЕКТОМ и part_last.from СТРОКОЙ. Остальной тикет —
 * рефлексией; при сюрпризах деградируем (без conversation → карточка без превью) или
 * пропускаем тикет, не пряча весь список.
 */
private fun parseTicketLenient(element: JsonElement, gson: Gson): TicketData? {
    if (!element.isJsonObject) return null
    // deepCopy: мутируем копию (вынимаем part_last, правим вложенные поля)
    val obj = element.asJsonObject.deepCopy()

    val conversationObj = obj.get(F.CONVERSATION)?.takeIf { it.isJsonObject }?.asJsonObject
    var partLast: io.carrotquest_sdk.android.lib.network.responses.messages.MessageData? = null
    if (conversationObj != null) {
        val partLastObj = conversationObj.get(F.PART_LAST)?.takeIf { it.isJsonObject }?.asJsonObject
        if (partLastObj != null) {
            // conversation-объект → id (convertJsonToMessageData ждёт строку)
            runCatching { normalizeConversationField(partLastObj) }
            partLast = try {
                io.carrotquest_sdk.android.lib.network.responses.utils.convertJsonToMessageData(partLastObj)
            } catch (e: Exception) {
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.NETWORK, LENIENT_TAG,
                    "part_last skipped (ticket=${obj.get(F.ID)}): $e"
                )
                null
            }
        }
        conversationObj.remove(F.PART_LAST)
    }

    val ticket = try {
        gson.fromJson(obj, TicketData::class.java)
    } catch (first: Exception) {
        // Падение почти наверняка во вложенном conversation — пробуем без него:
        // тикет остаётся в списке (карточка без превью), не прячем весь список
        try {
            val stripped = obj.deepCopy().also { it.remove(F.CONVERSATION) }
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.NETWORK, LENIENT_TAG,
                "ticket parsed without conversation (id=${obj.get(F.ID)}): $first"
            )
            gson.fromJson(stripped, TicketData::class.java)
        } catch (second: Exception) {
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.NETWORK, LENIENT_TAG,
                "ticket skipped (id=${obj.get(F.ID)}): $second"
            )
            null
        }
    }
    // part_last возвращаем в модель (DataConversation — мутабельный бин)
    ticket?.conversation?.partLast = partLast
    return ticket
}

/** conversation-объект → id-строка (в /parts и RTS это поле — id строкой). */
private fun normalizeConversationField(part: JsonObject) {
    val conversationField = part.get(F.CONVERSATION) ?: return
    if (conversationField.isJsonObject) {
        val id = conversationField.asJsonObject.get(F.ID)
        part.remove(F.CONVERSATION)
        if (id != null && !id.isJsonNull) {
            part.add(F.CONVERSATION, id)
        }
    }
}

private fun okMeta(): Meta = Meta().apply { status = 200 }
