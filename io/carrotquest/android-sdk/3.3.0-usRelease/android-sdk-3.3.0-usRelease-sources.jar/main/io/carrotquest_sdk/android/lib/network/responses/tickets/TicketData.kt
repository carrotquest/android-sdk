package io.carrotquest_sdk.android.lib.network.responses.tickets

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation

/**
 * Тикет из GET /users/{id}/tickets[/{ticketId}].
 *
 * Особенности контракта (зафиксированы по стенду 15.07.2026, фикстуры в ~/Documents/tickets/):
 * - id приходят строками (запросы шлём с id_as_string=true);
 * - created/dueDate — ISO-строки с микросекундами и таймзоной ("2026-07-15T14:28:28.152521+0300"),
 *   dueDate может быть null; парсить через [TicketDates.parseIsoToMillis];
 * - conversation nullable (OneToOneField(null=True) на бэке) и внутри — обычные unix-секунды;
 *   у свежесозданных тикетов conversation.partLast == null;
 * - список приходит только при include_conversation=true;
 * - closed_at/is_reopenable (CAR-76310, подтверждены на проде 12.08.2026): инвариант бэка
 *   closed_at != null ⟺ status.is_final; is_reopenable=false у легаси-тикетов (закрыты до
 *   релиза переоткрытия) и на старом бэке (поля нет) — деградация к read-only.
 */
@Keep
data class TicketData(
    @SerializedName(F.ID) val id: String? = null,
    @SerializedName(F.SHORT_ID) val shortId: Int? = null,
    @SerializedName(F.TITLE) val title: String? = null,
    @SerializedName(F.CREATED) val created: String? = null,
    @SerializedName(F.DUE_DATE) val dueDate: String? = null,
    @SerializedName(F.CLOSED_AT) val closedAt: String? = null,
    @SerializedName(F.IS_REOPENABLE) val isReopenable: Boolean = false,
    @SerializedName(F.STATUS) val status: TicketStatusData? = null,
    @SerializedName(F.CONVERSATION) val conversation: DataConversation? = null
)

/**
 * Статус тикета — произвольная запись на аппе (НЕ enum: имена и цвета кастомизируемы).
 * Стадию (initial/intermediate/final) выводим из is_initial/is_final; color бэка в UI
 * не используем — красим фиксированными стадийными цветами (веб делает так же).
 */
@Keep
data class TicketStatusData(
    @SerializedName(F.ID) val id: String? = null,
    @SerializedName(F.NAME) val name: String? = null,
    @SerializedName(F.COLOR) val color: String? = null,
    @SerializedName(F.ORDER) val order: Int? = null,
    @SerializedName(F.IS_INITIAL) val isInitial: Boolean = false,
    @SerializedName(F.IS_FINAL) val isFinal: Boolean = false
)
