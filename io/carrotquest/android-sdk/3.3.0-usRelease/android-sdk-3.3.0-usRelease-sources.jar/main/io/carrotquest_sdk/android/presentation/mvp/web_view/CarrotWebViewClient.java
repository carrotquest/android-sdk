package io.carrotquest_sdk.android.presentation.mvp.web_view;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.webkit.*;

import io.carrotquest_sdk.android.BuildConfig;

public class CarrotWebViewClient extends WebViewClient {

    private boolean pageInError = false;
    private CarrotWebViewPresenter presenter;
    CarrotWebViewClient(CarrotWebViewPresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        presenter.onPageFinished(pageInError);
    }

    // Ошибки учитываем только для main frame: сбой отдельного субресурса (картинка, шрифт)
    // не должен "окирпичивать" страницу. super не вызываем — его дефолтная реализация
    // дёргает deprecated-оверлоад и ошибка задвоится.
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        if (request.isForMainFrame()) {
            pageInError = true;
            presenter.onReceivedError();
        }
    }

    // API 21–22: фреймворк зовёт только этот оверлоад, и только для main frame.
    @SuppressWarnings("deprecation")
    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            pageInError = true;
            presenter.onReceivedError();
        }
    }

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        super.onPageStarted(view, url, favicon);
        pageInError = false;
        presenter.onPageStarted();
    }

    @Override
    public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
        super.onReceivedHttpError(view, request, errorResponse);
        // Только main frame: 404 одного субресурса раньше выставлял pageInError и
        // load-обсерверы не уведомлялись — страница молча оставалась пустой.
        if (request.isForMainFrame()) {
            pageInError = true;
        }
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if(url.contains(BuildConfig.CALENDLY_URL)
                || url.contains("external-widget/")) {
            return super.shouldOverrideUrlLoading(view, url);
        }
        else {
            presenter.onOpenOutsideUrl(url);
            return true;
        }
    }


    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        WebResourceResponse response = presenter.shouldInterceptRequest(request.getUrl());
        return response == null ? super.shouldInterceptRequest(view, request) : response;
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
        WebResourceResponse response = presenter.shouldInterceptRequest(Uri.parse(url));
        return response == null ? super.shouldInterceptRequest(view, url) : response;
    }
}
