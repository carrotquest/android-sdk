package io.carrotquest_sdk.android.presentation.tickets

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.ui.UnreadBadge
import kotlin.math.roundToInt

/** Вкладки стартового экрана. */
internal enum class ListTab { MESSAGES, TICKETS }

/**
 * Единый источник моушен-констант переключения вкладок: индикатор-«резинка» здесь,
 * кросс-фейд контента и фейд кнопки «Написать» — в ListScreen. Менять согласованно.
 */
internal object TabSwitchMotion {
    /** Длительность движения индикатора. */
    const val INDICATOR_MS = 300
    /** Задержка ведомого края — растяжение пилюли на пике перехода (rubber-band по макету). */
    const val TRAILING_EDGE_DELAY_MS = 70
    /** Кросс-фейд списков и фейд кнопки «Написать». */
    const val CONTENT_FADE_MS = 250
}

private val ControlHeight = 40.dp

// Спеки статичны — не пересоздаём на каждой рекомпозиции
private val LeadingSpec: TweenSpec<Float> =
    tween(durationMillis = TabSwitchMotion.INDICATOR_MS, easing = FastOutSlowInEasing)
private val TrailingSpec: TweenSpec<Float> = tween(
    durationMillis = TabSwitchMotion.INDICATOR_MS,
    delayMillis = TabSwitchMotion.TRAILING_EDGE_DELAY_MS,
    easing = FastOutSlowInEasing
)

/**
 * Сегмент-контрол «Сообщения / Тикеты» для нижней подложки списка (см. [BottomTabPanel]).
 *
 * Индикатор активного сегмента едет с эффектом «резинки»: ведущий край опережает ведомый,
 * поэтому в середине перехода пилюля вытягивается и затем схлопывается на цель. Края
 * анимируются в долях ширины, а State читается только в layout-фазе (Modifier.layout) —
 * анимация не рекомпозирует контрол покадрово. Текст табов кросс-фейдит цвет.
 * Рендерится только при включённой тикет-системе.
 */
@Composable
internal fun SegmentedTabs(
    selected: ListTab,
    messagesUnreadCount: Int,
    ticketsUnreadCount: Int,
    isDark: Boolean,
    accentColor: Color,
    onSelect: (ListTab) -> Unit
) {
    val selectedIndex = if (selected == ListTab.TICKETS) 1 else 0
    // С двумя вкладками направление детерминировано: цель index==1 → едем вправо.
    val movingRight = selectedIndex == 1
    val indicatorColor = SdkColors.segmentIndicator(isDark, accentColor)

    // При движении вправо ведущий = правый край (без задержки), ведомый = левый (с задержкой);
    // при движении влево — наоборот.
    val leftFraction by animateFloatAsState(
        targetValue = selectedIndex * 0.5f,
        animationSpec = if (movingRight) TrailingSpec else LeadingSpec,
        label = "indicatorLeft"
    )
    val rightFraction by animateFloatAsState(
        targetValue = selectedIndex * 0.5f + 0.5f,
        animationSpec = if (movingRight) LeadingSpec else TrailingSpec,
        label = "indicatorRight"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(ControlHeight)
    ) {
        // Индикатор — под сегментами (рисуется первым). Position/size — в layout-фазе.
        Box(
            modifier = Modifier
                .layout { measurable, constraints ->
                    val left = (leftFraction * constraints.maxWidth).roundToInt()
                    val right = (rightFraction * constraints.maxWidth).roundToInt()
                    val placeable = measurable.measure(
                        Constraints.fixed((right - left).coerceAtLeast(0), constraints.maxHeight)
                    )
                    layout(constraints.maxWidth, constraints.maxHeight) {
                        placeable.place(left, 0)
                    }
                }
                .clip(CircleShape)
                .background(indicatorColor)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            SegmentButton(
                iconRes = R.drawable.ic_cq_tab_message,
                label = stringResource(R.string.tabs_messages),
                badgeCount = messagesUnreadCount,
                isSelected = selectedIndex == 0,
                isDark = isDark,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onSelect(ListTab.MESSAGES) }
            )
            SegmentButton(
                iconRes = R.drawable.ic_cq_tab_ticket,
                label = stringResource(R.string.tabs_tickets),
                badgeCount = ticketsUnreadCount,
                isSelected = selectedIndex == 1,
                isDark = isDark,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onSelect(ListTab.TICKETS) }
            )
        }
    }
}

@Composable
private fun SegmentButton(
    iconRes: Int,
    label: String,
    badgeCount: Int,
    isSelected: Boolean,
    isDark: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val contentColor by animateColorAsState(
        targetValue = SdkColors.segmentContent(isDark, isSelected, accentColor),
        animationSpec = tween(TabSwitchMotion.INDICATOR_MS),
        label = "tabContentColor"
    )

    Row(
        modifier = modifier
            .fillMaxHeight()
            // selectable: TalkBack озвучивает роль вкладки и состояние выбранности;
            // indication = null — фидбек переключения даёт едущий индикатор
            .selectable(
                selected = isSelected,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Tab,
                onClick = onClick
            ),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(20.dp)
            )
            UnreadBadge(
                count = badgeCount,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 5.dp, y = (-5).dp),
                height = 14.dp,
                fontSize = 8.sp
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = contentColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
