package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation

/**
 * «Оператор диалога» для превью в списке и шапки открытого диалога — единое правило,
 * калька вебовского getOperator (cqstatic, entities/conversation/lib.js): публичная
 * персона отправителя (message_sender — так представляются боты и триггерные сообщения)
 * приоритетнее last_admin, иначе список показывал бы реального админа за ботом,
 * расходясь и с вебом, и с аватарками сообщений внутри диалога (part.from).
 */
fun DataConversation.displayAdmin(): Admin? =
    if (lastSender?.type == F.MESSAGE_SENDER) lastSender else lastAdmin
