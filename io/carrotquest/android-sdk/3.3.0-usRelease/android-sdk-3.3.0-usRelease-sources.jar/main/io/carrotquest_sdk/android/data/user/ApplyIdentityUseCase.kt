package io.carrotquest_sdk.android.data.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.wss.jwt.getRefreshToken

private const val TAG = "ApplyIdentity"

/**
 * Единственная точка плановой смены идентичности (CAR-77172, этап 1): принятый ответ
 * /connect или /auth. Пишет атомарную тройку в [UserIdentityStore] (двигает epoch —
 * летящие token-only записи прежнего поколения будут отброшены) и синкает
 * легаси-состояние: [UserStateHolder] + prefs (CarrotToken/CarrotUserId/unread/banned).
 * С этапа 3 old/UserRepository удалён — его saveUser-семантика живёт здесь.
 *
 * @param access null — ответ пришёл без новой пары (token-less /connect): текущие
 *   токены стора сохраняются. Легаси user.token при этом обновляется значением из
 *   [user] — как это делал старый saveUser-путь.
 */
internal fun applyAcceptedIdentity(
    context: Context?,
    user: User,
    access: String?,
    refresh: String?,
) {
    UserIdentityStore.applyIdentity(context, user.id ?: "", access, refresh)
    try {
        applyLegacyUserState(context, user)
    } catch (t: Throwable) {
        SdkLogger.log(
            SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
            "legacy sync failed for user=${user.id}: $t",
        )
    }
}

/**
 * Семантика old/UserRepository.saveUser (дословно, чтобы не менять поведение на этапе 3):
 *  - merge поверх текущего состояния: token — всегда (в т.ч. пустой), id — только непустой,
 *    unread — только non-null, banned/hasConversations — всегда;
 *  - prefs: CarrotToken пишется только непустым; пустой НЕ стирает ключ, пока жива JWT-пара
 *    (иначе терялся последний кред и сессия попадала в token-less ловушку — шторм 401);
 *    CarrotUserId/unread/banned — из аргумента как есть.
 */
internal fun applyLegacyUserState(context: Context?, user: User) {
    val current = UserStateHolder.current()
    UserStateHolder.update(
        UserEntity(
            id = user.id?.takeIf { it.isNotEmpty() } ?: current?.id ?: "",
            token = user.token ?: "",
            hasConversations = user.isHasConversations,
            isBanned = user.isBanned,
            conversationsUnread = user.conversationsUnread
                ?: current?.conversationsUnread
                ?: emptyList(),
        )
    )
    if (context == null) return
    if (!user.token.isNullOrEmpty()) {
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_TOKEN, user.token)
    } else if (getRefreshToken(context).isNullOrEmpty()) {
        SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN)
    }
    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_USER_ID, user.id)
    SharedPreferencesLib.saveStringSet(
        context,
        SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS,
        HashSet(user.conversationsUnread ?: arrayListOf()),
    )
    SharedPreferencesLib.saveBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED, user.isBanned)
}

/**
 * Первая фаза deInit: личность обнуляется, токены остаются живыми — они нужны
 * интерсептору, чтобы легитимно обновить протухший access и провести отписку пушей.
 * Epoch двигается: refresh, стартовавший ДО logout, не воскресит прежнего юзера.
 * Вторая фаза (после отписки) — clearJwtTokens → [UserIdentityStore.clearTokens].
 */
internal fun clearIdentityKeepTokens(context: Context?) {
    UserIdentityStore.applyIdentity(context, "", null, null)
}

/**
 * Легаси-часть первой фазы deInit — то, что делал repo().saveUser(new User()):
 * prefs id/unread/banned чистятся, CarrotToken остаётся, пока жива JWT-пара
 * (нужен отписке пушей и её авто-рефрешу).
 */
internal fun clearLegacyUserState(context: Context?) {
    applyLegacyUserState(context, User())
}

/**
 * Полная вычистка персиста идентичности при server-side удалении юзера (RTS
 * UsersRemovedResponse; CAR-77172, этап 4). Раньше этот путь чистил только память:
 * prefs (CarrotUserId, CarrotToken, JWT-пара, authed-ключи, auth-креды) оставались,
 * deInit не вызывался, если ни один SDK-экран не открыт, — и следующий setup()
 * восстанавливал полный набор кред УДАЛЁННОГО юзера.
 */
internal fun wipePersistedIdentity(context: Context?) {
    // Тройка + JWT-ключи + CarrotUserId, epoch++ (летящий refresh будет отброшен CAS'ом).
    UserIdentityStore.clear(context)
    if (context == null) return
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_BANNED)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.AUTHED_AUTH_ID_KEY)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.AUTHED_SDK_USER_ID_KEY)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CONNECTED_USER_ID_KEY)
    io.carrotquest_sdk.android.domain.use_cases.user.clearAuthCredentials(context)
}

/**
 * Синк свежего access в легаси user.token: RequestIdentity отдаёт ему приоритет над
 * JWT-парой, поэтому протухшее значение затеняло бы только что обновлённый access.
 * Раньше этот идиом был скопирован у шести вызывателей refresh — собран сюда.
 */
internal fun syncLegacyUserToken(context: Context?, token: String) {
    try {
        val current = UserStateHolder.current() ?: return
        UserStateHolder.update(current.copy(token = token))
        if (context != null && token.isNotEmpty()) {
            SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_TOKEN, token)
        }
    } catch (t: Throwable) {
        SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "legacy token sync failed: $t")
    }
}

/**
 * Текущий юзер в виде легаси-модели [User] — для публичных колбэков (getAuthUserObserver),
 * которым SDK отдаёт User. Раньше его давал repo().getUser().
 */
internal fun currentLegacyUser(): User {
    val entity = UserStateHolder.current()
    return User().apply {
        id = entity?.id
        token = entity?.token
        isHasConversations = entity?.hasConversations ?: false
        isBanned = entity?.isBanned ?: false
        conversationsUnread = ArrayList(entity?.conversationsUnread ?: emptyList())
    }
}
