package io.carrotquest_sdk.android.data.repositories

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import java.util.Collections

class ConversationsRepository private constructor() {
    private var currentAfter = ""

    private val conversations = Collections.synchronizedList(ArrayList<DataConversation>())

    private var openedConversation: String = ""
    private var lastOpenedConversation: String = ""

    // Flow — modern API for Compose/Coroutines consumers
    private val _conversationsFlow = MutableStateFlow<List<DataConversation>>(emptyList())
    val conversationsFlow: StateFlow<List<DataConversation>> = _conversationsFlow.asStateFlow()

    private val _newConversationFlow = MutableSharedFlow<DataConversation>(extraBufferCapacity = 1)
    val newConversationFlow: SharedFlow<DataConversation> = _newConversationFlow.asSharedFlow()

    // Сигнал об изменении состояния списка. Нужен потому, что часть мутаторов меняет
    // существующий объект DataConversation in-place (см. ConversationReplyChangedMessage:
    // RTS приходит при удалении/редактировании сообщения и обновляет partLast у того же
    // объекта). После этого _conversationsFlow.value = ArrayList(this.conversations)
    // содержит ТЕ ЖЕ references → ArrayList.equals возвращает true → MutableStateFlow
    // не уведомляет подписчиков. Этот flow гарантирует уведомление в любом случае.
    private val _changeSignal = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val changeSignal: SharedFlow<Unit> = _changeSignal.asSharedFlow()

    private fun emitConversationsChanged(snapshot: ArrayList<DataConversation>) {
        _conversationsFlow.value = snapshot
        _changeSignal.tryEmit(Unit)
    }

    // Singleton реализован в companion object внизу файла — там же deInit() обнуляет
    // ссылку для re-init сценария.

    // Замена conversationsSubject (BehaviorSubject.createDefault). Источник правды —
    // _conversationsFlow (для .value/Compose) + _changeSignal (срабатывает на КАЖДОЕ изменение,
    // включая in-place). onStart реплеит текущий список новому подписчику, .map даёт свежий
    // снимок на каждый сигнал → НЕ дедупит (как BehaviorSubject), в отличие от StateFlow.asObservable().
    // Continuous-поток снимков списка (changeSignal-driven; реплеит текущий через onStart).
    // Flow-источник для Kotlin-потребителей; getConversations() — его Observable-мост.
    fun conversationsChangesFlow(): kotlinx.coroutines.flow.Flow<ArrayList<DataConversation>> =
        _changeSignal
            .onStart { emit(Unit) }
            .map { ArrayList(_conversationsFlow.value) }

    // getConversations() Observable-мост удалён — потребители на conversationsChangesFlow() (Flow).

    fun getConversationsSync(): ArrayList<DataConversation> {
        // Копия synchronizedList'а — итерация под монитором самого списка (контракт
        // Collections.synchronizedList), иначе ConcurrentModificationException при конкурентном
        // addConversation/saveConversations.
        return synchronized(this.conversations) { ArrayList(this.conversations) }
    }

    fun getConversationById(id: String): DataConversation? {
        return synchronized(this.conversations) {
            this.conversations.find { x -> x.id != null && x.id == id }
        }
    }

    fun saveConversations(data: ArrayList<DataConversation>) {
        if(data == null || data.isEmpty()) {
            return
        }
        // ВАЖНО: монитор — this.conversations (как во всех остальных методах и как требует
        // Collections.synchronizedList при итерации). Раньше тут был отдельный объект lock —
        // он НЕ сериализовался с synchronized(this.conversations) в addConversation и др.,
        // из-за чего итерация (.find) ловила ConcurrentModificationException.
        synchronized(this.conversations) {
            try {
                for (conversation in data) {
                    if (this.conversations.find { x -> x.id != null && x.id == conversation.id } == null) {
                        this.conversations.add(conversation)
                    }
                }

                emitConversationsChanged(ArrayList(this.conversations))
            } catch (e: Exception) {
                Log.e("saveConversations", e)
            }
        }
    }

    fun clearConversations() {
        synchronized(this.conversations) {
            this.conversations.clear()
            emitConversationsChanged(ArrayList(this.conversations))
        }
    }

    // Тикет-диалоги ХРАНЯТСЯ здесь наравне с обычными: пайплайн открытого диалога
    // (getConversationSuspend/commonSubscribes/updateInput) использует репозиторий как кэш
    // текущей беседы — фильтр на этом уровне зацикливал сетевые ретраи. Из UI-списка
    // диалогов тикеты отсекает ListViewModel (см. filterOutTicketDialogs).
    fun addConversation(conversation: DataConversation) {
        if (conversation == null) return
        synchronized(this.conversations) {
            if (this.conversations.find { it.id != null && it.id == conversation.id } != null) return
            val resAdd = this.conversations.add(conversation)
            if (resAdd) {
                _newConversationFlow.tryEmit(conversation)
                emitConversationsChanged(ArrayList(this.conversations))
            }
        }
    }

    fun updateLastAdmin(conversationId: String, admin: Admin?) {
        synchronized(this.conversations) {
            val conversation = this.conversations.find { it.id != null && it.id == conversationId }
                ?: return
            conversation.lastAdmin = admin
            emitConversationsChanged(ArrayList(this.conversations))
        }
    }

    fun updateInfoAboutConversation(conversation: DataConversation) {
        if(conversation.id != null) {
            this.updateConversation(conversation.id, conversation)
        }
    }

    fun removeConversation(id: String) {
        synchronized(this.conversations) {
            val resRemove = this.conversations.remove(this.conversations.find { it.id != null && it.id == id })
            if (resRemove) {
                emitConversationsChanged(ArrayList(this.conversations))
            }
        }
    }
    
    fun removeUnreadConversation(conversationId: String) {
        synchronized(this.conversations) {
            val c = this.conversations.find { x -> x.id == conversationId } ?: return
            val index = this.conversations.indexOf(c)
            c.unreadPartsCount = 0

            if(c.sourceJsonData != null) {
                val sJd = c.sourceJsonData
                if(sJd.has(F.UNREAD_PARTS_COUNT)) {
                    sJd.remove(F.UNREAD_PARTS_COUNT)
                    sJd.addProperty(F.UNREAD_PARTS_COUNT, 0)
                }
                c.sourceJsonData = sJd
            }

            this.conversations[index] = c
            emitConversationsChanged(ArrayList(this.conversations))
        }
    }

    fun saveOpenedConversation(id: String) {
        if(id.isNotEmpty()) {
            lastOpenedConversation = id
        }
        this.openedConversation = id
    }

    fun getOpenedConversationId() : String {
        return openedConversation
    }

    fun getLastOpenedConversationId() : String {
        return lastOpenedConversation
    }

    fun updateConversation(conversationId: String, conversation: DataConversation) {
        synchronized(this.conversations) {
            val foundConversation = this.conversations.find { x -> x.id != null && x.id == conversationId }
                    ?: return

            // Merge-guard: часть WSS-событий и ответов API не включает last_admin либо
            // присылает его как частичный объект (только id, без name/avatar). Без этой
            // защиты корректные имя и аватар оператора затираются пустыми значениями.
            // Реальная смена оператора всегда приходит с полными данными нового оператора.
            val oldAdmin = foundConversation.lastAdmin
            val newAdmin = conversation.lastAdmin
            if (oldAdmin != null) {
                if (newAdmin == null) {
                    // last_admin отсутствует совсем → восстанавливаем старого оператора
                    conversation.lastAdmin = oldAdmin
                    patchLastAdminInSourceJson(conversation, oldAdmin)
                } else if ((newAdmin.id == null || newAdmin.id == oldAdmin.id)
                        && (newAdmin.name.isNullOrEmpty() || newAdmin.avatar.isNullOrEmpty())) {
                    // Тот же оператор, но данные неполные → дополняем из сохранённого
                    if (newAdmin.name.isNullOrEmpty()) newAdmin.name = oldAdmin.name
                    if (newAdmin.avatar.isNullOrEmpty()) newAdmin.avatar = oldAdmin.avatar
                    patchLastAdminInSourceJson(conversation, newAdmin)
                }
            }

            // last_sender (публичная персона бота/триггера) теряется ещё чаще last_admin:
            // многие RTS-кадры и ответы его не несут вовсе. Замена объекта целиком
            // обнуляла бы персону первым же обновлением — восстанавливаем сохранённую.
            // Частичных last_sender (id без name/avatar) в природе не наблюдалось,
            // поэтому достаточно restore-if-missing, без дополнения полей.
            val oldSender = foundConversation.lastSender
            if (oldSender != null && conversation.lastSender == null) {
                conversation.lastSender = oldSender
                patchAdminInSourceJson(conversation, oldSender, F.LAST_SENDER)
            }

            // randomId живёт только на клиенте (матч псевдо-id routing_* → реальный id в
            // DialogPresenter); обновления с сервера могут приходить без него — не затираем,
            // иначе подмена псевдо-id становится невозможной.
            if (conversation.randomId.isNullOrEmpty() && !foundConversation.randomId.isNullOrEmpty()) {
                conversation.randomId = foundConversation.randomId
            }

            this.conversations.remove(foundConversation)
            this.conversations.add(0, conversation)

            emitConversationsChanged(ArrayList(this.conversations))

            if(foundConversation.randomId == openedConversation) {
                saveOpenedConversation(conversation.id)
            }
        }
    }
    
    private fun patchLastAdminInSourceJson(conversation: DataConversation, admin: Admin) =
        patchAdminInSourceJson(conversation, admin, F.LAST_ADMIN)

    private fun patchAdminInSourceJson(conversation: DataConversation, admin: Admin, field: String) {
        val src = conversation.sourceJsonData ?: return
        val existingAdminObj = src.takeIf { it.has(field) }
            ?.get(field)
            ?.takeIf { it.isJsonObject }
            ?.asJsonObject
        val hasFullAdmin = existingAdminObj != null
                && existingAdminObj.has(F.NAME) && !existingAdminObj.get(F.NAME).isJsonNull
                && existingAdminObj.has(F.AVATAR) && !existingAdminObj.get(F.AVATAR).isJsonNull
        if (!hasFullAdmin) {
            src.remove(field)
            runCatching {
                val adminJson = JsonParser.parseString(Gson().toJson(admin))
                if (adminJson.isJsonObject) {
                    src.add(field, adminJson.asJsonObject)
                }
            }
        }
    }

    // Назначение/смена оператора (RTS ConversationAssigned). updateConversation переставляет
    // диалог в начало и шлёт changeSignal → список и шапка оператора обновляются в реалтайме.
    fun assignedConversation(conversation: DataConversation) {
        updateConversation(conversation.id, conversation)
    }

    // getAddedConversation() (Observable-мост) удалён — потребители на newConversationFlow напрямую.

    fun setCurrentAfter(after: String) {
        this.currentAfter = after
    }

    fun getCurrentAfter() = this.currentAfter

    /**
     * Полный teardown для re-init сценария. Сбрасывает локальное состояние и обнуляет singleton —
     * при следующем getInstance() создаётся свежий с пустыми Flow. Прежние подписчики на
     * Observable от старого инстанса просто перестают получать события (Flow не завершается),
     * а презентеры на teardown диспозят подписки сами.
     */
    fun deInit() {
        synchronized(this.conversations) {
            this.conversations.clear()
        }
        currentAfter = ""
        openedConversation = ""
        lastOpenedConversation = ""

        synchronized(ConversationsRepository::class.java) {
            holderRef = null
        }
    }

    companion object {
        @Volatile
        private var holderRef: ConversationsRepository? = null
        fun getInstance(): ConversationsRepository {
            val existing = holderRef
            if (existing != null) return existing
            return synchronized(ConversationsRepository::class.java) {
                val cur = holderRef
                if (cur != null) cur
                else {
                    val fresh = ConversationsRepository()
                    holderRef = fresh
                    fresh
                }
            }
        }
    }
}