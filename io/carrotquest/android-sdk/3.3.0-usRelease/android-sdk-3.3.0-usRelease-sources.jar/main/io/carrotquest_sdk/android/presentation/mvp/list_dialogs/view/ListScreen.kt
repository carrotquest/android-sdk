package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.presentation.ui.LoadingContent
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationListItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListUiState
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel.ListViewModel
import io.carrotquest_sdk.android.presentation.tickets.ListTab
import io.carrotquest_sdk.android.presentation.tickets.TabSwitchMotion
import io.carrotquest_sdk.android.presentation.tickets.TicketCardUiItem
import io.carrotquest_sdk.android.presentation.tickets.TicketListContent
import io.carrotquest_sdk.android.presentation.tickets.TicketsViewModel

// ── Главный экран (только контент, без шапки) ─────────────────────────────────

@Composable
fun ListContentScreen(
    viewModel: ListViewModel,
    ticketsViewModel: TicketsViewModel,
    theme: ThemeSdk,
    accentColor: Color,
    messagesUnreadCount: Int,
    onConversationClick: (id: String) -> Unit,
    onNewConversationClick: () -> Unit,
    onTicketClick: (TicketCardUiItem) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val headerData by viewModel.headerData.collectAsState()
    val isDark = theme == ThemeSdk.DARK
    // Навбар здесь НЕ учитываем: контейнер уже применяет navigationBarsPadding() (см. BottomTabPanel)
    val showPoweredBy = headerData.showPoweredBy

    // Табы «Сообщения/Тикеты» — только при непустой истории тикетов (создать тикет может
    // лишь оператор); пока тикетов нет, экран не меняется вообще
    val ticketsEnabled by ticketsViewModel.ticketsEnabled.collectAsState()
    val showTabs by ticketsViewModel.showTabs.collectAsState()
    val ticketsUnread by ticketsViewModel.unreadCount.collectAsState()
    val tickets by ticketsViewModel.tickets.collectAsState()
    val selectedTab by ticketsViewModel.selectedTab.collectAsState()

    // Загрузка тикетов — при включении фичи (параллельно диалогам), не дожидаясь открытия вкладки:
    // от результата зависит сам показ табов, а бейджи/превью должны быть готовы к переключению
    LaunchedEffect(ticketsEnabled) {
        if (ticketsEnabled) ticketsViewModel.loadTickets()
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            // Write — только на вкладке «Сообщения»: кнопка создаёт обычный диалог,
            // на «Тикетах» ей делать нечего (создания тикета клиентом нет)
            val onMessagesTab = !showTabs || selectedTab == ListTab.MESSAGES
            val showWriteButton = onMessagesTab &&
                (uiState is ListUiState.Content || uiState is ListUiState.Empty)
            // Подложка нужна, если есть что показать: табы (есть тикеты) и/или Powered-by
            val showPanel = showTabs || showPoweredBy

            // Нижний инсет ленты = измеренная высота панели + АНИМИРОВАННОЕ место под кнопку.
            // Кнопка по макету гаснет НА МЕСТЕ (чистый fade, без изменения размера), поэтому
            // высоту её AnimatedVisibility мерить нельзя (скачок одним кадром в конце exit'а) —
            // резервируемое место анимируем отдельно, синхронно с фейдом. Навбар не суммируем —
            // контейнер уже применяет navigationBarsPadding().
            val density = LocalDensity.current
            var panelInset by remember { mutableStateOf(0.dp) }
            val writeButtonGap = if (showPanel) 10.dp else 16.dp
            val buttonSpace by animateDpAsState(
                targetValue = if (showWriteButton) WriteButtonHeight + writeButtonGap else 0.dp,
                animationSpec = tween(TabSwitchMotion.CONTENT_FADE_MS),
                label = "writeButtonSpace"
            )
            val bottomInset = (if (showPanel) panelInset else 0.dp) + buttonSpace

            // Контент вкладок с кросс-фейдом Сообщения ⇄ Тикеты
            Crossfade(
                targetState = showTabs && selectedTab == ListTab.TICKETS,
                animationSpec = tween(TabSwitchMotion.CONTENT_FADE_MS),
                label = "listTabContent"
            ) { showTickets ->
                // pointerInput на обёртке: во время кросс-фейда оба дерева в композиции и уходящее
                // остаётся hit-testable; верхний (входящий) слой обязан перехватывать тапы, даже
                // если его контент без собственного pointer-input (Empty/Loading) — иначе тап
                // проваливается в гаснущий список и открывает элемент «той» вкладки
                Box(modifier = Modifier.fillMaxSize().pointerInput(Unit) {}) {
                    if (showTickets) {
                        TicketListContent(
                            tickets = tickets,
                            isDark = isDark,
                            bottomPadding = bottomInset,
                            onTicketClick = onTicketClick
                        )
                    } else {
                        when (val state = uiState) {
                            // Loading/Error не скроллятся — просто поджимаем их снизу на высоту
                            // плавающего низа, чтобы панель не перекрывала спиннер/кнопку «Повторить»
                            is ListUiState.Loading -> Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(bottom = bottomInset)
                            ) {
                                LoadingContent(accentColor)
                            }
                            is ListUiState.Empty -> EmptyState(isDark, bottomInset)
                            is ListUiState.Content -> ConversationListContent(
                                recentItems = state.recentItems,
                                historyItems = state.historyItems,
                                isDark = isDark,
                                accentColor = accentColor,
                                bottomPadding = bottomInset,
                                onItemClick = onConversationClick,
                                onToggleGroup = { viewModel.toggleGroup(it) },
                                onPagination = { viewModel.onPagination() }
                            )
                            is ListUiState.Error -> Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(bottom = bottomInset)
                            ) {
                                ListErrorContent(
                                    errorType = state.type,
                                    isDark = isDark,
                                    onRetry = { viewModel.loadData() }
                                )
                            }
                        }
                    }
                }
            }

            // Плавающий низ: кнопка «Написать» (гаснет при уходе с «Сообщений») + условная подложка
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                AnimatedVisibility(
                    visible = showWriteButton,
                    // По макету кнопка гаснет/проявляется НА МЕСТЕ — только fade, размер не меняем
                    // (место в ленте анимирует buttonSpace выше, синхронным tween'ом)
                    enter = fadeIn(tween(TabSwitchMotion.CONTENT_FADE_MS)),
                    exit = fadeOut(tween(TabSwitchMotion.CONTENT_FADE_MS))
                ) {
                    FloatingWriteButton(
                        accentColor = accentColor,
                        // с подложкой — зазор до неё; без подложки — небольшой отступ
                        // (навбар уже учтён контейнером через navigationBarsPadding)
                        bottomPadding = writeButtonGap,
                        // во время fade-out кнопка остаётся hit-testable — гасим действие
                        enabled = showWriteButton,
                        onClick = onNewConversationClick
                    )
                }
                if (showPanel) {
                    BottomTabPanel(
                        showTabs = showTabs,
                        selectedTab = selectedTab,
                        messagesUnreadCount = messagesUnreadCount,
                        ticketsUnreadCount = ticketsUnread,
                        showPoweredBy = showPoweredBy,
                        appName = headerData.appName,
                        isDark = isDark,
                        accentColor = accentColor,
                        modifier = Modifier.onSizeChanged {
                            panelInset = with(density) { it.height.toDp() }
                        },
                        onSelectTab = { ticketsViewModel.selectTab(it) }
                    )
                }
            }
        }
    }
}

// ── Список диалогов ───────────────────────────────────────────────────────────

@Composable
private fun ConversationListContent(
    recentItems: List<ConversationListItem>,
    historyItems: List<ConversationListItem>,
    isDark: Boolean,
    accentColor: Color,
    bottomPadding: Dp,
    onItemClick: (String) -> Unit,
    onToggleGroup: (String) -> Unit,
    onPagination: () -> Unit
) {
    val listState = rememberLazyListState()
    val reachedEnd by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            lastVisible >= listState.layoutInfo.totalItemsCount - 3
        }
    }

    LaunchedEffect(reachedEnd) {
        if (reachedEnd) onPagination()
    }

    // Fix: когда диалог переходит из истории в recent (оператор написал), он попадает в
    // начало списка. Если пользователь уже смотрит на верх — проскролливаем, чтобы новое
    // сообщение осталось видно. Если пользователь пролистал вниз — не дёргаем, пусть
    // уходит под шапку, иначе сбросится контекст чтения.
    val density = LocalDensity.current
    val scrollThresholdPx = remember(density) { with(density) { 20.dp.toPx() }.toInt() }
    val firstRecentKey = recentItems.firstOrNull()?.let { listItemKey(it) }
    LaunchedEffect(firstRecentKey) {
        if (firstRecentKey == null) return@LaunchedEffect
        val nearTop = listState.firstVisibleItemScrollOffset <= scrollThresholdPx
        if (nearTop) {
            listState.animateScrollToItem(0)
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 8.dp, bottom = bottomPadding + 8.dp)
    ) {
        items(items = recentItems, key = { listItemKey(it) }) { item ->
            ListItemRow(item = item, isDark = isDark, accentColor = accentColor, onItemClick = onItemClick, onToggleGroup = onToggleGroup)
        }

        if (historyItems.isNotEmpty()) {
            item(key = "history_header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HorizontalDivider(
                        modifier = Modifier.weight(1f),
                        thickness = 1.dp,
                        color = SdkColors.divider(isDark)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.list_history_section),
                        color = SdkColors.sectionLabel,
                        fontSize = 12.sp
                    )
                }
            }
            items(items = historyItems, key = { listItemKey(it) }) { item ->
                ListItemRow(item = item, isDark = isDark, accentColor = accentColor, onItemClick = onItemClick, onToggleGroup = onToggleGroup)
            }
        }
    }
}

private fun listItemKey(item: ConversationListItem): String = when (item) {
    is ConversationListItem.Single -> "single_${item.conversation.id}"
    is ConversationListItem.Group  -> "group_${item.groupKey}"
}

@Composable
private fun ListItemRow(
    item: ConversationListItem,
    isDark: Boolean,
    accentColor: Color,
    onItemClick: (String) -> Unit,
    onToggleGroup: (String) -> Unit
) {
    when (item) {
        is ConversationListItem.Single ->
            ConversationCard(item = item.conversation, isDark = isDark, accentColor = accentColor, onClick = { onItemClick(item.conversation.id) })
        is ConversationListItem.Group ->
            ConversationGroupItem(group = item, isDark = isDark, accentColor = accentColor, onItemClick = onItemClick, onToggle = { onToggleGroup(item.groupKey) })
    }
}
