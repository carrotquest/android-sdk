package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.domain.entities.TicketClosedPatch
import io.carrotquest_sdk.android.domain.entities.TicketEntity
import io.carrotquest_sdk.android.domain.entities.TicketStage
import io.carrotquest_sdk.android.domain.entities.TicketStatusEntity
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Кэш тикетов + счётчик непрочитанных тикет-диалогов.
 *
 * Семантика счётчика — как tickets_unread бэка и вебовский unreadTicketCount: количество
 * ДИАЛОГОВ с непрочитанным (не сообщений). Инкремент — только при переходе карточки
 * 0 → >0, декремент — идемпотентный в markAsRead (только если карточка была непрочитанной),
 * с clamp на 0.
 *
 * Все read-modify-write мутаторы — под synchronized(this): StateFlow-присваивание атомарно,
 * но «прочитал-изменил-записал» без монитора теряет конкурентные обновления
 * (урок conversations_cme_locking).
 */
class TicketsRepository private constructor() {

    private val _ticketsFlow = MutableStateFlow<List<TicketEntity>>(emptyList())
    val ticketsFlow: StateFlow<List<TicketEntity>> = _ticketsFlow.asStateFlow()

    private val _unreadTicketsCountFlow = MutableStateFlow(0)
    val unreadTicketsCountFlow: StateFlow<Int> = _unreadTicketsCountFlow.asStateFlow()

    /**
     * Диалог тикета, открытый на экране прямо сейчас: для него RTS-сообщения не инкрементят
     * unread (аналог поведения обычного открытого чата). Выставляет/снимает экран тикета (Шаг 6).
     */
    @Volatile
    var currentlyViewedConversationId: String? = null

    /**
     * Поколение сессии: инкрементируется в [reset] (logout/смена пользователя). Загрузка списка
     * снимает значение ДО сетевого запроса и сверяет ПОСЛЕ — поздний ответ по прошлому
     * пользователю не должен воскресить его тикеты и бейдж поверх сброшенного состояния.
     */
    @Volatile
    var sessionEpoch: Int = 0
        private set

    /**
     * Стартовое значение счётчика из /connect (data.user.tickets_unread; null = фича выключена).
     *
     * Только ранняя инициализация ДО первой загрузки списка: если кэш уже наполнен, счётчик
     * пересчитан из карточек (saveTickets) с учётом локального прочтения и просматриваемого
     * тикета — connect-значение (например, при reconnect/recovery) его бы откатило. Под
     * монитором, как остальные мутаторы счётчика: это read-modify-write относительно кэша.
     */
    fun initUnreadFromConnect(ticketsUnread: Int?): Unit = synchronized(this) {
        if (_ticketsFlow.value.isNotEmpty()) return
        _unreadTicketsCountFlow.value = ticketsUnread ?: 0
    }

    /**
     * Полная замена кэша (loadTickets). Сортировка — серверное правило (см. [sortTickets]).
     *
     * Глобальный счётчик пересинхронизируется со списком: unread_parts_count карточек — та же
     * серверная истина, что tickets_unread из /connect, но свежее. Иначе бейдж таба живёт только
     * на стартовом значении connect и RTS-инкрементах — при любом их пропуске (рестарт после
     * непрочитанного RTS-сообщения) навсегда застревает в 0, хотя карточки непрочитанные.
     * Просматриваемый тикет не считаем — его прочтение уже в полёте (markAsRead/маркрид).
     */
    fun saveTickets(tickets: List<TicketEntity>) = synchronized(this) {
        _ticketsFlow.value = sortTickets(tickets)
        _unreadTicketsCountFlow.value = tickets.count {
            it.unreadCount > 0 && it.conversationId != currentlyViewedConversationId
        }
    }

    fun getTicketById(ticketId: String): TicketEntity? =
        _ticketsFlow.value.find { it.id == ticketId }

    fun getTicketByConversationId(conversationId: String): TicketEntity? =
        _ticketsFlow.value.find { it.conversationId == conversationId }

    /**
     * Новое сообщение тикет-диалога из RTS-кадра conversation_parts_batch.
     *
     * Unread карточки: серверные счётчики из кадра (кадр несёт unread_parts_count) —
     * надёжнее слепого инкремента; fallback +1, если счётчика в кадре нет. Для просматриваемого
     * тикета unread не растёт (сервер это не знает — гейтим сами).
     *
     * @return false — тикет не найден в кэше (создан после загрузки списка): вызывающий
     * обязан дёрнуть loadTickets(); true — обновление применено.
     */
    fun updateFromNewPart(
        conversationId: String,
        partLast: MessageData?,
        serverUnreadCount: Int?,
        lastUpdateMillis: Long?
    ): Boolean = synchronized(this) {
        val current = _ticketsFlow.value
        val index = current.indexOfFirst { it.conversationId == conversationId }
        if (index == -1) return false

        val ticket = current[index]
        val isViewed = currentlyViewedConversationId == conversationId
        val newUnread = when {
            isViewed -> ticket.unreadCount
            serverUnreadCount != null -> serverUnreadCount
            else -> ticket.unreadCount + 1
        }
        if (ticket.unreadCount == 0 && newUnread > 0) {
            _unreadTicketsCountFlow.value += 1
        }

        val updated = ticket.copy(
            partLast = partLast ?: ticket.partLast,
            unreadCount = newUnread,
            lastUpdateMillis = lastUpdateMillis ?: ticket.lastUpdateMillis
        )
        _ticketsFlow.value = sortTickets(current.toMutableList().also { it[index] = updated })
        true
    }

    /**
     * Локальное прочтение тикета (открытие экрана). Идемпотентно: декремент общего счётчика —
     * только если карточка была непрочитанной («преждевременная» очистка до RTS-эха, как в вебе).
     * Серверный markread делает обычный пайплайн диалога.
     */
    fun markAsRead(conversationId: String): Unit = synchronized(this) {
        val current = _ticketsFlow.value
        val index = current.indexOfFirst { it.conversationId == conversationId }
        if (index == -1) return
        val ticket = current[index]
        if (ticket.unreadCount == 0) return

        _unreadTicketsCountFlow.value = (_unreadTicketsCountFlow.value - 1).coerceAtLeast(0)
        _ticketsFlow.value = current.toMutableList().also { it[index] = ticket.copy(unreadCount = 0) }
    }

    /**
     * Патч тикета по RTS-событию ticket/updated (смена статуса, вкл. закрытие/переоткрытие).
     * Пейлоад события частичный (без short_id/due_date/conversation) — обновляем только
     * пришедшее, остальное сохраняем (паттерн вебовского updateTicket, cqstatic PR#1176).
     *
     * @param closedPatch закрытость тикета (CAR-76310); null — событие без данных о закрытии
     * (старый бэк/нет статуса) → сохраняем прежние closedAtMillis/isReopenable.
     * @return false — тикета нет в кэше: вызывающий перезагружает список.
     */
    fun updateTicket(
        ticketId: String,
        title: String?,
        status: TicketStatusEntity?,
        lastUpdateMillis: Long?,
        closedPatch: TicketClosedPatch? = null
    ): Boolean = synchronized(this) {
        val current = _ticketsFlow.value
        val index = current.indexOfFirst { it.id == ticketId }
        if (index == -1) return false

        val ticket = current[index]
        val updated = ticket.copy(
            title = title ?: ticket.title,
            status = status ?: ticket.status,
            lastUpdateMillis = lastUpdateMillis ?: ticket.lastUpdateMillis,
            closedAtMillis = if (closedPatch != null) closedPatch.closedAtMillis else ticket.closedAtMillis,
            isReopenable = closedPatch?.isReopenable ?: ticket.isReopenable
        )
        _ticketsFlow.value = sortTickets(current.toMutableList().also { it[index] = updated })
        true
    }

    /** Сброс на logout/смену пользователя (точка вызова — Шаг 7). */
    fun reset(): Unit = synchronized(this) {
        sessionEpoch += 1
        _ticketsFlow.value = emptyList()
        _unreadTicketsCountFlow.value = 0
        currentlyViewedConversationId = null
    }

    companion object {
        @Volatile
        private var holderRef: TicketsRepository? = null

        fun getInstance(): TicketsRepository {
            val existing = holderRef
            if (existing != null) return existing
            return synchronized(this) {
                holderRef ?: TicketsRepository().also { holderRef = it }
            }
        }
        // deInit-обнуления синглтона сознательно нет: activity-scoped TicketsViewModel держит
        // StateFlow-ссылки на инстанс, пересоздание их оторвало бы. Смену пользователя закрывает
        // reset() (clearHistory) + sessionEpoch против поздних ответов загрузки.

        /** Серверное правило сортировки: нефинальные раньше финальных, внутри — по убыванию last_update. */
        fun sortTickets(tickets: List<TicketEntity>): List<TicketEntity> =
            tickets.sortedWith(
                compareBy<TicketEntity> { it.status.stage == TicketStage.FINAL }
                    .thenByDescending { it.lastUpdateMillis ?: 0L }
            )
    }
}
