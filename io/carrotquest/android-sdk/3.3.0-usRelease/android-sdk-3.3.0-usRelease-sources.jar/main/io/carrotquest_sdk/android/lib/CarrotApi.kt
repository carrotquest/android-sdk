package io.carrotquest_sdk.android.lib

import com.google.gson.JsonObject
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.lib.models.UserConversations
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse
import io.carrotquest_sdk.android.lib.network.responses.messages.AttachmentUploadResponse
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketResponse
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketsResponse
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit-интерфейс API. Переведён с RxJava2 `Observable<T>` на корутинные `suspend fun`
 * (ветка remove_rx, фаза 1). Сетевой слой больше не требует RxJava2CallAdapterFactory —
 * Retrofit 2.11 поддерживает suspend нативно.
 */
interface CarrotApi {

    @FormUrlEncoded
    @POST("connect")
    suspend fun connect(
        @Field("api_key") apiKey: String,
        @Field("include_auto_events") includeAutoEvents: Boolean?,
        @Field("include_js_scripts") includeJsScripts: Boolean?,
        @Field("include_push_domain") includePushDomain: Boolean?,
        @Field("browser") browser: String,
        @Field("os") os: String,
        @Field("device") device: String,
        @Field("device_type") deviceType: String,
        @Field("token_type") tokenType: String,
        @Field("referrer") referrer: String
    ): ConnectResponse

    @FormUrlEncoded
    @POST("connect")
    suspend fun connect(
        @Field("api_key") apiKey: String,
        @Field("include_auto_events") includeAutoEvents: Boolean?,
        @Field("include_js_scripts") includeJsScripts: Boolean?,
        @Field("include_push_domain") includePushDomain: Boolean?,
        @Field("browser") browser: String,
        @Field("os") os: String,
        @Field("device") device: String,
        @Field("device_type") deviceType: String,
        @Field("token_type") tokenType: String
    ): ConnectResponse

    @FormUrlEncoded
    @POST("users/app_auth/")
    suspend fun auth(
        @Field("user_id") userId: String,
        @Field("hash") hash: String,
        @Field("token_type") tokenType: String
    ): AuthResponse

    @POST("auth/jwt/refresh")
    suspend fun refresh(
        @Query("update_refresh_token") updateRefreshToken: Boolean?
    ): RefreshResponse

    // Ниже — $self_user вместо явного user_id: сервер определяет юзера по auth_token. Явный id в
    // пути захватывался вызывающим кодом заранее и мог устареть к моменту отправки (смена
    // идентичности: auth-склейка, пересоздание сессии) — пара «путь одного юзера + токен другого»
    // давала 403 PermissionDeniedError.
    @FormUrlEncoded
    @POST("users/\$self_user/events")
    suspend fun trackEvent(
        @Field("event") event: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/events")
    suspend fun trackEvent(
        @Field("event") event: String,
        @Field("params") params: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/props")
    suspend fun sendProps(
        @Field("operations") operations: String
    ): NetworkResponse

    @GET("users/{user_id}")
    suspend fun getUser(
        @Path("user_id") userId: String,
        @Query("by_user_id") byUserId: Boolean?
    ): User

    @GET("users/{user_id}")
    suspend fun loadUser(
        @Path("user_id") userId: String,
        @Query("by_user_id") byUserId: Boolean?
    ): UserResponse

    @GET("users/{user_id}/conversations")
    suspend fun getConversations(
        @Path("user_id") userId: String
    ): UserConversations

    @GET("users/{user_id}/conversations")
    suspend fun getConversations(
        @Path("user_id") userId: String,
        // Курсор пагинации — paginate_position (как в /parts для сообщений), НЕ "after":
        // параметр "after" сервер игнорировал и отдавал ту же первую страницу.
        @Query("paginate_position") paginatePosition: String,
        @Query("paginate_including") paginateIncluding: Boolean?,
        @Query("paginate_direction") paginateDirection: String
    ): UserConversations

    @GET("conversations/{conversationId}")
    suspend fun getConversation(@Path("conversationId") conversationId: String): ConversationResponse

    // Тикеты Лимит списка на бэке — 20, пагинации нет.
    // include_conversation=true — превью/unread карточек приходят сразу в списке;
    // id_as_string=true — id строками (без потери точности long-чисел).
    @GET("users/{user_id}/tickets")
    suspend fun getTickets(
        @Path("user_id") userId: String,
        @Query("include_conversation") includeConversation: Boolean = true,
        @Query("id_as_string") idAsString: Boolean = true
    ): TicketsResponse

    // Детальный GET users/{id}/tickets/{ticketId} сознательно не заведён: единственный клиентский
    // fallback (вход извне по conversationId) деталью не решается — она ищет по ticketId,
    // а перезагрузка списка уже есть (refreshTickets). Контракт бэка описан в плане тикетов.

    // Запрос CSAT-опроса по закрытому тикету (CAR-76310, кнопка «Решён»). Бэк создаёт
    // VOTE-реплику в диалоге тикета (прилетит по RTS) и идемпотентен: повторный вызов
    // дублей не плодит; после переоткрытия оценка сбрасывается — новый цикл оценивается заново.
    // Открытый тикет → 400 TicketIsNotClosed.
    @POST("users/{user_id}/tickets/{ticket_id}/csat/")
    suspend fun sendTicketCsat(
        @Path("user_id") userId: String,
        @Path("ticket_id") ticketId: String,
        @Query("id_as_string") idAsString: Boolean = true
    ): TicketResponse

    @FormUrlEncoded
    @POST("users/{user_id}/startconversation")
    suspend fun startConversation(
        @Path("user_id") userId: String,
        @Field("body") messageText: String,
        // JSON-массив уже загруженных вложений (из POST /attachments). null → поле не отправляется.
        @Field("attachments_cached") attachmentsCached: String? = null
    ): StartConversationResponse

    @Multipart
    @POST("users/{user_id}/startconversation")
    suspend fun startConversationWithFile(
        @Path("user_id") userId: String,
        @Part("boundary") requestFile: RequestBody,
        @Part("filename") filename: RequestBody,
        @Part file: MultipartBody.Part
    ): StartConversationResponse

    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String
    ): MessagesResponse

    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String,
        @Query("paginate_position") paginatePosition: String,
        @Query("paginate_including") paginateIncluding: Boolean?,
        @Query("paginate_direction") paginateDirection: String
    ): MessagesResponse

    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String,
        @Query("paginate_position") paginatePosition: String,
        @Query("count") count: Int?,
        @Query("paginate_including") paginateIncluding: Boolean?,
        @Query("paginate_direction") paginateDirection: String
    ): MessagesResponse

    // Прыжок к сообщению (цитирование, CAR-75966): direction=around грузит окно ВОКРУГ позиции,
    // direction=after — страницу НОВЕЕ позиции (заполнение разрыва). Позиции — id-снежинки
    // сообщений; page_order=asc — порядок внутри страницы (клиент всё равно сортирует сам).
    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String,
        @Query("paginate_position") paginatePosition: String,
        @Query("paginate_direction") paginateDirection: String,
        @Query("paginate_page_order") paginatePageOrder: String?,
        @Query("paginate_including") paginateIncluding: Boolean?
    ): MessagesResponse

    @FormUrlEncoded
    @POST("conversations/{conversation_id}/reply")
    suspend fun reply(
        @Path("conversation_id") conversationId: String,
        @Field("body") messageText: String,
        @Field("from_user") fromUser: Boolean,
        @Field("random_id") randomId: String,
        // JSON-массив уже загруженных вложений (из POST /attachments). null → поле не отправляется.
        @Field("attachments_cached") attachmentsCached: String? = null,
        // id цитируемого сообщения (CAR-75966). null → поле не отправляется. Бэкенд валидирует:
        // только reply_user/reply_admin/article, тот же диалог, существующий серверный id — иначе 400.
        @Field("replied_to") repliedTo: String? = null,
        // Полезная нагрузка ответа кнопкой быстрого ответа (quick_reply): meta_data кнопки как есть.
        // null → поле не отправляется. Так же шлёт веб-виджет (ChatBotButtons).
        @Field("meta_data") metaData: String? = null
    ): ReplyResponse

    @FormUrlEncoded
    @POST("users/\$self_user/pushes_subscribe")
    suspend fun sendPushToken(
        @Field("token") token: String,
        @Field("type") type: String,
        @Field("device_guid") deviceId: String,
        @Field("device") device: String,
        @Field("device_type") deviceType: String,
        @Field("os") os: String,
        @Field("browser") browser: String,
        @Field("user_agent") userAgent: String
    ): PushSubResponse

    // Заголовок помечает запрос как teardown (logout): TokenRefreshInterceptor на его 401/403 НЕ
    // эскалирует в session-recovery (иначе провал отписки посреди deInit запускал recovery-шторм).
    // Авто-рефреш при живом refresh остаётся — чтобы отписка прошла и устройство отвязалось.
    @FormUrlEncoded
    @Headers("X-CQ-No-Session-Recovery: 1")
    @POST("users/{userId}/pushes_unsubscribe")
    suspend fun deletePushToken(
        @Path("userId") userId: String,
        @Query("device_guid") deviceId: String,
        @Field("type") type: String,
        // Токен старого юзера передаём ЯВНО: при deInit креды уже очищены, и интерсептор
        // (paramAdds) свой auth_token не приложит — запрос ушёл бы неаутентифицированным, и
        // сервер не снял бы привязку. При пустых кредах дубля auth_token не будет.
        @Query("auth_token") authToken: String? = null
    ): PushSubResponse

    // Загрузка вложения отдельно от сообщения (upload-on-select). Возвращает объект attachment,
    // который затем кладётся в поле attachments_cached при отправке сообщения. app/auth_token/
    // id_as_string добавляет интерсептор paramAdds (как query) — здесь только файл + имя.
    @Multipart
    @POST("attachments")
    suspend fun uploadAttachment(
        @Part attachment: MultipartBody.Part,
        @Part("attachment_file_name") fileName: RequestBody,
        // Сервер требует app в form-data (request_app_id из query не подходит → 400 ValidationError).
        @Part("app") app: RequestBody
    ): AttachmentUploadResponse

    @POST("conversations/{conversationId}/markread")
    suspend fun markRead(@Path("conversationId") conversationId: String): NetworkResponse

    @FormUrlEncoded
    @POST("conversationparts/{messageId}/meta_data")
    suspend fun conversationParts(
        @Path("messageId") messageId: String,
        @Field("meta_data") metaData: JsonObject
    ): NetworkResponse

    @FormUrlEncoded
    @POST("conversations/{conversationId}/settyping")
    suspend fun setTyping(
        @Path("conversationId") conversationId: String,
        @Field("body") messageBody: String,
        @Field("from_user") fromUser: Boolean
    ): NetworkResponse

    // $self_user вместо явного user_id: сервер резолвит юзера по auth_token. Раньше здесь стоял
    // @Path("user_id"), который UserPresenceService захватывал ОДИН раз при run() и потом бил им
    // каждые 30с — переживая смену идентичности (auth-склейка, пересоздание сессии). Пара
    // «путь от старого юзера + живой токен нового» давала 403 PermissionDeniedError.
    @FormUrlEncoded
    @POST("users/\$self_user/setpresence")
    suspend fun setPresence(
        @Field("presence") presence: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/setpresence")
    suspend fun setPresenceCurrentScreen(
        @Field("presence") presence: String,
        @Field("current_sdk_page") currentScreen: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("conversationparts/{part_id}/meta_data")
    suspend fun setMetaData(
        @Path("part_id") partId: String,
        @Field("meta_data") metaData: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("messages/trackinteraction")
    suspend fun trackinteraction(
        @Field("conversation_id") conversationId: String,
        @Field("type") type: String
    ): NetworkResponse

    @GET("chatbots/routing/choose")
    suspend fun chooseRoutingBot(@Query("conversation") conversationId: String): ChooseRoutingBotResponse

    @FormUrlEncoded
    @POST("chatbots/routing/start")
    suspend fun startRoutingBot(
        @Field("chat_bot") botId: String,
        @Field("initial_answer_action") buttonActionId: String,
        @Field("initial_answer_body") buttonActionText: String,
        @Field("random_id") randomId: String?,
        @Field("conversation") conversationId: String?
    ): NetworkResponse

    @FormUrlEncoded
    @POST("chatbots/routing/start")
    suspend fun startRoutingBot(
        @Field("chat_bot") botId: String,
        @Field("initial_answer_action") buttonActionId: String,
        @Field("initial_answer_body") buttonActionText: String,
        @Field("random_id") randomId: String?
    ): NetworkResponse

    @FormUrlEncoded
    @POST("utils/logs")
    suspend fun sendLog(
        @Field("message_type") messageType: String,
        @Field("message") message: String,
        @Field("data") data: String
    ): NetworkResponse

    @GET("triggers/trigger_types")
    suspend fun getTriggers(): TriggersResponse

    @FormUrlEncoded
    @POST("users/\$self_user/triggers")
    suspend fun sendTrigger(
        @Field("trigger_types") triggerIds: List<String>
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/user_consent")
    suspend fun setUserConsentContact(
        @Field("contacts") contacts: String,
        @Field("part") partId: String,
        @Query("request_user") userId: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/user_consent")
    suspend fun setUserConsentDataProcessing(
        @Field("data_processing") dataProcessing: Boolean,
        @Query("request_user") userId: String
    ): NetworkResponse
}