package io.carrotquest_sdk.android.data.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.wss.jwt.jwtTokenKey
import io.carrotquest_sdk.android.lib.wss.jwt.jwtTokenUpdateTimeStampKey
import io.carrotquest_sdk.android.lib.wss.jwt.refreshTokenKey
import io.carrotquest_sdk.android.lib.wss.jwt.refreshTokenUpdateTimeStampKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val TAG = "UserIdentityStore"

/**
 * Неделимый снимок идентичности: тройка (userId, access, refresh) + поколение (epoch).
 * Читатель всегда видит согласованную тройку одного поколения — никогда «id одного
 * юзера + токен другого».
 */
internal data class IdentitySnapshot(
    val userId: String,
    val accessToken: String,
    val refreshToken: String,
    val epoch: Long,
) {
    val isEmpty: Boolean
        get() = userId.isEmpty() && accessToken.isEmpty() && refreshToken.isEmpty()
}

/**
 * Единый источник истины для идентичности пользователя (CAR-77172).
 *
 * Инварианты:
 *  - тройка (userId, access, refresh) пишется только атомарно — частичные записи
 *    вида «только токен» возможны исключительно через CAS по epoch;
 *  - epoch монотонно растёт при каждой смене идентичности: auth, применение ответа
 *    /connect, пересоздание сессии, deInit. Результат refresh, стартовавшего при
 *    прежнем epoch, отбрасывается — это тот самый класс гонок, из которого вырос
 *    прод-баг «склейка не работает» (403 PermissionDeniedError);
 *  - персист — в СУЩЕСТВУЮЩИЕ ключи prefs (CarrotUserId, JWT-пара с таймстемпами)
 *    одной транзакцией editor, чтобы легаси-читатели (restoreFromPrefs,
 *    isActualJwtToken) продолжали работать, пока писатели мигрируют поэтапно;
 *  - epoch НЕ персистится: гонки, от которых он защищает, живут внутри процесса,
 *    kill процесса убивает и летящие рефреши.
 *
 * Пока НЕ подключён к боевым путям — писатели переводятся этапом 1
 * (docs/plans/CAR-77172-user-storage.md).
 */
internal object UserIdentityStore {

    private val lock = Any()

    private val _state = MutableStateFlow(IdentitySnapshot("", "", "", 0L))
    val state: StateFlow<IdentitySnapshot> = _state.asStateFlow()

    /** Согласованный снимок для построения запроса: id и токен — одного поколения. */
    fun snapshot(): IdentitySnapshot = _state.value

    /**
     * Плановая смена идентичности (auth, применение ответа /connect): атомарная запись
     * всей тройки, epoch растёт — летящие token-only записи прежнего поколения
     * становятся недействительными.
     *
     * null-токен — «сервер подтвердил идентичность текущими токенами, новых не прислал»
     * (token-less /connect): значение переносится из текущего снимка той же транзакцией,
     * так что тройка остаётся согласованной. Пустая строка — явная запись пустого токена.
     */
    fun applyIdentity(
        context: Context?,
        userId: String,
        accessToken: String?,
        refreshToken: String?,
    ): IdentitySnapshot {
        val applied: IdentitySnapshot
        val previous: IdentitySnapshot
        synchronized(lock) {
            previous = _state.value
            applied = IdentitySnapshot(
                userId,
                accessToken ?: previous.accessToken,
                refreshToken ?: previous.refreshToken,
                previous.epoch + 1,
            )
            _state.value = applied
            persist(context, applied, previous)
        }
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "identity applied: userId=$userId epoch=${applied.epoch}",
        )
        return applied
    }

    /**
     * Результат refresh — единственная разрешённая «token-only» запись, и только по
     * compare-and-swap: если epoch изменился, пока запрос был в полёте, пара
     * принадлежит прежней идентичности и отбрасывается. userId не меняется, epoch
     * не двигается (идентичность та же).
     *
     * @param refreshToken null/пустой — access-only refresh, текущий refresh сохраняется.
     * @return true, если пара применена.
     */
    fun applyRefreshedTokens(
        context: Context?,
        expectedEpoch: Long,
        accessToken: String,
        refreshToken: String?,
    ): Boolean {
        if (accessToken.isEmpty()) return false
        val applied: IdentitySnapshot
        val previous: IdentitySnapshot
        synchronized(lock) {
            previous = _state.value
            if (previous.epoch != expectedEpoch) {
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "refreshed tokens DISCARDED: epoch moved $expectedEpoch -> " +
                        "${previous.epoch} while the refresh was in flight",
                )
                return false
            }
            applied = previous.copy(
                accessToken = accessToken,
                refreshToken = if (refreshToken.isNullOrEmpty()) previous.refreshToken else refreshToken,
            )
            _state.value = applied
            persist(context, applied, previous)
        }
        return true
    }

    /**
     * Пересоздание сессии: идентичность формально та же, но все летящие token-only
     * записи должны быть отброшены — двигаем epoch, тройку не трогаем.
     */
    fun advanceEpoch(): Long = synchronized(lock) {
        val next = _state.value.copy(epoch = _state.value.epoch + 1)
        _state.value = next
        next.epoch
    }

    /**
     * Токены мертвы (серверный отказ refresh, пересоздание сессии, вторая фаза deInit):
     * атомарный переход в «идентичность без токенов», epoch растёт — летящий refresh
     * убитой пары будет отброшен CAS'ом.
     */
    fun clearTokens(context: Context?) {
        synchronized(lock) {
            val previous = _state.value
            _state.value = previous.copy(
                accessToken = "",
                refreshToken = "",
                epoch = previous.epoch + 1,
            )
            // Персистим только токен-ключи: CARROT_USER_ID не трогаем — идентичность жива,
            // а стор в этот момент может быть ещё не населён (вызов до restoreFromPrefs),
            // и общий persist() затёр бы сохранённый id пустым значением.
            if (context != null) {
                try {
                    context
                        .getSharedPreferences(SharedPreferencesLib.NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE)
                        .edit()
                        .putString(jwtTokenKey, "")
                        .putString(refreshTokenKey, "")
                        .remove(jwtTokenUpdateTimeStampKey)
                        .remove(refreshTokenUpdateTimeStampKey)
                        .apply()
                } catch (t: Throwable) {
                    SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "clearTokens persist failed: $t")
                }
            }
        }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "tokens cleared, identity kept")
    }

    /** deInit: пустая тройка, epoch растёт, персист чистится той же транзакцией. */
    fun clear(context: Context?) {
        synchronized(lock) {
            val previous = _state.value
            _state.value = IdentitySnapshot("", "", "", previous.epoch + 1)
            clearPersisted(context)
        }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "identity cleared")
    }

    /**
     * Холодный старт: поднимает тройку с диска, если в памяти пусто. Живую идентичность
     * не затирает (setup после auth в том же процессе).
     */
    fun restoreFromPrefs(context: Context) {
        synchronized(lock) {
            if (!_state.value.isEmpty) return
            val userId = SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_USER_ID)
            val access = SharedPreferencesLib.getString(context, jwtTokenKey)
            val refresh = SharedPreferencesLib.getString(context, refreshTokenKey)
            if (userId.isEmpty() && access.isEmpty() && refresh.isEmpty()) return
            _state.value = IdentitySnapshot(userId, access, refresh, _state.value.epoch + 1)
        }
    }

    /**
     * Тройка + таймстемпы токенов — одной транзакцией editor: запись либо видна целиком,
     * либо не видна вовсе (kill процесса между apply() двух ключей не оставит
     * «id одного + токен другого» на диске). Таймстемп двигается только при смене
     * значения токена — семантика saveJwtToken/saveRefreshToken, на ней стоит
     * isActualJwtToken.
     */
    private fun persist(context: Context?, applied: IdentitySnapshot, previous: IdentitySnapshot) {
        if (context == null) return
        try {
            val editor = context
                .getSharedPreferences(SharedPreferencesLib.NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE)
                .edit()
                .putString(SharedPreferenceKeys.CARROT_USER_ID, applied.userId)
                .putString(jwtTokenKey, applied.accessToken)
                .putString(refreshTokenKey, applied.refreshToken)
            val now = System.currentTimeMillis()
            // Пустой токен — таймстемп удаляем (семантика clearJwtTokens): «свежий таймстемп
            // при пустом значении» не должен влиять на вердикты актуальности.
            when {
                applied.accessToken.isEmpty() -> editor.remove(jwtTokenUpdateTimeStampKey)
                applied.accessToken != previous.accessToken -> editor.putLong(jwtTokenUpdateTimeStampKey, now)
            }
            when {
                applied.refreshToken.isEmpty() -> editor.remove(refreshTokenUpdateTimeStampKey)
                applied.refreshToken != previous.refreshToken -> editor.putLong(refreshTokenUpdateTimeStampKey, now)
            }
            editor.apply()
        } catch (t: Throwable) {
            // Как в SharedPreferencesLib: сбой диска не должен валить SDK; память уже
            // обновлена, на следующем персисте запишется снова.
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "persist failed: $t")
        }
    }

    private fun clearPersisted(context: Context?) {
        if (context == null) return
        try {
            context
                .getSharedPreferences(SharedPreferencesLib.NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE)
                .edit()
                .remove(SharedPreferenceKeys.CARROT_USER_ID)
                .remove(jwtTokenKey)
                .remove(refreshTokenKey)
                .remove(jwtTokenUpdateTimeStampKey)
                .remove(refreshTokenUpdateTimeStampKey)
                .apply()
        } catch (t: Throwable) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "clearPersisted failed: $t")
        }
    }

    /** Только для тестов: object-синглтон, состояние течёт между тестами. */
    internal fun resetForTest() {
        synchronized(lock) {
            _state.value = IdentitySnapshot("", "", "", 0L)
        }
    }
}
