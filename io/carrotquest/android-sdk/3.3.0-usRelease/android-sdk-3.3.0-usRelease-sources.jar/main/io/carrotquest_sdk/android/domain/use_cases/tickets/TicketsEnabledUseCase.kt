package io.carrotquest_sdk.android.domain.use_cases.tickets

import com.google.gson.JsonParser
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings

/**
 * Фиче-флаг тикетов: tickets_unread из /connect (null/отсутствие = выключено).
 * При выключенной фиче UI тикетов полностью скрыт, подписка на канал ticket не обрабатывается.
 */
fun isTicketsEnabled(): Boolean = getSettings()?.ticketsUnread != null

/**
 * Настройка «оценка оператора» (messenger_vote) — управляет видом карточки резолюции
 * закрытого тикета (CAR-76310): включена → вопрос «Ваш вопрос решён?» с CSAT-веткой,
 * выключена → одна кнопка «Мой вопрос не решён» (веб: isVoteEnabled в
 * ticket-resolution-prompt).
 */
fun isMessengerVoteEnabled(): Boolean = parseMessengerVote(getSettings()?.sourceData)

/**
 * Чтение messenger_vote из sourceData настроек (= data ответа /connect, strangler-паттерн:
 * типизированного поля в SettingsEntity нет). Путь app/settings/messenger_vote. Нет поля /
 * битый JSON / не-boolean → false, как falsy-поведение веба. Чистая — покрыта
 * ParseMessengerVoteTest.
 */
internal fun parseMessengerVote(sourceData: String?): Boolean = runCatching {
    val json = sourceData?.takeIf { it.isNotBlank() } ?: return@runCatching false
    JsonParser.parseString(json).takeIf { it.isJsonObject }?.asJsonObject
        ?.getAsJsonObject("app")
        ?.getAsJsonObject("settings")
        ?.get("messenger_vote")
        ?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }
        ?.asBoolean == true
}.getOrDefault(false)
