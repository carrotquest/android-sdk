package io.carrotquest_sdk.android.data.network.wss_responses

import android.os.Handler
import android.os.Looper
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.core.constants.Flags
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.TicketsRepository
import io.carrotquest_sdk.android.data.user.UserStateHolder
import io.carrotquest_sdk.android.domain.use_cases.tickets.loadTickets
import io.carrotquest_sdk.android.lib.network.F
import kotlinx.coroutines.launch
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsAllHelper
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage.DirectionMessage

class   ConversationPartsBatchRtsMessage: IRtsMessage {

    private val tag = "ConversationPartsBatchRtsMessage"

    lateinit var conversation: DataConversation
    lateinit var randomId: String
    lateinit var parts: ArrayList<MessageData>

    private var conversationClosed = false

    // lazy: объект создаётся Gson'ом при парсинге каждого кадра — DI/синглтоны
    // нужны только в process(), а не на этапе десериализации
    private val messagesRepository: MessagesRepository by lazy { MessagesRepository.getInstance() }
    private val conversationsRepository: ConversationsRepository by lazy {
        ConversationsRepository.getInstance()
    }

    override fun process() {

        // Тикет-диалоги — отдельный путь: сообщения идут в ленту (живость открытого экрана
        // тикета), но НЕ в ConversationsRepository/обычные счётчики/нотификации — их учитывает
        // TicketsRepository (вкладка «Тикеты»)
        if (conversation.isTicketConversation) {
            processTicketFrame()
            return
        }

        //Обновляем диалог в базе
        var isConvUpdate = false
        val partLast = conversation.partLast

        if (partLast != null && !partLast.actions.isNullOrEmpty()) {
            val actions = partLast.actions
            val nArray = ArrayList<ActionMessage>()
            for (action in actions) {
                action.messageId = partLast.id
                nArray.add(action)
            }
            if (nArray.isNotEmpty()) {
                isConvUpdate = true
            }
            partLast.actions = nArray
        }

        val conversationId = conversation.id
        if(conversationId != null) {
            val foundConv =
                ConversationsRepository.getInstance().getConversationById(conversationId)
            if (foundConv != null) {
                // Конверсацию мог первым добавить канал message_conversation_started — тогда
                // random_id есть только в этом фрейме. Проносим его в update, чтобы merge-guard
                // репозитория не потерял, а подписчики матча по randomId (подмена псевдо-id
                // routing_* в DialogPresenter) увидели его через conversationsChangesFlow.
                if (conversation.randomId.isNullOrEmpty() && this::randomId.isInitialized && randomId.isNotEmpty()) {
                    conversation.randomId = randomId
                }
                ConversationsRepository.getInstance()
                    .updateConversation(foundConv.id, conversation)
                isConvUpdate = true
            } else {
                conversation.randomId = randomId
                ConversationsRepository.getInstance().addConversation(conversation)
            }

            if (!isConvUpdate) {
                ConversationsRepository.getInstance()
                    .updateConversation(conversationId, conversation)
            }
        }

        this.parts.forEach { m ->
            createAndSaveMessage(m)
        }
    }

    /**
     * Обработка batch-кадра тикет-диалога (Шаг 4 тикетов).
     *
     * Лента: обычные части — в MessagesRepository тем же гейтом, что и у диалогов, но без
     * учёта в user.conversationsUnread и без нотификации (счётчик тикетов ведёт TicketsRepository,
     * вкладка «Тикеты» имеет свой бейдж). Части с body_json.is_ticket_ref=true пропускаем
     * целиком: это копии выбранных сообщений из кадра СОЗДАНИЯ тикета, их parts[].conversation
     * указывает на ИСХОДНЫЙ обычный диалог — вливание задвоило бы сообщения в открытом чате.
     *
     * Счётчики: серверные unread из кадра → TicketsRepository.updateFromNewPart; если тикет
     * неизвестен (создан после загрузки списка) — перезагружаем список (in-flight guard внутри).
     */
    private fun processTicketFrame() {
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag) {
            "ticket frame: conv=${conversation.id} ticket=${conversation.ticket} parts=${parts.size}"
        }

        parts.forEach { m ->
            if (!isTicketRefPart(m)) {
                createAndSaveMessage(m, isTicketConversation = true)
            }
        }

        val conversationId = conversation.id ?: return

        // Кэш беседы обновляем как в обычном пути: подписки открытого экрана тикета
        // (updateInput по conversationsFlow) живут от ConversationsRepository. В UI-список
        // «Сообщения» тикет не попадёт — фильтр на уровне ListViewModel.
        if (conversationsRepository.getConversationById(conversationId) != null) {
            conversationsRepository.updateConversation(conversationId, conversation)
        } else {
            conversationsRepository.addConversation(conversation)
        }

        val lastUpdateMillis = conversation.lastUpdate?.toLongOrNull()?.times(1000)
        val handled = TicketsRepository.getInstance().updateFromNewPart(
            conversationId,
            conversation.partLast,
            conversation.unreadPartsCount,
            lastUpdateMillis
        )
        if (!handled) {
            val userId = UserStateHolder.currentId().takeIf { it.isNotEmpty() } ?: return
            // RtsProcessing.scope (отменяется в deInit) — см. reloadTickets в TicketRtsMessage:
            // одноразовый скоуп переживал logout и дописывал тикеты прошлого пользователя.
            RtsProcessing.scope.launch {
                loadTickets(userId)
            }
        }
    }

    companion object {
        /**
         * Часть-«ссылка» из кадра создания тикета: копия выбранного оператором сообщения
         * (body_json.is_ticket_ref=true, parts[].conversation указывает на ИСХОДНЫЙ диалог).
         * В ленты не вливается.
         */
        internal fun isTicketRefPart(message: MessageData): Boolean {
            val bodyJson = message.bodyJson ?: return false
            if (!bodyJson.isJsonObject) return false
            val ref = bodyJson.asJsonObject.get(F.IS_TICKET_REF) ?: return false
            return !ref.isJsonNull && ref.isJsonPrimitive && ref.asJsonPrimitive.isBoolean && ref.asBoolean
        }
    }

    private fun createAndSaveMessage(message: MessageData, isTicketConversation: Boolean = false) {
        // Трассировка обработки входящей части диалога: метаданные сообщения и предикаты гейта
        // (по ним видно, добавляется ли сообщение в чат или отсеивается). Без тела (PII) — release-safe.
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag) {
            "parts_batch part: id=${message.id} conv=${message.conversation} dir=${message.direction} " +
                "sentVia=${message.sentVia} read=${message.read} bodyJsonNull=${message.bodyJson == null} " +
                "actions=${message.actions?.size ?: 0} convClosed=$conversationClosed " +
                "fromAdmin=${fromAdminToUser(message)} inputBot=${isInputBotAction(message)} buttonsBot=${isButtonsBotAction(message)}"
        }
        if ((message.read == null || !message.read)
            && (!conversationClosed)
        ) {
            if (fromAdminToUser(message) || isInputBotAction(message) || isButtonsBotAction(message)) {
                // Тикет-диалоги не участвуют в обычном счётчике непрочитанных (их ведёт
                // TicketsRepository)
                if (!isTicketConversation) {
                    // Апдейт непрочитанных — через UserStateHolder (CAR-77172, этап 3).
                    if (message.conversation != conversationsRepository.getOpenedConversationId() && Flags.NEW_CONVERSATION_ID_ARG != conversationsRepository.getOpenedConversationId()) {
                        UserStateHolder.markConversationUnread(
                            CarrotInternal.getLibComponent().contextSdk, message.conversation,
                        )
                    }
                }
                // Первую ветку routing-бота в живой сессии рисует шаблон chooseRoutingBot —
                // её серверные части (is_first_branch) в репозиторий не вливаем, иначе дубль.
                if (message.bodyJson != null && message.bodyJson.isJsonObject) {
                    if (!message.isFirstBranchPart) {
                        messagesRepository.addWssMessage(message)
                        logMessage("RTS: add message to repository", message)
                    } else {
                        logMessage("RTS: skip first branch part of the bot (drawn from template)", message)
                    }
                }

                messagesRepository.updateMessage(message)
                logMessage("RTS: update message to repository.", message)
            } else {
                // Отложенное обновление: 2с (как раньше Single.delay), затем на главном потоке.
                Handler(Looper.getMainLooper()).postDelayed({
                    messagesRepository.updateMessage(message)
                    logMessage("RTS: update message to repository.", message)
                }, 2000)
            }
        }

        var directionMessage = DirectionMessage.USER_TO_ADMIN
        if (ResponseFields.ADMIN_2_USER == message.direction) {
            directionMessage = DirectionMessage.ADMIN_TO_USER
        }

        var messageType = IncomingMessage.MessageType.TEXT
        if (message.attachments != null && message.attachments.size > 0) {
            messageType = IncomingMessage.MessageType.ATTACHMENT
        }

        // Обычная нотификация ведёт в диалог как в обычный чат — для тикетов не шлём
        // (как веб: у вкладки «Тикеты» свой бейдж)
        if (!isTicketConversation) {
            val incomingMessage = IncomingMessage(
                IncomingMessage.IncomingMessageSourceType.RTS,
                message.id,
                message.conversation,
                message.body,
                directionMessage,
                messageType
            )
            NotificationsAllHelper.getInstance().pushMessage(incomingMessage)
        }
    }

    private fun isInputBotAction(message: MessageData): Boolean {
        if ("message_chat_bot" == message.sentVia && message.actions != null && message.actions.size > 0) {
            val firstAction: ActionMessage = message.actions[0]
            return "property_field" == firstAction.type
        }
        return false
    }

    private fun isButtonsBotAction(message: MessageData): Boolean {
        if ("message_chat_bot" == message.sentVia && message.actions != null && message.actions.size > 0) {
            val firstAction: ActionMessage = message.actions[0]
            return "button" == firstAction.type || "meet" == firstAction.type
        }
        return false
    }

    private fun fromAdminToUser(message: MessageData): Boolean {
        return message.direction != null
                && ResponseFields.ADMIN_2_USER == message.direction.lowercase()
    }

    private fun logMessage(title: String, message: MessageData) {
        val params = HashMap<String, Any>()
        params["log_message_id"] = message.id
        params["log_conversation_id"] = message.conversation
        params["log_body"] = message.body

        LogToElk.getInstance().write(
            Carrot.getAppId(),
            title,
            MessageToElkType.RTS_MESSAGE_ADDED_TO_REPO,
            params
        )
    }
}