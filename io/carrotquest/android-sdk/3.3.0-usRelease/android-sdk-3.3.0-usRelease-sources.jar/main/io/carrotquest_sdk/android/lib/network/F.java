package io.carrotquest_sdk.android.lib.network;

public class F {
    public static final String USER = "user";
    public static final String ID = "id";
    public static final String CHANNEL = "channel";
    public static final String RANDOM_ID = "random_id";
    public static final String REPLY_TYPE = "reply_type";
    public static final String DIRECTION = "direction";
    public static final String NONCE = "_nonce";
    public static final String USER_AGENT = "user_agent";
    public static final String ID_AS_STRING = "id_as_string";
    public static final String MERGE_RESULT = "merge_result";
    public static final String RESULT = "result";
    public static final String DATA = "data";
    public static final String META = "meta";
    public static final String APP = "app";
    public static final String META_DATA = "meta_data";
    public static final String KB_LINK = "kb_link";
    public static final String FROM = "from";
    public static final String STATUS = "status";
    public static final String NEXT_ARTER = "next_after";
    public static final String NEXT_BEFORE_POSITION = "next_before_position";
    public static final String AUTH_TOKEN = "auth_token";
    public static final String DEVICE_GUID = "device_guid";
    public static final String REALTIME_SERVICES = "realtime_services";
    public static final String HOSTS = "hosts";
    public static final String CHANNELS = "channels";
    public static final String CLIKCKED = "clicked";
    public static final String UNSUBSCRIBED = "unsubscribed";
    public static final String CLOSED = "closed";
    public static final String MESSAGE = "message";
    public static final String PART_LAST = "part_last";
    public static final String PARTS_COUNT = "parts_count";
    public static final String ASSIGNEE = "assignee";
    public static final String UNREAD_PARTS_COUNT = "unread_parts_count";
    public static final String USER_UNREAD_COUNT = "user_unread_count";
    public static final String LAST_ADMIN = "last_admin";
    public static final String LAST_SENDER = "last_sender";
    public static final String LAST_UPDATE = "last_update";
    public static final String TAGS = "tags";
    public static final String ERROR_MESSAGE = "error_message";
    public static final String TIME = "time";
    public static final String TAG = "tag";
    public static final String ATTACHMENTS = "attachments";
    public static final String ATTACHMENT = "attachment";
    public static final String VOTE = "vote";
    public static final String COMMENT = "comment";
    public static final String LOADING = "loading";
    public static final String REPLIED = "replied";
    public static final String NAME = "name";
    public static final String STATUS_OPERATORS = "status_operators";
    public static final String AVATAR = "avatar";
    public static final String FILENAME = "filename";
    public static final String MIME_TYPE = "mime_type";
    public static final String SIZE = "size";
    public static final String URL = "url";
    public static final String CREATED = "created";
    public static final String ID_ASSIGN_PART = "id_assign_part";
    public static final String SETTINGS = "settings";
    public static final String NEXT_BRANCH_ID = "next_branch_id";
    public static final String ACTIONS = "actions";
    public static final String PLACEHOLDER = "placeholder";

    public static final String CONVERSATION = "conversation";
    public static final String CONVERSATION_ID = "conversation_id";
    public static final String BODY = "body";
    public static final String BODY_JSON = "body_json";
    public static final String IS_FIRST_BRANCH = "is_first_branch";
    public static final String CLICK_ACTION = "click_action";

    public static final String HAS_CONVERSATIONS = "has_conversations";
    public static final String IS_BANNED = "is_banned";
    public static final String CONVERSATIONS_UNREAD = "conversations_unread";
    public static final String TICKETS_UNREAD = "tickets_unread";

    // Тикеты
    public static final String SHORT_ID = "short_id";
    public static final String DUE_DATE = "due_date";
    public static final String COLOR = "color";
    public static final String ORDER = "order";
    public static final String IS_INITIAL = "is_initial";
    public static final String IS_FINAL = "is_final";
    public static final String TICKET = "ticket";
    public static final String EVENT_TYPE = "event_type";
    public static final String IS_TICKET_REF = "is_ticket_ref";
    public static final String CLOSED_AT = "closed_at";
    public static final String IS_REOPENABLE = "is_reopenable";

    public static final String READ = "read";
    public static final String TYPE = "type";

    public static final String VALUE = "value";
    public static final String SENT_VIA = "sent_via";
    public static final String FIRST = "first";
    public static final String CONVERSATION_TYPE = "conversation_type";

    public static final String KIND = "kind";
    public static final String COMPARISON = "comparison";
    public static final String SDK_PAGE = "sdk_page";
    public static final String REMOVED = "removed";

    public static final String TITLE = "title";

    public static final String UNDEFINED = "undefined";

    public static final String MESSENGER_ICON_VK_SHOW = "messenger_icon_vk_show";
    public static final String MESSENGER_ICON_VK_TEXT = "messenger_icon_vk_text";

    public static final String MESSENGER_ICON_VIBER_SHOW = "messenger_icon_viber_show";
    public static final String MESSENGER_ICON_VIBER_TEXT = "messenger_icon_viber_text";

    public static final String MESSENGER_ICON_FACEBOOK_SHOW = "messenger_icon_facebook_show";
    public static final String MESSENGER_ICON_FACEBOOK_TEXT = "messenger_icon_facebook_text";

    public static final String MESSENGER_ICON_TELEGRAM_SHOW = "messenger_icon_telegram_show";
    public static final String MESSENGER_ICON_TELEGRAM_TEXT = "messenger_icon_telegram_text";

    public static final String MESSENGER_ICON_INSTAGRAM_SHOW = "messenger_icon_instagram_show";
    public static final String MESSENGER_ICON_INSTAGRAM_TEXT = "messenger_icon_instagram_text";

    public static final String MESSENGER_ICON_WHATSAPP_SHOW = "messenger_icon_whatsapp_show";
    public static final String MESSENGER_ICON_WHATSAPP_TEXT = "messenger_icon_whatsapp_text";

    public static final String MESSENGER_COLLAPSED_COLOR = "messenger_collapsed_color";
    public static final String MESSENGER_WELCOME_MESSAGE = "messenger_welcome_message";
    public static final String MESSENGER_AVATAR = "messenger_avatar";
    public static final String MESSENGER_SHOW_POWERED_BY = "messenger_show_powered_by";
    public static final String MESSENGER_SHOW_KB_LINK_IN_WELCOME_MESSAGE = "messenger_show_kb_link_in_welcome_message";

    public static final String MESSENGER_OFFLINE_MESSAGE = "messenger_offline_message";
    public static final String MESSENGER_ONLINE_MESSAGE = "messenger_online_message";
    public static final String MESSENGER_SHOW_OFFLINE_MESSAGE = "messenger_show_offline_message";

    public static final String MESSENGER_THEME = "messenger_theme";
    public static final String MESSENGER_NAME = "messenger_name";
    public static final String MESSENGER_PATTERN = "messenger_pattern";
    public static final String MESSENGER_ENABLE_NEW_CONVERSATION_BUTTON = "messenger_enable_new_conversation_button";
    public static final String MESSENGER_ENABLE_AUDIO_MESSAGES = "messenger_enable_audio_messages";

    public static final String ACTIVE = "active";
    public static final String ADMINS = "admins";

    public static final String EXPIRATION_TIME = "expiration_time";

    public static final String ONLINE_USER = "online";
    public static final String OFFLINE_IDLE_USER = "idle";


    public static final String EMAIL$ = "$email";
    public static final String PHONE$ = "$phone";
    public static final String NAME$ = "$name";

    public static final String RECIPIENT_TYPE = "recipient_type";
    public static final String ALLOW_USER_REPLIES = "allow_user_replies";

    public static final String DURATION = "duration";

    public static final String FOUND = "found";
    public static final String MESSAGE_SENDER = "message_sender";
    public static final String CHAT_BOT = "chat_bot";
    public static final String PARTS = "parts";
    public static final String START_BRUNCH = "start_branch";

    public static final String BLOCKED = "blocked";

    public static final String LOCALE = "locale";

    public static final String ACCESS = "access";
    public static final String REFRESH = "refresh";

    public static final String REQUEST_USER_ID = "request_user_id";
    public static final String REQUEST_APP_ID = "request_app_id";

    public static final String REPLIED_TO = "replied_to";
    public static final String PARTIAL_TEXT = "partial_text";
    public static final String EDITED = "edited";

}
