package io.carrotquest_sdk.android.presentation.tickets

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.SdkColors

/**
 * Пилюля «Дополнить тикет» внизу ленты тикета (вместо инпута). Видна только у
 * нефинальных тикетов до активации режима ввода. Светлая тема — акцент приложения,
 * тёмная — белый на #595959 (веб-слоты --supplement-button-*).
 */
@Composable
internal fun SupplementTicketButton(
    accentColor: Color,
    isDark: Boolean,
    onClick: () -> Unit
) {
    // Слоты общие с кнопками карточки «Ваш вопрос решён?» — пилюли должны выглядеть одинаково
    val contentColor = SdkColors.ticketPillContent(isDark, accentColor)
    val borderColor = SdkColors.ticketPillBorder(isDark, accentColor)

    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = contentColor)
    ) {
        Text(
            text = stringResource(R.string.ticket_supplement),
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
