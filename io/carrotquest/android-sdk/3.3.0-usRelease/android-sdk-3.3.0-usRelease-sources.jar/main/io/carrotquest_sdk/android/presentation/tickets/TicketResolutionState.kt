package io.carrotquest_sdk.android.presentation.tickets

import java.util.concurrent.ConcurrentHashMap

/**
 * Состояние карточки «Ваш вопрос решён?» закрытого переоткрываемого тикета (CAR-76310).
 *
 * Ответ пользователя привязан к ЦИКЛУ закрытия — ключу (ticketId, closedAtMillis): повторное
 * закрытие оператором даёт другой closedAt, прошлый ответ перестаёт совпадать, и вопрос
 * показывается снова — отдельного сброса не нужно (паттерн вебовского
 * ticket-resolution-prompt/model.js). Память процесса переживает уход с экрана тикета и
 * возврат (composable размонтируется вместе со своим состоянием); персиста нет — как весь
 * кэш тикетов (веб хранит в sessionStorage, наш аналог сессии — процесс).
 */
internal object TicketResolutionState {

    enum class Answer { RESOLVED, NOT_RESOLVED }

    private data class Stored(val closedAtMillis: Long?, val answer: Answer)

    private val answers = ConcurrentHashMap<String, Stored>()

    fun getAnswer(ticketId: String, closedAtMillis: Long?): Answer? {
        val stored = answers[ticketId] ?: return null
        return if (stored.closedAtMillis == closedAtMillis) stored.answer else null
    }

    fun setAnswer(ticketId: String, closedAtMillis: Long?, answer: Answer) {
        answers[ticketId] = Stored(closedAtMillis, answer)
    }

    /** Сброс при logout/смене пользователя (вместе с TicketsRepository.reset). */
    fun reset() {
        answers.clear()
    }
}

/** Видимое состояние карточки резолюции. */
internal enum class TicketResolutionUiState { QUESTION, PROMPT, HIDDEN }

/**
 * Чистая функция состояния карточки: ответа нет → вопрос; «Не решён» → подсказка
 * «напишите сообщение»; «Решён» → скрыта. Покрыта TicketResolutionStateTest.
 */
internal fun ticketResolutionUiState(answer: TicketResolutionState.Answer?): TicketResolutionUiState =
    when (answer) {
        null -> TicketResolutionUiState.QUESTION
        TicketResolutionState.Answer.NOT_RESOLVED -> TicketResolutionUiState.PROMPT
        TicketResolutionState.Answer.RESOLVED -> TicketResolutionUiState.HIDDEN
    }
