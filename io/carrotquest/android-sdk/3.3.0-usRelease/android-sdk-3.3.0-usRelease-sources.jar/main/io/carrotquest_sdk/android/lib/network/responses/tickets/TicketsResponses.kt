package io.carrotquest_sdk.android.lib.network.responses.tickets

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta

/** Ответ GET /users/{id}/tickets — список тикетов в стандартном конверте {meta, data}. */
@Keep
data class TicketsResponse(
    @SerializedName(F.META) val meta: Meta? = null,
    @SerializedName(F.DATA) val data: List<TicketData>? = null
)

/** Ответ GET /users/{id}/tickets/{ticketId} — деталь тикета. 404 = TicketNotFound (чужой/несуществующий id неразличимы). */
@Keep
data class TicketResponse(
    @SerializedName(F.META) val meta: Meta? = null,
    @SerializedName(F.DATA) val data: TicketData? = null
)
