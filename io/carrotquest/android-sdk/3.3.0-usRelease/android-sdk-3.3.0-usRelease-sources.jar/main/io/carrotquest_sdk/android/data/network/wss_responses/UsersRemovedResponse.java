package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

import io.carrotquest_sdk.android.data.user.UserStateHolder;

public class UsersRemovedResponse implements IRtsMessage {

    @SerializedName("ids")
    @Expose
    private ArrayList<String> ids = null;

    public ArrayList<String> getIds() {
        return ids;
    }

    public void setIds(ArrayList<String> ids) {
        this.ids = ids;
    }


    @Override
    public void process() {
        // Смена холдера + слушатели «юзер удалён» (BaseSdkActivity) — CAR-77172, этап 3.
        boolean currentUserRemoved = UserStateHolder.INSTANCE.removeUsers(ids);
        if (currentUserRemoved) {
            // Юзер удалён на сервере: чистим и ПЕРСИСТ идентичности (CAR-77172, этап 4).
            // Раньше prefs (креды, authed-ключи) оставались, а deInit случался только если
            // был открыт SDK-экран — следующий setup() восстанавливал удалённого юзера.
            android.content.Context context =
                    io.carrotquest_sdk.android.core.main.CarrotInternal.getLibComponent().getContextSdk();
            io.carrotquest_sdk.android.data.user.ApplyIdentityUseCaseKt.wipePersistedIdentity(context);
            io.carrotquest_sdk.android.data.repositories.SettingsRepository.Companion.getInstance().deInit();
        }
    }
}
