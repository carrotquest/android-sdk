package io.carrotquest_sdk.android.presentation.mvp.popup

import android.os.SystemClock
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger

/**
 * Тайминг-трассировка показа поп-апа: единый t0 на показ, каждая метка пишет в лог
 * дельту от предыдущего этапа и от старта. Нужна, чтобы понять, какой этап цепочки
 * show → settings → loadUrl → page finished → widget ready → initPopup → popUpIsReady
 * съедает время на медленной сети/устройстве.
 *
 * Логи уровня DEBUG (видны после Carrot.setLogLevel(DEBUG)); в проде по умолчанию молчит.
 * Показы поп-апов не пересекаются (PopupAlertDialog.isShowing), поэтому одного t0 достаточно.
 */
internal object PopUpLoadTrace {
    private const val TAG = "PopUpLoadTrace"

    @Volatile
    private var t0 = 0L

    @Volatile
    private var last = 0L

    /** Начало показа поп-апа (создание диалога). */
    fun start(popUpId: String) {
        t0 = SystemClock.elapsedRealtime()
        last = t0
        log("popup show started, id=$popUpId")
    }

    /** Метка этапа: дельта от предыдущей метки и суммарное время от старта. */
    fun mark(stage: String) {
        if (t0 == 0L) return
        val now = SystemClock.elapsedRealtime()
        val sinceLast = now - last
        val total = now - t0
        last = now
        log("$stage: +${sinceLast}ms (total ${total}ms)")
    }

    private fun log(message: String) {
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.LIFECYCLE, TAG, message)
    }
}
