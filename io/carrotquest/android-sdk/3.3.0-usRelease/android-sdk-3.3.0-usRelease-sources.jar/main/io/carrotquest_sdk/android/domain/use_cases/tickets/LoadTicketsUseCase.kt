package io.carrotquest_sdk.android.domain.use_cases.tickets

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.repositories.TicketsRepository
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

private const val TAG = "LoadTicketsUseCase"

/** Чем закончилась загрузка списка — вкладке «Тикеты» нужно отличать сбой от пустого списка. */
enum class TicketsLoadOutcome {
    /** Список получен и сохранён (в т.ч. честно пустой). */
    LOADED,

    /** Сетевой/парсинговый сбой — кэш не тронут, у UI есть повод показать ошибку с ретраем. */
    FAILED,

    /** Загрузка неприменима: нет userId (фича ещё не поднялась) или сессия сменилась под ногами. */
    SKIPPED,
}

// Коалесинг конкурентных перезагрузок (RTS created-событие, batch-кадр с неизвестным
// диалогом, резюме экрана, открытие вкладки): вызовы сериализуются мьютексом, а счётчик
// запросов позволяет «опоздавшим» переиспользовать загрузку, СТАРТОВАВШУЮ ПОСЛЕ их запроса.
// Прежний AtomicBoolean-guard просто выбрасывал второй вызов — перезагрузка, запрошенная во
// время полёта чужого запроса, терялась (данные снапшота могли быть сняты ДО события).
private val loadMutex = Mutex()
private val requestCounter = AtomicInteger(0)
@Volatile private var completedRequestMark = 0

/**
 * Перезагрузка списка с резолвом userId: из настроек (гарантированы к моменту
 * ticketsEnabled=true; UserRepository при холодном старте может быть ещё пуст),
 * fallback — UserRepository. Нет userId — фича ещё не поднялась, честный SKIPPED.
 */
suspend fun refreshTickets(): TicketsLoadOutcome {
    val userId = SettingsRepository.getInstance().getSettingsObject()?.userId
        ?.takeIf { it.isNotBlank() }
        ?: io.carrotquest_sdk.android.data.user.UserStateHolder.currentId().takeIf { it.isNotEmpty() }
        ?: return TicketsLoadOutcome.SKIPPED
    return loadTickets(userId)
}

/**
 * Загрузка списка тикетов в TicketsRepository. Ошибка не фатальна (фича вторичная):
 * лог + кэш не трогаем; исход отдаём вызывающему — вкладка отличает сбой от пустого списка.
 */
suspend fun loadTickets(userId: String): TicketsLoadOutcome = withContext(Dispatchers.IO) {
    if (userId.isBlank()) return@withContext TicketsLoadOutcome.SKIPPED

    val myMark = requestCounter.incrementAndGet()
    loadMutex.withLock {
        // Загрузка, стартовавшая ПОСЛЕ нашего запроса, уже прошла (мы стояли за ней в очереди) —
        // её снапшот покрывает и наш триггер, второй поход в сеть не нужен
        if (completedRequestMark >= myMark) return@withContext TicketsLoadOutcome.LOADED

        // Все запросы, накопившиеся к этому моменту, удовлетворяются одной загрузкой
        val satisfiesUpTo = requestCounter.get()
        val repo = TicketsRepository.getInstance()
        val epoch = repo.sessionEpoch

        val outcome = try {
            val response = CarrotInternal.getService().carrotLib.getTicketsSuspend(userId)
            when {
                response.meta == null -> TicketsLoadOutcome.FAILED
                // Сессия сменилась, пока ответ летел (logout/новый пользователь): список и бейдж
                // прошлого пользователя не воскрешаем поверх сброшенного состояния
                repo.sessionEpoch != epoch -> TicketsLoadOutcome.SKIPPED
                else -> {
                    repo.saveTickets(response.data?.mapNotNull { it.toTicketEntity() } ?: emptyList())
                    TicketsLoadOutcome.LOADED
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, e)
            TicketsLoadOutcome.FAILED
        }
        if (outcome == TicketsLoadOutcome.LOADED) {
            completedRequestMark = satisfiesUpTo
        }
        outcome
    }
}
