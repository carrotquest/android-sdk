package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Stable
sealed class ConversationListItem {
    @Immutable
    data class Single(val conversation: ConversationUiItem) : ConversationListItem()

    @Immutable
    data class Group(
        // Ключ группировки — admin id, а без него имя (у ботов/триггеров id нет,
        // они группируются по имени бота/приложения; тёзки-операторы различаются по id)
        val groupKey: String,
        val conversations: List<ConversationUiItem>,   // первый — самый новый
        val isExpanded: Boolean
    ) : ConversationListItem()
}
