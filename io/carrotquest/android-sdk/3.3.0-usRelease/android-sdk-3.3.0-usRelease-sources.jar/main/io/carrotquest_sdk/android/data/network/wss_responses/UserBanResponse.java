package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.data.user.UserStateHolder;

public class UserBanResponse implements IRtsMessage {

    @SerializedName("user_id")
    @Expose
    private String userId;

    @SerializedName("value")
    @Expose
    private boolean isBan;

    @Override
    public void process() {
        if(isBan) {
            UserStateHolder.INSTANCE.banUser(userId);
        }
        else {
            UserStateHolder.INSTANCE.unBanUser(userId);
        }
    }
}
