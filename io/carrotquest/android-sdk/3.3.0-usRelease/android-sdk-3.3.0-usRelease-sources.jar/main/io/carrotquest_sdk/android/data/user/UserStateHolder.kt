package io.carrotquest_sdk.android.data.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

internal object UserStateHolder {

    private val _state: MutableStateFlow<UserEntity?> = MutableStateFlow(null)
    val state: StateFlow<UserEntity?> = _state.asStateFlow()

    // Слушатели «текущий юзер удалён» (BaseSdkActivity: закрыть экран + deInit).
    // Жили в old/UserRepository — переехали сюда вместе с removeUsers (CAR-77172, этап 3).
    private val removeUserListeners = ArrayList<UserRemovedListener>()

    fun update(user: UserEntity?) {
        _state.value = user
    }

    fun current(): UserEntity? = _state.value

    fun currentId(): String = _state.value?.id ?: ""

    fun currentToken(): String = _state.value?.token ?: ""

    fun banUser(userId: String?) {
        if (userId.isNullOrEmpty()) return
        val current = _state.value ?: return
        if (current.id == userId) {
            _state.value = current.copy(isBanned = true)
        }
    }

    fun unBanUser(userId: String?) {
        if (userId.isNullOrEmpty()) return
        val current = _state.value ?: return
        if (current.id == userId) {
            _state.value = current.copy(isBanned = false)
        }
    }

    /** @return true, если удалён именно текущий юзер (state обнулён, слушатели оповещены). */
    fun removeUsers(removedUserIds: Collection<String>?): Boolean {
        if (removedUserIds.isNullOrEmpty()) return false
        val current = _state.value ?: return false
        if (removedUserIds.contains(current.id)) {
            _state.value = null
            // Копия: слушатель (BaseSdkActivity) в onUserRemoved дёргает finish()/deInit().
            // Список чистится после — семантика old/UserRepository.removeUsers.
            for (listener in ArrayList(removeUserListeners)) {
                listener.onUserRemoved(current)
            }
            removeUserListeners.clear()
            return true
        }
        return false
    }

    /** Добавить слушателя события удаления юзера. */
    fun addRemoveUserObserver(listener: UserRemovedListener) {
        removeUserListeners.add(listener)
    }

    /** Удалить слушателя события удаления юзера. */
    fun removeRemoveUserObserver(listener: UserRemovedListener) {
        removeUserListeners.remove(listener)
    }

    /**
     * Пришло сообщение в незакрытую и не открытую сейчас беседу: беседа уходит в конец списка
     * непрочитанных, у юзера появляются диалоги. Раньше этот апдейт шёл через
     * old/UserRepository.saveUser из двух RTS-хендлеров.
     */
    fun markConversationUnread(context: Context?, conversationId: String) {
        val current = _state.value ?: return
        val unread = current.conversationsUnread.toMutableList()
        unread.remove(conversationId)
        unread.add(conversationId)
        _state.value = current.copy(hasConversations = true, conversationsUnread = unread)
        if (context != null) {
            SharedPreferencesLib.saveStringSet(
                context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS, HashSet(unread),
            )
        }
    }

    fun clear() {
        _state.value = null
    }

    fun restoreFromPrefs(context: Context) {
        val token = SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_TOKEN)
        val id = SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_USER_ID)
        if (token.isEmpty() && id.isEmpty()) return
        _state.value = UserEntity(
            id = id,
            token = token,
            isBanned = SharedPreferencesLib.getBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED),
            conversationsUnread = SharedPreferencesLib.getPreferenceArray(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS)
        )
    }
}
