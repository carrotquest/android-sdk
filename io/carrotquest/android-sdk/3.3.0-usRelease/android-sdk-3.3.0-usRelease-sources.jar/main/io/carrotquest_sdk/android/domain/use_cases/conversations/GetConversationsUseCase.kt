package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.Callback

import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.isPopUpConversationType
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.recipientTypeIsRight
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Тег логирования (используется и внешними потребителями, напр. DialogPresenter).
const val TAG = "Conversations"

// Observable-ext getConversations/getPopupConversations/getUnreadConversations/getNotPopup* удалены —
// все потребители на чистые фильтры/Flow ниже (ветка remove_rx).

// --- Чистые фильтры (без Rx) + Flow/snapshot для Kotlin-потребителей ---

internal fun List<DataConversation>.validConversations(): List<DataConversation> =
    filter { it.id != null }.distinctBy { it.id }.filter { it.recipientType.recipientTypeIsRight() }

internal fun List<DataConversation>.notPopup(): List<DataConversation> =
    filter { it.id != null && it.type != null }

internal fun List<DataConversation>.notPopupHard(): List<DataConversation> =
    filter {
        it.id != null && it.type != null &&
                (it.type == ConversationType.CHAT.stringValue ||
                        it.type == ConversationType.ROUTING_BOT.stringValue ||
                        it.type == ConversationType.LEAD_BOT.stringValue) &&
                it.recipientType.recipientTypeIsRight()
    }

// Тикет-диалоги исключены: они лежат в общем кэше (пайплайн открытого тикета использует его как
// кэш беседы), но их непрочитанное ведёт TicketsRepository и показывает бейдж вкладки «Тикеты».
// Без фильтра здесь они утекали в публичный getUnreadConversations/setUnreadConversationsCallback
// (хост-приложение видело завышенный счётчик) и в бейдж FloatingButton.
internal fun List<DataConversation>.unread(): List<DataConversation> =
    filter {
        it.id != null && it.unreadPartsCount > 0 && it.recipientType.recipientTypeIsRight() &&
                !it.isTicketConversation
    }

internal fun List<DataConversation>.popup(): List<DataConversation> =
    filter {
        it.id != null && it.type == ConversationType.BLOCK_POPUP_SMALL.stringValue &&
                it.recipientType.recipientTypeIsRight()
    }

/** Continuous-поток валидных бесед (как getConversations() Observable, но без Rx). */
fun conversationsFlow(): Flow<List<DataConversation>> =
    ConversationsRepository.getInstance().conversationsChangesFlow().map { it.validConversations() }

/** Снимок валидных бесед (как getConversations().awaitFirstOrNull()). */
fun currentConversations(): List<DataConversation> =
    ConversationsRepository.getInstance().getConversationsSync().validConversations()

/**
 * Самый свежий диалог по lastUpdate. Сравнение строго ЧИСЛОВОЕ: lastUpdate приходит строкой,
 * и строковая сортировка даёт неверный порядок ("999999999" > "1000000000"). Единственная точка
 * выбора «самого свежего» — обе публичные функции ниже обязаны идти через неё.
 */
internal fun List<DataConversation>.freshestByLastUpdate(): DataConversation? =
    maxByOrNull { it.lastUpdate?.toLongOrNull() ?: 0L }

/**
 * Последний диалог, который можно открыть как чат: самый свежий по lastUpdate, ИСКЛЮЧАЯ поп-ап-беседы
 * (их нельзя показать в теле диалога — было бы пусто, баг #11). null — подходящих диалогов нет.
 *
 * Этим выбором SDK открывает чат при старте контейнера (SdkContainerActivity.proceedAfterInit) и по
 * кнопке «Написать», когда апп запретил создавать новые диалоги (messenger_enable_new_conversation_button).
 *
 * NB: отличается от [getLastConversation] фильтром — здесь чёрный список поп-ап типов (незнакомый
 * тип проходит), там белый список открываемых типов + recipientType. Разница осознанная, свежесть
 * при этом считается одинаково — через [freshestByLastUpdate].
 */
fun lastDisplayableConversationId(): String? {
    val all = ConversationsRepository.getInstance().getConversationsSync()
    val chosen = all
        // Тикет-диалоги в кэше есть (пайплайн открытого тикета использует его как кэш беседы),
        // но авто-открывать их как обычный чат нельзя — инпут/шапка были бы не тикетные
        .filter {
            it.id != null && it.type != null && !isPopUpConversationType(it.type) &&
                !it.isTicketConversation
        }
        .freshestByLastUpdate()
    // Диагностика: этим выбором открывается чат, а фильтр здесь ШИРЕ, чем validConversations()
    // (нет recipientTypeIsRight). Логируем recipientType, чтобы по логам было видно, когда SDK
    // открыл диалог, который остальные потоки считают «не своим» (симптом — conversationsFlow
    // emit size=0 found=false при непустом репозитории).
    Log.d(TAG, "lastDisplayableConversationId: total=${all.size} chosen=${chosen?.id} " +
            "type=${chosen?.type} recipientType=${chosen?.recipientType} " +
            "recipientTypeIsRight=${chosen?.recipientType?.recipientTypeIsRight()}")
    return chosen?.id
}

/** Последний (по lastUpdate, численно) не-попап диалог; null если нет (как Observable-ext getLastConversation). */
fun getLastConversation(): DataConversation? =
    ConversationsRepository.getInstance().getConversationsSync()
        .validConversations()
        .notPopupHard()
        .freshestByLastUpdate()

/**
 * Непрерывно уведомляет [callback] id-шниками непрочитанных диалогов при изменении списка
 * (раньше — getUnreadConversations(getConversations()).subscribe в CarrotSDK). Возвращает
 * [Cancellable] для отписки (на deInit). Для Java-вызывателя CarrotSDK.
 */
fun observeUnreadConversationIds(callback: Callback<List<String>>): Cancellable {
    val scope = sdkScope(SdkDispatchers.io)
    scope.launch {
        conversationsFlow().collect { conversations ->
            val ids = conversations.unread().mapNotNull { it.id }
            // Бросок в клиентском колбэке не должен убивать подписку (иначе непрочитанные
            // перестают приходить до конца сессии). Глотаем с логом.
            withContext(SdkDispatchers.main) {
                try {
                    callback.onResponse(ids)
                } catch (t: Throwable) {
                    Log.e(TAG, t)
                }
            }
        }
    }
    return Cancellable { scope.cancel() }
}
