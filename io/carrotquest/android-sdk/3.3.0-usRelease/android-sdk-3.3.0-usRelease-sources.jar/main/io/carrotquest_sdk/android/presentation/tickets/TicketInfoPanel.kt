package io.carrotquest_sdk.android.presentation.tickets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.domain.entities.TicketEntity
import io.carrotquest_sdk.android.domain.entities.TicketStage
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

/**
 * Инфо-панель тикета над лентой: статус (bold, цвет стадии) + время в стадии (тикер 60с,
 * только нефинальные), #short_id справа, прогресс-бар из 3 сегментов, строка дедлайна.
 * Дизайн — Figma «Тикет» 4929:14233 (+инфо-панели 5295:*).
 */
@Composable
internal fun TicketInfoPanel(
    ticket: TicketEntity,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val stage = ticket.status.stage

    // Тикер «времени в работе»: раз в 60с; LaunchedEffect отменяется при выходе из композиции
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    if (stage != TicketStage.FINAL) {
        LaunchedEffect(Unit) {
            while (true) {
                delay(60_000L)
                nowMs = System.currentTimeMillis()
            }
        }
    }

    // CAR-76566: имя статуса с бэка как есть; «В работе» — только fallback пустого intermediate.
    val inProgressLabel = stringResource(R.string.ticket_in_progress)
    val statusLabel = ticketStatusLabel(ticket.status.name, stage, inProgressLabel)
    // Подпись статуса — нейтральным цветом (как title, по дизайну). Цвет стадии/кастомный
    // остаётся только на прогресс-баре (для intermediate — кастомный цвет с бэка).
    val customArgb = ticketCustomColorArgb(stage, ticket.status.colorHex)
    val stageColor = customArgb?.let { Color(it) } ?: SdkColors.ticketStageColor(stage, isDark)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SdkColors.pageBackground(isDark))
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Левая группа занимает всё до #short_id; внутри неё гибкое — только имя статуса:
            // длинное кастомное имя ellipsis'ится, время и #short_id не выдавливаются
            // (аналог веба: name flex:1+min-width:0, соседи flex-shrink:0)
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = statusLabel,
                    color = SdkColors.title(isDark),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (stage != TicketStage.FINAL && ticket.createdMillis != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    val elapsed = ticketElapsed(nowMs - ticket.createdMillis)
                    val pluralRes = when (elapsed.unit) {
                        TicketTimeUnit.MINUTES -> R.plurals.ticket_time_minutes
                        TicketTimeUnit.HOURS -> R.plurals.ticket_time_hours
                        TicketTimeUnit.DAYS -> R.plurals.ticket_time_days
                        TicketTimeUnit.MONTHS -> R.plurals.ticket_time_months
                    }
                    Text(
                        // pluralStringResource, а не context.resources: читает LocalConfiguration,
                        // поэтому строка пересобирается при смене локали/шрифта без пересоздания
                        // экрана (единый приём с MessageBubble/MessageInput)
                        text = pluralStringResource(pluralRes, elapsed.count, elapsed.count),
                        color = SdkColors.secondaryText(isDark),
                        fontSize = 14.sp,
                        maxLines = 1
                    )
                }
            }
            if (ticket.shortId != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "#${ticket.shortId}",
                    color = SdkColors.sectionLabel,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        TicketProgressBar(stage = stage, fillColor = stageColor, isDark = isDark)

        if (isDueDateVisible(stage, ticket.dueDateMillis)) {
            Spacer(modifier = Modifier.height(10.dp))
            val dueDateText = remember(ticket.dueDateMillis) {
                SimpleDateFormat("d MMMM", Locale.getDefault()).format(Date(ticket.dueDateMillis!!))
            }
            Text(
                text = stringResource(R.string.ticket_due_date, dueDateText),
                color = SdkColors.secondaryText(isDark),
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(thickness = 1.dp, color = SdkColors.divider(isDark))
    }
}

@Composable
private fun TicketProgressBar(stage: TicketStage, fillColor: Color, isDark: Boolean) {
    // fillColor уже учитывает кастомный цвет intermediate (CAR-76566); передаётся из панели
    val filled = ticketProgressSegments(stage)
    val emptyColor = SdkColors.ticketEmptyBar(isDark)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        repeat(3) { index ->
            Spacer(
                modifier = Modifier
                    .weight(1f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (index < filled) fillColor else emptyColor)
            )
        }
    }
}
