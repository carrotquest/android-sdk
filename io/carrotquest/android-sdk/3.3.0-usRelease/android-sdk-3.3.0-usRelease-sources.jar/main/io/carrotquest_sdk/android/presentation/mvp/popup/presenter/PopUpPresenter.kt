package io.carrotquest_sdk.android.presentation.mvp.popup.presenter

import io.carrotquest_sdk.android.Callback

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.data.network.js_interface.pop_up.IJSPopUpPresenter
import io.carrotquest_sdk.android.domain.use_cases.agreements.TrackContacts
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowDataProcessingUseCase
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowTrackContactsUseCase
import io.carrotquest_sdk.android.data.repositories.PopupRepository
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettingsSuspend
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.models.UserProperty
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.popup.PopUpLoadTrace
import io.carrotquest_sdk.android.presentation.mvp.popup.view.IPopUp
import io.carrotquest_sdk.android.presentation.mvp.utils.jsonUtils.prepareJsonSettings
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.net.URLDecoder

class PopUpPresenter(private var view: IPopUp?) : IJSPopUpPresenter {
    companion object {
        // Таймаут от showContent (loadUrl) до widget-ready: покрывает загрузку бандла по сети.
        internal const val LOAD_READY_TIMEOUT_MS = 30_000L

        // Таймаут от executeJs(initPopup) до popUpIsReady: рендер контента виджетом.
        internal const val JS_READY_TIMEOUT_MS = 10_000L
    }

    private val tag = this.javaClass.name
    // Корутинная замена compositeDisposable (ветка remove_rx, фаза 7), на Main.
    private var presenterScope = sdkScope(SdkDispatchers.main)

    private var currentTopOffsetInput = 0
    private var conversationId: String? = null

    // Страховка от вечно белого поп-апа: если popUpIsReady так и не пришёл — экран ошибки.
    // Гонка самоизлечивается: если после срабатывания таймаута страница всё же догрузилась,
    // loadingObserver в PopUpWebView спрячет ошибку, а popUpIsReady — спиннер.
    private var readyTimeoutJob: Job? = null

    fun onResume(id: String, blocksJson: String, backColor: String) {
        conversationId = id

        if(backColor.isNotEmpty()) {
            view?.updateBackground(backColor)
        }

        val providerName = when (BuildConfig.FLAVOR) {
            "common" -> "Carrot quest"
            "us" -> "Dashly"
            else -> ""
        }
        val providerIcon = when (BuildConfig.FLAVOR) {
            "common" -> R.drawable.ic_cq_logo_carrot
            "us" -> R.drawable.ic_logo_dashly
            else -> R.drawable.ic_logo_dashly
        }

        view?.updatePoweredBy(providerName, providerIcon)

        presenterScope.launch {
            try {
                PopUpLoadTrace.mark("onResume: requesting settings")
                val settings = getSettingsSuspend()
                PopUpLoadTrace.mark("settings received")
                if (settings != null) {
                    if (settings.showPoweredBy) {
                        view?.showPoweredBy()
                    }

                    val jsonObject = JsonObject()
                    val joConnect = prepareJsonSettings(JsonParser.parseString(settings.sourceData) as JsonObject, view?.getContext())

                    if (providerName.isNotEmpty()) {
                        joConnect.addProperty("provider_name", providerName)
                    }

                    jsonObject.add("appSettings", joConnect)

                    if (blocksJson.isNotEmpty()) {
                        val blocksJsonObject = JsonParser.parseString(blocksJson) as JsonObject
                        jsonObject.add("bodyJson", blocksJsonObject)
                    }

                    val initJson = "javascript:window.webView.initPopup($jsonObject)"
                    PopUpLoadTrace.mark("init json built (${initJson.length} chars), loadUrl")
                    view?.showContent(initJson)
                    startReadyTimeout(LOAD_READY_TIMEOUT_MS)
                }
            } catch (t: Throwable) {
                Log.e(javaClass.name, t)
            }
        }

        subscribeOnExpiration(id)
    }

    fun onDestroy() {
        presenterScope.cancel()
        presenterScope = sdkScope(SdkDispatchers.main)
        view = null
    }

    fun onTabCloseButton() {
        view?.closePopUp()
    }

    /**
     * Вьюха загрузилась. Можно вызывать initPopUp()
     */
    fun onLoaded(initJson: String) {
        PopUpLoadTrace.mark("widget ready, executeJs(initPopup)")
        // Перевзводим таймаут: страница готова, ждём рендер контента (popUpIsReady).
        // Этот же путь срабатывает после retry — reload заново уведомляет обсерверов.
        startReadyTimeout(JS_READY_TIMEOUT_MS)
        view?.executeJs(initJson)
    }

    private fun startReadyTimeout(timeoutMs: Long) {
        readyTimeoutJob?.cancel()
        readyTimeoutJob = presenterScope.launch {
            delay(timeoutMs)
            view?.showLoadError()
        }
    }

    /**
     * JSInterface методы
     */

    /**
     * Говорит о том что попап готов и возвращет его размеры
     */
    override fun popUpIsReady(width: Int, height: Int) {
        Log.d(tag, "popUpIsReady")
        PopUpLoadTrace.mark("popUpIsReady: content rendered (${width}x${height})")
        // Контент реально отрисован: снимаем таймаут и индикатор загрузки.
        // Вызов приходит с JS-bridge потока, Job.cancel() потокобезопасен.
        readyTimeoutJob?.cancel()
        readyTimeoutJob = null
        view?.hideLoading()
        view?.setHeight(height - 10)
    }

    override fun close() {
        view?.closePopUp()
    }

    override fun openLink(url: String) {
        view?.openLink(url)
        //view?.closePopUp()
        if(conversationId != null) {
            trackClick(conversationId!!, object: Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                }

                override fun onFailure(t: Throwable?) {
                }
            })
        }
    }

    override fun trackEvent(eventName: String) {
        Carrot.trackEvent(URLDecoder.decode(eventName, "UTF-8"))
    }

    override fun setUserProperty(props: String) {
        val json = JsonParser.parseString(URLDecoder.decode(props, "UTF-8")).asJsonObject

        val keys = json.keySet()
        if (keys.isNotEmpty()) {
            keys.forEach { key ->
                val value = json[key].asString
                Carrot.setUserProperty(UserProperty(key, value))
            }
        }
    }

    override fun setTopOffsetCurrentInputBar(topOffset: Int) {
        this.currentTopOffsetInput = topOffset
    }

    override fun allowDataProcessing() {
        allowDataProcessingUseCase()
    }

    override fun allowTrackContacts(dataJson: String, replyId: String) {
        val jsData = Gson().fromJson(dataJson, JsonObject::class.java)
        val email = if(jsData.has("email")) {
            jsData.get("email").asString
        } else {
            null
        }

        val phone = if(jsData.has("phone")) {
            jsData.get("phone").asString
        } else {
            null
        }

        val contacts = TrackContacts(
            email = email,
            phone = phone
        )

        allowTrackContactsUseCase(contacts, replyId)
    }

    fun onShowKeyboard() {
        view?.updateUpScroll(currentTopOffsetInput)
    }

    fun onHideKeyboard() {
        presenterScope.launch {
            delay(100)
            view?.updateDownScroll()
        }
    }


    private fun subscribeOnExpiration(id: String) {
        if (id.isNotEmpty()) {
            presenterScope.launch {
                try {
                    val expirationPopUpId = PopupRepository.expirationFlow.first()
                    if (expirationPopUpId == id) {
                        close()
                    }
                } catch (e: Throwable) {
                }
            }
        }
    }
}