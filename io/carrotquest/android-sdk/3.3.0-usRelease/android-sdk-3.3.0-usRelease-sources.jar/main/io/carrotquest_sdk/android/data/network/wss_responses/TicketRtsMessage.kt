package io.carrotquest_sdk.android.data.network.wss_responses

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.TicketsRepository
import io.carrotquest_sdk.android.domain.entities.TicketClosedPatch
import io.carrotquest_sdk.android.domain.entities.TicketStage
import io.carrotquest_sdk.android.domain.entities.TicketStatusEntity
import io.carrotquest_sdk.android.domain.entities.ticketStageOf
import io.carrotquest_sdk.android.domain.use_cases.tickets.isTicketsEnabled
import io.carrotquest_sdk.android.domain.use_cases.tickets.loadTickets
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketDates
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketStatusData
import kotlinx.coroutines.launch

/**
 * Событие канала ticket.{app}.{user}: {ticket: {id, title, status, last_update(ISO)}, event_type}.
 *
 * Пейлоад частичный (нет short_id/due_date/conversation), поэтому:
 * - created → карточку из события не собрать → перезагрузка списка (in-flight guard в loadTickets);
 * - updated → патч статуса/title в кэше по id без сети (conversation-поля сохраняются);
 *   тикета нет в кэше → перезагрузка;
 * - неизвестный event_type (появится deleted?) → игнор с логом, без краша.
 *
 * Формат зафиксирован по реальным WSS-кадрам 15.07.2026
 * (~/Documents/tickets/fixture_rts_ticket_events_2026-07-15.json).
 */
class TicketRtsMessage : IRtsMessage {

    @SerializedName(F.TICKET)
    val ticket: TicketEventPayload? = null

    @SerializedName(F.EVENT_TYPE)
    val eventType: String? = null

    override fun process() {
        // Фиче-флаг гейтит обработку (подписка на канал безусловная — см. WssManager)
        if (!isTicketsEnabled()) return

        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, TAG) {
            "ticket event: type=$eventType id=${ticket?.id} status=${ticket?.status?.name}"
        }

        when (eventType) {
            EVENT_CREATED -> reloadTickets()
            EVENT_UPDATED -> {
                val ticketId = ticket?.id
                if (ticketId.isNullOrBlank()) return
                val statusData = ticket.status
                val statusEntity = statusData?.let {
                    TicketStatusEntity(
                        id = it.id ?: "",
                        name = it.name ?: "",
                        stage = ticketStageOf(it.isInitial, it.isFinal),
                        colorHex = it.color
                    )
                }
                val patched = TicketsRepository.getInstance().updateTicket(
                    ticketId = ticketId,
                    title = ticket.title,
                    status = statusEntity,
                    lastUpdateMillis = TicketDates.parseIsoToMillis(ticket.lastUpdate),
                    closedPatch = closedPatchOf(statusEntity)
                )
                if (!patched) reloadTickets()
            }
            else -> SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.REALTIME, TAG,
                "unknown ticket event_type=$eventType — skipped"
            )
        }
    }

    private fun reloadTickets() {
        val userId = io.carrotquest_sdk.android.data.user.UserStateHolder.currentId().takeIf { it.isNotEmpty() } ?: return
        // RtsProcessing.scope (отменяется в deInit), а не одноразовый скоуп: orphan-корутина
        // дописывала тикеты и бейдж СТАРОГО пользователя после logout — поверх уже сброшенного
        // состояния новой сессии.
        RtsProcessing.scope.launch {
            loadTickets(userId)
        }
    }

    /**
     * Закрытость из updated-события (CAR-76310). Якорь — стадия статуса (инвариант бэка
     * closed_at != null ⟺ is_final): нефинальный статус детерминированно сбрасывает закрытость
     * (переоткрытие); финальный берёт closed_at/is_reopenable пейлоада. Если у финального
     * события ОБОИХ полей нет (старый бэк или рассинхрон RTS-сериализатора с REST) — кэш
     * не трогаем: REST-список уже дал корректные значения, а затирание превращало бы
     * переоткрываемый тикет в read-only и заново показывало «Ваш вопрос решён?».
     * Без статуса закрытость тоже не трогаем.
     */
    private fun closedPatchOf(status: TicketStatusEntity?): TicketClosedPatch? {
        if (status == null) return null
        return if (status.stage == TicketStage.FINAL) {
            if (ticket?.closedAt == null && ticket?.isReopenable == null) {
                null
            } else {
                TicketClosedPatch(
                    closedAtMillis = TicketDates.parseIsoToMillis(ticket?.closedAt),
                    isReopenable = ticket?.isReopenable == true
                )
            }
        } else {
            TicketClosedPatch(closedAtMillis = null, isReopenable = false)
        }
    }

    companion object {
        private const val TAG = "TicketRtsMessage"
        private const val EVENT_CREATED = "created"
        private const val EVENT_UPDATED = "updated"
    }
}

/** Частичный тикет из RTS-события (TicketUserRTSSerializer бэка). */
class TicketEventPayload {
    @SerializedName(F.ID)
    val id: String? = null

    @SerializedName(F.TITLE)
    val title: String? = null

    @SerializedName(F.STATUS)
    val status: TicketStatusData? = null

    @SerializedName(F.LAST_UPDATE)
    val lastUpdate: String? = null

    // CAR-76310: сериализатор нового бэка шлёт оба поля в каждом updated-событии;
    // nullable — чтобы отличить старый бэк (поля нет) и не затирать кэш
    @SerializedName(F.CLOSED_AT)
    val closedAt: String? = null

    @SerializedName(F.IS_REOPENABLE)
    val isReopenable: Boolean? = null
}
