package io.carrotquest_sdk.android.lib.network.responses.messages;

import android.util.Log;

import androidx.annotation.Keep;

import com.google.gson.JsonElement;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class MessageData {

    @SerializedName(F.ID)
    @Expose
    private String id = null;
    @SerializedName(F.CREATED)
    @Expose
    private String created = null;
    @SerializedName(F.CONVERSATION)
    @Expose
    private String conversation = null;
    @SerializedName(F.BODY)
    @Expose
    private String body = "";
    @SerializedName(F.BODY_JSON)
    @Expose
    private JsonElement bodyJson = null;
    @SerializedName(F.READ)
    @Expose
    private Boolean read = false;
    @SerializedName(F.TYPE)
    @Expose
    private String type;
    @SerializedName(F.SENT_VIA)
    @Expose
    private String sentVia;
    @SerializedName(F.FIRST)
    @Expose
    private boolean first = false;
    @SerializedName(F.DIRECTION)
    @Expose
    private String direction;
    @SerializedName(F.STATUS)
    private String status;
    @SerializedName(F.REPLY_TYPE)
    private String replyType;

    @SerializedName(F.RANDOM_ID)
    @Expose
    private String randomId;

    @SerializedName(F.FROM)
    private Admin messageFrom;

    @SerializedName(F.ATTACHMENTS)
    private ArrayList<Attachment> attachments;

    @SerializedName(F.META_DATA)
    private MessageMetaData messageMetaData;

    @SerializedName(F.EXPIRATION_TIME)
    private Long expirationTime;

    @SerializedName(F.ACTIONS)
    private ArrayList<ActionMessage> actions;

    private JSONObject sourceJsonData;

    @SerializedName(F.REMOVED)
    private String removed;

    @SerializedName(F.CONVERSATION_TYPE)
    private String conversationType;

    @SerializedName(F.KB_LINK)
    private Boolean hasKBLink;

    /**
     * Цитата (`replied_to`) — снапшот процитированного оригинала. null, если сообщение ни на
     * что не отвечает либо оригинал физически удалён (бэкенд убирает ключ целиком).
     */
    @SerializedName(F.REPLIED_TO)
    private RepliedTo repliedTo;

    /**
     * Локальный ключ сортировки для оптимистичных исходящих сообщений. transient — НЕ часть
     * протокола и не сериализуется Gson'ом в sourceJsonData. Серверные сообщения имеют
     * монотонно растущие id-снежинки, по которым их можно надёжно упорядочить внутри одной
     * секунды; у оптимистичного сообщения id — это локальное время в секундах (несравнимо
     * со снежинками). Чтобы оптимистичный ответ вставал строго после текущего последнего
     * сообщения и перед будущими серверными, ему присваивается sortKey = maxId+1 (см.
     * CreateMessageSuspend), а MessageMapper использует его в приоритете над id.
     */
    private transient Long sortKey = null;

    /**
     * Секунда в СЕРВЕРНОМ таймлайне для сортировки — только у оптимистичных исходящих
     * (transient, как sortKey). created оптимиста берётся с часов устройства и честно
     * отображается как время отправки, но для порядка в ленте непригоден: спешащие часы
     * уводят его в будущее, и серверный ответ бота/оператора с меньшим created вставал БЫ
     * выше только что отправленного пузыря. Сортировка MessageMapper использует
     * sortCreated ?: created; выставляется якорем в CreateMessageSuspend (см. anchorSortKeys).
     */
    private transient Long sortCreated = null;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getSortKey() {
        return sortKey;
    }

    public void setSortKey(Long sortKey) {
        this.sortKey = sortKey;
    }

    public Long getSortCreated() {
        return sortCreated;
    }

    public void setSortCreated(Long sortCreated) {
        this.sortCreated = sortCreated;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getConversation() {
        return conversation;
    }

    public void setConversation(String conversation) {
        this.conversation = conversation;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public Boolean getRead() {
        return read;
    }

    public void setRead(Boolean read) {
        this.read = read;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSentVia() {
        return sentVia;
    }

    public void setSentVia(String sentVia) {
        this.sentVia = sentVia;
    }

    public boolean isFirst() {
        return first;
    }

    public void setFirst(boolean first) {
        this.first = first;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRandomId() {
        return randomId;
    }

    public void setRandomId(String randomId) {
        this.randomId = randomId;
    }

    public Admin getMessageFrom() {
        return messageFrom;
    }

    public void setMessageFrom(Admin messageFrom) {
        this.messageFrom = messageFrom;
    }

    public ArrayList<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(ArrayList<Attachment> attachments) {
        this.attachments = attachments;
    }

    public String getReplyType() {
        return replyType;
    }

    public void setReplyType(String replyType) {
        this.replyType = replyType;
    }

    public MessageMetaData getMessageMetaData() {
        return messageMetaData;
    }

    public void setMessageMetaData(MessageMetaData messageMetaData) {
        this.messageMetaData = messageMetaData;
    }

    public void setBodyJson(JsonElement bodyJson) {
        this.bodyJson = bodyJson;
    }

    public JsonElement getBodyJson() {
        return bodyJson;
    }

    /**
     * Часть первой ветки routing-бота, записанная сервером (body_json.is_first_branch=true).
     * В живой сессии первую ветку рисует шаблон из chooseRoutingBot, поэтому RTS такие части
     * не вливает, а ChatViewModel снимает шаблон, когда они приходят историей.
     */
    public boolean isFirstBranchPart() {
        if (bodyJson == null || !bodyJson.isJsonObject()) return false;
        JsonElement flag = bodyJson.getAsJsonObject().get(F.IS_FIRST_BRANCH);
        return flag != null && flag.isJsonPrimitive() && flag.getAsJsonPrimitive().isBoolean()
                && flag.getAsBoolean();
    }

    public Long getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(Long expirationTime) {
        this.expirationTime = expirationTime;
    }

    public ArrayList<ActionMessage> getActions() {
        return actions;
    }

    public void setActions(ArrayList<ActionMessage> actions) {
        this.actions = actions;
    }

    public JSONObject getSourceJsonData() {
        return sourceJsonData;
    }

    public void setSourceJsonData(JSONObject sourceJsonData) {
        this.sourceJsonData = sourceJsonData;
    }

    public String getRemoved() {
        return removed;
    }

    public void setRemoved(String removed) {
        this.removed = removed;
    }

    public String getConversationType() {
        return conversationType;
    }

    public void setConversationType(String conversationType) {
        this.conversationType = conversationType;
    }

    public Boolean getHasKBLink() {
        return hasKBLink;
    }

    public void setHasKBLink(Boolean showKbLink) {
        this.hasKBLink = showKbLink;
    }

    public RepliedTo getRepliedTo() {
        return repliedTo;
    }

    public void setRepliedTo(RepliedTo repliedTo) {
        this.repliedTo = repliedTo;
    }
}
