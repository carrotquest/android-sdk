package io.carrotquest_sdk.android.presentation.tickets

import io.carrotquest_sdk.android.domain.entities.TicketEntity
import io.carrotquest_sdk.android.domain.entities.TicketStage

/** Карточка тикета на вкладке «Тикеты». */
data class TicketCardUiItem(
    val id: String,
    val title: String,
    /** "#26" — короткий номер тикета справа от заголовка */
    val shortIdLabel: String,
    val stage: TicketStage,
    /** Подпись статуса: имя с бэка как есть (упрощение делает бэк); «В работе» — только fallback пустого intermediate */
    val statusLabel: String,
    /** Цвет статуса с бэка ("#RRGGBB") — применяется только к INTERMEDIATE */
    val statusColorHex: String? = null,
    /** Превью последнего сообщения (может быть пустым — тикет без переписки) */
    val previewText: String,
    val unreadCount: Int,
    val conversationId: String?
)

/**
 * Stateless-билдер карточки. Не зависит от Android Context: локализованную строку
 * «В работе» и готовое превью передаёт вызывающий (VM) — легко покрывается юнит-тестами.
 */
internal object TicketCardBuilder {

    fun build(ticket: TicketEntity, inProgressLabel: String, previewText: String): TicketCardUiItem {
        return TicketCardUiItem(
            id = ticket.id,
            title = ticket.title,
            shortIdLabel = ticket.shortId?.let { "#$it" } ?: "",
            stage = ticket.status.stage,
            // CAR-76566: упрощение имени делает бэкенд; клиент — только fallback пустого intermediate
            statusLabel = ticketStatusLabel(ticket.status.name, ticket.status.stage, inProgressLabel),
            statusColorHex = ticket.status.colorHex,
            previewText = previewText,
            unreadCount = ticket.unreadCount,
            conversationId = ticket.conversationId
        )
    }
}
