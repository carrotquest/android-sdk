package io.carrotquest_sdk.android.presentation.tickets

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.mvp.utils.toAnnotatedHtml
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.ui.UnreadBadge

// ── Вкладка «Тикеты»: список карточек тикетов ─────────────────────────────

// Пустых/загрузочных/ошибочных состояний нет: вкладка вообще показывается только
// при непустом кэше тикетов (см. showTabs в ListContentScreen)
@Composable
internal fun TicketListContent(
    tickets: List<TicketCardUiItem>,
    isDark: Boolean,
    bottomPadding: Dp,
    onTicketClick: (TicketCardUiItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp + bottomPadding)
    ) {
        items(items = tickets, key = { it.id }) { ticket ->
            TicketCardItem(
                item = ticket,
                isDark = isDark,
                onClick = { onTicketClick(ticket) }
            )
        }
    }
}

// ── Карточка тикета ───────────────────────────────────────────────────────────

@Composable
internal fun TicketCardItem(
    item: TicketCardUiItem,
    isDark: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SdkColors.background(isDark)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, SdkColors.cardBorder(isDark))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кастомный цвет статуса с бэка (CAR-76566) красит В КАРТОЧКЕ и глиф, и подпись —
            // это цвет, который админ задал статусу, он должен читаться в списке (решение
            // пользователя/дизайна). Стадийные токены темы — только фолбэк, когда цвета нет.
            // В инфо-панели наоборот: там подпись нейтральная, а цвет живёт на прогресс-баре.
            val customArgb = ticketCustomColorArgb(item.stage, item.statusColorHex)
            val glyphColor = customArgb?.let { Color(it) } ?: SdkColors.ticketStageColor(item.stage, isDark)
            val labelColor = customArgb?.let { Color(it) } ?: SdkColors.ticketStageTextColor(item.stage, isDark)

            // Круглая иконка тикета, глиф — цветом стадии
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(SdkColors.ticketCardIconBg(isDark)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_cq_tab_ticket),
                    contentDescription = null,
                    tint = glyphColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // title растягивается на всю ширину, прижимая #short_id к правому краю
                    // карточки (по макету); длинный title ellipsis'ится, номер не выдавливается
                    Text(
                        text = item.title,
                        color = SdkColors.title(isDark),
                        fontSize = 15.sp,
                        lineHeight = 21.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (item.shortIdLabel.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = item.shortIdLabel,
                            color = SdkColors.sectionLabel,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                // Бейдж непрочитанных стоит В СТРОКЕ превью и прижат к её низу (по макету
                // 4929:14458: «Messages counter» лежит внутри блока последнего сообщения, а сам
                // текст сужен на его ширину) — иначе он центрировался по всей карточке и
                // наезжал бы на вторую строку.
                Row(verticalAlignment = Alignment.Bottom) {
                    // «Статус · превью» — ОДНИМ Text, а не Row из трёх: в Row невзвешенные дети
                    // меряются по порядку, поэтому длинная подпись кастомного статуса
                    // («Ждём ответа от разработчиков») выдавливала превью из карточки целиком, а
                    // weight у подписи лишь перевернул бы проблему в пользу длинного превью.
                    // Единый Text обрезает строку естественно: сначала кончается превью, потом
                    // подпись, и справа не остаётся пустоты. Две строки — как в макете.
                    Text(
                        text = buildAnnotatedString {
                            withStyle(
                                SpanStyle(color = labelColor, fontWeight = FontWeight.SemiBold)
                            ) { append(item.statusLabel) }
                            if (item.previewText.isNotBlank()) {
                                append(" · ")
                                append(item.previewText.toAnnotatedHtml())
                            }
                        },
                        color = SdkColors.secondaryText(isDark),
                        fontSize = 14.sp,
                        lineHeight = 18.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (item.unreadCount > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        // Общий компонент вместо своего круга: жёсткий size(20.dp) обрезал «99+»
                        // (у UnreadBadge пилюля тянется по содержимому и переживает fontScale)
                        UnreadBadge(count = item.unreadCount)
                    }
                }
            }
        }
    }
}
