package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.data.user.UserIdentityStore
import io.carrotquest_sdk.android.data.user.UserStateHolder

/**
 * Согласованная пара идентичности для построения запроса: request_user_id и auth_token
 * взяты из ОДНОГО снимка одного поколения (CAR-77172, этап 2).
 *
 * Раньше paramAdds брал user_id из old/UserRepository, а fallback-токен — из JWT-prefs:
 * два независимых хранилища, из которых можно было прочитать «id одного юзера + токен
 * другого» (тот самый класс гонок, что дал прод-403 PermissionDeniedError).
 */
internal class RequestIdentity(
    val userId: String,
    val authToken: String,
    /**
     * Легаси user.token как есть — нужен только freedom-ветке /connect (Dashly-миграция).
     * От [authToken] отличается лишь тем, что не подменяется access'ом при пустоте.
     */
    val legacyUserToken: String,
)

/**
 * Приоритет токена: легаси user.token (UserStateHolder ← CarrotToken), фолбэк — access
 * из снимка стора. КОНТРАКТ (осознанное решение этапа 3, CAR-77172): легаси-приоритет
 * сохраняется, потому что для старых инсталляций без JWT-пары CarrotToken — единственный
 * кред; при живом JWT оба значения синкается одной воронкой и совпадают.
 *
 * Единственное определение этого приоритета: им пользуются и сборка запроса (paramAdds),
 * и проверка инварианта идентичности — иначе барьер сверял бы владельца не того токена,
 * что реально уйдёт в запрос.
 */
internal fun currentRequestIdentity(): RequestIdentity {
    val snap = UserIdentityStore.snapshot()
    val legacy = runCatching { UserStateHolder.currentToken() }.getOrDefault("")
    return RequestIdentity(
        userId = snap.userId,
        authToken = legacy.ifEmpty { snap.accessToken },
        legacyUserToken = legacy,
    )
}

/** [currentRequestIdentity].authToken для кода вне интерсептора (барьер идентичности). */
internal fun currentRequestAuthToken(): String = currentRequestIdentity().authToken
