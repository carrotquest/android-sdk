package io.carrotquest_sdk.android.core.connection

import android.content.Context
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.wss.jwt.clearAllCreds
import io.carrotquest_sdk.android.lib.wss.jwt.clearRtsDataIfNeed
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.RefreshOutcome
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlockingDetailed
import io.carrotquest_sdk.android.lib.wss.jwt.tokenStateSummary
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException

internal object ConnectionManager {

    private const val TAG = "ConnectionManager"
    private const val MAX_RETRIES = 3

    private var retryCount = 0

    suspend fun connect(
        apiKey: String,
        appId: String,
        sdkVersion: String,
        referrer: String,
        startSession: Boolean,
        context: Context,
        carrotLib: CarrotLib,
    ): ConnectResponse {
        if (retryCount > MAX_RETRIES) {
            throw IllegalStateException("Too many connection attempts")
        }

        clearRtsDataIfNeed(context, appId)

        val actual = isActualJwtToken(context)
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "connect: attempt=$retryCount, isActualAccess=$actual. Tokens: ${tokenStateSummary()}",
        )

        if (actual) {
            retryCount = 0
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "connect: access actual → connecting directly (token-less if access empty)",
            )
            return try {
                carrotLib.connectSuspend(apiKey, "sdk $sdkVersion", "sdk_user_android", referrer, startSession)
            } catch (error: Throwable) {
                // Токен «свеж по времени», но сервер его отверг (401/403). Чистим креды и делаем
                // один token-less reconnect как новый аноним — init должен пройти БЕЗ токена.
                // Свежий JWT/refresh придут в ответе /connect (ConnectDeserializer их сохранит),
                // а клиентский auth(userId) после init склеит анонима со старым пользователем.
                if (error is HttpException && (error.code() == 401 || error.code() == 403)) {
                    SdkLogger.log(
                        SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                        "connect rejected (${error.code()}), clearing tokens and reconnecting anonymously",
                    )
                    clearAllCreds(context)
                    carrotLib.connectSuspend(apiKey, "sdk $sdkVersion", "sdk_user_android", referrer, startSession)
                } else {
                    throw error
                }
            }
        }

        // JWT протух — пытаемся обновить токен, затем повторяем connect.
        try {
            val outcome = refreshToken()
            if (outcome is RefreshOutcome.NotAttempted) {
                // Сети не было вовсе: нечем аутентифицировать /refresh, недавний отказ в кэше или
                // идентичность сменилась под нами. Это НЕ приговор кредам — раньше такой случай
                // неотличимо сливался с серверным отказом и стирал личность авторизованного юзера
                // (token-less /connect выдавал НОВОГО анонима, а запросы продолжали идти со старым
                // user_id → 403 PermissionDeniedError). Пробуем connect с тем, что есть.
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "connect: refresh not attempted (${outcome.reason}) — creds left intact, connecting as is",
                )
                retryCount++
                return carrotLib.connectSuspend(apiKey, "sdk $sdkVersion", "sdk_user_android", referrer, startSession)
            }
            if (outcome is RefreshOutcome.Rejected) {
                throw IllegalStateException("refresh rejected by server")
            }
            // Success: свежий access уже синхронизирован в user.token внутри refresh-юзкейса
            // (saveRefreshedTokens/фолбэк) — локальная копия здесь дублировала бы его.
            retryCount++
            return connect(apiKey, appId, sdkVersion, referrer, startSession, context, carrotLib)
        } catch (error: Throwable) {
            if (error is IOException) {
                // Сетевая ошибка — refresh-токен может быть валиден, просто нет сети.
                // Не очищаем токены: при восстановлении сети NetworkManager перезапустит
                // setup() и refresh пройдёт успешно.
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refresh failed due to network error, not clearing tokens: $error",
                )
                throw error
            }
            // Сервер отклонил refresh (4xx) — токены действительно мертвы.
            // Чистим ВСЕ persisted креды (вкл. легаси CarrotToken) и подключаемся как новая сессия.
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "refresh rejected by server, clearing tokens and falling back to /connect: $error",
            )
            clearAllCreds(context)
            retryCount++
            if (retryCount > MAX_RETRIES) {
                throw error
            }
            return carrotLib.connectSuspend(apiKey, "sdk $sdkVersion", "sdk_user_android", referrer, startSession)
        }
    }

    fun reset() {
        retryCount = 0
    }

    /**
     * Обновляет JWT-токен через blocking refresh (под shared lock) на IO-диспетчере.
     *
     * Возвращает исход целиком: вызывающему важно отличать серверный отказ (креды мертвы, сессию
     * надо пересоздавать) от «попытки не было» (креды валидны, трогать их нельзя). Сетевые ошибки
     * по-прежнему пробрасываются исключением.
     */
    private suspend fun refreshToken(): RefreshOutcome = withContext(SdkDispatchers.io) {
        refreshJwtTokenBlockingDetailed()
    }
}
