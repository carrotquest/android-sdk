package io.carrotquest_sdk.android.presentation.mvp.notifications

import io.carrotquest_sdk.android.Callback

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.constants.isPopUpConversationType
import io.carrotquest_sdk.android.domain.use_cases.popup.ensurePopUpDownloaded
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackUtm

class PushTapActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_push_tap)

        createIntentAndStartActivity()
    }

    private fun createIntentAndStartActivity() {
        //Отправим событие для статистики (событие Клик на пуш)
        val conversationId: String? = if (intent.hasExtra(PushTapReceiver.conversationIdExtraKey)) {
            intent.getStringExtra(PushTapReceiver.conversationIdExtraKey)
        } else {
            ""
        }
        val conversationType: String? =
            if (intent.hasExtra(PushTapReceiver.conversationTypeExtraKey)) {
                intent.getStringExtra(PushTapReceiver.conversationTypeExtraKey)
            } else {
                ""
            }
        if (conversationId != null && conversationType != null && conversationType == "sdk_push") {
            CarrotInternal.bootstrap(this)
            trackClick(conversationId, object : Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                    finish()
                }

                override fun onFailure(t: Throwable?) {
                    finish()
                }

            })
        }

        val link: String? = if (intent.hasExtra(PushTapReceiver.linkExtraKey)) {
            intent.getStringExtra(PushTapReceiver.linkExtraKey)
        } else {
            ""
        }


        if (link.isNullOrEmpty()) {
            val pm = this.packageManager
            val intent =
                pm.getLaunchIntentForPackage(this.packageName)

            // Поп-ап: диалог не открываем (тела чата у поп-ап-беседы нет) — запускаем хост-приложение,
            // а поп-ап покажет SdkApp.handlePopUps поверх его активити, когда поп-ап окажется в PopUpDao
            // (по need_show_popup_conv_id). На холодном старте его докачает connect (downloadPopUps),
            // в «тёплом» — ensurePopUpDownloaded. Показывать отсюда напрямую нельзя: активити noHistory
            // и умирает сразу после startActivity, её lifecycleScope отменил бы отложенный показ.
            if (isPopUpConversationType(conversationType) && !conversationId.isNullOrEmpty()) {
                SharedPreferencesLib.saveString(this, "need_show_popup_conv_id", conversationId)
                clearPopupNotifications(conversationType)
                ensurePopUpDownloaded(conversationId)
            }

            intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent?.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            intent?.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            intent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent?.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            this.overridePendingTransition(0, 0)

            this.startActivity(intent)
        } else {
            val intent = Intent(Intent.ACTION_VIEW)
            if (!link.contains("://")) {
                intent.data = Uri.parse("https://$link")
            } else {
                intent.data = Uri.parse(link)
            }


            //Trac UTMs
            trackUtm(link)

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            this.overridePendingTransition(0, 0)
            try {
                this.startActivity(intent)
            } catch (e: Exception) {
                val pm = this.packageManager
                val intentX =
                    pm.getLaunchIntentForPackage(this.packageName)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                intentX?.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                this.overridePendingTransition(0, 0)
                this.startActivity(intentX)
            }
        }
    }

    private fun clearPopupNotifications(conversationType: String?) {
        if (conversationType.isNullOrEmpty()) return
        val notificationManager =
            this.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (notification in notificationManager.activeNotifications) {
                if (notification != null
                    && notification.tag != null
                    && notification.tag.contains(conversationType)
                ) {
                    notificationManager.cancel(notification.tag, notification.id)
                }
            }
        }
    }
}
