package io.carrotquest_sdk.android.presentation.mvp.popup.view

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.util.AttributeSet
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.constraintlayout.widget.ConstraintLayout
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import io.carrotquest_sdk.android.presentation.mvp.web_view.WebViewLoadListener

class PopUpWebView: CarrotWebView {
    private val loadingObserver = WebViewLoadListener { isLoaded ->
        if (isLoaded) {
            // Спиннер здесь НЕ гасим: widget-ready — это ещё не отрисованный контент.
            // Спиннер скрывается по popUpIsReady (см. PopUpPresenter). А вот экран ошибки
            // чистим — успешная загрузка после retry должна его убрать.
            hideLoadError()
        }
    }

    constructor(context: Context?): super(context)
    constructor(context: Context?, attrs: AttributeSet?): super(context, attrs)

    init {
        super.addLoadingObserver(loadingObserver)
        // Страница поп-апа выставляет initPopup (initDialogue — у чата): без этого проверка
        // готовности никогда не проходила и поллинг всегда ждал полный 3-секундный таймаут.
        setReadyFunctionName("initPopup")
        // HTTP-кэш безопасен именно для поп-апа: имена ассетов content-hashed, версия виджета в
        // пути URL, CDN отдаёт max-age=1800 + ETag → повторное открытие идёт из кэша/по 304
        // вместо полной перекачки бандла (базовый CarrotWebView живёт с LOAD_NO_CACHE).
        super.webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        // Заливку контейнера спиннера (белую/#333 из initViews) делаем прозрачной:
        // фон под спиннером даёт сам поп-ап своим цветом.
        findViewById<ConstraintLayout>(R.id.load_progress_bar_container)
            ?.setBackgroundColor(Color.TRANSPARENT)
        super.webView.isVerticalScrollBarEnabled = false
        super.webView.isVerticalFadingEdgeEnabled = false
        super.webView.setOnScrollChangeListener { _: WebView?, _: Int, _: Int, _: Int, _: Int ->
            run {

                Log.d("", "")
            }
        }
        super.webView.isScrollContainer = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            super.webView.requestFocus()
        }
    }

    override fun onOverScrolled(scrollX: Int, scrollY: Int, clampedX: Boolean, clampedY: Boolean) {
        super.onOverScrolled(scrollX, scrollY, clampedX, clampedY)
        Log.d("", "")
    }

}