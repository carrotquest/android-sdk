package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.TicketsRepository
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.presentation.tickets.TicketResolutionState

// Синхронная очистка истории диалогов (ветка remove_rx) — Observable-ext убрана.
fun clearHistory() {
    ConversationsRepository.getInstance().clearConversations()
    // Тикеты — вместе с диалогами: deInit/смена пользователя обязаны сбросить кэш и
    // счётчик непрочитанных (иначе чужие тикеты/бейдж доживут до следующего connect).
    // Стартовый unread нового пользователя заново придёт из /connect (initUnreadFromConnect).
    TicketsRepository.getInstance().reset()
    // Ответы «Ваш вопрос решён?» — тоже пользовательские данные (CAR-76310)
    TicketResolutionState.reset()
    Log.d("clearHistory", "clear History dialogs")
}
