package io.carrotquest_sdk.android.lib.network.deserializers;

import android.util.Log;

import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.models.*;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.DataConnect;
import io.carrotquest_sdk.android.lib.network.responses.connect.RealtimeService;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;
import io.carrotquest_sdk.android.lib.wss.jwt.SaveJwtTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.jwt.SaveRefreshTokenUseCaseKt;

import com.google.gson.*;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

public class ConnectDeserializer implements JsonDeserializer<ConnectResponse> {
    @Override
    public ConnectResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ConnectResponse response = new ConnectResponse();

        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("ConnectDeserializer. meta is null or dataJsonElement is null");
        }


        JsonElement meta = json.getAsJsonObject().get(F.META);
        JsonElement data = json.getAsJsonObject().get(F.DATA);
        try {
            response.setMeta(new Gson().fromJson(meta, Meta.class));
            if(data != null && !data.isJsonNull()) {
                response.setSourceData(data.toString());
            }

            DataConnect dataConnect = new DataConnect();

            App app = new App();

            JsonObject appJsonObject = data.getAsJsonObject().get(F.APP).getAsJsonObject();
            if(appJsonObject.has(F.BLOCKED) && appJsonObject.get(F.BLOCKED).getAsBoolean()) {
                app.setBlocked(true);
                dataConnect.setApp(app);
                response.setData(dataConnect);
                return response;
            } else {
                app.setBlocked(false);
            }

            app.setId(appJsonObject.get(F.ID).getAsString());
            app.setName(appJsonObject.get(F.NAME).getAsString());
            app.setActive(appJsonObject.get(F.ACTIVE).getAsBoolean());
            app.setStatusOperators(appJsonObject.get(F.STATUS_OPERATORS).getAsString());

            if (appJsonObject.has(F.ADMINS)) {
                ArrayList<Admin> adminsArray = new ArrayList<>();
                JsonArray adminsJsArray = appJsonObject.get(F.ADMINS).getAsJsonArray();
                if(!adminsJsArray.isJsonNull()) {
                    for(JsonElement element : adminsJsArray) {
                        Admin admin = new Admin();
                        admin.setId(element.getAsJsonObject().get(F.ID).getAsString());
                        admin.setName(element.getAsJsonObject().get(F.NAME).getAsString());
                        admin.setAvatar(element.getAsJsonObject().get(F.AVATAR).getAsString());
                        admin.setType(element.getAsJsonObject().get(F.TYPE).getAsString());
                        adminsArray.add(admin);
                    }
                }
                app.setAdmins(adminsArray);
            }

            if(appJsonObject.has(F.SETTINGS)) {
                Settings settings = new Gson().fromJson(appJsonObject.get(F.SETTINGS), Settings.class);
                app.setSettings(settings);
            }
            dataConnect.setApp(app);


            String authToken = "";
            if(data.getAsJsonObject().has(F.AUTH_TOKEN)) {
                if(data.getAsJsonObject().get(F.AUTH_TOKEN).isJsonObject()) {
                    JsonObject authTokenJO = data.getAsJsonObject().get(F.AUTH_TOKEN).getAsJsonObject();
                    if (authTokenJO != null && !authTokenJO.isJsonNull() && authTokenJO.has(F.ACCESS)) {
                        // Только парсим. Сохраняет токены тот, кто ПРИМЕНЯЕТ ответ
                        // (InitCoordinator.applyConnectSideEffects): ответ ещё может быть отброшен
                        // по таймауту/ретраю или фильтром заблокированного приложения, а запись
                        // прямо отсюда уже подменяла бы глобальную пару токенов.
                        authToken = authTokenJO.get(F.ACCESS).getAsString();
                        if (authTokenJO.has(F.REFRESH) && !authTokenJO.get(F.REFRESH).isJsonNull()) {
                            dataConnect.setRefreshToken(authTokenJO.get(F.REFRESH).getAsString());
                        }
                    }
                } else {
                    authToken = data.getAsJsonObject().get(F.AUTH_TOKEN).getAsString();
                }
            }

            if(!authToken.isEmpty()) {
                dataConnect.setAuthToken(authToken);

            }

            JsonObject userJsonObject = data.getAsJsonObject().get(F.USER).getAsJsonObject();
            User user = new User();
            user.setId(userJsonObject.get(F.ID).getAsString());
            user.setToken(authToken);
            user.setBanned(userJsonObject.get(F.IS_BANNED).getAsBoolean());
            user.setHasConversations(userJsonObject.get(F.HAS_CONVERSATIONS).getAsBoolean());
            if (userJsonObject.has(F.CONVERSATIONS_UNREAD)) {
                ArrayList<String> unreadConversationsArray = new ArrayList<>();
                JsonArray unreadConversationsJsArray = userJsonObject.get(F.CONVERSATIONS_UNREAD).getAsJsonArray();
                if(!unreadConversationsJsArray.isJsonNull()) {
                    for(JsonElement element : unreadConversationsJsArray) {
                        unreadConversationsArray.add(element.getAsString());
                    }
                }
                user.setConversationsUnread(unreadConversationsArray);
            } else {
                user.setConversationsUnread(new ArrayList<>());
            }
            // tickets_unread: null/отсутствие поля = тикет-система выключена — оставляем null,
            // не схлопываем в 0 (0 = включена без непрочитанных)
            if (userJsonObject.has(F.TICKETS_UNREAD) && !userJsonObject.get(F.TICKETS_UNREAD).isJsonNull()) {
                user.setTicketsUnread(userJsonObject.get(F.TICKETS_UNREAD).getAsInt());
            }
            dataConnect.setUser(user);




            dataConnect.setDeviceId(data.getAsJsonObject().get(F.DEVICE_GUID).getAsString());
            if (data.getAsJsonObject().has(F.ID)) {
                dataConnect.setId(data.getAsJsonObject().get(F.ID).getAsString());
            }


            if(data.getAsJsonObject().has(F.REALTIME_SERVICES)) {
                JsonObject realtimeServiceJsonObject = data.getAsJsonObject().get(F.REALTIME_SERVICES).getAsJsonObject();
                if (realtimeServiceJsonObject != null && !realtimeServiceJsonObject.isJsonNull() && realtimeServiceJsonObject.isJsonObject()) {
                    HashMap<Integer, String> hosts = new HashMap<>();
                    if(realtimeServiceJsonObject.has(F.HOSTS)) {
                        JsonArray hostsArray = realtimeServiceJsonObject.get(F.HOSTS).getAsJsonArray();
                        if(!hostsArray.isEmpty()) {
                            JsonElement firstHost = hostsArray.get(0);
                            hosts.put(0, firstHost.getAsString());
                        }
                    }

                    ArrayList<String> channels = new ArrayList<>();
                    if(realtimeServiceJsonObject.has(F.CHANNELS)) {
                        JsonArray channelsArray = realtimeServiceJsonObject.get(F.CHANNELS).getAsJsonArray();
                        if(!channelsArray.isEmpty()) {
                            for(JsonElement channel : channelsArray) {
                                channels.add(channel.getAsString());
                            }
                        }
                    }


                    RealtimeService realtimeService = new RealtimeService(hosts, channels);
                    dataConnect.setRealtimeServices(realtimeService);
                }
            }

            response.setData(dataConnect);
        }
        catch (Exception e) {
            response = oldParseResponse(json);
        }

        return response;
    }

    private ConnectResponse oldParseResponse(JsonElement json) {
        JsonElement meta = json.getAsJsonObject().get(F.META);
        JsonElement data = json.getAsJsonObject().get(F.DATA);

        ConnectResponse response = new ConnectResponse();
        response.setMeta(new Gson().fromJson(meta, Meta.class));
        response.setData(new Gson().fromJson(data, DataConnect.class));
        if (response.getData() != null) {
            if(data != null && !data.isJsonNull()) {
                response.setSourceData(data.toString());
            }

            User user = response.getData().getUser();
            if(user == null) {
                throw new JsonParseException("Connect deserialize error: User is null! Json = " + json.toString());
            }
            user.setToken(response.getData().getAuthToken());
            if (response.getData().getApp() == null) {
                DataConnect dataConnect = response.getData();
                dataConnect.setApp(new App());
                response.setData(dataConnect);
            }
            App app = response.getData().getApp();
            if (app.getSettings() == null) {
                DataConnect dataConnect = response.getData();
                App appConnect = dataConnect.getApp();
                appConnect.setSettings(new Settings());
                dataConnect.setApp(appConnect);
                response.setData(dataConnect);
            }
        }


        return response;
    }
}