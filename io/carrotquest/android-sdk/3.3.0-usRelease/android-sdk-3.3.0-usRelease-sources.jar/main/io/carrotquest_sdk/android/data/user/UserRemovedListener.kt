package io.carrotquest_sdk.android.data.user

import io.carrotquest_sdk.android.domain.entities.UserEntity

/**
 * Колбэк «текущий юзер удалён» (RTS UsersRemovedResponse). Раньше жил в
 * data/repositories/old рядом с UserRepository — переехал к [UserStateHolder]
 * вместе с реестром слушателей (CAR-77172, этап 3).
 */
internal fun interface UserRemovedListener {
    fun onUserRemoved(user: UserEntity)
}
