package io.carrotquest_sdk.android.presentation.mvp.base;


import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.user.UserRemovedListener;
import io.carrotquest_sdk.android.data.user.UserStateHolder;

public class BaseSdkActivity extends AppCompatActivity {

    private UserRemovedListener removeObserver;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        removeObserver = user -> {
            if (user != null) {
                finish();
                if (Carrot.isInit()) {
                    Carrot.deInit();
                }
            }
        };

        if(CarrotInternal.getLibComponent() != null){
            UserStateHolder.INSTANCE.addRemoveUserObserver(removeObserver);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        UserStateHolder.INSTANCE.removeRemoveUserObserver(removeObserver);
    }
}
