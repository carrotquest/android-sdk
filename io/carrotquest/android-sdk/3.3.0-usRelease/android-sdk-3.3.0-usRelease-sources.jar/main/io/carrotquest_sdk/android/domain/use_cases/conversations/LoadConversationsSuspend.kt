package io.carrotquest_sdk.android.domain.use_cases.conversations

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val loadConversationTag = "LoadConversationsSuspend"

/**
 * Suspend versions of load conversations use cases.
 * Coexist with the RxJava Observable extensions in LoadConversationsUseCase.kt —
 * different signatures (no Observable receiver), no conflict.
 */

suspend fun loadConversations(userId: String) = withContext(Dispatchers.IO) {
    try {
        val response = CarrotInternal.getService().carrotLib
            .getConversationsSuspend(userId)

        val repo = ConversationsRepository.getInstance()
        val conversations = ArrayList<DataConversation>()
        if (response.conversations?.isNotEmpty() == true) {
            conversations.addAll(response.conversations)
        }
        response.meta?.nextAfter?.let { repo.setCurrentAfter(it) }

        for (c in conversations) {
            runCatching {
                val json = Gson().toJson(c)
                c.sourceJsonData = JsonParser.parseString(json).asJsonObject
            }
        }
        repo.saveConversations(conversations)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(loadConversationTag, e)
    }
}

suspend fun loadMoreConversations(userId: String, after: String) = withContext(Dispatchers.IO) {
    try {
        // Пустой курсор = страниц больше нет. Иначе запрос без курсора перезагрузил бы 1-ю страницу.
        if (after.isBlank()) return@withContext

        val response = CarrotInternal.getService().carrotLib
            .getConversationsSuspend(userId, after)

        val repo = ConversationsRepository.getInstance()
        // ВАЖНО: двигаем курсор на следующую страницу. Без этого следующая пагинация грузила бы
        // ту же страницу (дубли отсеивались → новые диалоги не появлялись = «пагинация не работает»).
        repo.setCurrentAfter(response.meta?.nextAfter ?: "")

        val conversations = ArrayList<DataConversation>()
        if (response.conversations?.isNotEmpty() == true) {
            conversations.addAll(response.conversations)
        }
        for (c in conversations) {
            // sourceJsonData проставляем так же, как в loadConversations (UI/билдеры на него опираются).
            runCatching {
                c.sourceJsonData = JsonParser.parseString(Gson().toJson(c)).asJsonObject
            }
            repo.addConversation(c)
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(loadConversationTag, e)
    }
}

suspend fun reloadConversation(conversationId: String): DataConversation? = withContext(Dispatchers.IO) {
    try {
        val response = CarrotInternal.getService().carrotLib
            .getConversationSuspend(conversationId)

        // Раньше .filter{meta!=null && data!=null} отсекал неполный ответ → blockingFirst давал null.
        if (response.meta == null || response.data == null) return@withContext null
        if (response.meta?.error != null) return@withContext null

        val conversation = response.data ?: return@withContext null
        val jsonStr = Gson().toJson(conversation)
        if (jsonStr != null) {
            conversation.sourceJsonData = JsonParser.parseString(jsonStr).asJsonObject
            conversation.partLast?.let { part ->
                part.sourceJsonData = JSONObject(Gson().toJson(part))
            }
            conversation.partLast?.actions?.let { actions ->
                conversation.partLast.actions = actions.onEach { it.messageId = conversation.partLast.id }
            }
        }
        val repo = ConversationsRepository.getInstance()
        if (repo.getConversationById(conversationId) != null) {
            repo.updateConversation(conversationId, conversation)
        } else {
            // Диалога нет в кэше (тикет-диалог: /conversations/ его не отдаёт) — добавляем,
            // иначе getConversationSuspend промахивается на каждый вызов и подписки открытого
            // тикета зацикливают сетевые перезапросы
            repo.addConversation(conversation)
        }
        conversation
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(loadConversationTag, e)
        null
    }
}
