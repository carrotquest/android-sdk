package io.carrotquest_sdk.android.presentation.mvp.web_view;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceResponse;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import com.google.android.gms.common.util.IOUtils;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.core.logging.SdkLogCategory;
import io.carrotquest_sdk.android.core.logging.SdkLogLevel;
import io.carrotquest_sdk.android.core.logging.SdkLogger;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.files.SavedFile;
import io.carrotquest_sdk.android.core.util.Log;

import javax.inject.Inject;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

public class CarrotWebViewPresenter {

    @Inject
    CarrotSdkDB db;

    private CarrotWebView view;
    private final Context context;

    private static final String TAG = "CarrotWebViewPresenter";

    private List<WebViewLoadListener> loadingObservers = new ArrayList<>();
    private boolean pageLoadedSuccessfully = false;
    private int pollGeneration = 0;

    // Тайминги загрузки для диагностики (DEBUG-логи, по умолчанию молчат).
    private long pageStartTime = 0L;
    private long pollStartTime = 0L;

    private static final int WIDGET_CHECK_INTERVAL_MS = 150;
    private static final int WIDGET_CHECK_MAX_ATTEMPTS = 20; // 3 секунды максимум

    CarrotWebViewPresenter(Context context) {
        this.context = context;
    }

    public void attachView(CarrotWebView view) {
        this.view = view;

//        NetworkManager.getInstance(view.getContext())
//                .addObserver(isConnect -> {
//                    if(isConnect) {
//                        view.hideLoadError();
//                    } else {
//                        view.showLoadError();
//                    }
//
//                }, throwable -> Log.e(TAG, throwable), new Action() {
//                    @Override
//                    public void run() throws Exception {
//
//                    }
//                });

    }

    public void detachView() {
        this.view = null;
    }

    void onStartView() {
        //NetworkManager networkManager = NetworkManager.getInstance(this.context);// CarrotLib.getLibComponents(context, new UserRepository(context)).getWssService().getNetworkManager();
        NetworkManager.getInstance(this.context).addObserver(
                isConnect -> {
                    if (view != null) {
                        if (isConnect) {
                            view.hideLoadError();
                            if (!pageLoadedSuccessfully) {
                                view.reloadUrl();
                            }
                        } else {
                            if (NetworkManager.isAirplaneModeOn()) {
                                view.setAirModeErrorContent();
                                view.showAirplaneModError();
                            } else {
                                view.setLoadErrorContent();
                                view.showNoInternetError();
                            }

                        }
                    }
                }
        );
    }

    void onSetColor(int color) {
        view.updateColor(color);
    }

    void onAddLoadingObserver(WebViewLoadListener observer) {
        loadingObservers.add(observer);
    }

    void onPageStarted() {
        pageLoadedSuccessfully = false;
        pollGeneration++;
        pageStartTime = android.os.SystemClock.elapsedRealtime();
        logTiming("page load started");
    }

    private void logTiming(String message) {
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.LIFECYCLE, TAG, message);
    }

    void onPageFinished(boolean pageInError) {
        if (pageInError) {
            // HTTP-ошибка main frame (404/5xx от CDN): показываем экран ошибки с retry.
            // Обсерверов не уведомляем — иначе executeJs уйдёт в мёртвую страницу.
            if (view != null) {
                view.showLoadError();
            }
        } else {
            pageLoadedSuccessfully = true;
            if (pageStartTime != 0L) {
                logTiming("page finished in " + (android.os.SystemClock.elapsedRealtime() - pageStartTime) + "ms");
            }
            pollStartTime = android.os.SystemClock.elapsedRealtime();
            int generation = pollGeneration;
            pollForWidgetReady(0, generation);
        }
    }

    // Сбой загрузки main frame (DNS, обрыв соединения и т.п.).
    void onReceivedError() {
        pageLoadedSuccessfully = false;
        pollGeneration++; // гасим возможный поллинг готовности виджета
        if (view != null) {
            view.showLoadError();
        }
    }

    private void pollForWidgetReady(int attempt, int generation) {
        if (view == null || generation != pollGeneration) return;
        view.checkWidgetReady(value -> {
            if (generation != pollGeneration) return;
            if ("\"ready\"".equals(value) || "ready".equals(value)) {
                logTiming("widget ready after " + attempt + " poll attempts ("
                        + (android.os.SystemClock.elapsedRealtime() - pollStartTime) + "ms)");
                notifyLoadingObservers();
            } else if (attempt < WIDGET_CHECK_MAX_ATTEMPTS) {
                new android.os.Handler(android.os.Looper.getMainLooper())
                        .postDelayed(() -> pollForWidgetReady(attempt + 1, generation), WIDGET_CHECK_INTERVAL_MS);
            } else {
                // таймаут — отправляем всё равно, лучше неудачная попытка, чем ничего
                logTiming("widget ready TIMEOUT after " + attempt + " poll attempts ("
                        + (android.os.SystemClock.elapsedRealtime() - pollStartTime) + "ms), notifying anyway");
                notifyLoadingObservers();
            }
        });
    }

    private void notifyLoadingObservers() {
        try {
            Iterator<WebViewLoadListener> iterator = loadingObservers.iterator();
            while (iterator.hasNext()) {
                try {
                    WebViewLoadListener observer = iterator.next();
                    if (observer != null) {
                        observer.onLoaded(true);
                    }
                } catch (Exception e) {
                    Log.e(TAG, e);
                }
            }
        } catch (ConcurrentModificationException modificationException) {
            Log.e(TAG, modificationException);
        }
    }

    WebResourceResponse shouldInterceptRequest(Uri url) {
        if (url != null) {
            if (!url.toString().contains(BuildConfig.BASE_FILES_URL)
                    && !url.toString().contains("carrotquest.io")
            ) {
                Log.d(TAG, "Запрос со сторонним URL: " + url.toString());
            }

            return overrideResource(url);
        } else {
            return null;
        }
    }

    private WebResourceResponse overrideResource(Uri url) {
        if(context== null) {
            return null;
        }

        String strUri = url.toString().toLowerCase();
        String strICarrotFile = BuildConfig.BASE_FILES_URL.toLowerCase();
        if (strUri.contains(strICarrotFile)) {
            if (db == null) {
                db = CarrotInternal.getLibComponent().getSdkDataBase();
            }
            if (db.savedFileDao() != null) {
                long interceptStart = android.os.SystemClock.elapsedRealtime();
                ContentResolver contentResolver = context.getContentResolver();
                SavedFile localFile = db.savedFileDao().getByURL(strUri);
                File lFile = new File(localFile != null ? localFile.localUri : "");
                if (lFile.exists()) {
                    try {
                        logTiming("intercepted file served from local cache in "
                                + (android.os.SystemClock.elapsedRealtime() - interceptStart) + "ms, url=" + strUri);
                        return new WebResourceResponse(contentResolver.getType(url), "UTF-8", new FileInputStream(lFile));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension((MimeTypeMap.getFileExtensionFromUrl(url.toString())).toLowerCase());
                        if (type != null && type.contains("image")) {
                            // Кэш-промах: картинка качается синхронно прямо в shouldInterceptRequest —
                            // на медленной сети это главный подозреваемый в долгом рендере.
                            File downloadedFile = downloadFile(url);
                            logTiming("intercepted image cache MISS, downloaded synchronously in "
                                    + (android.os.SystemClock.elapsedRealtime() - interceptStart) + "ms, url=" + strUri);
                            if (downloadedFile != null) {
                                return new WebResourceResponse(contentResolver.getType(url), "UTF-8", new FileInputStream(downloadedFile.getAbsolutePath()));
                            }
                        }
                    } catch (FileNotFoundException e) {
                        Log.e("WebViewPresenter", e);
                    } catch (IOException e) {
                        Log.e("WebViewPresenter", e);
                    }
                }
            }
        }
        return null;
    }

    private File downloadFile(Uri url) throws IOException {
        File imagesDirectory = context.getCacheDir();
        boolean directoryIsExist = imagesDirectory.exists();

        URL urlObj = new URL(url.toString());
        URLConnection urlConnection = urlObj.openConnection();
        InputStream urlInput = urlConnection.getInputStream();

        if (directoryIsExist) {
            String localNameFile = String.valueOf(System.currentTimeMillis()) + ".jpg";
            File file = new File(imagesDirectory, localNameFile);
            boolean fileIsExist = file.createNewFile();

            if (fileIsExist) {
                FileOutputStream fileOutputStream = new FileOutputStream(file, false);

                byte[] dataBA = IOUtils.toByteArray(urlInput);
                if (dataBA != null && dataBA.length > 0) {
                    fileOutputStream.write(dataBA);
                }

                urlInput.close();
                fileOutputStream.close();

                //save image info to db
                SavedFile savedFile = new SavedFile(String.valueOf(System.currentTimeMillis()));
                savedFile.localUri = file.getAbsolutePath();
                savedFile.url = url.toString();
                db.savedFileDao().insert(savedFile);

                return file;
            }
        }
        return null;
    }

    void onOpenOutsideUrl(String url) {
        view.openOutsideUrl(url);
    }
}
