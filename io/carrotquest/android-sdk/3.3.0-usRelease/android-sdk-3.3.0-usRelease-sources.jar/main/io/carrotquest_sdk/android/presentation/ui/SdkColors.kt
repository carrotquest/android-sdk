package io.carrotquest_sdk.android.presentation.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils

internal object SdkColors {
    // Фон карточек / поверхностей
    fun background(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFF2F2F2)

    // ── Тикеты ────────────────────────────────────────────────────
    // Стадийные цвета по Figma («Цвета» 5353:11128/11136); status.color бэка игнорируем.
    // Иконки и линии статусов: Новое / В работе / Закрыто
    fun ticketStageColor(stage: io.carrotquest_sdk.android.domain.entities.TicketStage, isDark: Boolean): Color =
        when (stage) {
            io.carrotquest_sdk.android.domain.entities.TicketStage.INITIAL ->
                if (isDark) Color(0xFFFFFFFF) else Color(0xFF333333)
            io.carrotquest_sdk.android.domain.entities.TicketStage.INTERMEDIATE -> Color(0xFFFFBB33)
            io.carrotquest_sdk.android.domain.entities.TicketStage.FINAL -> Color(0xFF66CC66)
        }

    // Текстовые подписи статусов — темнее линий (в тёмной теме — единый набор с линиями)
    fun ticketStageTextColor(stage: io.carrotquest_sdk.android.domain.entities.TicketStage, isDark: Boolean): Color =
        when (stage) {
            io.carrotquest_sdk.android.domain.entities.TicketStage.INITIAL ->
                if (isDark) Color(0xFFFFFFFF) else Color(0xFF333333)
            io.carrotquest_sdk.android.domain.entities.TicketStage.INTERMEDIATE ->
                if (isDark) Color(0xFFFFBB33) else Color(0xFFCC8800)
            io.carrotquest_sdk.android.domain.entities.TicketStage.FINAL ->
                if (isDark) Color(0xFF66CC66) else Color(0xFF339933)
        }

    // Круг под иконкой тикета в карточке списка
    fun ticketCardIconBg(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFFFFFFFF)

    // Незакрашенные сегменты прогресс-бара статуса тикета
    fun ticketEmptyBar(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFE6E6E6)
    // Фон страницы (контейнер)
    fun pageBackground(isDark: Boolean): Color = if (isDark) Color(0xFF333333) else Color(0xFFFFFFFF)
    // Заголовки, основной текст
    fun title(isDark: Boolean): Color = if (isDark) Color(0xFFFFFFFF) else Color(0xFF333333)
    // Вторичный текст, метаданные
    fun secondaryText(isDark: Boolean): Color = if (isDark) Color(0xFFF2F2F2) else Color(0xFF595959)
    // Рамки карточек
    fun cardBorder(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFF2F2F2)
    // Разделитель (линия)
    fun divider(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFE6E6E6)
    // Граница поля ввода сообщения — по макету input (~/Documents/design/input)
    fun inputBorder(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFFE3E5E8)
    // Заливка крестика удаления вложения (бейдж на чипе) — по макету input_4
    fun attachmentRemoveBadge(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFF4D4D4D)
    // Индикатор активного сегмента в табах «Сообщения/Тикеты» (нижняя панель списка)
    fun segmentIndicator(isDark: Boolean, accent: Color): Color =
        if (isDark) Color(0xFF4D4D4D) else accent.copy(alpha = 0.12f)

    /**
     * Текст и иконка сегмента табов. В тёмной теме неактивный сегмент специально приглушён:
     * раньше он был #F2F2F2 против белого активного — на глаз одно и то же, и выбранность
     * держалась только на низкоконтрастной пилюле индикатора.
     */
    fun segmentContent(isDark: Boolean, isSelected: Boolean, accent: Color): Color = when {
        isSelected && isDark -> Color.White
        isSelected -> accent
        isDark -> Color(0xFF999999)
        else -> Color(0xFF595959)
    }

    /**
     * Обводка и текст пилюль тикета — «Дополнить тикет» и кнопок карточки «Ваш вопрос решён?».
     * Светлая тема — акцент приложения, тёмная — нейтральный серый (веб-слоты
     * --supplement-button-*). Один слот на оба компонента: раньше #595959 был литералом в двух
     * файлах, и они могли разъехаться.
     */
    fun ticketPillBorder(isDark: Boolean, accent: Color): Color =
        if (isDark) Color(0xFF595959) else accent

    fun ticketPillContent(isDark: Boolean, accent: Color): Color =
        if (isDark) Color.White else accent
    // Тени нижней панели и плавающей кнопки «Написать» — по макету (Figma):
    // панель — #000 @10%, offset (0,-20), blur 50; кнопка — 0 1 1 @3% + 0 5 7.5 @10%
    val panelShadow: Color = Color.Black.copy(alpha = 0.10f)
    val buttonShadowAmbient: Color = Color.Black.copy(alpha = 0.08f)
    val buttonShadowSpot: Color = Color.Black.copy(alpha = 0.16f)
    // Метка раздела (например, «История»)
    val sectionLabel: Color = Color(0xFF999999)
    // Время сообщения (мета рядом с баблом) — по макету #999999 в обеих темах
    val messageTime: Color = Color(0xFF999999)
    // Бейдж непрочитанных сообщений
    val unreadBadge: Color = Color(0xFFFF3B30)
    // Текст и иконки поверх акцентного цвета шапки/кнопок — чёрные на светлом accent,
    // белые на тёмном. Порог luminance 0.5 совпадает с логикой статус-бара.
    fun onAccent(accent: Color): Color =
        if (ColorUtils.calculateLuminance(accent.toArgb()) > 0.45) Color(0xFF333333) else Color.White
    // Полупрозрачный скрим под шторкой
    val scrim: Color = Color.Black.copy(alpha = 0.25f)
    // Вторичный текст поверх акцентного фона (исходящие сообщения)
    val secondaryOnAccent: Color = Color.White.copy(alpha = 0.7f)
    // Заглушка аватара отправителя
    val avatarPlaceholder: Color = Color(0xFFBDBDBD)
    // Фон карточки файла. Исходящие: акцент, осветлённый белым (альфа 0.1) — чуть светлее бабла.
    // Входящие (по макету): карточка контрастирует с баблом #F2F2F2/#4D4D4D — темнее в светлой
    // теме (#E6E6E6), светлее в тёмной (#595959).
    fun fileCardBg(isDark: Boolean, isOutgoing: Boolean, accent: Color): Color =
        if (isOutgoing) Color(ColorUtils.blendARGB(accent.toArgb(), Color.White.toArgb(), 0.1f))
        else if (isDark) Color(0xFF595959) else Color(0xFFE6E6E6)
    // Фон чипа с датой в списке сообщений
    fun dateChipBg(isDark: Boolean): Color = if (isDark) Color(0xFF2C2C2E) else Color.White
    // Фон карточки статьи из базы знаний
    fun articleCard(isDark: Boolean): Color = if (isDark) Color(0xFF5A5A5A) else Color(0xFFF1F2F4)
    // Рамка карточки оценки оператора
    fun voteBorder(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFE6E6E6)
    // Фон кружков-кнопок оценки
    fun voteButtonBg(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFFF2F2F2)
    // Рамка поля ввода комментария к оценке (светлее рамки карточки в тёмной теме)
    fun commentInputBorder(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFFE6E6E6)
    // Фон поля ввода контактных данных (авто-ответ)
    fun contactInputBg(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color.White
    // Рамка поля ввода контактных данных
    fun contactInputBorder(isDark: Boolean): Color = if (isDark) Color(0xFF737373) else Color(0xFFE6E6E6)
    // Фон блока цитаты (replied_to) в бабле: сдвиг цвета бабла к контрасту ~8% — светлый
    // бабл затемняем, тёмный осветляем. Формула сверена с Figma «Цитирование сообщений»
    // (#F2F2F2→~#E0E0E0, #4D4D4D→~#5B5B5B, акцентные баблы — аналогично от своего цвета).
    fun quoteBg(bubbleColor: Color): Color {
        val toward = if (ColorUtils.calculateLuminance(bubbleColor.toArgb()) > 0.45) Color.Black else Color.White
        return Color(ColorUtils.blendARGB(bubbleColor.toArgb(), toward.toArgb(), 0.08f))
    }
    // Акцентная полоса слева у цитаты: тёмно-серая на светлом бабле, белая на тёмном (Figma).
    // Порог luminance тот же, что в onAccent.
    fun quoteBar(bubbleColor: Color): Color =
        if (ColorUtils.calculateLuminance(bubbleColor.toArgb()) > 0.45) Color(0xFF5C6370) else Color.White
}
