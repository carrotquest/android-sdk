package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import kotlinx.coroutines.withContext

// suspend (ветка remove_rx) — Observable-ext убрана. Обновляет беседу новым сообщением
// (partLast/unread/lastUpdate/sourceJsonData) или догружает беседу, если её нет; затем
// заменяет typing-индикатор на сообщение.
suspend fun addNewMessage(message: MessageData) = withContext(SdkDispatchers.io) {
    val foundConversations = ConversationsRepository.getInstance().getConversationById(message.conversation)
    if (foundConversations != null) {
        if (foundConversations.partLast == null ||
            (foundConversations.partLast.id != message.id
                    && foundConversations.partLast.id != message.randomId
                    && foundConversations.partLast.randomId != message.id
                    && foundConversations.partLast.randomId != message.randomId)
        ) {
            val isOpened = ConversationsRepository.getInstance().getOpenedConversationId() == foundConversations.id
            val unreadPartsCount = if (isOpened) {
                foundConversations.unreadPartsCount
            } else {
                foundConversations.unreadPartsCount + 1
            }

            // lastAdmin обновляем только для реплики ЖИВОГО оператора (reply_admin), как веб
            // (conversationPartsBatch.js пишет last_admin только для type === 'reply_admin'):
            // бот-парты (chat_bot_*, auto_reply и т.п.) несут в from персону бота и затирали
            // бы last_admin тем, чем сервер его не переписывал — превью списка расходилось
            // с вебом. У user-сообщений messageFrom = null — их тоже отсекаем.
            val isFromAdmin = message.direction == ResponseFields.ADMIN_2_USER
                    && message.type == ResponseFields.REPLY_ADMIN
                    && message.messageFrom != null

            foundConversations.unreadPartsCount = unreadPartsCount
            foundConversations.partsCount += 1
            foundConversations.lastUpdate = message.created
            if (isFromAdmin) {
                foundConversations.lastAdmin = message.messageFrom
            }

            val sourceConversation = foundConversations.sourceJsonData
            if (sourceConversation != null) {
                sourceConversation.remove(F.PART_LAST)
                val jsonPartLastString = message.sourceJsonData.toString()
                val jsonPartLast = JsonParser().parse(jsonPartLastString).asJsonObject
                sourceConversation.add(F.PART_LAST, jsonPartLast)

                if (isFromAdmin) {
                    sourceConversation.remove(F.LAST_ADMIN)
                    val adminJson = Gson().toJson(message.messageFrom)
                    sourceConversation.add(F.LAST_ADMIN, JsonParser().parse(adminJson).asJsonObject)
                }

                foundConversations.sourceJsonData = sourceConversation
            }

            ConversationsRepository.getInstance().updateConversation(message.conversation, foundConversations)
        }
    } else {
        // беседы нет в кэше — догружаем с сервера и добавляем
        try {
            val conversation = CarrotInternal.getService().carrotLib
                .getConversationSuspend(message.conversation).data
            if (conversation != null && conversation.id != null) {
                ConversationsRepository.getInstance().addConversation(conversation)
            }
        } catch (e: Exception) {
            Log.e("addNewMessage", e.toString())
        }
    }

    MessagesRepository.getInstance().replaceMessageTyping(message)
}
