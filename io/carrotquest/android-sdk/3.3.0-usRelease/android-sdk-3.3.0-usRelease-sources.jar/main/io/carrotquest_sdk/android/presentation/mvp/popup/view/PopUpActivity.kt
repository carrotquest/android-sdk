package io.carrotquest_sdk.android.presentation.mvp.popup.view

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.PorterDuff
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.DynamicDrawableSpan
import android.text.style.ImageSpan
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver.OnGlobalLayoutListener
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.widget.NestedScrollView
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.js_interface.pop_up.PopUpJSInterface
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.presentation.mvp.popup.presenter.PopUpPresenter
import io.carrotquest_sdk.android.presentation.mvp.web_view.WebViewLoadListener
import kotlin.math.min

class PopUpActivity: AppCompatActivity(), IPopUp {
    companion object {
        const val POP_UP_BLOCKS_ARG = "pop_up_blocks_arg"
        const val POP_UP_ID_ARG = "pop_up_id_arg"
        const val POP_UP_BACKGROUND_ARG = "pop_up_background_arg"

        const val MIN_KEYBOARD_HEIGHT_PX = 150
    }

    private val presenter = PopUpPresenter(this)
    private val tag = this.javaClass.name
    private var initJson = ""

    private var currentScrollY = 0
    private var keyboardHeight = 0
    private var scrollBeforeShowKeyboard = 0

    private val mainPopupScroll = findViewById<NestedScrollView>(R.id.main_popup_scroll)
    private val closePopupButton = findViewById<ImageButton>(R.id.close_popup_btn)
    private val popUpWebView = findViewById<PopUpWebView>(R.id.popup_web_view)
    private val popUpWebViewContainer = findViewById<FrameLayout>(R.id.popup_web_view_container)
    private val poweredByPopPpTextView = findViewById<TextView>(R.id.powered_by_popup_tv)
    private val poweredByMainConstraintLayout = findViewById<ConstraintLayout>(R.id.powered_by_main_cl)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.popup_layout)

        closePopupButton.setOnClickListener { presenter.onTabCloseButton() }

        mainPopupScroll.viewTreeObserver.addOnScrollChangedListener {
            currentScrollY = mainPopupScroll.scrollY
        }

        val decorView = this.window.decorView
        decorView.viewTreeObserver.addOnGlobalLayoutListener(object : OnGlobalLayoutListener {
            private val windowVisibleDisplayFrame = Rect()
            private var lastVisibleDecorViewHeight = 0
            override fun onGlobalLayout() {
                decorView.getWindowVisibleDisplayFrame(windowVisibleDisplayFrame)
                val visibleDecorViewHeight = windowVisibleDisplayFrame.height()
                if (lastVisibleDecorViewHeight != 0) {
                    if (lastVisibleDecorViewHeight > visibleDecorViewHeight + MIN_KEYBOARD_HEIGHT_PX) {
                        if(lastVisibleDecorViewHeight - visibleDecorViewHeight > 0) {
                            keyboardHeight = lastVisibleDecorViewHeight - visibleDecorViewHeight
                        }
                        presenter.onShowKeyboard()
                    } else if (lastVisibleDecorViewHeight + MIN_KEYBOARD_HEIGHT_PX < visibleDecorViewHeight) {
                        presenter.onHideKeyboard()
                    }
                }
                lastVisibleDecorViewHeight = visibleDecorViewHeight
            }
        })

        popUpWebView.addLoadingObserver {
            presenter.onLoaded(initJson)
            popUpWebView.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> Log.d("", "")
                }

                v?.onTouchEvent(event) ?: true
            }
        }
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume(
                if(intent.hasExtra(POP_UP_ID_ARG)) intent.getStringExtra(POP_UP_ID_ARG)!! else "",
                if(intent.hasExtra(POP_UP_BLOCKS_ARG)) intent.getStringExtra(POP_UP_BLOCKS_ARG)!! else "",
                if(intent.hasExtra(POP_UP_BACKGROUND_ARG)) intent.getStringExtra(POP_UP_BACKGROUND_ARG)!! else "")

        resizePopUp()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun updateBackground(color: String) {
        val drawable = resources.getDrawable(R.drawable.cq_popup_bkg)
        drawable.setColorFilter(Color.parseColor(color), PorterDuff.Mode.SRC_ATOP)

        popUpWebViewContainer.background = drawable
        popUpWebView.setBackgroundColor(Color.parseColor(color))
    }

    override fun showContent(contentJson: String) {
        initJson = contentJson
        popUpWebView.initJsInterface(PopUpJSInterface(this@PopUpActivity, presenter, popUpWebView))
        popUpWebView.loadUrl(BuildConfig.POP_UP_URL)

        //popUpWebView.loadUrl("http://192.168.1.63:8080/popup/")
        //popUpWebView.loadUrl("https://cdn.carrotquest.io/external-widget/0.4.26/android/popup/")
    }

    override fun reload() {
        popUpWebView.reloadUrl()
    }

    override fun hideLoading() {
        popUpWebView.post { popUpWebView.hideLoading() }
    }

    override fun showLoadError() {
        setHeight(PopupAlertDialog.ERROR_CONTAINER_HEIGHT_DP)
        popUpWebView.showLoadError()
    }

    override fun getContext(): Context? {
        return this
    }

    override fun setLoadWebViewObserver(loadWebViewObserver: WebViewLoadListener) {
        popUpWebView.addLoadingObserver(loadWebViewObserver)
    }

    override fun closePopUp() {
        finish()
    }

    override fun executeJs(script: String) {
        popUpWebView.executeJsInWebView(script)
    }

    override fun setHeight(h: Int) {
        runOnUiThread {
            val p = Point()
            window.windowManager.defaultDisplay.getSize(p)

            val params = popUpWebViewContainer.layoutParams
            params.height = GraphicUtils.dpToPx(this, h.toFloat() + 30)
            popUpWebViewContainer.layoutParams = params
            popUpWebViewContainer.requestLayout()
        }
    }

    override fun updatePoweredBy(providerName: String, providerIcon: Int) {
        val startText = getString(R.string.popup_powered_by_start_text) + "   "
        val drawableIcon = resources.getDrawable(providerIcon)
        drawableIcon.bounds = Rect(0,0, poweredByPopPpTextView.lineHeight, poweredByPopPpTextView.lineHeight)
        val ssb = SpannableStringBuilder(startText)
        ssb.setSpan(ImageSpan(drawableIcon, DynamicDrawableSpan.ALIGN_BOTTOM), startText.length - 1, startText.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        ssb.append(" $providerName")

        poweredByPopPpTextView.text = ssb
    }

    override fun showPoweredBy() {
        poweredByMainConstraintLayout.visibility = View.VISIBLE
    }

    override fun openLink(url: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(url)
        startActivity(intent)
    }

    override fun updateUpScroll(offsetFocusInput: Int) {
        val decorView = this.window.decorView
        val windowVisibleDisplayFrame = Rect()
        decorView.getWindowVisibleDisplayFrame(windowVisibleDisplayFrame)
        val visibleDecorViewHeight = windowVisibleDisplayFrame.height()

        val yInput = GraphicUtils.dpToPx(this, offsetFocusInput.toFloat()) + popUpWebViewContainer.y
        val y = yInput - visibleDecorViewHeight

        scrollBeforeShowKeyboard = currentScrollY
        //main_popup_scroll.scrollTo(0, currentScrollY + keyboardHeight)
        mainPopupScroll.scrollTo(0, currentScrollY + if(y.toInt() > 0) y.toInt() else 0)
    }

    override fun updateDownScroll() {
        mainPopupScroll.scrollTo(0, scrollBeforeShowKeyboard)
    }

    private fun resizePopUp() {
        val p = Point()
        window.windowManager.defaultDisplay.getSize(p)
        if (p.x > 0) {
            val params = popUpWebViewContainer.layoutParams
            params.width = min(p.x, GraphicUtils.dpToPx(this, 350.0f)) - GraphicUtils.dpToPx(this, 30.0f)
            popUpWebViewContainer.layoutParams = params
        }
    }

    private fun getStatusBarHeight(): Int {
        var result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
        return result
    }
}