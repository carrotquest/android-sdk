package io.carrotquest_sdk.android.domain.use_cases.tickets

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Запрос CSAT-опроса по закрытому тикету (CAR-76310, кнопка «Решён» карточки резолюции).
 *
 * Best-effort, как в вебе: эндпоинт идемпотентен, ошибку глотает CarrotLib (карточка уже
 * скрыта на момент вызова, ретраев не нужно). VOTE-реплика с опросом при успехе прилетает
 * в ленту тикета по RTS — отдельной обработки ответа нет.
 */
suspend fun sendTicketCsat(ticketId: String) = withContext(Dispatchers.IO) {
    if (ticketId.isBlank()) return@withContext
    // Резолв userId как в refreshTickets: настройки гарантированы при включённой фиче
    val userId = SettingsRepository.getInstance().getSettingsObject()?.userId
        ?.takeIf { it.isNotBlank() }
        ?: io.carrotquest_sdk.android.data.user.UserStateHolder.currentId().takeIf { it.isNotEmpty() }
        ?: return@withContext
    CarrotInternal.getService().carrotLib.sendTicketCsatSuspend(userId, ticketId)
}
