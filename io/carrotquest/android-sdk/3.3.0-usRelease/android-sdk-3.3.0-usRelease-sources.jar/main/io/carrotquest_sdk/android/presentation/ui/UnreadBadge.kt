package io.carrotquest_sdk.android.presentation.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Красный бейдж непрочитанных: круг при 1-9, пилюля при многозначных, кап «99+».
 * Единый компонент для карточек/шапки/табов — правило переполнения не должно расходиться
 * между местами показа (бейджи в одном экране обязаны показывать одно и то же число).
 * При count <= 0 не рендерится.
 */
@Composable
internal fun UnreadBadge(
    count: Int,
    modifier: Modifier = Modifier,
    height: Dp = 20.dp,
    fontSize: TextUnit = 10.sp
) {
    if (count <= 0) return
    Box(
        modifier = modifier
            .height(height)
            .widthIn(min = height)
            .clip(CircleShape)
            .background(SdkColors.unreadBadge)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = unreadBadgeLabel(count),
            color = Color.White,
            fontSize = fontSize,
            maxLines = 1
        )
    }
}

/** Подпись бейджа с капом «99+». Чистая функция — единое правило переполнения, покрыта тестом. */
internal fun unreadBadgeLabel(count: Int): String = if (count > 99) "99+" else count.toString()
