package io.carrotquest_sdk.android.presentation.mvp.popup.view

import android.content.Context
import io.carrotquest_sdk.android.presentation.mvp.web_view.WebViewLoadListener

interface IPopUp {
    //TODO change it
    fun showContent(contentJson: String)
    fun setLoadWebViewObserver(loadWebViewObserver: WebViewLoadListener)
    fun closePopUp()
    fun executeJs(script: String)
    
    fun setHeight(h: Int)
    fun updatePoweredBy(providerName: String, providerIcon: Int)
    fun showPoweredBy()
    fun openLink(url: String)
    fun updateUpScroll(offsetFocusInput: Int)
    fun updateDownScroll()
    fun updateBackground(color: String)
    fun reload()

    /** Скрыть индикатор загрузки (вызывается, когда контент поп-апа реально отрисован). */
    fun hideLoading()

    /** Показать экран ошибки загрузки с кнопкой повтора. */
    fun showLoadError()

    fun getContext(): Context?
}