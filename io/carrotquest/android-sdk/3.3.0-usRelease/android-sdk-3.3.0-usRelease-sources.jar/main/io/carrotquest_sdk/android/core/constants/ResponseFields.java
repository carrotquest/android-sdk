package io.carrotquest_sdk.android.core.constants;

import org.jetbrains.annotations.NotNull;

public class ResponseFields {
    public static final String ID = "id";
    public static final String META = "meta";
    public static final String META_DATA = "meta_data";
    public static final String ERROR_MESSAGE = "error_message";
    public static final String CREATED = "created";
    public static final String LAST_ADMIN = "last_admin";
    public static final String LAST_SENDER = "last_sender";
    public static final String LAST_UPDATE = "last_update";
    public static final String PART_LAST = "part_last";
    public static final String PART_LAST_ID = "part_last_id";
    public static final String PARTS_COUNT = "parts_count";
    public static final String UNREAD_PARTS_COUNT = "unread_parts_count";
    public static final String CONVERSATION = "conversation";
    public static final String PARTS = "parts";
    public static final String ASSIGNEE = "assignee";
    public static final String BODY = "body";
    public static final String BODY_JSON = "body_json";
    public static final String DIRECTION = "direction";
    public static final String READ = "read";
    public static final String TYPE = "type";
    public static final String SENT_VIA = "sent_via";
    public static final String REPLY_TYPE = "reply_type";
    public static final String RANDOM_ID = "random_id";
    public static final String CONVERSATION_CLOSED = "conversation_closed";
    public static final String CONVERSATION_TAGS = "conversation_tags";
    public static final String CONVERSATION_ADMIN_UNREAD_COUNT = "conversation_admin_unread_count";
    public static final String CHANNEL = "channel";
    public static final String FROM = "from";
    public static final String EXPIRATION_TIME = "expiration_time";
    public static final String ACTIONS = "actions";

    public static final String ATTACHMENTS = "attachments";

    public static final String ADMIN = "admin";
    public static final String ADMIN_2_USER = "a2u";
    public static final String USER_2_ADMIN = "u2a";

    public static final String REPLY_USER = "reply_user";
    public static final String REPLY_ADMIN = "reply_admin";
    public static final String FILE_TYPE = "file";
    public static final String TYPING = "typing_admin";
    public static final String ARTICLE = "article";
    public static final String MIME_TYPE_IMAGE = "image/png";

    public static final String SDK_ANDROID = "sdk_android";

    public static final String STATUS = "status";
    public static final String ATTACHMENT_ID = "attachment_id";
    public static final String URL = "url";

    public static final String LAST_PART_BODY = "";

    public static final String UNSTRUCTURED_CONVERSATION_LIST = "unstructuredConversationList";

    public static final String AVATAR = "avatar";
    public static final String NAME = "name";
    public static final String VOTE = "vote";
    public static final String AUTO_REPLY = "auto_reply";

    public static final String BLOCKS = "blocks";
    public static final String PARAMS = "params";
    public static final String BACKGROUND_IMAGE = "backgroundImage";
    public static final String BACKGROUND_COLOR = "backgroundColor";
    public static final  String CHAT_BOT_USER = "chat_bot_user";
    public static final  String CHAT_BOT_ADMIN = "chat_bot_admin";

    // Тип action-кнопки в реплике админа, отправленной через public API
    // (POST /conversations/{id}/reply c actions). Не путать с бот-кнопками type="button".
    public static final String ACTION_QUICK_REPLY = "quick_reply";
}
