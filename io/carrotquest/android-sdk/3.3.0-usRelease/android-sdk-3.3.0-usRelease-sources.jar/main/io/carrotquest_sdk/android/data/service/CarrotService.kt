package io.carrotquest_sdk.android.data.service

import io.carrotquest_sdk.android.Callback

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.auth.AuthManager
import io.carrotquest_sdk.android.core.connection.ConnectionManager
import io.carrotquest_sdk.android.core.connection.WssManager
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.init.InitCoordinator
import io.carrotquest_sdk.android.core.init.OperationQueue
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.huawei.isHuawei
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationTypingResponse
import io.carrotquest_sdk.android.data.network.wss_responses.RtsProcessing
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.core.auth.IdentityConsistency
import io.carrotquest_sdk.android.data.user.UserStateHolder
import io.carrotquest_sdk.android.data.user.applyAcceptedIdentity
import io.carrotquest_sdk.android.data.user.clearLegacyUserState
import io.carrotquest_sdk.android.data.user.currentLegacyUser
import io.carrotquest_sdk.android.data.user.clearIdentityKeepTokens
import io.carrotquest_sdk.android.domain.use_cases.user.clearAuthCredentials
import io.carrotquest_sdk.android.domain.use_cases.user.getAuthCredentials
import io.carrotquest_sdk.android.domain.use_cases.user.getAuthedUserIdUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.saveAuthCredentials
import io.carrotquest_sdk.android.domain.use_cases.user.getConnectedUserIdUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.getUserAgent
import io.carrotquest_sdk.android.domain.use_cases.user.saveAuthedUserIdUseCase
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.models.UserProperty
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.lib.utils.AndroidUtils
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.wss.jwt.JwtTokenRefreshService
import io.carrotquest_sdk.android.lib.wss.jwt.clearAllCreds
import io.carrotquest_sdk.android.lib.wss.jwt.getRefreshToken
import io.carrotquest_sdk.android.lib.wss.jwt.getJwtToken
import io.carrotquest_sdk.android.domain.use_cases.agreements.updateAppUserFlags
import io.carrotquest_sdk.android.lib.wss.jwt.clearJwtTokens
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.network.auth.JwtIdentityGuard
import io.carrotquest_sdk.android.lib.wss.jwt.RefreshOutcome
import io.carrotquest_sdk.android.lib.wss.jwt.maskToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlockingDetailed
import io.carrotquest_sdk.android.presentation.mvp.utils.isTablet
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.ResponseBody
import retrofit2.HttpException
import javax.inject.Inject

class CarrotService : ICarrotService {

    @JvmField
    @Inject
    var gson: Gson? = null

    /** Идентификатор аппа */
    private var appId: String? = null
    private var isUseEuServers = false

    /** Общая библиотека для работы с API */
    @JvmField
    var carrotLib: CarrotLib

    // Скоуп всех асинхронных операций сервиса (раньше CompositeDisposable allDisposables +
    // отдельные Disposable). Отменяется в deInit через cancelChildren.
    private val serviceScope = sdkScope(SdkDispatchers.io)

    // Отдельный скоуп для отписки push в deInit — НЕ отменяется teardown'ом (раньше это была
    // standalone-подписка, не добавленная в allDisposables; должна доработать до timeout).
    private val pushScope = sdkScope(SdkDispatchers.io)

    private var authJob: Job? = null

    // Идёт сетевая авторизация. Пока она в полёте, пересоздавать сессию нельзя: ответ auth уже
    // несёт новую личность со свежими токенами, а параллельный token-less /connect оставил бы
    // поверх неё нового анонима — победил бы тот ответ, который пришёл последним.
    @Volatile
    private var isAuthInFlight = false

    // typing-индикатор (раньше typingDisposable/typingDebounceDisposable + startTypingTime).
    @Volatile
    private var startTypingTime: Long? = null
    private var typingJob: Job? = null

    // Поток "оператор печатает" (RTS). PublishSubject → MutableSharedFlow (replay=0) (ветка remove_rx).
    // CarrotService пересоздаётся при re-init, поэтому отдельный onComplete/recreate не нужен.
    private val adminTypingFlow = MutableSharedFlow<ConversationTypingResponse>(extraBufferCapacity = 16)
    val adminTypingEvents: SharedFlow<ConversationTypingResponse> = adminTypingFlow.asSharedFlow()

    // appId nullable: Dagger-модуль может строить сервис до setup() SDK (напр. тап пуша при
    // закрытом приложении → PushTapActivity → trackClick → getService()), тогда appId == null.
    // В Java-оригинале параметр был nullable; Kotlin-порт сделал его non-null → NPE-краш.
    constructor(context: Context, appId: String?, useEuServers: Boolean) {
        this.appId = appId
        this.isUseEuServers = useEuServers
        CarrotInternal.getLibComponent().inject(this)
        instance = this
        carrotLib = CarrotLib(context, isUseEuServers)
    }

    constructor() {
        this.appId = CarrotSDK.getAppId()
        this.isUseEuServers = CarrotSDK.isUseEuApi()
        CarrotInternal.getLibComponent().inject(this)
        carrotLib = CarrotLib(CarrotInternal.getLibComponent().contextSdk, isUseEuServers)
    }

    private val contextSdk: Context get() = CarrotInternal.getLibComponent().contextSdk

    /**
     * Инициализация сервисов (вызов setup()).
     */
    override fun init(apiKey: String, callback: Callback<Boolean>?, startSession: Boolean) {
        // Прежний repo().saveToken("") здесь удалён (CAR-77172, этап 3): он был буггован —
        // персистил в prefs CARROT_USER_ID (не токен!) и тем самым стирал сохранённый id
        // на каждом init, пока UserStateHolder ещё держал восстановленного юзера.
        InitCoordinator.connect(
            appId.orEmpty(), apiKey, carrotLib, startSession, callback,
            // Вызывается по готовности сессии (InitCoordinator.initComplete).
            { initPushesService() },
            {
                startRefreshTokenService()
                reAuthStoredUserIfNeeded()
                // Сессия поднялась: личность (могла восстановиться из prefs) и токены (могли
                // прийти от token-less /connect) обязаны принадлежать одному пользователю.
                IdentityConsistency.checkAndRepairAsync("session-ready")
            },
        )
    }

    override fun deInit() {
        deInit(null)
    }

    fun deInit(onComplete: Runnable?) {
        // Синхронный teardown — нет race window с последующим setup()
        SdkStateManager.onDeInit()
        AuthManager.onDeInit()
        InitCoordinator.abort()
        OperationQueue.cancelAll()
        ConnectionManager.reset()
        WssManager.stop()
        JwtTokenRefreshService.getInstance().stop()

        cancelServiceWork()

        // Обработка RTS-сообщений в полёте — иначе orphan-корутины дописывали данные СТАРОГО
        // пользователя (настройки/диалоги/попапы) в синглтоны уже после teardown.
        RtsProcessing.cancelWork()

        // Ремонт идентичности: отменяем начатый и обнуляем кулдаун/счётчик — следующая сессия
        // начинается с чистым бюджетом попыток, а ремонт «прошлой» личности не должен доработать
        // поверх нового setup().
        IdentityConsistency.reset()

        // Сбрасываем репозитории — singleton'ы держали подписки на старый CarrotService
        // (typing-индикатор) и хранили stale-данные.
        try {
            MessagesRepository.getInstance().deInit()
        } catch (t: Throwable) {
            Log.e(TAG, "MessagesRepository.deInit failed: $t")
        }
        try {
            ConversationsRepository.getInstance().deInit()
        } catch (t: Throwable) {
            Log.e(TAG, "ConversationsRepository.deInit failed: $t")
        }
        try {
            // Настройки предыдущей сессии (включая settings.userId) не должны переживать logout:
            // через них getCurrentUser() воскрешал предыдущего юзера (CAR-77172, этап 4).
            @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
            io.carrotquest_sdk.android.data.repositories.SettingsRepository.getInstance().deInit()
        } catch (t: Throwable) {
            Log.e(TAG, "SettingsRepository.deInit failed: $t")
        }
        // TicketsRepository здесь сознательно НЕ пересоздаётся: его данные чистит clearHistory
        // (reset + инкремент sessionEpoch отбрасывает поздние ответы загрузки), подписок на
        // CarrotService у него нет, а обнуление синглтона оторвало бы живые StateFlow-ссылки
        // у activity-scoped TicketsViewModel.

        // Захватываем userId И auth-токен ДО очистки локального состояния — иначе отписка ниже
        // уходит неаутентифицированной (интерсептор читает креды в момент отправки, а они уже
        // стёрты) и сервер не снимает привязку device↔user → пуши идут прежнему юзеру.
        //
        // ОДНИМ чтением UserStateHolder.current(): id и токен приходят из одного иммутабельного
        // UserEntity — пара не может быть склеена из двух пользователей. Раздельные чтения
        // (currentId() + repo().user.token, где User ещё и мутируется in-place) под гонку с
        // довершающимся auth() могли захватить id старого юзера с токеном нового — IdentityGuard
        // блокировал бы такую отписку (и её persisted-ретраи с той же битой парой) навсегда.
        val userSnapshot = UserStateHolder.current()
        val userId = userSnapshot?.id.orEmpty()
        val deviceId = AndroidUtils.getInstallId(contextSdk)
        val authToken = userSnapshot?.token?.takeIf { it.isNotEmpty() }
            ?: getJwtToken().takeIf { it.isNotEmpty() }
            ?: SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.CARROT_TOKEN)

        // Диагностика согласованности пары: ownersMatch=false означает, что захваченный токен НЕ
        // принадлежит захваченному userId (владельцы декодируются из JWT-клеймов) — такая отписка
        // обречена на 403 absent_scopes, а её pending-ретрай бесполезен. source показывает, откуда
        // пришёл токен (entity-снапшот / prefs-access / легаси CarrotToken). ownersMatch=null —
        // токен не-JWT/нечитаем, guard пропустит (fail-open).
        run {
            val owners = JwtIdentityGuard.tokenOwnerIds(authToken)
            val source = when {
                userSnapshot?.token?.isNotEmpty() == true -> "entity"
                getJwtToken().isNotEmpty() -> "prefs-access"
                else -> "legacy"
            }
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG,
                "deInit: unsubscribe identity captured user=$userId token=${maskToken(authToken)} " +
                    "source=$source ownersMatch=${owners?.contains(userId)} owners=${owners?.size}",
            )
        }

        // Персистим pending-отписку ДО очистки кред: если запрос не дойдёт (таймаут/офлайн/kill),
        // повторим на следующем старте (retryPendingPushUnsubscribe). Очистится при успехе.
        if (userId.isNotEmpty()) {
            SharedPreferencesLib.saveString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_USER_ID, userId)
            SharedPreferencesLib.saveString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_DEVICE_ID, deviceId)
            SharedPreferencesLib.saveString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_TOKEN, authToken ?: "")
        }

        // Синхронная очистка ЛИЧНОСТИ (user.token/id). JWT-креды (access/refresh) НЕ чистим здесь —
        // см. ниже: их нужно оставить живыми до отписки, чтобы интерсептор мог легитимно обновить
        // протухший access по refresh и отписка прошла (иначе 401 отписки → recovery-шторм).
        clearLegacyUserState(contextSdk)
        UserStateHolder.clear()
        // Стор идентичности: личность обнуляется, токены остаются живыми до отписки (см. ниже),
        // epoch двигается — refresh, стартовавший до logout, не воскресит прежнего юзера.
        clearIdentityKeepTokens(contextSdk)
        // Креды авторизации — иначе восстановление сессии вернуло бы уже вышедшего пользователя.
        clearAuthCredentials(contextSdk)

        // Асинхронная отписка push с timeout — onComplete гарантированно стрельнёт.
        // pushScope не отменяется teardown'ом (раньше — standalone .subscribe вне allDisposables).
        logoutUnsubscribeInFlight = true
        pushScope.launch {
            try {
                if (userId.isNotEmpty()) {
                    sendPushUnsubscribe(userId, deviceId, authToken)
                }
                // Чистим persisted JWT-креды ПОСЛЕ отписки (раньше — синхронно ДО, что обесточивало
                // авто-рефреш интерсептора: на 401 отписки refresh уже пуст → token-less ветка →
                // паразитный session-recovery посреди logout). Теперь refresh жив во время отписки,
                // а token-less /connect после этого шага уводит следующий setup в анонима.
                clearJwtTokens(contextSdk)
            } finally {
                logoutUnsubscribeInFlight = false
            }
            // onComplete на main: раньше unsubscribePush имел .observeOn(mainThread). Колбэк делает
            // UI (Toast) и повторный setup() — на фоне это падало и re-setup не выполнялся.
            withContext(SdkDispatchers.main) { onComplete?.run() }
        }
    }

    /**
     * Отправляет отписку push-токена от юзера с ЯВНЫМ auth-токеном (креды к этому моменту уже
     * очищены deInit). При подтверждённом успехе (meta.error == null) снимает pending-запись;
     * иначе оставляет её для повтора на следующем старте. Провал логируется (раньше глотался молча).
     */
    private suspend fun sendPushUnsubscribe(userId: String, deviceId: String, authToken: String?) {
        try {
            val response = withTimeoutOrNull(UNSUBSCRIBE_PUSH_TIMEOUT_SECONDS * 1000) {
                carrotLib.deletePushTokenSuspend(userId, deviceId, "mobile", authToken)
            }
            val ok = response != null && response.meta?.error == null
            if (ok) {
                clearPendingPushUnsubscribe()
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push unsubscribe confirmed for user=$userId")
            } else if (response != null) {
                // Сервер ОТВЕТИЛ ошибкой (401/403 — токен старого юзера мёртв, обновить нечем):
                // повтор с тем же токеном не поможет → ДРОПАЕМ pending, чтобы не досылать вечно
                // на каждом старте (это и кормило recovery-шторм до barrier'а в интерсепторе).
                clearPendingPushUnsubscribe()
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG,
                    "push unsubscribe rejected by server (dropped, no retry): error=${response.meta?.error} hadToken=${!authToken.isNullOrEmpty()}",
                )
            } else {
                // Таймаут (response == null) — сеть медленная/недоступна; pending ОСТАВЛЯЕМ для
                // повтора на следующем старте (retryPendingPushUnsubscribe).
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG,
                    "push unsubscribe timed out (kept for retry) hadToken=${!authToken.isNullOrEmpty()}",
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: io.carrotquest_sdk.android.lib.network.auth.IdentityMismatchException) {
            // Барьер идентичности заблокировал отписку — её user_id не принадлежит владельцу
            // токена, и так будет на КАЖДОМ старте (retryPendingPushUnsubscribe идёт с тем же
            // персистнутым pending). Повтор обречён → дропаем, иначе вечный ERROR BLOCKED в логах.
            clearPendingPushUnsubscribe()
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG,
                "push unsubscribe blocked by identity guard (dropped, no retry): $e",
            )
        } catch (e: java.io.IOException) {
            // Сетевая ошибка — pending оставляем для повтора на старте.
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "push unsubscribe network error (kept for retry): $e")
        } catch (e: Throwable) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "push unsubscribe failed (kept for retry): $e")
        }
    }

    private fun clearPendingPushUnsubscribe() {
        SharedPreferencesLib.clearPreference(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_USER_ID)
        SharedPreferencesLib.clearPreference(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_DEVICE_ID)
        SharedPreferencesLib.clearPreference(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_TOKEN)
    }

    /**
     * Повтор незавершённой отписки на старте SDK: если прошлый deInit не смог подтвердить отписку
     * (таймаут/офлайн/kill процесса), запись сохранилась в prefs — досылаем её здесь. Идёт с
     * сохранённым токеном старого юзера, поэтому не зависит от текущих кред. Вызывается из init.
     */
    fun retryPendingPushUnsubscribe() {
        val userId = SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_USER_ID)
        if (userId.isNullOrEmpty()) return
        val deviceId = SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_DEVICE_ID)
        val token = SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_TOKEN)?.takeIf { it.isNotEmpty() }
        // Диагностика: см. парный лог захвата в deInit — ownersMatch=false объясняет, почему
        // сервер ответит 403 absent_scopes на этот ретрай (токен не принадлежит userId).
        val owners = JwtIdentityGuard.tokenOwnerIds(token)
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG,
            "retrying pending push unsubscribe for user=$userId token=${maskToken(token)} " +
                "ownersMatch=${owners?.contains(userId)} owners=${owners?.size}",
        )
        pushScope.launch {
            sendPushUnsubscribe(userId, deviceId.orEmpty(), token)
        }
    }

    // Cooldown между авто-восстановлениями сессии: серия 403 absent_scopes не должна плодить re-init.
    // elapsedRealtime, не wall clock: перевод часов не должен ломать/раздувать кулдаун.
    @Volatile
    private var lastSessionRecoveryMs = 0L

    // Триггер, пришедший в кулдаун, не дропаем, а коалесцируем в один отложенный повтор.
    @Volatile
    private var recoveryRetryScheduled = false

    /**
     * Авто-восстановление сессии при невосстановимом отказе авторизации: refresh отвергнут ИЛИ
     * 403 `absent_scopes` (токен валиден по времени, но без нужных scopes — refresh выдаёт новый
     * access с теми же scopes и не лечит). Чистим ВСЕ креды + обнуляем auth_token и переигрываем
     * init token-less: `/connect` поднимает свежую сессию с корректными scopes. Раньше это требовало
     * полной выгрузки приложения (только холодный старт чинил). Single-flight (@Synchronized) +
     * cooldown — чтобы шторм 403 не зациклил re-init. Вызывается из [SdkStateManager.notifySessionExpired].
     */
    @Synchronized
    fun recoverSession() {
        // Дешёвый guard (без диска) держим синхронным под @Synchronized, чтобы серия 403 не плодила
        // параллельные recovery. Саму работу (чтение prefs, сброс кред, re-init) уводим с вызывающего
        // потока — recoverSession часто зовётся с сетевого треда OkHttp (через интерсептор), а там
        // нельзя блокировать на дисковом I/O.
        // isInitializing — ПЕРВЫМ: пока идёт init/recovery, любые триггеры бессмысленны
        // (раньше проверка кулдауна стояла раньше и лог врал «cooldown» вместо «initializing»).
        if (SdkStateManager.isInitializing()) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery skipped (already initializing)")
            return
        }
        // Сессии нет (Idle после deInit / Failed init) — «восстанавливать» нечего: token-less
        // re-init здесь поднял бы сессию, которую хост только что выключил (так делал доработавший
        // после deInit ремонт идентичности). Failed лечится своим путём: init-retry и network
        // observer.
        if (!SdkStateManager.isInit()) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery skipped (SDK not ready — deInit'd or failed init)")
            return
        }
        // Авторизация в полёте: её ответ вот-вот принесёт новую личность вместе со свежей парой
        // токенов. Пересоздавать сессию сейчас — значит гонку двух сетевых ответов, где победитель
        // определяется порядком прихода: token-less /connect мог записаться ПОСЛЕ auth и оставить
        // нового анонима поверх только что авторизованного юзера. Триггер не теряем: если auth
        // всё же провалится, следующий 401/403 позовёт recovery снова.
        if (isAuthInFlight) {
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "session recovery skipped (authentication in flight — it brings a fresh identity)",
            )
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val sinceLast = now - lastSessionRecoveryMs
        if (lastSessionRecoveryMs != 0L && sinceLast < SESSION_RECOVERY_COOLDOWN_MS) {
            // Коалесцируем в один отложенный повтор на момент истечения кулдауна: раньше триггер
            // просто дропался, и лечение ждало СЛЕДУЮЩЕГО 401 (иногда — вечного спиннера у юзера).
            if (!recoveryRetryScheduled) {
                recoveryRetryScheduled = true
                val delayMs = SESSION_RECOVERY_COOLDOWN_MS - sinceLast
                serviceScope.launch {
                    kotlinx.coroutines.delay(delayMs)
                    recoveryRetryScheduled = false
                    recoverSession()
                }
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery deferred ${delayMs}ms (cooldown)")
            } else {
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery skipped (cooldown, retry already scheduled)")
            }
            return
        }
        // Офлайн-попытка гарантированно провалится, но раньше сжигала весь 30с бюджет кулдауна —
        // первое лечение после реконнекта блокировалось. Не взводим кулдаун: network observer
        // (см. init-блок) запустит recovery, когда сеть реально появится.
        if (!NetworkManager.getInstance(contextSdk).isNetworkAvailable()) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG, "session recovery deferred: no network (cooldown NOT armed)")
            return
        }
        lastSessionRecoveryMs = now

        serviceScope.launch {
            runSessionRecovery()
        }
    }

    /**
     * Появилась сеть (вызывается network-observer'ом [CarrotSDK]): сбрасываем кулдаун recovery —
     * офлайн-попытки не должны блокировать первое лечение после реконнекта. Если сессия
     * деградировала (SDK Ready, но кредов нет — их вычистил интерсептор после мёртвого refresh),
     * network-observer её не лечит (гейт !isInit), а 401-триггер может прийти нескоро —
     * запускаем recovery сразу.
     */
    fun onNetworkRestored() {
        lastSessionRecoveryMs = 0L
        val noCreds = getRefreshToken(contextSdk).isNullOrEmpty() &&
            UserStateHolder.currentToken().isEmpty()
        if (noCreds && SdkStateManager.isInit()) {
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "network restored with empty creds while Ready — triggering session recovery",
            )
            recoverSession()
        }
    }

    private fun runSessionRecovery() {
        val apiKey = SharedPreferencesLib.getString(contextSdk, "api_key")
        if (apiKey.isNullOrEmpty()) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "session recovery aborted: no stored api_key")
            return
        }
        SdkLogger.log(
            SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
            "session recovery: clearing creds and re-initializing with token-less /connect",
        )

        // Token-less: чистим JWT/refresh И обнуляем user.token (=auth_token обычных запросов),
        // чтобы /connect пошёл анонимно и сервер выдал новую сессию с правильными scopes.
        clearAllCreds(contextSdk)

        // Лёгкий reset (НЕ полный deInit — репозитории/подписки чата не трогаем): сбрасываем
        // connect-ретраи и переводим state в Idle, чтобы InitCoordinator.onInitStarted прошёл.
        // RTS НЕ останавливаем здесь явно: init→initComplete→WssManager.start() сам сделает stop()+
        // start() со свежим токеном. (Лишний WssManager.stop() здесь дал бы преждевременный
        // NetworkManager.deInit, рубящий сетевые observers открытого диалога.)
        ConnectionManager.reset()
        SdkStateManager.onDeInit()

        // Token-less /connect поднимет НОВОГО анонима; вернуть пользователя в его идентичность
        // берётся reAuthStoredUserIfNeeded() — он вызывается по готовности сессии (см. init).
        init(apiKey, null, true)
    }

    /**
     * Переигрывает авторизацию сохранёнными кредами, когда сессия поднялась заново.
     *
     * Нужно после любого token-less /connect: и после [runSessionRecovery], и после фоллбека
     * ConnectionManager на 401/403 — оба выдают НОВОГО анонима. Без этого пользователь молча
     * оставался анонимом до следующего auth() со стороны хоста, а на бэкенде копились анонимы
     * и «склейка» выглядела сломанной.
     *
     * Лишней сети не создаёт: [performAuth] сам пропускает сетевой вызов, если connect вернул
     * того же пользователя, которым мы уже авторизованы (shouldSkipAuth).
     */
    private fun reAuthStoredUserIfNeeded() {
        // Хостовый auth уже запущен или ждёт готовности сессии в OperationQueue — он и определит
        // идентичность. Запускать поверх него реавторизацию нельзя: authUser()/hashedAuth()
        // начинаются с authJob?.cancel(), и внутренний вызов отменил бы свежий запрос хоста,
        // оставив пользователя под СТАРОЙ сохранённой личностью (штатный паттерн интеграции —
        // setup() и сразу auth()). Обратное направление безопасно: хостовый auth, пришедший позже,
        // сам отменит внутренний job — побеждает явный запрос хоста.
        if (authJob?.isActive == true) {
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "stored-user re-auth skipped — host auth is already in flight/queued (it defines the identity)",
            )
            return
        }
        val credentials = runCatching { getAuthCredentials(contextSdk) }.getOrNull() ?: return
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "session is ready — restoring the authenticated user (hashed=${credentials.isHashed})",
        )
        if (credentials.isHashed) {
            hashedAuth(credentials.externalId, credentials.secret, null)
        } else {
            authUser(credentials.externalId, credentials.secret, null)
        }
    }

    override fun isInit(): Boolean = SdkStateManager.isInit()

    override fun authUser(id: String, userAuthKey: String) {
        authUser(id, userAuthKey, null)
    }

    override fun authUser(id: String, userAuthKey: String, callback: Callback<User>?) {
        authJob?.cancel()
        authJob = serviceScope.launch {
            OperationQueue.execute {
                performAuth(id, userAuthKey, isHashed = false, getAuthUserObserver = callback) {
                    carrotLib.authSuspend(id, userAuthKey)
                }
            }
        }
    }

    override fun hashedAuth(id: String, hash: String, callback: Callback<User>?) {
        authJob?.cancel()
        authJob = serviceScope.launch {
            OperationQueue.execute {
                performAuth(id, hash, isHashed = true, getAuthUserObserver = callback) {
                    carrotLib.hashedAuthSuspend(id, hash)
                }
            }
        }
    }

    override fun setUserProperty(userProperty: List<UserProperty>) {
        OperationQueue.enqueue { setUserPropertySimple(userProperty) }
    }

    fun setUserPropertySimple(userProperty: List<UserProperty>) {
        serviceScope.launch {
            try {
                carrotLib.setPropertySuspend(userProperty)
                Log.d(TAG, "onNext setUserProperty")
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, e)
            }
        }
    }

    override fun setUserProperty(userProperty: List<UserProperty>, callback: Callback<Boolean>) {
        val prefix = "Set user property: "
        serviceScope.launch {
            try {
                OperationQueue.execute { carrotLib.setPropertySuspend(userProperty) }
                withContext(SdkDispatchers.main) { callback.onResponse(true) }
                Log.d(TAG, prefix + "onComplete")
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, prefix + "error: " + e)
                withContext(SdkDispatchers.main) { callback.onFailure(e) }
            }
        }
    }

    override fun trackEvent(eventName: String, eventParams: String?, callback: Callback<NetworkResponse>) {
        OperationQueue.enqueue { trackEventSimple(eventName, eventParams, callback) }
    }

    fun trackEventSimple(eventName: String, eventParams: String?, callback: Callback<NetworkResponse>) {
        serviceScope.launch {
            try {
                val r = carrotLib.trackEventSuspend(eventName, eventParams)
                withContext(SdkDispatchers.main) { callback.onResponse(r) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                withContext(SdkDispatchers.main) { callback.onFailure(e) }
            }
        }
    }

    // getConversations×2 / getConversation observer-методы удалены (ветка remove_rx):
    // единственный потребитель (old/UserRepository.java) был закомментирован; чтение бесед
    // идёт через ConversationsRepository / use-case suspend.

    // Мёртвые observer-методы удалены (ветка remove_rx): startConversations×2/getMessage/
    // reply/replyFile — потребители используют carrotLib.*Suspend / use-case suspend напрямую.

    override fun trackClickByPush(conversationId: String, callback: Callback<Boolean>) {
        serviceScope.launch {
            try {
                carrotLib.trackInteractionSuspend(conversationId, "clicked")
                withContext(SdkDispatchers.main) { callback.onResponse(true) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, e.toString())
                withContext(SdkDispatchers.main) { callback.onFailure(e) }
            }
        }
    }

    // Мёртвые observer-методы удалены (ветка remove_rx): markConversationAsRead/voteOperator×2/
    // updateAutoReply — голосование и mark-read идут через use-case suspend (SendVoteOperatorUseCase,
    // markConversationAsRead suspend) напрямую.

    // downloadF/downloadFile(Observer) удалены — мёртвые (чат качает через FileDownloadRepository
    // на корутинах/OkHttp; downloadFileUseCase не вызывался). Download* остаётся только для
    // кэша картинок попапа (DownloadUtil.downloadFilesToCash).

    override fun setTyping(conversationId: String, messageBody: String) {
        if (!SdkStateManager.isInit()) return

        // Лидирующий throttle: пинг typing-индикатора на первом символе и далее не чаще раза
        // в TYPING_THROTTLE_MS, пока пользователь печатает.
        // Раньше здесь была вторая ветка через Observable.just(true).debounce(2s); из-за
        // just(true)+onComplete «дебаунс» эмитил немедленно (таймер не срабатывал) и слал
        // дубликат запроса на каждый символ. Ветка удалена (remove_rx ревью, L3) — поведение
        // изменено: backend получает пинг не чаще раза в 2с вместо одного на символ.
        val now = System.currentTimeMillis()
        if (now - (startTypingTime ?: 0L) < TYPING_THROTTLE_MS) return
        if (typingJob?.isActive == true) return

        startTypingTime = now
        typingJob = serviceScope.launch(SdkDispatchers.main) {
            try {
                carrotLib.setTypingSuspend(conversationId, messageBody)
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, e.toString())
            }
        }
    }

    override fun getSaveUserId(): String = UserStateHolder.currentId()

    // Мёртвый observer-метод chooseRoutingBot удалён (ветка remove_rx) — бот идёт через
    // loadRoutingBot/chooseRoutingBotSuspend напрямую.

    private fun initPushesService() {
        try {
            // Досылаем незавершённую отписку прошлого юзера ДО подписки текущего — если прошлый
            // deInit не подтвердил её (таймаут/офлайн/kill). Идёт с сохранённым токеном.
            retryPendingPushUnsubscribe()

            if (isHuawei()) return

            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "initPushesService: FCM token fetch failed: ${task.exception?.message}")
                    return@addOnCompleteListener
                }

                val notificationManager = NotificationManagerCompat.from(contextSdk)
                if (task.result != null && notificationManager.areNotificationsEnabled()) {
                    val token = task.result
                    val deviceId = AndroidUtils.getInstallId(contextSdk)
                    sendPushToken(token, deviceId)
                }
            }
        } catch (eIllegalState: IllegalStateException) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "initPushesService: Firebase unavailable", eIllegalState)
        } catch (e: Exception) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "initPushesService failed", e)
        }
    }

    /**
     * user_id НЕ принимается параметром намеренно: он читается непосредственно перед сетевым
     * вызовом. Раньше id захватывался заранее (в FCM-колбэке или на стороне вызывающего) и
     * переживал несколько асинхронных хопов — OperationQueue.execute ждёт готовности SDK и может
     * подвиснуть на время re-init/recovery. За это время идентичность успевала смениться, и запрос
     * уходил с путём users/{старый id}/pushes_subscribe при живом токене нового юзера — сервер
     * отвечал 403 PermissionDeniedError (прод-баг «склейка не работает»).
     */
    fun sendPushToken(token: String?, deviceId: String) {
        if (token.isNullOrEmpty()) return
        serviceScope.launch {
            try {
                OperationQueue.execute {
                    val sUserAgent = getUserAgent()
                    val deviceType = if (isTablet(contextSdk)) "tablet" else "phone"
                    val device = if (isHuawei()) "Huawei [huawei_push] 1.0.0" else "Android"
                    val sdkVersion = CarrotSDK.getVersion()
                    val browser = "sdk " + (sdkVersion ?: "")
                    val userId = UserStateHolder.currentId()
                    if (userId.isEmpty()) {
                        SdkLogger.log(
                            SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG,
                            "sendPushToken skipped: no current user (session is being (re)created)",
                        )
                        return@execute
                    }
                    val res = carrotLib.sendPushTokenSuspend(token, deviceId, "mobile", deviceType, device, browser, sUserAgent)
                    SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push token sent to backend")
                }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.PUSH, TAG, "sendPushToken failed", e)
            }
        }
    }

    fun adminTyping(pair: ConversationTypingResponse) {
        adminTypingFlow.tryEmit(pair)
    }

    fun startRefreshTokenService() {
        // Переподключение сокетов при обновлении JWT обрабатывает сам JwtWssService.
        JwtTokenRefreshService.getInstance().start()
    }

    /**
     * Единая точка записи данных аутентифицированного юзера. Обёрнуто в try-блоки по каждой
     * записи, чтобы частичный сбой одного холдера не порушил остальные.
     */
    private fun persistAuthedUser(tempUser: User, authedId: String, refreshToken: String?) {
        // Токен берём из tempUser.token — в него уже подставлен data.auth_token.access
        // (см. performAuth). Сохраняем ЗДЕСЬ, а не в AuthDeserializer: парсер не должен менять
        // глобальное состояние до того, как ответ применён.
        val access = tempUser.token
        if (access.isNullOrEmpty()) {
            // Личность записана, а токена для неё нет — ровно то состояние, в котором барьер
            // идентичности блокирует всё до переустановки. Громко логируем и оставляем ремонт
            // вызывающему: performAuth после применения ответа проверит инвариант и полечит.
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "persistAuthedUser: auth response carried NO access token for user=${tempUser.id} — " +
                    "identity written without a matching token, repair will be triggered",
            )
        }
        try {
            // Атомарная тройка + синк легаси-хранилищ (old repo → UserStateHolder → prefs).
            // Пустой access = подтверждение личности без новой пары: текущие токены стора остаются.
            applyAcceptedIdentity(
                contextSdk,
                tempUser,
                access?.takeIf { it.isNotEmpty() },
                refreshToken?.takeIf { it.isNotEmpty() },
            )
        } catch (e: Exception) {
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "persistAuthedUser failed: $e — identity may not match the stored token",
            )
        }
        try {
            saveAuthedUserIdUseCase(authedId, tempUser.id, contextSdk)
        } catch (e: Exception) {
            Log.e(TAG, "persistAuthedUser.saveAuthedId: $e")
        }
    }

    /** Обновляет JWT-токен, если протух (под shared lock, на IO). */
    private suspend fun refreshTokenIfNeeded() {
        if (isActualJwtToken(contextSdk)) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "refreshTokenIfNeeded: access actual → no pre-auth refresh")
            return
        }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "refreshTokenIfNeeded: access NOT actual → refreshing before auth")
        withContext(SdkDispatchers.io) {
            // Детальная версия вместо refreshJwtTokenBlocking: та схлопывает Rejected и NotAttempted
            // в один null, а чистить токены можно ТОЛЬКО при реальном серверном отказе. NotAttempted
            // (token-less, недавний отказ в негативном кэше) — не приговор кредам: auth ниже сам
            // разберётся с тем, что есть. Сетевая ошибка (IOException) пробрасывается из blocking.
            when (val outcome = refreshJwtTokenBlockingDetailed(null)) {
                is RefreshOutcome.Success -> {
                    // user.token уже синхронизирован внутри refresh-юзкейса (saveRefreshedTokens/фолбэк).
                    SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "refreshTokenIfNeeded: refreshed access before auth (no new lead)")
                }
                is RefreshOutcome.NotAttempted -> {
                    SdkLogger.log(
                        SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                        "refreshTokenIfNeeded: refresh not attempted (${outcome.reason}) — creds left intact, continuing auth as is",
                    )
                }
                RefreshOutcome.Rejected -> {
                    // Сервер отверг refresh → оба токена мертвы. Чистим протухшие persisted креды:
                    // дальнейший auth всё равно упадёт 403, но persisted-состояние станет чистым,
                    // и на следующем /connect (перезапуск приложения) сессия восстановится анонимом
                    // без переустановки.
                    SdkLogger.log(
                        SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                        "refreshTokenIfNeeded: refresh dead (both tokens expired) → clearing creds, will fall back to anonymous on next /connect",
                    )
                    clearJwtTokens(contextSdk)
                }
            }
        }
    }

    /**
     * Общее ядро авторизации (performAuth/performHashedAuth отличались только вызовом
     * carrotLib.auth vs hashedAuth — параметризовано authCall).
     */
    private suspend fun performAuth(
        id: String,
        secret: String,
        isHashed: Boolean,
        getAuthUserObserver: Callback<User>?,
        // Ремонт идентичности: сетевой auth нужен, даже если shouldSkipAuth считает его лишним.
        // В залипшем состоянии (личность одна, токен другой) именно этот гейт глушил единственный
        // путь к правильному токену — «склейка не работает, лечится переустановкой».
        force: Boolean = false,
        authCall: suspend () -> io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse
    ) {
        if (!SdkStateManager.isInit()) return

        val connectedUserId = getConnectedUserIdUseCase(contextSdk)
        val authedUserIds = getAuthedUserIdUseCase(contextSdk)
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "performAuth: externalId=$id, connectedUserId=$connectedUserId, storedAuthedIds=$authedUserIds, force=$force",
        )
        if (!force && shouldSkipAuth(id, connectedUserId, authedUserIds)) {
            // Уже авторизованы тем же id и connect вернул того же пользователя — сеть не нужна.
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "performAuth: SKIP network auth — already authed (connectedUserId==authedUserId)")
            getAuthUserObserver?.let { obs ->
                val user = currentLegacyUser()
                withContext(SdkDispatchers.main) { obs.onResponse(user) }
            }
            return
        }

        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "performAuth: running network auth (will refresh access first if not actual)")
        isAuthInFlight = true
        try {
            refreshTokenIfNeeded()
            val response = authCall()
            // Креды успешной авторизации — чтобы восстановление сессии (token-less /connect, которое
            // выдаёт нового анонима) могло само вернуть пользователя в его идентичность.
            saveAuthCredentials(id, secret, isHashed, contextSdk)
            // NonCancellable: склейка на сервере УЖЕ выполнена, и её токен пришёл в этом ответе.
            // Отмена authJob (её делает любой следующий authUser/hashedAuth) между сетевым вызовом
            // и применением ответа теряла новый токен навсегда: клиент оставался с токеном прежней
            // личности, а бэкенд на повторный auth отвечает «уже склеено» и токена не даёт.
            withContext(NonCancellable + SdkDispatchers.main) {
                val data = response.data
                if (data?.user != null) {
                    val tempUser = data.user
                    // Авторитетный источник access — data.auth_token.access. Вложенное
                    // data.user.auth_token (бэкенд его сейчас не присылает) не обязано ему
                    // соответствовать, а раньше побеждало: непустое значение оттуда попадало
                    // и в user.token, и в глобальный JWT, затирая правильный access.
                    if (!data.authToken.isNullOrEmpty()) {
                        tempUser.token = data.authToken
                    }
                    persistAuthedUser(tempUser, id, data.refreshToken)

                    // Смена пользователя (аноним→authed): переносим флаги согласий из ответа app_auth
                    // в sourceData настроек. Без этого buildConsentState читал флаги предыдущего юзера
                    // (аноним, не давал согласие) → плашка согласия показывалась повторно.
                    val consentFlags = buildMap {
                        data.dataProcessingPolicyIsAllowed?.let { put("data_processing_policy_is_allowed", it) }
                        data.emailStorageIsAllowed?.let { put("email_storage_is_allowed", it) }
                        data.phoneStorageIsAllowed?.let { put("phone_storage_is_allowed", it) }
                    }
                    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.NETWORK, "UserConsent") {
                        "auth: applying consent flags to settings=$consentFlags"
                    }
                    updateAppUserFlags(consentFlags)
                } else if (data != null && "not_need" == data.result) {
                    // Раньше здесь перезакреплялась пара externalId→UserStateHolder.currentId(). При
                    // рассинхроне это цементировало чужую личность: в AUTHED_SDK_USER_ID попадал
                    // id анонима, после чего shouldSkipAuth навсегда выключал сетевой auth — тот
                    // самый «auth не работает, лечится переустановкой». Ответ «не нужно» id не
                    // содержит, поэтому сохранённое соответствие НЕ трогаем.
                    SdkLogger.log(
                        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                        "performAuth: server says auth not needed — stored externalId→userId mapping left as is",
                    )
                }

                val user = currentLegacyUser()
                // Подгрузка бесед после auth (раньше — getConversations(observer)): отдельная
                // корутина, чтобы performAuth не ждал сеть и сразу шёл к initPushesService().
                serviceScope.launch {
                    try {
                        OperationQueue.execute { carrotLib.getConversationsSuspend(user.id) }
                        withContext(SdkDispatchers.main) {
                            getAuthUserObserver?.onResponse(user)
                            WssManager.start(appId.orEmpty(), user.id.orEmpty())
                        }
                    } catch (e: Throwable) {
                        withContext(SdkDispatchers.main) { getAuthUserObserver?.onFailure(e) }
                    }
                }

                initPushesService()
            }
            // Личность применена — токен обязан ей принадлежать. Если нет (ответ пришёл без
            // auth_token, запись токена упала, ответ был «not_need»), сессия остаётся с токеном
            // прежней личности, и все запросы users/{id}/... будут заблокированы барьером до
            // переустановки. Проверяем и лечим здесь, а не ждём первого отказа.
            IdentityConsistency.checkAndRepairAsync("post-auth")
        } catch (c: CancellationException) {
            throw c
        } catch (e: Throwable) {
            authError(e)
            withContext(SdkDispatchers.main) { getAuthUserObserver?.onFailure(e) }
        } finally {
            isAuthInFlight = false
        }
    }

    /**
     * Повторная авторизация сохранёнными кредами для ремонта идентичности — принудительная
     * (force), в обход shouldSkipAuth. Возвращает false, если кредов нет (лечить нечем).
     */
    internal suspend fun reAuthForIdentityRepair(): Boolean {
        // Хостовый auth в полёте/в очереди — он и определит идентичность (возможно, ДРУГУЮ:
        // authUser(новый id)). Ремонт идёт мимо authJob, поэтому без этого гейта два сетевых auth
        // (сохранённые креды vs свежие хостовые) гонялись бы за право записать личность —
        // побеждал бы пришедший последним. Тот же гейт стоит в reAuthStoredUserIfNeeded.
        if (authJob?.isActive == true) {
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "identity repair re-auth skipped — host auth is in flight (it defines the identity)",
            )
            return false
        }
        val credentials = runCatching { getAuthCredentials(contextSdk) }.getOrNull() ?: return false
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "identity repair: forcing re-auth with stored credentials (hashed=${credentials.isHashed})",
        )
        val id = credentials.externalId
        val secret = credentials.secret
        if (credentials.isHashed) {
            performAuth(id, secret, isHashed = true, getAuthUserObserver = null, force = true) {
                carrotLib.hashedAuthSuspend(id, secret)
            }
        } else {
            performAuth(id, secret, isHashed = false, getAuthUserObserver = null, force = true) {
                carrotLib.authSuspend(id, secret)
            }
        }
        return true
    }

    private fun authError(e: Throwable) {
        if (e is HttpException) {
            val code = e.code()
            try {
                val responseBody: ResponseBody? = e.response()?.errorBody()
                val body = responseBody?.string() ?: ""
                // Раньше тело 403/401 читалось и молча отбрасывалось — отсюда "логов почти нет".
                // Логируем реальную причину отказа сервера (invalid hash / token expired / forbidden и т.п.).
                // ВАЖНО: здесь токены НЕ чистим. К моменту authError TokenRefreshInterceptor уже пытался
                // обновить access по refresh-токену. Если refresh был жив — токены валидны, и 401/403
                // означают НЕ-токеновую причину (например, неверный hash). Чистить креды здесь нельзя:
                // это уничтожило бы валидный refresh и заставило бы зря создавать нового анонима.
                // Сброс кредов делается только там, где /refresh реально провалился (interceptor /
                // refreshTokenIfNeeded / ConnectionManager).
                SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "authError: HTTP $code body=$body")

                // Сервер отверг сами креды (неверный/протухший hash) — забываем их, иначе
                // reAuthStoredUserIfNeeded() слал бы заведомо провальный auth на каждой
                // инициализации. Типичный случай: приложение не открывали месяцами, токены
                // умерли, сессия поднялась анонимной, а сохранённый hash давно недействителен.
                // Авторизацию всё равно инициирует хост — он рассчитывает свежий hash.
                if (code == 401 || code == 403) {
                    SdkLogger.log(
                        SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                        "auth credentials rejected by server — dropping them, the host app will provide fresh ones",
                    )
                    runCatching { clearAuthCredentials(contextSdk) }
                }
            } catch (npe: NullPointerException) {
                Log.e(TAG, npe)
            } catch (e1: Exception) {
                Log.e(TAG, e1)
            }
        }
        Log.e(TAG, e)
    }

    /** Отмена всех асинхронных операций сервиса (раньше deInitDisposables). */
    private fun cancelServiceWork() {
        authJob?.cancel()
        typingJob?.cancel()
        serviceScope.coroutineContext.cancelChildren()
        // adminTypingFlow не требует сброса: CarrotService пересоздаётся при re-init, а подписчик
        // (MessagesRepository) отменяет свой collect в своём deInit.
    }

    override fun setUserConsentContact(contacts: String, userId: String, partId: String, callback: Callback<Boolean>) {
        serviceScope.launch {
            // Причину неуспеха фиксируем ЗДЕСЬ — выше по стеку доступен только Boolean, и
            // сбой user_consent был полностью молчаливым (согласие терялось без следа).
            // Значения контактов не логируем (PII) — только ключи.
            val contactKeys = runCatching {
                com.google.gson.JsonParser.parseString(contacts).asJsonObject.keySet().joinToString(",")
            }.getOrDefault("?")
            try {
                val r = carrotLib.setUserConsentContactSuspend(contacts, partId, userId)
                val error = r.meta?.error
                if (error != null) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                        "user_consent contact rejected: error=$error status=${r.meta?.status} keys=$contactKeys partId=$partId"
                    }
                }
                withContext(SdkDispatchers.main) { callback.onResponse(error == null) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                    "user_consent contact request failed: $e keys=$contactKeys partId=$partId"
                }
                withContext(SdkDispatchers.main) { callback.onResponse(false) }
            }
        }
    }

    override fun setUserConsentDataProcessing(dataProcessing: Boolean?, userId: String, callback: Callback<Boolean>) {
        serviceScope.launch {
            try {
                val r = carrotLib.setUserConsentDataProcessingSuspend(dataProcessing, userId)
                val error = r.meta?.error
                if (error != null) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                        "user_consent data_processing rejected: error=$error status=${r.meta?.status}"
                    }
                }
                withContext(SdkDispatchers.main) { callback.onResponse(error == null) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                    "user_consent data_processing request failed: $e"
                }
                withContext(SdkDispatchers.main) { callback.onResponse(false) }
            }
        }
    }

    companion object {
        private const val TAG = "CarrotService"
        private const val UNSUBSCRIBE_PUSH_TIMEOUT_SECONDS = 5L

        // Отписка пушей второй фазы deInit ещё в полёте (тот же процесс). Пока она жива, setup()
        // НЕ должен стирать JWT-креды по pending-записи (clearInterruptedLogoutCreds): фаза 2
        // сама вычистит их после отписки, а стирание сейчас обесточило бы её авто-рефреш —
        // 401 отписки → pending дропнут → устройство осталось бы привязанным к прежнему юзеру.
        // Гард нужен только для kill-кейса: в новом процессе маркер false.
        @JvmStatic
        @Volatile
        var logoutUnsubscribeInFlight: Boolean = false
            private set
        // Минимальный интервал между авто-восстановлениями сессии (см. recoverSession).
        private const val SESSION_RECOVERY_COOLDOWN_MS = 30_000L
        // Минимальный интервал между пингами typing-индикатора (лидирующий throttle).
        private const val TYPING_THROTTLE_MS = 2000L

        /**
         * Авторизацию по сети можно пропустить, если мы уже авторизованы тем же внешним id и
         * connect вернул того же пользователя, что сохранён как authed. Чистая функция — вынесена
         * из performAuth для тестируемости.
         *
         * @param id               внешний id, переданный в auth()
         * @param connectedUserId  carrot-id, полученный при последнем connect (может быть null)
         * @param authedUserIds    [authedExternalId, authedCarrotUserId] из хранилища (может быть null)
         */
        @JvmStatic
        internal fun shouldSkipAuth(id: String, connectedUserId: String?, authedUserIds: List<String>?): Boolean {
            if (authedUserIds != null && authedUserIds.size == 2) {
                val authedId = authedUserIds[0]
                val authedUserId = authedUserIds[1]
                return authedId == id && connectedUserId != null && connectedUserId == authedUserId
            }
            return false
        }

        private var instance: CarrotService? = null

        @JvmStatic
        fun getInstance(): CarrotService {
            return instance ?: CarrotService().also { instance = it }
        }
    }
}
