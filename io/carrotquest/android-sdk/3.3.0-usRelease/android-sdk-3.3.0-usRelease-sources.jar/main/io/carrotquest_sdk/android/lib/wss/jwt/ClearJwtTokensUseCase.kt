package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

private const val TAG = "TokenFlow"

/**
 * Полностью сбрасывает persisted JWT-креды, чтобы следующий /connect начал свежую сессию.
 *
 * Важно: чистим не только новые JWT-ключи, но и легаси "CarrotToken". Легаси-ключ переживал
 * прежние частичные очистки токенов (ConnectionManager чистил только jwt/refresh) и мог
 * "воскрешать" мёртвый токен через refresh-fallback в RetrofitModule.paramAdds, а также через
 * UserRepository.loadUser(). Из-за этого протухшая авторизация залипала до переустановки —
 * после сброса достаточно перезапуска приложения.
 */
fun clearJwtTokens(context: Context = CarrotLib.getLibComponents().getContext()) {
    SdkLogger.log(
        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
        "clearJwtTokens: wiping access+refresh+CarrotToken. Before: ${tokenStateSummary()}",
    )
    // Токены чистит стор — атомарно (память + prefs одной транзакцией) и с инкрементом epoch:
    // refresh убитой пары, который ещё летит, будет отброшен CAS'ом (CAR-77172).
    io.carrotquest_sdk.android.data.user.UserIdentityStore.clearTokens(context)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN)
}

/**
 * Хвост прерванного logout (CAR-77172, этап 4). Если жива pending-запись отписки пушей,
 * значит предыдущий deInit не дошёл до своей второй фазы (clearJwtTokens после отписки) —
 * процесс убили в окне, и на диске остались живые JWT-креды уже вышедшего юзера. Без этой
 * чистки restoreFromPrefs на следующем setup воскрешал бы его сессию. Самой отписке эти
 * ключи не нужны: retryPendingPushUnsubscribe идёт с ЯВНЫМ токеном из pending-записи.
 */
fun clearInterruptedLogoutCreds(context: Context) {
    val pendingUserId = SharedPreferencesLib.getString(
        context, SharedPreferenceKeys.PENDING_UNSUB_USER_ID,
    )
    if (pendingUserId.isNullOrEmpty()) return
    SdkLogger.log(
        SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
        "interrupted logout detected (pending unsubscribe for user=$pendingUserId) — " +
            "wiping leftover creds before restore",
    )
    clearJwtTokens(context)
}

/**
 * Полный сброс кред для пересоздания сессии: [clearJwtTokens] + обнуление легаси user.token.
 *
 * [clearJwtTokens] НАМЕРЕННО не трогает user.token (он подставляется как `auth_token` обычных
 * запросов в RetrofitModule.paramAdds). Поэтому каждый, кто хочет «полностью сбросить авторизацию»,
 * обязан дополнительно обнулить его, иначе следующий /connect/запрос уйдёт со старым
 * auth_token. Раньше этот двухшаговый идиом был скопирован в 4 местах и норовил разъехаться —
 * собрано здесь в одну точку. С этапа 3 (CAR-77172) user.token живёт в UserStateHolder.
 */
fun clearAllCreds(context: Context = CarrotLib.getLibComponents().getContext()) {
    clearJwtTokens(context)
    io.carrotquest_sdk.android.data.user.UserStateHolder.current()?.let { user ->
        io.carrotquest_sdk.android.data.user.UserStateHolder.update(user.copy(token = ""))
    }
}
