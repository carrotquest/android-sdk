package io.carrotquest_sdk.android.domain.entities

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData

/**
 * Стадия тикета. Статусы на бэке — произвольные записи аппа (имена/цвета кастомизируемы),
 * клиент группирует их в 3 стадии по флагам is_initial/is_final. Все стадийные цвета/подписи
 * UI строит от стадии, НЕ от status.color бэка (веб делает так же).
 */
enum class TicketStage { INITIAL, INTERMEDIATE, FINAL }

/** is_final приоритетнее is_initial (как isFinalStatus в вебе). */
fun ticketStageOf(isInitial: Boolean, isFinal: Boolean): TicketStage = when {
    isFinal -> TicketStage.FINAL
    isInitial -> TicketStage.INITIAL
    else -> TicketStage.INTERMEDIATE
}

data class TicketStatusEntity(
    val id: String,
    // Имя статуса с бэка КАК ЕСТЬ (CAR-76566): упрощение intermediate до «В работе» делает
    // бэкенд по настройке аппа; клиентский fallback — только на пустое имя intermediate
    val name: String,
    val stage: TicketStage,
    // Цвет статуса с бэка ("#RRGGBB"); UI использует его ТОЛЬКО для INTERMEDIATE
    // (initial/final — стадийные цвета темы)
    val colorHex: String? = null
)

/**
 * Патч закрытости тикета из RTS ticket/updated (CAR-76310). Выделен в объект, чтобы
 * updateTicket отличал «событие несёт закрытость» (в т.ч. закономерный null closedAt
 * у переоткрытого) от «данных нет — сохранить прежнее» (старый бэк).
 */
data class TicketClosedPatch(
    val closedAtMillis: Long?,
    val isReopenable: Boolean
)

/**
 * Тикет в домене. Источник — GET /users/{id}/tickets (include_conversation=true)
 * или патчи из RTS-канала ticket.
 */
data class TicketEntity(
    val id: String,
    val shortId: Int?,
    val title: String,
    val status: TicketStatusEntity,
    /** null — тикет без диалога (nullable OneToOneField на бэке): экран без ленты/инпута */
    val conversationId: String?,
    /** Последнее сообщение диалога — для превью карточки; null у свежесозданных тикетов */
    val partLast: MessageData?,
    /** Непрочитанные сообщения карточки (unread_parts_count — то же поле использует веб) */
    val unreadCount: Int,
    val createdMillis: Long?,
    val dueDateMillis: Long?,
    /** Для сортировки: conversation.last_update (unix), fallback — created тикета */
    val lastUpdateMillis: Long?,
    /**
     * Момент закрытия (CAR-76310). Инвариант бэка: != null ⟺ стадия FINAL. Вместе с id тикета —
     * ключ состояния карточки «Ваш вопрос решён?»: новое закрытие меняет ключ, вопрос показывается снова.
     */
    val closedAtMillis: Long? = null,
    /**
     * Можно ли переоткрыть закрытый тикет (сообщение авто-переоткроет его на бэке).
     * false — легаси-тикет или старый бэк без поля → read-only. ТОЛЬКО серверная истина:
     * не выводить на клиенте (появится тайм-аут финального закрытия — поле станет false молча).
     */
    val isReopenable: Boolean = false
)
