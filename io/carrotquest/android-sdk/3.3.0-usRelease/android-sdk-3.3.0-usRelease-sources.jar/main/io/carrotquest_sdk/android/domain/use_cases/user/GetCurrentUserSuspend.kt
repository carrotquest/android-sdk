package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.repositories.UserRepository
import io.carrotquest_sdk.android.data.user.applyAcceptedIdentity
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.lib.CarrotLib
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val TAG = "GetCurrentUserSuspend"

/**
 * Suspend version of getCurrentUser. Returns the cached user if available,
 * otherwise fetches from API and caches the result.
 *
 * Coexists with the RxJava extension [Observable<T>.getCurrentUser()] —
 * different signatures, no conflict.
 */
suspend fun getCurrentUser(): UserEntity? = withContext(Dispatchers.IO) {
    val cached = UserRepository.getInstance().getUserSync()
    if (cached != null && cached.id.isNotEmpty()) return@withContext cached

    val settings = SettingsRepository.getInstance().getSettingsObject()
        ?: return@withContext null

    try {
        val user = CarrotInternal.getService().carrotLib
            .getUserSuspend(settings.userId)

        // Через воронку: раньше здесь обновлялся ТОЛЬКО UserStateHolder, минуя старый
        // репозиторий и prefs, — одно из мест рассинхрона идентичности (CAR-77172).
        // access=null: это перевыборка того же юзера, JWT-пара стора не меняется.
        applyAcceptedIdentity(
            runCatching { CarrotLib.getLibComponents().context }.getOrNull(),
            user,
            access = null,
            refresh = null,
        )
        UserEntity(
            id = user.id,
            token = user.token,
            hasConversations = user.hasConversations,
            isBanned = user.isBanned,
            conversationsUnread = user.conversationsUnread ?: emptyList()
        )
    } catch (e: Exception) {
        Log.e(TAG, e)
        null
    }
}
