package io.carrotquest_sdk.android.presentation.tickets

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.SdkColors

/**
 * Карточка резолюции закрытого переоткрываемого тикета (CAR-76310), над скрытым инпутом.
 * Веб-эталон — cqstatic ticket-resolution-prompt/Ui.svelte:
 * - оценка оператора включена (messenger_vote) → карточка «Ваш вопрос решён?» с кнопками
 *   [Решён][Нет, не решён];
 * - выключена → БЕЗ карточки, одна полноширинная кнопка «Мой вопрос не решён» в стиле
 *   «Дополнить тикет» (ветка «Решён» вела бы к CSAT-опросу, которого не будет, а вход
 *   в переоткрытие остаться обязан);
 * - «Не решён» → подсказка «Напишите сообщение — тикет вернётся в работу оператору».
 * Состояние (QUESTION/PROMPT/HIDDEN) держит вызывающий — см. [ticketResolutionUiState].
 */
@Composable
internal fun TicketResolutionPrompt(
    state: TicketResolutionUiState,
    isVoteEnabled: Boolean,
    accentColor: Color,
    isDark: Boolean,
    onResolved: () -> Unit,
    onNotResolved: () -> Unit
) {
    when (state) {
        TicketResolutionUiState.QUESTION -> if (isVoteEnabled) {
            ResolutionCard(isDark) {
                Text(
                    text = stringResource(R.string.ticket_resolution_question),
                    color = SdkColors.title(isDark),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                // height(IntrinsicSize.Min) + fillMaxHeight: у кнопок разная длина подписи, и на
                // узком экране (или крупном fontScale) «Нет, не решён» переносится в две строки —
                // без общей высоты пара выглядела ступенькой.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ResolutionButton(
                        text = stringResource(R.string.ticket_resolution_resolved),
                        accentColor = accentColor,
                        isDark = isDark,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onClick = onResolved
                    )
                    ResolutionButton(
                        text = stringResource(R.string.ticket_resolution_not_resolved),
                        accentColor = accentColor,
                        isDark = isDark,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onClick = onNotResolved
                    )
                }
            }
        } else {
            // Оценка выключена — единственная полноширинная кнопка без карточки-обёртки,
            // визуально повторяет «Дополнить тикет»
            ResolutionButton(
                text = stringResource(R.string.ticket_resolution_not_resolved_only),
                accentColor = accentColor,
                isDark = isDark,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                onClick = onNotResolved
            )
        }

        TicketResolutionUiState.PROMPT -> ResolutionCard(isDark) {
            Text(
                text = stringResource(R.string.ticket_resolution_prompt),
                color = SdkColors.title(isDark),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        TicketResolutionUiState.HIDDEN -> Unit
    }
}

@Composable
private fun ResolutionCard(
    isDark: Boolean,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .border(1.dp, SdkColors.cardBorder(isDark), RoundedCornerShape(12.dp))
            .padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        content()
    }
}

@Composable
private fun ResolutionButton(
    text: String,
    accentColor: Color,
    isDark: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    // Слоты те же, что у «Дополнить тикет» — обе пилюли обязаны выглядеть одинаково
    val contentColor = SdkColors.ticketPillContent(isDark, accentColor)
    val borderColor = SdkColors.ticketPillBorder(isDark, accentColor)

    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = contentColor)
    ) {
        Text(
            text = text,
            // Одна типографика с «Дополнить тикет» (15sp/Medium): кнопки стоят на одном месте
            // экрана и подменяют друг друга по стадии тикета — разный вес бросался в глаза.
            // maxLines = 2: «Нет, не решён» на узком экране/крупном fontScale переносится,
            // и без ограничения кнопки в паре получали разную высоту.
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            textAlign = TextAlign.Center
        )
    }
}
