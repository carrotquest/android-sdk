package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.core.constants.ResponseFields;

public class ConversationReadMessage implements IRtsMessage {

    @SerializedName(ResponseFields.ID)
    public String id;

    @Override
    public void process() {

    }
}
