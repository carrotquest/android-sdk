package io.carrotquest_sdk.android.lib.managers

import android.util.Log
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.F
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class UserPresenceService private constructor() {

    private var isRun = false
    private val scope = sdkScope(SdkDispatchers.io)
    // Периодическая отправка ONLINE (раньше Observable.interval + disposable).
    private var presenceJob: Job? = null
    // Разовая отправка ONLINE при старте (раньше firstDisposable).
    private var firstJob: Job? = null

    companion object {
        private const val TAG = "UserPresenceService"
        private const val PRESENCE_INTERVAL_MS = 30_000L
        private var instance: UserPresenceService? = null
        fun getInstance(): UserPresenceService {
            if (instance == null) {
                instance = UserPresenceService()
            }
            return instance!!
        }
    }

    // Ошибка отправки presence некритична — раньше onErrorReturn(status=400) просто проглатывался.
    // user_id не передаём: запрос идёт на users/$self_user/setpresence, сервер резолвит юзера по
    // токену. Раньше id захватывался один раз в run() и переживал смену идентичности — тик через
    // 30с уходил с путём старого юзера и токеном нового (403 PermissionDeniedError).
    private suspend fun sendPresence(presence: String) {
        // Кредов нет совсем (token-less после сброса сессии): запрос гарантированно словит 401 и
        // зря разгонит 401→recovery-каскад. Пропускаем тик — после успешного /connect креды
        // появятся, и следующий тик уйдёт как обычно.
        val hasCreds = io.carrotquest_sdk.android.data.user.UserStateHolder.currentToken().isNotEmpty() ||
            io.carrotquest_sdk.android.lib.wss.jwt.getRefreshToken() != null ||
            io.carrotquest_sdk.android.lib.wss.jwt.getJwtToken().isNotEmpty()
        if (!hasCreds) {
            Log.w(TAG, "presence skipped: no credentials (token-less session)")
            return
        }
        try {
            CarrotLib.getLibComponents().carrotApi.setPresence(presence)
        } catch (c: CancellationException) {
            // Отмена корутины (stop()/повторный run() при reconnect/deInit отменяют in-flight
            // presence) — это НЕ ошибка. Пробрасываем, иначе ломаем структурную конкурентность и
            // зашумляем логи ERROR-ом JobCancellationException на каждом старте.
            throw c
        } catch (t: Throwable) {
            Log.e(TAG, "$t")
        }
    }

    fun run() {
        if (isRun) {
            stop()
        } else {
            sendEventAboutStop()
        }
        isRun = true

        // Гейт «есть ли кому слать» проверяется в sendPresence по кредам (hasCreds), а не по
        // захваченному id: id больше не участвует в запросе.
        firstJob = scope.launch { sendPresence(F.ONLINE_USER) }
        presenceJob = scope.launch {
            while (isActive) {
                delay(PRESENCE_INTERVAL_MS)
                sendPresence(F.ONLINE_USER)
            }
        }
    }

    private fun sendEventAboutStop() {
        scope.launch { sendPresence(F.OFFLINE_IDLE_USER) }
    }

    fun stop() {
        isRun = false
        presenceJob?.cancel()
        presenceJob = null
        firstJob?.cancel()
        firstJob = null
    }
}
