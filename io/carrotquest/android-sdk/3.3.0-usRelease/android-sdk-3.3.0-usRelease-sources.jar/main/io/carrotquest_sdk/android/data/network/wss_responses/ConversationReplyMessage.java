package io.carrotquest_sdk.android.data.network.wss_responses;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;

import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.core.constants.Flags;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.repositories.MessagesRepository;
import io.carrotquest_sdk.android.data.user.UserStateHolder;
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsAllHelper;
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage;

public class ConversationReplyMessage extends MessageData implements IRtsMessage {

    public Boolean conversationClosed = false;

    private MessagesRepository messagesRepository;
    private ConversationsRepository conversationsRepository;

    public ConversationReplyMessage(MessageData messageData) {
        this.setId(messageData.getId());
        this.setBody(messageData.getBody());
        this.setActions(messageData.getActions());
        this.setRandomId(messageData.getRandomId());
        this.setReplyType(messageData.getReplyType());
        this.setSentVia(messageData.getSentVia());
        this.setType(messageData.getType());
        this.setRead(messageData.getRead());
        this.setDirection(messageData.getDirection());
        this.setBodyJson(messageData.getBodyJson());
        this.setConversation(messageData.getConversation());
        this.setCreated(messageData.getCreated());
        this.setMessageMetaData(messageData.getMessageMetaData());
        this.setMessageFrom(messageData.getMessageFrom());
        this.setAttachments(messageData.getAttachments());
        this.setExpirationTime(messageData.getExpirationTime());
        this.setFirst(messageData.isFirst());
        this.setSourceJsonData(messageData.getSourceJsonData());
        this.setStatus(messageData.getStatus());
        this.setRemoved(messageData.getRemoved());
        this.setConversationType(messageData.getConversationType());
    }

    @Override
    public void process() {
        if (conversationsRepository == null) {
            conversationsRepository = ConversationsRepository.Companion.getInstance();
        }
        if (messagesRepository == null) {
            messagesRepository = MessagesRepository.Companion.getInstance();
        }

        //TODO: LEAD_BOT
//        if("lead_bot".equals(this.getConversationType())) {
//            return;
//        }

        if ((getRead() == null || !getRead())
                && (conversationClosed == null || !conversationClosed)
                && messagesRepository != null) {
            if (fromAdminToUser() || isInputBotAction() || isButtonsBotAction()) {
                // Апдейт непрочитанных — через UserStateHolder (CAR-77172, этап 3; раньше —
                // мутация User + old/UserRepository.saveUser; ветка else на случай
                // userRepository == null была пустой и удалена вместе с репозиторием).
                if (!getConversation().equals(conversationsRepository.getOpenedConversationId())
                        && !Flags.NEW_CONVERSATION_ID_ARG.equals(conversationsRepository.getOpenedConversationId())
                ) {
                    UserStateHolder.INSTANCE.markConversationUnread(
                            CarrotInternal.getLibComponent().getContextSdk(), getConversation());
                }

                // Первую ветку routing-бота рисует шаблон chooseRoutingBot — её серверные
                // части (is_first_branch) не вливаем, см. MessageData.isFirstBranchPart.
                if (this.getBodyJson() != null && this.getBodyJson().isJsonObject()
                        && !this.isFirstBranchPart()) {
                    messagesRepository.addWssMessage(this);
                }

                messagesRepository.updateMessage(this);
            } else {
                // Отложенное обновление сообщения: даём 2с (как раньше Single.delay), затем
                // обновляем на главном потоке. Rx-цепочка → Handler.postDelayed.
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> messagesRepository.updateMessage(this), 2000);
            }

        }

        IncomingMessage.DirectionMessage directionMessage = IncomingMessage.DirectionMessage.USER_TO_ADMIN;
        if (ResponseFields.ADMIN_2_USER.equals(getDirection())) {
            directionMessage = IncomingMessage.DirectionMessage.ADMIN_TO_USER;
        }

        IncomingMessage.MessageType messageType = IncomingMessage.MessageType.TEXT;
        if (getAttachments() != null && getAttachments().size() > 0) {
            messageType = IncomingMessage.MessageType.ATTACHMENT;
        }

        Log.d("ClientWebSocket", "Body = " + getBody());

        IncomingMessage message = new IncomingMessage(IncomingMessage.IncomingMessageSourceType.RTS, getId(), getConversation(), getBody(), directionMessage, messageType);
        NotificationsAllHelper.getInstance().pushMessage(message);
    }

    private boolean isInputBotAction() {
        if ("message_chat_bot".equals(this.getSentVia()) && this.getActions() != null && this.getActions().size() > 0) {
            ActionMessage firstAction = this.getActions().get(0);
            return "property_field".equals(firstAction.getType());
        }

        return false;
    }

    private boolean isButtonsBotAction() {
        if ("message_chat_bot".equals(this.getSentVia()) && this.getActions() != null && this.getActions().size() > 0) {
            ActionMessage firstAction = this.getActions().get(0);
            return "button".equals(firstAction.getType());
        }

        return false;
    }

    private boolean fromAdminToUser() {
        return getDirection() != null && ResponseFields.ADMIN_2_USER.equals(getDirection().toLowerCase());
    }
}