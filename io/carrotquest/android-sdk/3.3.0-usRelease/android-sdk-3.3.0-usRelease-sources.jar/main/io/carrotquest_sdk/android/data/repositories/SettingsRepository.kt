package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.countries.GetDefaultRegionUseCase
import io.carrotquest_sdk.android.domain.use_cases.countries.SaveCountryRegionUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first

class SettingsRepository {
    // Заменяет BehaviorSubject.create() (ветка remove_rx, фаза 4): replay=1 реплеит последние
    // настройки новым подписчикам и не эмитит до первого saveSettings — как BehaviorSubject.create().
    private val currentSettingsFlow = MutableSharedFlow<SettingsEntity>(replay = 1, extraBufferCapacity = 1)

    // @Volatile: читается из main/IO без лока (getSettingsObject), пишется под writeLock.
    @Volatile
    private var settings: SettingsEntity? = null

    // Сериализует ВСЕ записи настроек: полная перезапись (saveSettings из /connect) и
    // read-modify-write (updateSettings). Без него два конкурентных copy()-апдейта строились
    // на одном снапшоте и тихо теряли друг друга (consent-флаги vs statusOperators).
    private val writeLock = Any()

    companion object {
        @Volatile
        private var instance : SettingsRepository? = null
        // double-checked locking — как в ConversationsRepository/MessagesRepository:
        // без него гонка могла создать два инстанса (saveSettings в один, чтение из другого).
        fun getInstance(): SettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: SettingsRepository().also { instance = it }
            }
        }
    }

    // Непрерывный поток настроек (раньше Observable-мост getSettings(); remove_rx).
    // Реплеит последние настройки новому подписчику (replay=1), не эмитит до первого saveSettings.
    fun settingsChangesFlow(): Flow<SettingsEntity> = currentSettingsFlow.asSharedFlow()

    // suspend-эквивалент getSettings().awaitFirstOrNull(): ждёт первую (реплеенную) эмиссию.
    // currentSettingsFlow никогда не завершается, поэтому возвращает только реальные настройки
    // (как awaitFirstOrNull на never-completing Observable — null фактически не приходит).
    suspend fun awaitSettings() : SettingsEntity = currentSettingsFlow.first()

    fun getLastSettings() : SettingsEntity? {
        return currentSettingsFlow.replayCache.firstOrNull()
    }

    fun saveSettings(settings: SettingsEntity) = synchronized(writeLock) {
        saveLocked(settings)
    }

    /**
     * Атомарный read-modify-write: [transform] получает актуальные настройки и возвращает новые —
     * чтение и запись происходят под одним локом, конкурентная запись не может вклиниться между
     * ними и потеряться. Использовать вместо пары getSettings()+saveSettings() везде, где новые
     * настройки строятся из текущих (copy с правкой поля).
     *
     * Возврат ТОГО ЖЕ инстанса из [transform] — «менять нечего»: сохранения и эмиссии в
     * settingsChangesFlow не будет (коллекторы не получат дубль).
     *
     * @return результат [transform], либо null если настроек ещё нет (transform не вызывался).
     */
    fun updateSettings(transform: (SettingsEntity) -> SettingsEntity): SettingsEntity? =
        synchronized(writeLock) {
            val current = settings ?: return null
            val updated = transform(current)
            if (updated !== current) saveLocked(updated)
            updated
        }

    private fun saveLocked(settings: SettingsEntity) {
        this.settings = settings
        currentSettingsFlow.tryEmit(settings)

        //save current country
        val locale = settings.locale
        if(locale.isNotEmpty()) {
            val region = GetDefaultRegionUseCase().call(locale)
            SaveCountryRegionUseCase().call(region)
        }
    }

    fun getSettingsObject() = this.settings

    /**
     * Сброс на deInit / server-side удаление юзера (CAR-77172, этап 4). Раньше настройки
     * (включая settings.userId) переживали logout, и getCurrentUser() после deInit заново
     * выкачивал и кэшировал ПРЕДЫДУЩЕГО юзера. Чистим и replay-кэш: awaitSettings/getLastSettings
     * не должны отдавать настройки прошлой сессии; следующий /connect наполнит заново.
     */
    @kotlinx.coroutines.ExperimentalCoroutinesApi
    fun deInit() = synchronized(writeLock) {
        settings = null
        currentSettingsFlow.resetReplayCache()
    }
}