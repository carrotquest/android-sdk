package io.carrotquest_sdk.android.domain.use_cases.tickets

import io.carrotquest_sdk.android.domain.entities.TicketEntity
import io.carrotquest_sdk.android.domain.entities.TicketStatusEntity
import io.carrotquest_sdk.android.domain.entities.ticketStageOf
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketData
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketStatusData
import io.carrotquest_sdk.android.lib.network.responses.tickets.TicketDates

/**
 * DTO → домен. Возвращает null только для тикета без id. Отсутствующий статус —
 * INTERMEDIATE-заглушка с пустым именем (UI покажет «В работе»), как в вебе:
 * бэк гарантирует не-null статус (include_removed), но RTS/старые данные могут прислать null.
 */
fun TicketData.toTicketEntity(): TicketEntity? {
    val ticketId = id?.takeIf { it.isNotBlank() } ?: return null
    val statusData = status ?: TicketStatusData()

    val createdMillis = TicketDates.parseIsoToMillis(created)
    // conversation.last_update — unix-СЕКУНДЫ строкой (Gson коэрсит число в String)
    val lastUpdateMillis = conversation?.lastUpdate?.toLongOrNull()?.times(1000)
        ?: createdMillis

    return TicketEntity(
        id = ticketId,
        shortId = shortId,
        title = title ?: "",
        status = TicketStatusEntity(
            id = statusData.id ?: "",
            name = statusData.name ?: "",
            stage = ticketStageOf(statusData.isInitial, statusData.isFinal),
            colorHex = statusData.color
        ),
        conversationId = conversation?.id,
        partLast = conversation?.partLast,
        // Источник unread карточки — unread_parts_count (как в вебе)
        unreadCount = conversation?.unreadPartsCount ?: 0,
        createdMillis = createdMillis,
        dueDateMillis = TicketDates.parseIsoToMillis(dueDate),
        lastUpdateMillis = lastUpdateMillis,
        closedAtMillis = TicketDates.parseIsoToMillis(closedAt),
        isReopenable = isReopenable
    )
}
