package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.core.CarrotState
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.popUpMessageFromConversation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

private const val TAG = "EnsurePopUpDownloaded"

// Сколько ждём connect'а после тапа по пушу на холодном старте. Дольше — бессмысленно: pref
// need_show_popup_conv_id персистентный, и поп-ап покажет downloadPopUps при следующем connect'е.
private const val SDK_READY_TIMEOUT_MS = 15_000L

// Пауза после connect'а на холодном старте: downloadPopUps сохраняет поп-апы через 2 с после ответа.
private const val COLD_START_GRACE_MS = 3_000L

// Процессный скоуп: PushTapActivity — noHistory и уничтожается сразу после запуска хоста, её
// lifecycleScope отменил бы работу на первом же suspend. Пишем в PopUpDao, поэтому не
// SdkDetachedWorkScope (он только для задач без записи в кэши SDK).
private val ensureScope = sdkScope(SdkDispatchers.io)

/**
 * Тап по пушу поп-апа: гарантирует, что поп-ап окажется в [PopUpDao], — дальше его подхватит
 * штатный конвейер показа (Room Flow → SdkApp.handlePopUps → need_show_popup_conv_id → showPopup
 * поверх активити хоста).
 *
 * На холодном старте поп-ап докачает downloadPopUps на connect'е, и этот вызов ничего не добавит.
 * Нужен он для «тёплого» кейса: процесс жив, connect уже был, WSS в фоне закрыт — поп-ап не пришёл
 * ни по RTS, ни через downloadPopUps, и без докачки показать его нечем.
 */
fun ensurePopUpDownloaded(conversationId: String) {
    ensureScope.launch {
        try {
            val wasReady = SdkStateManager.publicState.value is CarrotState.Ready
            if (!wasReady) {
                val state = withTimeoutOrNull(SDK_READY_TIMEOUT_MS) {
                    SdkStateManager.publicState.first { it is CarrotState.Ready || it is CarrotState.Failed }
                }
                if (state !is CarrotState.Ready) {
                    SdkLogger.log(
                        SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG,
                        "sdk not ready ($state), pop-up $conversationId will be shown after next connect",
                    )
                    return@launch
                }
                // Холодный старт: connect только что прошёл, downloadPopUps сохранит поп-ап сам
                // (с задержкой 2 с) — даём ему шанс, чтобы не гонять loadConversations дважды.
                delay(COLD_START_GRACE_MS)
            }
            if (getPopUpEntity(conversationId) != null) return@launch

            val conversation = getConversationSuspend(conversationId)
            val popUp = conversation?.let { popUpMessageFromConversation(it) }
            if (popUp == null) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "no pop-up content for conversation $conversationId")
                return@launch
            }
            saveNewPopUp(popUp)
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.PUSH, TAG, "ensurePopUpDownloaded($conversationId) failed", t)
        }
    }
}
