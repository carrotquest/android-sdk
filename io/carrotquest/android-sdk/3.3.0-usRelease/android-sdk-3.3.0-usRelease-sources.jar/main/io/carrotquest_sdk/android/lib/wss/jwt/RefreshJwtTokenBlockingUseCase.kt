package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import kotlinx.coroutines.runBlocking

private const val TAG = "TokenFlow"

// Shared lock — serializes all callers (timer + HTTP 401 interceptor).
internal val refreshLock = Any()

// Негативный кэш провала (под refreshLock): серверный отказ /refresh с теми же кредами не имеет
// смысла повторять немедленно — конкурентные 401 (presence/parts/logs) плодили по сетевому
// /refresh на каждого ждущего. Снапшот сбрасывается, когда креды меняются (recovery/connect
// сохранил новую пару) — легитимный повтор проходит сразу.
private const val REFRESH_REJECT_CACHE_MS = 10_000L
private var lastRefreshRejectAtMs = 0L
private var lastRefreshRejectSnapshot: String? = null

/**
 * Исход попытки обновить токен. Раньше все три случая сливались в `null`, и вызывающий код
 * трактовал их одинаково — как «refresh-токен мёртв» → сброс всех кред → token-less /connect,
 * то есть НОВЫЙ анонимный пользователь поверх авторизованного. Но «мы даже не сходили в сеть»
 * (нет кредов, недавний отказ в негативном кэше) — это не приговор кредам.
 */
internal sealed class RefreshOutcome {
    data class Success(val access: String) : RefreshOutcome()

    /** Сервер отверг refresh-токен: креды действительно мертвы, сессию надо пересоздавать. */
    object Rejected : RefreshOutcome()

    /** Попытки не было. Креды трогать НЕЛЬЗЯ — они могут быть полностью валидны. */
    data class NotAttempted(val reason: String) : RefreshOutcome()
}

/**
 * Синхронно обновляет JWT-токен. Безопасно при конкурентных вызовах:
 * если пока мы ждали lock другой поток уже обновил токен — возвращаем готовый.
 *
 * Обёртка над [refreshJwtTokenBlockingDetailed] для вызывающих, которым достаточно «токен или нет».
 * Тем, кто по результату решает судьбу кред, нужна детальная версия.
 *
 * @param failedToken токен, с которым запрос получил 401 (null для timer-based refresh)
 */
internal fun refreshJwtTokenBlocking(failedToken: String? = null): String? =
    (refreshJwtTokenBlockingDetailed(failedToken) as? RefreshOutcome.Success)?.access

internal fun refreshJwtTokenBlockingDetailed(failedToken: String? = null): RefreshOutcome {
    // Никогда не звать с главного потока: блокирующий сетевой вызов под общим локом = ANR.
    // Все текущие вызыватели вне main (OkHttp-интерсептор / ConnectionManager на IO) — guard
    // фиксирует контракт и громко падает в debug, если его нарушат.
    if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
        throw IllegalStateException("refreshJwtTokenBlocking() must not be called on the main thread")
    }
    synchronized(refreshLock) {
        val current = getJwtToken()
        if (!failedToken.isNullOrEmpty() && current.isNotEmpty() && current != failedToken) {
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "refreshBlocking: token already refreshed by another thread, reusing access=${maskToken(current)}",
            )
            return RefreshOutcome.Success(current)
        }

        // Аутентифицировать /refresh нечем (paramAdds приложил бы refresh из prefs или легаси
        // CarrotToken) → запрос обречён на 401. Не ходим в сеть, caller уйдёт в recovery-путь.
        val storedRefresh = getRefreshToken()
        val legacyToken = io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
            .getString(CarrotLib.getLibComponents().context, "CarrotToken")
        if (storedRefresh.isNullOrEmpty() && legacyToken.isNullOrEmpty()) {
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "refreshBlocking: no refresh creds at all (token-less) — skipping network call",
            )
            return RefreshOutcome.NotAttempted("token-less")
        }

        // Недавний серверный отказ с ТЕМИ ЖЕ кредами — не спамим /refresh, отдаём провал сразу.
        if (storedRefresh == lastRefreshRejectSnapshot &&
            android.os.SystemClock.elapsedRealtime() - lastRefreshRejectAtMs < REFRESH_REJECT_CACHE_MS
        ) {
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "refreshBlocking: recent server reject with same creds — skipping network call",
            )
            return RefreshOutcome.NotAttempted("recent reject cached")
        }

        val updateRefresh = !isActualRefreshToken()
        // Поколение идентичности на момент СТАРТА запроса — для CAS в saveRefreshedTokens.
        val expectedEpoch = io.carrotquest_sdk.android.data.user.UserIdentityStore.snapshot().epoch
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "refreshBlocking: requesting /refresh (updateRefreshToken=$updateRefresh). State: ${tokenStateSummary()}",
        )
        return try {
            val carrotApi = CarrotLib.getLibComponents().carrotApi
            val response = runBlocking { carrotApi.refresh(updateRefresh) }
            if (response.meta.status == 200) {
                lastRefreshRejectSnapshot = null
                // Пока мы ждали ответ, идентичность могла смениться (auth-склейка / пересоздание
                // сессии). Тогда пара относится к прежнему юзеру и применять её нельзя — иначе
                // сессия откатится на него вместе с refresh-токеном.
                if (!saveRefreshedTokens(response.data.access, response.data.refresh, expectedEpoch)) {
                    // Лежащий access можно отдать как успех, только если он принадлежит ТЕКУЩЕЙ
                    // личности (легитимный случай: параллельный auth уже сохранил СВОЮ свежую
                    // пару). Безусловный Success здесь возвращал ЧУЖОЙ access, вызывающие писали
                    // его в user.token — и цементировали рассинхрон личности и токена (вплоть до
                    // СОЗДАНИЯ рассинхрона из здорового состояния при протухшем access и чужой
                    // refresh-паре в prefs). Нераспознанный токен (легаси) — fail-open, как в
                    // барьере идентичности.
                    val stored = getJwtToken()
                    val currentId = io.carrotquest_sdk.android.data.user.UserStateHolder.currentId()
                    val storedOwners = io.carrotquest_sdk.android.lib.network.auth.JwtIdentityGuard
                        .tokenOwnerIds(stored)
                    if (stored.isNotEmpty() &&
                        (storedOwners == null || currentId.isEmpty() || currentId in storedOwners)
                    ) {
                        // Лежащий access отдаём как успех — синкаем его и в легаси user.token
                        // (раньше это делал каждый вызыватель refresh со своим outcome.access).
                        io.carrotquest_sdk.android.data.user.syncLegacyUserToken(
                            runCatching { CarrotLib.getLibComponents().context }.getOrNull(), stored)
                        RefreshOutcome.Success(stored)
                    } else {
                        SdkLogger.log(
                            SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                            "refreshBlocking: pair rejected (identity changed while refreshing) and " +
                                "stored access does not belong to the current identity — reporting failure",
                        )
                        RefreshOutcome.NotAttempted("identity changed while refreshing")
                    }
                } else {
                    SdkLogger.log(
                        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                        "refreshBlocking: SUCCESS, new access=${maskToken(response.data.access)} (refresh token still alive)",
                    )
                    RefreshOutcome.Success(response.data.access)
                }
            } else {
                // Не-200: refresh-токен отвергнут сервером → оба токена мертвы → caller уйдёт в анонима.
                lastRefreshRejectSnapshot = storedRefresh
                lastRefreshRejectAtMs = android.os.SystemClock.elapsedRealtime()
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refreshBlocking: REJECTED status=${response.meta.status} error=${response.meta.error} → refresh token dead, will fall back to anonymous",
                )
                RefreshOutcome.Rejected
            }
        } catch (e: java.io.IOException) {
            // Сетевая ошибка — пробрасываем, чтобы caller мог отличить её от серверного отказа.
            // Токены при этом не трогаем: они могут быть валидны, просто сеть недоступна.
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "refreshBlocking: NETWORK error (tokens NOT touched): $e",
            )
            throw e
        } catch (e: Exception) {
            // Защита от обёрнутого checked IOException (если транспорт когда-либо завернёт его в
            // RuntimeException): разворачиваем и пробрасываем, иначе сетевой сбой выглядел бы как
            // «refresh мёртв» и приводил бы к сбросу токенов/анониму.
            val cause = e.cause
            if (cause is java.io.IOException) {
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refreshBlocking: NETWORK error (unwrapped, tokens NOT touched): $cause",
                )
                throw cause
            }
            // HTTP-ошибка (retrofit2.HttpException и т.п.) — серверный отказ, кэшируем как reject.
            lastRefreshRejectSnapshot = storedRefresh
            lastRefreshRejectAtMs = android.os.SystemClock.elapsedRealtime()
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "refreshBlocking: error $e")
            RefreshOutcome.Rejected
        }
    }
}
