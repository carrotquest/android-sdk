package io.carrotquest_sdk.android.lib.network

import retrofit2.HttpException

// Тело ошибки этого API — короткий JSON; больше в текст исключения тащить незачем.
private const val BODY_LIMIT = 512

/**
 * Провал отправки сообщения (POST /conversations/{id}/reply) с сохранённой причиной.
 *
 * Нужен потому, что Retrofit на suspend-функции с не-`Response<T>` типом сводит ЛЮБОЙ не-2xx к
 * [HttpException], а прежняя обёртка гасила её пустым `ReplyResponse()`. В итоге 500, 400, таймаут
 * и обрыв сокета были неразличимы: наружу шло одно и то же «network error (null meta)».
 *
 * [httpCode] — код ответа (null, если до ответа дело не дошло: таймаут/обрыв/DNS).
 * [serverBody] — тело ошибки, усечённое: причина отказа обычно именно там.
 */
internal class ReplySendException(
    val httpCode: Int?,
    val serverBody: String,
    cause: Throwable,
) : Exception(buildReplyFailureMessage(httpCode, serverBody, cause), cause)

/** Приводит любую ошибку отправки к [ReplySendException], вытаскивая код и тело из [HttpException]. */
internal fun Throwable.toReplySendException(): ReplySendException = when (this) {
    is ReplySendException -> this
    is HttpException -> ReplySendException(code(), readHttpErrorBody(this), this)
    else -> ReplySendException(null, "", this)
}

private fun buildReplyFailureMessage(httpCode: Int?, serverBody: String, cause: Throwable): String {
    val what = if (httpCode != null) "HTTP $httpCode" else "network failure (${cause.javaClass.simpleName})"
    val why = when {
        serverBody.isNotEmpty() -> " body=$serverBody"
        cause.message.isNullOrEmpty() -> ""
        else -> " (${cause.message})"
    }
    return "sendMessage failed: $what$why"
}

private fun readHttpErrorBody(e: HttpException): String = try {
    e.response()?.errorBody()?.string().orEmpty()
        .replace('\n', ' ').replace('\r', ' ').trim().take(BODY_LIMIT)
} catch (t: Exception) {
    // Диагностика не должна подменять исходную ошибку — просто останемся без тела.
    ""
}