package io.carrotquest_sdk.android.presentation.chat

import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage

/**
 * Стартовая ветка routing-бота (шаблон из chooseRoutingBot) показана в теле чата и является
 * ПОСЛЕДНИМ элементом ленты. Пока это так, шаблон — фактический part_last беседы: веб в
 * getPartsFromRoutingBot буквально переписывает conversation.reply_type и part_last, и поле ввода
 * следует за ними. У нас шаблон в репозиторий не попадает, поэтому его состояние отдаёт
 * [ChatViewModel], а видимость поля по нему решает презентер (DialogPresenter.updateInput).
 *
 * Как только ниже шаблона встаёт реальное сообщение (ответ пользователя, реплика бота или
 * оператора), состояние становится null — дальше поле ввода снова решается по серверным part'ам.
 *
 * @property allowUserReplies allow_user_replies бота: можно ли прервать бота свободным текстом.
 * @property propertyField запрос данных в первой ветке (вместо кнопок): веб рисует для него поле
 *   «Введите ответ» независимо от allow_user_replies, у нас это нижнее поле в режиме bot-input.
 *   Ответ уходит в routing/start тем же путём, что и кнопка (DialogPresenter.sendActionBot).
 */
class RoutingTemplateState(
    val allowUserReplies: Boolean,
    val propertyField: ActionMessage? = null,
) {
    // Равенство по id экшена, а не по ссылке: состояние пересчитывается на каждом rebuild ленты,
    // и «то же самое» состояние не должно дёргать updateInput → showInput (он сбрасывает текст поля).
    override fun equals(other: Any?): Boolean =
        other is RoutingTemplateState &&
            other.allowUserReplies == allowUserReplies &&
            other.propertyField?.id == propertyField?.id &&
            other.propertyField?.type == propertyField?.type

    override fun hashCode(): Int = 31 * allowUserReplies.hashCode() + (propertyField?.id?.hashCode() ?: 0)

    override fun toString(): String =
        "RoutingTemplateState(allowUserReplies=$allowUserReplies, propertyField=${propertyField?.id})"
}
