package io.carrotquest_sdk.android.presentation.chat

import android.webkit.URLUtil
import com.google.gson.JsonParser
import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.use_cases.agreements.RequestedContactField
import io.carrotquest_sdk.android.domain.use_cases.agreements.buildConsentState
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.isSoftRemoved
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object MessageMapper {

    // Значения reply_type автоответа, при которых показываем поле сбора контакта.
    // Остальные ('no' — сбор выключен в админке, 'text' и будущие) — обычное сообщение.
    private val COLLECTING_REPLY_TYPES = setOf("email", "phone", "phone_mask", "name")

    private fun String.parseEmoji(): String = EmojiParser.parseToUnicode(this)

    // Сортировка для reverseLayout=true (index 0 = низ экрана = новейшее): по created
    // убыванию, а внутри одной секунды (пак бота присылается одной секундой) — по id.
    // id сообщений — снежинки, монотонно растущие со временем, поэтому это надёжный
    // вторичный ключ. Порядок в repo НЕ используем: при bulk-загрузке истории с сервера
    // он обратный/произвольный, в отличие от живого append.
    // m.sortKey (если задан) имеет приоритет: оптимистичные исходящие получают
    // sortKey = maxId+1 (см. anchorSortKeys в CreateMessageSuspend), чтобы внутри одной
    // секунды встать строго после текущего последнего сообщения и перед будущими
    // серверными (у тех снежинки больше). У серверных sortKey == null → берём id.
    private fun sortKey(m: MessageData): Long =
        m.sortKey ?: m.id?.toLongOrNull() ?: m.randomId?.toLongOrNull() ?: 0L

    // Секунда для сортировки: у оптимистичных исходящих — якорь sortCreated (серверный
    // таймлайн, см. anchorSortKeys), у серверных — created. Голый created оптимиста для
    // порядка непригоден: спешащие часы устройства уводили его в будущее, и серверный
    // ответ бота с меньшим created вставал ВЫШЕ только что отправленного пузыря.
    private fun sortCreatedOf(m: MessageData): Long =
        m.sortCreated ?: m.created?.toLongOrNull() ?: 0L

    // Дедуп по id/randomId + сортировка «новейшие первыми» — единый порядок ленты.
    // Из группы дублей (optimistic + серверное эхо) предпочитаем живую версию, но removed
    // больше НЕ выбрасываем: сообщение остаётся в ленте с плашкой «Сообщение удалено»
    // (см. removedMessage) — раньше сообщения оператора при удалении просто исчезали.
    private fun sortNewestFirst(messages: List<MessageData>): List<MessageData> =
        messages.groupBy { it.id ?: it.randomId }.values
            .map { group -> group.firstOrNull { !it.isSoftRemoved() } ?: group.first() }
            .sortedWith(
                compareByDescending<MessageData> { sortCreatedOf(it) }
                    .thenByDescending { sortKey(it) }
            )

    /**
     * Новейшее сообщение ленты — тот же элемент, что [map] положит в index 0 (низ экрана) и
     * у которого одного активны кнопки бота. Нужен ChatViewModel, чтобы понять, является ли
     * шаблон стартовой ветки routing-бота фактическим последним сообщением (см. RoutingTemplateState).
     */
    fun newestOf(messages: List<MessageData>): MessageData? = sortNewestFirst(messages).firstOrNull()

    // Список отсортирован по убыванию (новейшие первыми) для reverseLayout = true.
    // DateDivider вставляется ПОСЛЕ последнего (старейшего) сообщения каждого дня,
    // чтобы при визуальном рендеринге снизу вверх разделитель оказался над сообщениями дня.
    fun map(
        messages: List<MessageData>,
        db: CarrotSdkDB,
        // Текстовые ответы боту, отправленные в этой сессии: id части-вопроса → текст ответа.
        // Пока сервер не донёс meta_data.answer_body, исходящий пузырь рисуем отсюда
        // (см. ChatViewModel.localBotTextAnswers).
        botTextAnswers: Map<String, String> = emptyMap(),
    ): List<ChatListItem> {
        val sorted = sortNewestFirst(messages)

        val result = mutableListOf<ChatListItem>()
        var lastDayKey: String? = null
        var pendingDivider: ChatListItem.DateDivider? = null

        // Кнопки активны только у самого свежего сообщения (sorted[0]). Прошлые ветки уже
        // отвечены (пользователь продвинулся дальше) — их кнопки схлопываются.
        val newestKey = sorted.firstOrNull()?.let { it.id ?: it.randomId }

        for (msg in sorted) {
            val timestampMs = (msg.created?.toLongOrNull() ?: 0L) * 1000L
            val dateEntry = dateLabelFor(timestampMs)
            val currentDayKey = dateEntry?.first

            if (currentDayKey != lastDayKey) {
                // Сбросить накопленный разделитель предыдущего дня
                pendingDivider?.let { result += it }
                pendingDivider = dateEntry?.let { (_, label) -> ChatListItem.DateDivider(label) }
                lastDayKey = currentDayKey
            }

            val isNewest = (msg.id ?: msg.randomId) == newestKey
            result += toListItems(msg, db, isNewest, botTextAnswers)
        }
        // Разделитель самого старого дня — окажется в самом верху списка
        pendingDivider?.let { result += it }

        return result
    }

    private fun toListItems(
        msg: MessageData,
        db: CarrotSdkDB,
        isNewest: Boolean,
        botTextAnswers: Map<String, String> = emptyMap(),
    ): List<ChatListItem> {
        // Диагностика контактных полей: бэк может прислать автоответ ТОЛЬКО с reply_type,
        // без actions.property_field (CAR-76466), поэтому логируем любой auto_reply и любое
        // сообщение с property_field — видно, с каким type/replyType/actions реально пришёл
        // вопрос-контакт. Текст ответа и контактные данные не логируем.
        val actionTypes = msg.actions?.map { it.type }.orEmpty()
        if (msg.type == ResponseFields.AUTO_REPLY || actionTypes.contains("property_field")) {
            Log.d("CQ_BotInput", "map msg: type=${msg.type} replyType=${msg.replyType} id=${msg.id} actions=$actionTypes isNewest=$isNewest")
        }
        // Мягко удалённое сообщение: плашка вместо контента, каким бы ни был исходный тип.
        // Проверка ДО ветвления по типам — удалённый reply_admin не должен рисовать вложения,
        // кнопки или цитату.
        if (msg.isSoftRemoved()) return listOf(removedMessage(msg))

        val items = when (msg.type) {
            ResponseFields.TYPING     -> listOf(TypingIndicator(msg))
            ResponseFields.VOTE       -> listOf(VoteCard(msg))
            ResponseFields.AUTO_REPLY -> autoReplyItems(msg, db, isNewest)
            ResponseFields.REPLY_USER -> {
                val outgoing = regularMessage(msg, Direction.OUTGOING, db)
                // Гард на полностью пустое сообщение (ни текста, ни вложений): такие
                // рождались из FailSendingMessage-записей без attach-меты (до v27) —
                // пустой исходящий бабл не рисуем.
                val content = outgoing.content as? MessageContent.TextContent
                if (content != null && content.body.isEmpty() && content.attachments.isEmpty()) {
                    emptyList()
                } else {
                    listOf(outgoing)
                }
            }
            ResponseFields.REPLY_ADMIN -> replyAdminItems(msg, db, isNewest)
            ResponseFields.ARTICLE -> listOf(articleMessage(msg))
            // Ответ пользователя боту + возможная следующая ветка с кнопками
            ResponseFields.CHAT_BOT_USER -> chatBotUserMessage(msg, db, isNewest, botTextAnswers[msg.id])
            // Сообщение от бота к пользователю (следующая ветка с кнопками/текстом/полем ввода)
            ResponseFields.CHAT_BOT_ADMIN -> autoReplyItems(msg, db, isNewest)
            else -> {
                val actions = msg.actions ?: emptyList()
                when {
                    actions.any { it.type == "button" || it.type == "meet" } ->
                        botMessageWithOptions(msg, db, isNewest)
                    // Бот-блоки без типа сообщения — в первую очередь шаблон стартовой ветки
                    // routing-бота (type=null, actions=[text, property_field…]). Текст лежит в
                    // action'ах, а body пуст: regularMessage рисовал пустой пузырь без текста.
                    // Контентные блоки — как у ветки с кнопками; property_field обслуживает
                    // нижнее поле (DialogPresenter, ROUTING_TEMPLATE_PROPERTY_FIELD).
                    actions.any { it.type == "property_field" || it.type == "text" } ->
                        botMessageWithOptions(msg, db, isNewest)
                    msg.direction == ResponseFields.ADMIN_2_USER ->
                        listOf(regularMessage(msg, Direction.INCOMING, db))
                    else -> listOf(unknownMessage(msg))
                }
            }
        }
        // Помечаем сообщения, порождённые ботом (для автоскролла: на бот-сообщение всегда к низу).
        // Централизованно, чтобы не тянуть флаг через каждый билдер.
        return if (isBotOrigin(msg)) {
            items.map { (it as? ChatListItem.Message)?.copy(isBot = true) ?: it }
        } else {
            items
        }
    }

    // Сообщение порождено ботом (а не оператором/пользователем): тип бота либо блок с actions.
    private fun isBotOrigin(msg: MessageData): Boolean = when (msg.type) {
        ResponseFields.AUTO_REPLY,
        ResponseFields.CHAT_BOT_ADMIN,
        ResponseFields.CHAT_BOT_USER,
        ResponseFields.VOTE,
        ResponseFields.ARTICLE -> true
        ResponseFields.REPLY_ADMIN, ResponseFields.REPLY_USER -> false
        else -> msg.actions?.any { it.type == "button" || it.type == "meet" || it.type == "property_field" } == true
    }

    // chat_bot_user: ответ пользователя (answerBody) + следующая ветка бота (actions)
    private fun chatBotUserMessage(
        msg: MessageData,
        db: CarrotSdkDB,
        isNewest: Boolean,
        // Локальный (ещё не подтверждённый сервером) текстовый ответ на этот вопрос.
        localAnswer: String? = null,
    ): List<ChatListItem> {
        val result = mutableListOf<ChatListItem>()

        // Исходящий бабл с ответом пользователя. Приоритет: серверный meta_data.answer_body →
        // локальный оверрайд (ответ только что отправлен, RTS ещё не пришёл) → body.
        // Локальный оверрайд заменил оптимистичное reply_user-сообщение: у того id — локальный
        // таймстамп, схлопнуть его с этим пузырём (id = id части) было нечем — дедуп везде идёт
        // по id/randomId, — и ответ показывался в теле чата ДВАЖДЫ. Здесь меняется только
        // источник текста, пузырь остаётся один. См. DialogPresenter.sendActionBot.
        val answerBody = (
            msg.messageMetaData?.answerBody?.takeIf { it.isNotBlank() }
                ?: localAnswer?.takeIf { it.isNotBlank() }
                ?: msg.body
                ?: ""
            ).parseEmoji()
        if (answerBody.isNotBlank()) {
            val attachments = msg.attachments?.mapNotNull { attachment(it, db) } ?: emptyList()
            result += ChatListItem.Message(
                id = msg.id ?: "",
                direction = Direction.OUTGOING,
                sender = null,
                timestampMs = timestampMs(msg),
                deliveryStatus = deliveryStatus(msg),
                content = MessageContent.TextContent(body = answerBody, attachments = attachments),
            )
        }

        // Следующая ветка: контентные блоки (текст и/или вложения) и кнопки от бота
        val actions = msg.actions ?: emptyList()
        val contentActions = botContentActions(actions)
        val buttonActions = actions.filter { it.type == "button" || it.type == "meet" }

        for (action in contentActions) {
            botContentMessage(msg, action, db)?.let { result += it }
        }

        // Группу кнопок показываем ТОЛЬКО пока ответ ещё не известен (answerBody пуст): активный
        // шаг — тапабельные кнопки, либо локально отвеченный — схлопнутый выбор. Как только пришёл
        // answerBody, ответ уже показан исходящим пузырём выше — повторная группа с выбранной
        // кнопкой дублировала бы его (баг дубля «Закрыть» после перезагрузки на resume).
        if (buttonActions.isNotEmpty() && answerBody.isBlank()) {
            // Кнопки активны только у самой свежей ветки; прошлые — уже отвечены.
            result += ChatListItem.BotOptionsGroup(
                messageId = msg.id ?: "",
                options = botOptions(buttonActions),
                isAnswered = !isNewest,
            )
        }

        // reverseLayout=true: меньший индекс → ниже визуально, поэтому группу переворачиваем
        return result.reversed()
    }

    /**
     * Рисует ли маппер ответ пользователя ПРЯМО на части-вопросе (исходящий пузырь из
     * meta_data.answer_body, см. [chatBotUserMessage]). Для таких частей оптимистичное
     * reply_user-сообщение не нужно — оно дало бы второй пузырь. Для остальных типов
     * (auto_reply/chat_bot_admin/reply_admin с property_field) ответ из answer_body не
     * рисуется вовсе, поэтому там оптимистичное сообщение — единственный источник пузыря.
     */
    internal fun rendersUserAnswerOnPart(partType: String?): Boolean =
        partType == ResponseFields.CHAT_BOT_USER

    // Ссылка, зашитая в кнопку бота, лежит в body_json экшена. Точный ключ зависит от
    // конфигурации, поэтому пробуем типичные варианты.
    private fun actionLink(action: ActionMessage): String? {
        val obj = action.bodyJson?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
        for (key in listOf("url", "href", "target", "link", "target_url")) {
            val v = obj.get(key)?.takeIf { it.isJsonPrimitive }?.asString
            if (!v.isNullOrBlank() && v.lowercase() != "undefined") return v
        }
        return null
    }

    private fun botOptions(buttonActions: List<ActionMessage>): List<BotOption> =
        buttonActions.map {
            BotOption(
                id = it.id ?: "",
                branchId = it.nextBranchId,
                text = (it.body ?: "").parseEmoji(),
                link = actionLink(it),
                actionType = it.type,
                metaData = it.metaData?.toString(),
            )
        }

    private fun TypingIndicator(msg: MessageData) = ChatListItem.TypingIndicator(
        name = msg.messageFrom?.name,
        avatarUrl = msg.messageFrom?.avatar?.takeIf { it.isNotBlank() } ?: defaultMessengerAvatar(),
    )

    private fun VoteCard(msg: MessageData): ChatListItem.VoteCard {
        val score = msg.messageMetaData?.vote
        return ChatListItem.VoteCard(
            messageId = msg.id ?: "",
            voteState = if (score != null) VoteState.Rated(score) else VoteState.Pending,
            questionText = (msg.body ?: "").parseEmoji(),
        )
    }

    private fun autoReplyItems(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        val actions = msg.actions
        return when {
            !actions.isNullOrEmpty() && actions.any { it.type == "button" || it.type == "meet" } ->
                botMessageWithOptions(msg, db, isNewest)
            msg.messageMetaData?.vote != null -> listOf(VoteCard(msg))
            !actions.isNullOrEmpty() && actions.any { it.type == "property_field" }
                    && msg.type == ResponseFields.AUTO_REPLY ->
                listOf(contactInputMessage(msg, actions.first { it.type == "property_field" }))
            // reply_type автоответа бэк резолвит из настройки «Сбор контактов в автоответах»:
            // 'no' = не собирать. Поле ввода — только для собирающих значений (allow-list,
            // как на вебе), иначе 'no' рисовал текстовый инпут при выключенном сборе.
            msg.replyType in COLLECTING_REPLY_TYPES && msg.type == ResponseFields.AUTO_REPLY ->
                listOf(replyTypeInputMessage(msg))
            // Бот-блоки с вложениями без кнопок: regularMessage мапит только msg.attachments,
            // а вложения лежат на action — иначе картинка/файл такого блока не покажется.
            !actions.isNullOrEmpty() && botContentActions(actions).any { !it.attachments.isNullOrEmpty() } ->
                botMessageWithOptions(msg, db, isNewest)
            else -> listOf(regularMessage(msg, Direction.INCOMING, db))
        }
    }

    // Тип запрашиваемого контакта для блока согласия. NAME/TEXT согласия на хранение контакта
    // не требуют (строку подписки не показываем), но согласие на обработку перс. данных может
    // показаться и для них (решает настройка data_processing_policy).
    private fun requestedFieldFor(inputType: ContactInputType): RequestedContactField = when (inputType) {
        ContactInputType.EMAIL -> RequestedContactField.EMAIL
        ContactInputType.PHONE -> RequestedContactField.PHONE
        ContactInputType.NAME, ContactInputType.TEXT -> RequestedContactField.NONE
    }

    // Блок согласия строим только пока ответа ещё нет (Idle): после отправки поле сменяется
    // «Спасибо», согласие уже не нужно. Чекбоксы стартуют неотмеченными (см. buildConsentState),
    // их состояние далее держит ChatViewModel (localConsentChecked).
    private fun consentFor(inputType: ContactInputType, state: ContactInputState) =
        if (state is ContactInputState.Idle)
            buildConsentState(requestedFieldFor(inputType)).takeIf { it.isVisible }
        else null

    private fun replyTypeInputMessage(msg: MessageData): ChatListItem.Message {
        val inputType = when (msg.replyType) {
            "email"              -> ContactInputType.EMAIL
            "phone", "phone_mask" -> ContactInputType.PHONE
            "name"               -> ContactInputType.NAME
            else                 -> ContactInputType.TEXT
        }
        val state = if (msg.messageMetaData?.replied == true)
            ContactInputState.Submitted(msg.messageMetaData?.answerBody ?: "")
        else
            ContactInputState.Idle
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.ContactInputContent(
                body = (msg.body ?: "").parseEmoji(),
                placeholder = null,
                inputType = inputType,
                state = state,
                consent = consentFor(inputType, state),
            ),
        )
    }

    private fun contactInputMessage(msg: MessageData, action: ActionMessage): ChatListItem.Message {
        val placeholderObj = action.placeholder
        val inputType = when (placeholderObj?.type) {
            "email"                -> ContactInputType.EMAIL
            "phone", "phone_mask"  -> ContactInputType.PHONE
            "name"                 -> ContactInputType.NAME
            else                   -> ContactInputType.TEXT
        }
        val placeholderText = if (placeholderObj?.type == "custom") placeholderObj.value else null
        val state = if (msg.messageMetaData?.replied == true)
            ContactInputState.Submitted(msg.messageMetaData?.answerBody ?: "")
        else
            ContactInputState.Idle
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.ContactInputContent(
                body = (msg.body ?: "").parseEmoji(),
                placeholder = placeholderText,
                inputType = inputType,
                state = state,
                consent = consentFor(inputType, state),
            ),
        )
    }

    // Реплика админа, отправленная через public API, может нести кнопки быстрых ответов
    // (actions с type="quick_reply"). Контракт — зеркало веб-виджета: группа кнопок строится
    // ТОЛЬКО для самого свежего сообщения списка (у прошлых сообщений диалог уже уехал дальше,
    // веб их тоже не показывает); гейт — по ПЕРВОМУ экшену, как на вебе. «Отвеченность» и
    // выбранная кнопка — из meta_data самого сообщения (answer_action_id, формат
    // "<индекс>_quick_reply" — см. parseMessageActions). Исходящий бабл ответа НЕ рисуем:
    // реплику пользователя создаёт бэкенд, она придёт по RTS обычным reply_user (иначе дубль).
    private fun replyAdminItems(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        val bubble = replyAdmin(msg, db)
        val quickReplies = msg.actions
            ?.takeIf { it.firstOrNull()?.type == ResponseFields.ACTION_QUICK_REPLY }
            ?.filter { it.type == ResponseFields.ACTION_QUICK_REPLY }
            .orEmpty()
        if (quickReplies.isEmpty() || !isNewest) return listOf(bubble)

        val answerActionId = msg.messageMetaData?.answerActionId
        val group = ChatListItem.BotOptionsGroup(
            messageId = msg.id ?: "",
            options = botOptions(quickReplies),
            isAnswered = answerActionId != null,
            selectedOptionId = answerActionId,
        )
        // reverseLayout=true: меньший индекс → ниже визуально, поэтому группа перед баблом
        return listOf(group, bubble)
    }

    private fun replyAdmin(msg: MessageData, db: CarrotSdkDB): ChatListItem {
        if (msg.hasKBLink == true) {
            val bodyUrl = msg.bodyJson
                ?.takeIf { it.isJsonObject }
                ?.asJsonObject?.get("url")
                ?.takeIf { !it.isJsonNull }
                ?.asString ?: ""
            // Welcome-сообщение создаётся без bodyJson (createWelcomeMessage), поэтому url пустой →
            // fallback на домашнюю страницу базы знаний, иначе кнопка «Открыть статью» мёртвая.
            // Серверные reply_admin KB-ссылки несут bodyJson.url и fallback не задевает.
            val url = bodyUrl.ifBlank { buildKbHomeUrl() }
            return ChatListItem.Message(
                id = msg.id ?: "",
                direction = Direction.INCOMING,
                sender = sender(msg),
                timestampMs = timestampMs(msg),
                deliveryStatus = null,
                content = MessageContent.ArticleLinkContent(
                    name = (msg.body ?: "").parseEmoji(),
                    shortDescription = null,
                    url = url,
                ),
            )
        }
        return regularMessage(msg, Direction.INCOMING, db)
    }

    private fun articleMessage(msg: MessageData): ChatListItem.Message {
        val bodyJson = msg.bodyJson?.takeIf { it.isJsonObject }?.asJsonObject
        val name = bodyJson?.get("name")?.takeIf { !it.isJsonNull }?.asString?.takeIf { it.isNotBlank() } ?: ""
        val shortDescription = bodyJson?.get("short_description")?.takeIf { !it.isJsonNull }?.asString?.takeIf { it.isNotBlank() }
        val articleId = msg.body?.trim() ?: ""
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.ArticleLinkContent(
                name = name,
                shortDescription = shortDescription,
                url = buildArticleUrl(articleId),
            ),
            isQuotable = isQuotable(msg),
        )
    }

    // Домашняя страница базы знаний (knowledge_base_domain из настроек). "" — если домена нет.
    private fun buildKbHomeUrl(): String = normalizeKbHomeUrl(rawKbDomain())

    private fun buildArticleUrl(articleId: String): String = buildKbArticleUrl(rawKbDomain(), articleId)

    // Сырой knowledge_base_domain из sourceData настроек (без нормализации). null — если нет.
    private fun rawKbDomain(): String? = runCatching {
        val sourceData = SettingsRepository.getInstance().getLastSettings()?.sourceData ?: return@runCatching null
        val json = JsonParser.parseString(sourceData)?.takeIf { it.isJsonObject }?.asJsonObject ?: return@runCatching null
        json.get("knowledge_base_domain")?.takeIf { !it.isJsonNull }?.asString
    }.getOrNull()

    // Нормализация домена базы знаний в URL главной страницы (протокол + без хвостового '/').
    // Чистая (без синглтонов) — покрыта MessageMapperKbUrlTest.
    internal fun normalizeKbHomeUrl(rawDomain: String?): String {
        val raw = rawDomain?.takeIf { it.isNotBlank() } ?: return ""
        return when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            raw.startsWith("//") -> "https:$raw"
            else -> "https://$raw"
        }.trimEnd('/')
    }

    // URL конкретной статьи базы знаний. "" — если нет articleId или домена. Чистая — покрыта тестом.
    internal fun buildKbArticleUrl(rawDomain: String?, articleId: String): String {
        if (articleId.isBlank()) return ""
        val home = normalizeKbHomeUrl(rawDomain)
        return if (home.isBlank()) "" else "$home/article/$articleId"
    }

    // Контентные блоки бота: текст и/или вложения. Картинки/файлы/голос у бота приходят как
    // attachments на action (нередко с ПУСТЫМ body), поэтому фильтровать по непустому тексту
    // нельзя — иначе блок с картинкой пропадает (виден только после переоткрытия, когда сообщение
    // приходит обычным reply_admin с msg.attachments). Кнопки/поля ввода сюда не попадают.
    private fun botContentActions(actions: List<ActionMessage>): List<ActionMessage> =
        actions.filter {
            (it.type == "text" || !it.attachments.isNullOrEmpty()) &&
                it.type != "button" && it.type != "meet" && it.type != "property_field"
        }

    private fun botContentMessage(msg: MessageData, action: ActionMessage, db: CarrotSdkDB): ChatListItem.Message? {
        val body = action.body?.trim()?.parseEmoji().orEmpty()
        val attachments = action.attachments?.mapNotNull { attachment(it, db) } ?: emptyList()
        if (body.isEmpty() && attachments.isEmpty()) return null
        return ChatListItem.Message(
            // Префикс "bot_" уводит синтетический id контентного блока в отдельное пространство
            // имён — реальные message.id числовые (снежинки), поэтому коллизия исключена.
            id = "bot_${msg.id}_${action.id}",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.TextContent(body = body, attachments = attachments),
        )
    }

    private fun botMessageWithOptions(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        val actions = msg.actions ?: emptyList()
        val contentActions = botContentActions(actions)
        val buttonActions = actions.filter { it.type == "button" || it.type == "meet" }

        val result = mutableListOf<ChatListItem>()

        // Несколько контентных блоков (текст и/или вложения) от бота идут перед кнопками
        for (action in contentActions) {
            botContentMessage(msg, action, db)?.let { result += it }
        }

        // Основной body/вложения сообщения (если нет отдельных контентных блоков)
        if (contentActions.isEmpty()) {
            val incoming = regularMessage(msg, Direction.INCOMING, db)
            val content = incoming.content as? MessageContent.TextContent
            if (content != null && (content.body.isNotBlank() || content.attachments.isNotEmpty())) {
                result += incoming
            }
        }

        if (buttonActions.isNotEmpty()) {
            // Активны кнопки только у самой свежей ветки; прошлые/отвеченные — схлопнуты.
            val isAnswered = msg.messageMetaData?.replied == true || !isNewest
            result += ChatListItem.BotOptionsGroup(
                messageId = msg.id ?: "",
                options = botOptions(buttonActions),
                isAnswered = isAnswered,
            )
        }

        // reverseLayout=true: меньший индекс → ниже визуально, поэтому группу переворачиваем
        return result.reversed()
    }

    /**
     * Мягко удалённое сообщение (removed — таймстамп удаления): бабл остаётся с плашкой
     * «Сообщение удалено» вместо контента (без вложений), но цитата (replied_to) СОХРАНЯЕТСЯ —
     * удалён ответ, а не то, на что отвечали (как в вебе: QuoteBlock над плашкой). Действия и
     * цитирование недоступны (isQuotable(msg) для removed и так false), аватар и время — как обычно.
     */
    internal fun removedMessage(msg: MessageData): ChatListItem.Message {
        // Своё (исходящее) сообщение пользователь удалить не может, но removed reply_user из
        // истории на всякий случай рисуем справа, как оно и висело.
        val direction =
            if (msg.type == ResponseFields.REPLY_USER || msg.type == ResponseFields.CHAT_BOT_USER) Direction.OUTGOING
            else Direction.INCOMING
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = direction,
            sender = if (direction == Direction.INCOMING) sender(msg) else null,
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.RemovedContent,
            replyTo = quotedMessage(msg),
            isQuotable = false,
        )
    }

    private fun regularMessage(msg: MessageData, direction: Direction, db: CarrotSdkDB): ChatListItem.Message {
        val attachments = msg.attachments?.mapNotNull { attachment(it, db) } ?: emptyList()
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = direction,
            sender = if (direction == Direction.INCOMING) sender(msg) else null,
            timestampMs = timestampMs(msg),
            deliveryStatus = if (direction == Direction.OUTGOING) deliveryStatus(msg) else null,
            content = MessageContent.TextContent(body = (msg.body ?: "").parseEmoji(), attachments = attachments),
            replyTo = quotedMessage(msg),
            isQuotable = isQuotable(msg),
        )
    }

    // Цитата (replied_to) → UI-модель. Сниппет: partial_text приоритетнее body. Чистая —
    // покрыта MessageMapperTest.
    internal fun quotedMessage(msg: MessageData): QuotedMessageUi? {
        val quote = msg.repliedTo ?: return null
        return QuotedMessageUi(
            originalId = quote.id,
            senderName = quote.from?.name?.takeIf { it.isNotBlank() },
            snippet = snippetOf(quote.partialText ?: quote.body),
            isRemoved = quote.removed,
            attachment = quoteAttachmentKind(quote.attachments),
        )
    }

    // Однострочный сниппет для цитаты/чипа ответа: HTML-теги вырезаем, пробелы схлопываем.
    internal fun snippetOf(body: String?): String? = body
        ?.replace(Regex("<[^>]*>"), " ")
        ?.replace(Regex("\\s+"), " ")
        ?.trim()
        ?.takeIf { it.isNotEmpty() }
        ?.parseEmoji()

    // Вложения оригинала сводятся к иконке+лейблу (по Figma миниатюр в цитате нет). Семантика
    // категорий — как у превью последнего сообщения в списке диалогов (MessagePreviewBuilder):
    // одиночный файл — именем, несколько файлов/смесь — «N файлов», картинки — «N изображений».
    internal fun quoteAttachmentKind(attachments: List<Attachment>): QuoteAttachment? = when {
        attachments.isEmpty() -> null
        attachments.size == 1 && isVoice(attachments.first()) -> QuoteAttachment.Voice
        attachments.all { it.mimeType?.startsWith("image/") == true || it.type == "image" } ->
            QuoteAttachment.Images(attachments.size)
        attachments.size == 1 -> QuoteAttachment.File(attachments.first().filename)
        else -> QuoteAttachment.Files(attachments.size)
    }

    // Зеркало бэкенд-валидации QUOTABLE_TYPES: отвечать можно только на эти типы.
    private val QUOTABLE_TYPES = setOf(
        ResponseFields.REPLY_USER, ResponseFields.REPLY_ADMIN, ResponseFields.ARTICLE,
    )

    // Статусы, при которых у сообщения ещё/уже нет валидного серверного состояния для цитирования.
    private val NON_QUOTABLE_STATUSES = setOf("loading", "warning", "failed")

    /**
     * Можно ли ответить на это сообщение (клиентское зеркало бэкенд-валидации, как веб-isQuotablePart):
     * тип из белого списка, не удалено, есть СЕРВЕРНЫЙ id (optimistic id == randomId — на сервере
     * такого id нет, был бы 400) и оно не в loading/warning.
     */
    internal fun isQuotable(msg: MessageData): Boolean {
        if (msg.type !in QUOTABLE_TYPES) return false
        if (!msg.removed.isNullOrEmpty()) return false
        val id = msg.id ?: return false
        if (id == msg.randomId) return false
        return msg.status !in NON_QUOTABLE_STATUSES
    }

    private fun unknownMessage(msg: MessageData) = ChatListItem.Message(
        id = msg.id ?: "",
        direction = if (msg.direction == ResponseFields.ADMIN_2_USER) Direction.INCOMING else Direction.OUTGOING,
        sender = null,
        timestampMs = timestampMs(msg),
        deliveryStatus = null,
        content = MessageContent.UnknownContent(msg.type),
    )

    private fun isVoice(att: Attachment): Boolean =
        att.type == "voice" || att.mimeType?.startsWith("audio/") == true

    private fun attachment(att: Attachment, db: CarrotSdkDB): UiAttachment? {
        val url = att.url
        val mime = att.mimeType
        val saved = url?.let { db.savedFileDao().getByURL(it) }
        // Голосовое — отдельный тип вложения ("voice" / audio/*), рисуется плеером.
        // Локальную копию из SavedFile берём, ТОЛЬКО пока файл реально существует: доставленный
        // голос подчищается orphan-sweep'ом на старте SDK (cleanupVoiceFiles), и маппинг
        // начинает указывать на удалённый путь — на нём MediaPlayer молчал (плеер немой). Тогда
        // стримим серверный http-URL (=ключ маппинга). Сырой url (локальный путь только что
        // записанного/упавшего голоса) отдаём как есть — файл на диске, стримить нечего.
        if (isVoice(att)) {
            val localUri = saved?.localUri?.takeIf { File(it).exists() }
            val model = localUri ?: url ?: return dropAttachment(att)
            return UiAttachment.VoiceAttachment(url = model)
        }
        // Картинка — если mime image/* ИЛИ вложение помечено type="image". При старте диалога
        // отправкой картинки mime может оказаться не image/*, но type выставлен в "image"
        // (легаси одиночной отправки; сам путь удалён, старые сообщения с таким type остаются) — иначе рисовалось бы как файл.
        // TIFF Android/Coil не декодирует — такое вложение рисуем файловой карточкой.
        val isTiff = mime == "image/tiff" || mime == "image/tif"
        val isImage = !isTiff && (mime?.startsWith("image/") == true || att.type == "image")
        if (isImage) {
            // Для рендера берём локальный файл, только пока он реально существует (только что
            // отправленная картинка хранит локальный путь в url, скачанная — в SavedFile.localUri),
            // иначе — серверный URL. Путь превращаем в file-URI через File.toURI(): он кодирует
            // спецсимволы в имени ('#', '%', пробелы), голая конкатенация "file://$path" их ломала.
            val localPath = (saved?.localUri ?: url?.takeIf { it.startsWith("/") })
                ?.takeIf { File(it).exists() }
            val remoteUrl = url?.takeIf { !it.startsWith("/") }
            return when {
                localPath != null -> UiAttachment.ImageAttachment(
                    url = File(localPath).toURI().toString(),
                    fallbackUrl = remoteUrl,
                )
                remoteUrl != null -> UiAttachment.ImageAttachment(url = remoteUrl)
                else              -> dropAttachment(att)
            }
        }
        if (url == null) return dropAttachment(att)
        return UiAttachment.FileAttachment(
            id = att.id ?: "",
            name = att.filename ?: att.id ?: "",
            mimeType = mime ?: "",
            size = att.size,
            url = url,
            downloadState = if (saved != null) DownloadState.Downloaded(saved.localUri)
                            else DownloadState.NotDownloaded,
        )
    }

    // Вложение без единого источника (нет ни живого локального файла, ни серверного URL)
    // отрисовать нечем — дропаем, но со следом в диагностике вместо молчаливой «дырки».
    private fun dropAttachment(att: Attachment): UiAttachment? {
        SdkLogger.log(
            SdkLogLevel.WARN, SdkLogCategory.GENERAL, "MessageMapper",
            "attachment dropped: no renderable source (id=${att.id}, type=${att.type}, mime=${att.mimeType})",
        )
        return null
    }

    private fun sender(msg: MessageData): Sender {
        val from = msg.messageFrom
        // У бот-веток (и прочих системных сообщений) avatar часто пустой → вместо серого
        // плейсхолдера подставляем дефолтный аватар мессенджера из настроек (как в welcome).
        val avatar = from?.avatar?.takeIf { it.isNotBlank() } ?: defaultMessengerAvatar()
        return Sender(name = from?.name, avatarUrl = avatar)
    }

    // Дефолтный аватар оператора = messengerAvatar из настроек: либо готовый URL, либо
    // имя файла относительно BASE_FILES_URL/avatars/ (логика как в createWelcomeMessage).
    private fun defaultMessengerAvatar(): String? = runCatching {
        val raw = SettingsRepository.getInstance().getSettingsObject()
            ?.messengerAvatar?.takeIf { it.isNotBlank() } ?: return@runCatching null
        if (URLUtil.isValidUrl(raw)) raw else BuildConfig.BASE_FILES_URL + "avatars/" + raw
    }.getOrNull()

    private fun timestampMs(msg: MessageData) = (msg.created?.toLongOrNull() ?: 0L) * 1000L

    // Локальные статусы исходящих сообщений (MessageStatus): "loaded" — доставлено серверу,
    // "warning" — ошибка отправки, "loading" — в процессе (индикатора пока нет).
    private fun deliveryStatus(msg: MessageData) = when (msg.status) {
        "loading"                     -> DeliveryStatus.SENDING
        "loaded", "sent", "delivered" -> DeliveryStatus.SENT
        "read"                        -> DeliveryStatus.READ
        "warning", "failed"           -> DeliveryStatus.FAILED
        else                          -> null
    }

    // Returns (dayKey for deduplication, DateLabel) or null if timestamp is 0.
    private fun dateLabelFor(timestampMs: Long): Pair<String, DateLabel>? {
        if (timestampMs == 0L) return null
        val cal = Calendar.getInstance().also { it.timeInMillis = timestampMs }
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().also { it.add(Calendar.DAY_OF_YEAR, -1) }
        val dayKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
        val label = when {
            isSameDay(cal, today)     -> DateLabel.Today
            isSameDay(cal, yesterday) -> DateLabel.Yesterday
            cal.get(Calendar.YEAR) == today.get(Calendar.YEAR) ->
                DateLabel.Exact(SimpleDateFormat("d MMMM", Locale.getDefault()).format(cal.time))
            else ->
                DateLabel.Exact(SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(cal.time))
        }
        return dayKey to label
    }

    private fun isSameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}
