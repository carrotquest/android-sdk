package io.carrotquest_sdk.android.presentation.mvp.dialog.presenter

import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.presentation.chat.RoutingTemplateState

/**
 * Ветка настройки поля ввода, которую применяет DialogPresenter.updateInput. Само решение вынесено
 * в [resolveInputBranch]: презентер завязан на синглтоны и не тестируется, а логика ветвления —
 * единственное место, где определяется, виден ли инпут.
 */
internal enum class InputBranch {
    /** Маленький блочный поп-ап: поля ввода нет. */
    HIDE_POPUP,
    /**
     * В ленте показана стартовая ветка routing-бота с запросом данных (property_field) вместо
     * кнопок: нижнее поле в режиме bot-input, ответ уходит в routing/start. Независимо от
     * allow_user_replies — веб рисует поле «Введите ответ» для такой ветки всегда.
     */
    ROUTING_TEMPLATE_PROPERTY_FIELD,
    /** В ленте показана стартовая ветка routing-бота с запретом прерывания: поле скрыто. */
    ROUTING_TEMPLATE_HIDDEN,
    /** В ленте показана стартовая ветка routing-бота, прерывание разрешено: свободный ввод. */
    ROUTING_TEMPLATE_ALLOWED,
    /** Обычный диалог без бота: простой текстовый ввод. */
    PLAIN,
    /** Бот запросил поле (телефон/почта/имя/произвольное): bot-input. */
    BOT_PROPERTY_FIELD,
    /** Последний part — ответ оператора: обычный ввод. */
    REPLY_ADMIN,
    /** Бот разрешает свободный текстовый ответ. */
    ALLOW_USER_REPLY,
    /** Бот разрешает текст, но поле уже в режиме bot-input — ничего не трогаем. */
    KEEP_BOT_INPUT,
    /** Бот завершил работу: свободный ввод. */
    CHAT_BOT_FINISHED,
    /** Бот ждёт ответа кнопками: поле скрыто. */
    HIDE,
}

/**
 * Решает, какую ветку применить к полю ввода.
 *
 * Порядок приоритетов:
 *  1. block_popup_small — инпута нет никогда.
 *  2. Активная стартовая ветка routing-бота ([routingTemplate] != null). Она — фактический
 *     part_last беседы (см. [RoutingTemplateState]), поэтому серверный partLast (например,
 *     reply_admin закрытого диалога) в этот момент устарел и НЕ должен показывать поле. Именно
 *     это ломалось при переоткрытии закрытого диалога с ботом без прерывания: бот снова показывал
 *     первую пачку, а поле оставалось видимым по старому reply_admin. Если первая ветка вместо
 *     кнопок запрашивает данные (property_field), поле нужно всегда — в режиме bot-input.
 *  3. Обычный диалог (не бот и без property_field) — простой ввод.
 *  4. Бот-ветки в прежнем порядке: property_field → reply_admin → allow text → finished → скрыть.
 *
 * @param conversationType conversation.type
 * @param lastPartType conversation.partLast.type
 * @param isAllowUserReply conversation.replyType == "text"
 * @param hasPropertyField в actions последнего part'а есть property_field
 * @param isChatBotFinished conversation.isChatBotFinished (RTS chat_bot_finished)
 * @param isBotInputMode текущий режим поля — BOT_INPUT
 * @param routingTemplate активная стартовая ветка routing-бота или null
 */
internal fun resolveInputBranch(
    conversationType: String?,
    lastPartType: String?,
    isAllowUserReply: Boolean,
    hasPropertyField: Boolean,
    isChatBotFinished: Boolean,
    isBotInputMode: Boolean,
    routingTemplate: RoutingTemplateState?,
): InputBranch {
    if (conversationType == ConversationType.BLOCK_POPUP_SMALL.stringValue) return InputBranch.HIDE_POPUP

    if (routingTemplate != null) {
        if (routingTemplate.propertyField != null) return InputBranch.ROUTING_TEMPLATE_PROPERTY_FIELD
        return if (routingTemplate.allowUserReplies) {
            InputBranch.ROUTING_TEMPLATE_ALLOWED
        } else {
            InputBranch.ROUTING_TEMPLATE_HIDDEN
        }
    }

    val isBotConversation = conversationType == ConversationType.LEAD_BOT.stringValue ||
        conversationType == ConversationType.ROUTING_BOT.stringValue
    // Бот-вопрос с полем ввода (property_field) требует bot-input ДАЖЕ когда conversation.type не
    // помечен как бот: такой вопрос приходит в part'е chat_bot_user внутри «обычного» диалога.
    if (!isBotConversation && !hasPropertyField) return InputBranch.PLAIN

    return when {
        // property_field — самый приоритетный признак, независимо от типа part'а.
        hasPropertyField -> InputBranch.BOT_PROPERTY_FIELD
        lastPartType == "reply_admin" -> InputBranch.REPLY_ADMIN
        isAllowUserReply -> if (isBotInputMode) InputBranch.KEEP_BOT_INPUT else InputBranch.ALLOW_USER_REPLY
        isChatBotFinished -> InputBranch.CHAT_BOT_FINISHED
        else -> InputBranch.HIDE
    }
}
