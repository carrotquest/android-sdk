package io.carrotquest_sdk.android.application

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.room.Room
import io.carrotquest_sdk.android.core.SdkGlobalHandlers
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import io.carrotquest_sdk.android.data.repositories.PopupRepository
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.SHOWED_POPUP_IDS
import io.carrotquest_sdk.android.domain.use_cases.popup.showPopup
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class SdkApp : Application() {

    lateinit var database: CarrotSdkDB
        private set

    // Скоуп показа попапов (раньше Observable.delay.subscribe под Disposable; remove_rx).
    private val popUpsScope = CoroutineScope(SupervisorJob() + SdkDispatchers.io)
    private var popUpsJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        // Подстраховка на случай, если хост всё-таки прописал SdkApp как Application.
        // Основной путь установки — CarrotSDK.commonSetup(). AtomicBoolean внутри
        // гарантирует, что реальная установка происходит ровно один раз.
        SdkGlobalHandlers.ensureInstalled()

        instance = this
        initDataBase(this)
    }

    fun initDataBase(context: Context) {
        database = Room.databaseBuilder(context, CarrotSdkDB::class.java, "carrot_sdk.db")
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            .build()
        initPopUps(context)
    }

    private fun initPopUps(context: Context) {
        Handler(Looper.getMainLooper()).post {
            BackgroundManager.getInstance().addObserver { isConnect ->
                if (isConnect) {
                    popUpsJob?.cancel()
                    popUpsJob = popUpsScope.launch {
                        PopupRepository.getAllPopUpsFlow().collect { popUpModels ->
                            // Раньше Observable.delay(1с) сдвигал каждую эмиссию неблокирующе; здесь
                            // delay(1с) внутри collect сериализует обработку (по сути дебаунс на 1с
                            // после прихода данных) — для Room-Flow со списком попапов это допустимо.
                            delay(1000)
                            handlePopUps(context, popUpModels)
                        }
                    }
                } else {
                    popUpsJob?.cancel()
                    popUpsJob = null
                }
            }
        }
    }

    private suspend fun handlePopUps(context: Context, popUpModels: ArrayList<PopUpDbEntity>) {
        val exitedSet = SharedPreferencesLib.getStringSet(context, SHOWED_POPUP_IDS)
        val needRemove = ArrayList<PopUpDbEntity>()
        for (p in popUpModels) {
            if (exitedSet.contains(p.id)) {
                needRemove.add(p)
            } else {
                exitedSet.add(p.id)
            }
        }
        SharedPreferencesLib.saveStringSet(context, SHOWED_POPUP_IDS, exitedSet)

        popUpModels.removeAll(needRemove)
        if (popUpModels.isEmpty()) return

        val neededShowPopUpConversationId = SharedPreferencesLib
            .getString(CarrotInternal.getLibComponent().contextSdk, "need_show_popup_conv_id")

        var popUpForShow = findPopUpMessage(neededShowPopUpConversationId, popUpModels)
        if (popUpForShow != null) {
            SharedPreferencesLib
                .clearPreference(CarrotInternal.getLibComponent().contextSdk, "need_show_popup_conv_id")
        } else {
            popUpForShow = popUpModels[popUpModels.size - 1]
        }

        val entity = PopUpMessageEntity(
            popUpForShow.id,
            popUpForShow.bodyJson,
            popUpForShow.expirationTime,
            popUpForShow.backgroundColor
        )

        try {
            showPopup(entity)
        } catch (t: Throwable) {
            Log.e("SHOW_POPUP", "ERROR: $t")
        }
    }

    val currentActivity: Activity?
        get() {
            val activity = mFTActivityLifecycleCallbacks.getCurrentActivity()
            if (activity != null) {
                return activity
            }

            val sdkContext = CarrotInternal.getLibComponent().contextSdk
            if (sdkContext is Activity) {
                return sdkContext
            }

            return null
        }

    private fun findPopUpMessage(conversationId: String?, list: ArrayList<PopUpDbEntity>): PopUpDbEntity? {
        if (conversationId.isNullOrEmpty()) {
            return null
        }

        for (p in list) {
            if (conversationId == p.id) {
                return p
            }
        }

        return null
    }

    private fun reg() {
        try {
            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val method = activityThreadClass.getMethod("currentApplication")
            val app = method.invoke(null) as? Application
            if (app != null) {
                app.registerActivityLifecycleCallbacks(mFTActivityLifecycleCallbacks)
                // Раньше тут был postDelayed → mFTActivityLifecycleCallbacks.onActivityPostStarted(c):
                // этот метод не переопределён (пустой дефолт интерфейса) — блок был no-op, удалён.
            }
        } catch (e: Exception) {
            Log.e("LIFE STYLE", "REG ERROR: $e")
        }
    }

    // Поток смены текущей Activity (раньше subscribeOnCurrentActivity → Disposable; remove_rx).
    fun currentActivityChanges(): Flow<Activity> = mFTActivityLifecycleCallbacks.currentActivityChanges()

    companion object {
        private var instance: SdkApp? = null
        private val mFTActivityLifecycleCallbacks = FTActivityLifecycleCallbacks()

        @JvmStatic
        fun getInstance(): SdkApp {
            if (instance == null) {
                instance = SdkApp()
                instance!!.reg()
            }
            return instance!!
        }
    }
}
