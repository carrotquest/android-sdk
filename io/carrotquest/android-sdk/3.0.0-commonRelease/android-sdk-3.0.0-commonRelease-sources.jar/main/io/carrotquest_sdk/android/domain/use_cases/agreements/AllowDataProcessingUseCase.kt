package io.carrotquest_sdk.android.domain.use_cases.agreements

import io.carrotquest_sdk.android.Callback

import android.os.Handler
import android.os.Looper
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.data.service.CarrotService
import io.carrotquest_sdk.android.lib.CarrotLib

/**
 * Создание свойства и события о разрешении сбора данных в чате
 */
fun allowDataProcessingUseCase() {
    val userId = CarrotLib.getLibComponents().userRep.user.id ?: ""
    if(userId.isEmpty()) {
        return
    }

    CarrotService.getInstance().setUserConsentDataProcessing(true, userId, object: Callback<Boolean> {
        override fun onResponse(result: Boolean) {
            if (result) {
                Handler(Looper.getMainLooper()).postDelayed({
                    updateAppSettings("data_processing_policy_is_allowed", true)
                }, 1000)

            }
        }

        override fun onFailure(t: Throwable) {
        }
    })
}

