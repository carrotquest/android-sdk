package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.content.Context
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView

interface IDialogView : IBaseView {

    fun updateAppColor(color: Int)

    fun showErrorNoInternet()
    fun showErrorAirplaneMode()
    fun showErrorSomething()
    fun showErrorFileNotFound()
    fun showErrorSendMessage()

    fun showSendButton()
    fun hideSendButton()
    fun showAttachFileButton()
    fun hideAttachFileButton()
    fun enableSendButton()
    fun disableSendButton()

    fun showPhonePrefix()
    fun hidePhonePrefix()

    fun enableInput()
    fun disableInput()
    fun hideInput()
    fun showInput(conversationId: String)
    fun clearInput()
    fun setInputMod(mod: InputMod)
    fun updateHint(hint: String?)
    fun updateMaxLengthInput(maxLength: Int?)

    fun showDataSavedMessage()

    fun hideLoadError()
    fun hideLoading()
    fun showLoadingOlderMessages()
    fun hideLoadingOlderMessages()

    fun openFilePicker()

    fun updatePhoneRegionFlag(flag: String)
    fun updatePhoneRegionPrefix(prefix: String)

    fun setKeyboardType(keyboardType: Int)

    fun getCurrentContext(): Context?
    fun getSupportFragmentManager(): FragmentManager?
}