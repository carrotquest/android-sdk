package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface FailSendingMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(FailSendingMessage message);

//    @Query("SELECT * FROM failsendingmessage WHERE id = :identifier")
//    Single<FailSendingMessage> getById(String identifier);

    @Query("SELECT * FROM failsendingmessage WHERE conversationId = :conversationId AND inSendingProcess = 0")
    List<FailSendingMessage> getAllByConversationId(String conversationId);

    @Query("SELECT * FROM failsendingmessage WHERE inSendingProcess = 0")
    List<FailSendingMessage> getAll();

    @Query("DELETE FROM failsendingmessage WHERE id = :identifier")
    void remove(String identifier);

    @Query("UPDATE failsendingmessage SET inSendingProcess=:inProcess WHERE id = :messageId")
    void updateProcessStatus(String messageId, int inProcess);
}