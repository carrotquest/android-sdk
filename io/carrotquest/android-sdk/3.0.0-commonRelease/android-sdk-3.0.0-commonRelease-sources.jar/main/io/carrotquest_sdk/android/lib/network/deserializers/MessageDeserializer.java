package io.carrotquest_sdk.android.lib.network.deserializers;

import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;

import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.responses.messages.*;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

import com.google.gson.*;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MessageDeserializer implements JsonDeserializer<MessagesResponse> {
    private MetaMessages getMetaFromJsonElement(JsonElement jsonElement, JsonElement _meta) {
        if (jsonElement != null) {
            MetaMessages meta = new MetaMessages();
            // status может прийти не числом (строкой из-за расхождения схемы) — в этом
            // случае setStatus(0) лучше, чем уронить десериализацию всего ответа.
            try {
                JsonObject metaObj = _meta.getAsJsonObject();
                if (metaObj.has(F.STATUS) && metaObj.get(F.STATUS).isJsonPrimitive()) {
                    meta.setStatus(metaObj.get(F.STATUS).getAsInt());
                }
            } catch (Exception e) {
                Log.e("MessageDeserializer", e);
            }
            try {
                if (jsonElement.isJsonArray() && jsonElement.getAsJsonArray().size() > 0) {
                    meta.setNextAfter(jsonElement.getAsJsonArray().get(0).getAsString());
                } else if (jsonElement.isJsonPrimitive()) {
                    meta.setNextAfter(jsonElement.getAsString());
                }
            } catch (Exception e) {
                Log.e("MessageDeserializer", e);
            }

            return meta;
        }
        return (new Gson().fromJson(_meta, MetaMessages.class));
    }

    @Override
    public MessagesResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        MessagesResponse messagesResponse = new MessagesResponse();

        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("MessageDeserializer. meta is null or dataJsonElement is null");
        }

        JsonElement _meta = json.getAsJsonObject().get(F.META);
        JsonElement nextAfterJE;
        if (_meta.getAsJsonObject().has(F.NEXT_ARTER) && !_meta.getAsJsonObject().get(F.NEXT_ARTER).isJsonNull()) {
            nextAfterJE = _meta.getAsJsonObject().get(F.NEXT_ARTER);
            messagesResponse.setMeta(getMetaFromJsonElement(nextAfterJE, _meta));
        } else if (_meta.getAsJsonObject().has(F.NEXT_BEFORE_POSITION) && !_meta.getAsJsonObject().get(F.NEXT_BEFORE_POSITION).isJsonNull()) {
            nextAfterJE = _meta.getAsJsonObject().get(F.NEXT_BEFORE_POSITION);
            messagesResponse.setMeta(getMetaFromJsonElement(nextAfterJE, _meta));
        } else {
            messagesResponse.setMeta(new Gson().fromJson(_meta, MetaMessages.class));
        }

        JsonElement _data = json.getAsJsonObject().get(F.DATA);
        messagesResponse.setSourceData(_data);

        JsonArray jsonElements = _data.getAsJsonArray();
        if (jsonElements != null && jsonElements.size() > 0) {
            ArrayList<MessageData> listData = new ArrayList<>();
            for (JsonElement element : jsonElements) {
                MessageData data;
                /*if (element.getAsJsonObject().get(F.FROM) != null && element.getAsJsonObject().get(F.FROM).isJsonObject()) {
                    data = new Gson().fromJson(element, MessageData.class);
                } else {*/
                    data = new MessageData();
                    JsonObject joData = element.getAsJsonObject();
                    if (joData != null) {
                        try {
                            data.setSourceJsonData(new JSONObject((new Gson()).toJson(joData)));
                        } catch (JSONException e) {
                            Log.e("MessageDeserializer", e);
                        }
                        ArrayList<Attachment> attachments = new ArrayList<>();
                        String body = null;

                        if (joData.has(F.ID))
                            data.setId(joData.get(F.ID).getAsString());
                        if (joData.has(F.CREATED))
                            data.setCreated(joData.get(F.CREATED).getAsString());
                        if (joData.has(F.CONVERSATION))
                            data.setConversation(joData.get(F.CONVERSATION).getAsString());
                        if (joData.has(F.BODY)) {
                            body = joData.get(F.BODY).getAsString();
                            data.setBody(body);
                        }
                        if (joData.has(F.BODY_JSON))
                            data.setBodyJson(joData.get(F.BODY_JSON));
                        if (joData.has(F.READ))
                            data.setRead(joData.get(F.READ).getAsBoolean());
                        if (joData.has(F.TYPE))
                            data.setType(joData.get(F.TYPE).getAsString());
                        if (joData.has(F.REMOVED) && !joData.get(F.REMOVED).isJsonNull())
                            data.setRemoved(joData.get(F.REMOVED).getAsString());
                        if (joData.has(F.SENT_VIA)) {
                            String sentVia = joData.get(F.SENT_VIA).getAsString();
                            data.setSentVia(sentVia);

                            if ("message_manual".equals(sentVia) && body != null) {
                                int startIndex = body.indexOf("https://files.carrotquest.io");
                                int endIndex = body.indexOf(" style=") - 1;
                                if (startIndex >= 0 && endIndex >= 0 && endIndex > startIndex) {
                                    String path = body.substring(startIndex, endIndex);
                                    if (URLUtil.isValidUrl(path)) {
                                        Attachment attachment = new Attachment();
                                        attachment.setUrl(path);
                                        attachment.setId(data.getId());
                                        attachment.setType(data.getType());
                                        attachment.setCreated(data.getCreated());
                                        attachment.setFilename("file");
                                        String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension((MimeTypeMap.getFileExtensionFromUrl(path)).toLowerCase());
                                        attachment.setMimeType(mimeType);

                                        attachments.add(attachment);
                                    }
                                }
                                int startBodyIndex = body.indexOf("<p>");
                                int endBodyIndex = body.indexOf("<", 2);
                                if(startBodyIndex >= 0 && endBodyIndex >= 0 && endBodyIndex > startBodyIndex) {
                                    data.setBody(body.substring(startBodyIndex, endBodyIndex));
                                }
                                else {
                                    data.setBody("");
                                }
                            }
                        }
                        if (joData.has(F.FIRST))
                            data.setFirst(joData.get(F.FIRST).getAsBoolean());
                        if (joData.has(F.REPLY_TYPE))
                            data.setReplyType(joData.get(F.REPLY_TYPE).getAsString());

                        if (joData.has(F.FROM)) {
                            if (joData.get(F.FROM).isJsonObject()) {
                                Admin messageFrom = new Gson().fromJson(joData.get(F.FROM), Admin.class);
                                data.setMessageFrom(messageFrom);
                            } else {
                                Admin messageFrom = new Admin();
                                messageFrom.setId(joData.get(F.FROM).getAsString());
                                data.setMessageFrom(messageFrom);
                            }
                        }
                        if (joData.has(F.META_DATA)) {
                            MessageMetaData messageMetaData = new Gson().fromJson(joData.get(F.META_DATA), MessageMetaData.class);
                            data.setMessageMetaData(messageMetaData);
                        }


                        if (joData.has(F.ATTACHMENTS)) {
                            JsonArray attachmentsJArray = joData.getAsJsonArray(F.ATTACHMENTS);
                            if (attachmentsJArray != null && attachmentsJArray.size() > 0) {
                                //ArrayList<Attachment> attachments = new ArrayList<>();
                                for (JsonElement attachmentJElement : attachmentsJArray) {
                                    Attachment attachment = new Gson().fromJson(attachmentJElement, Attachment.class);
                                    if (attachment.getStatus() == null) {
                                        attachment.setStatus("");
                                    }
                                    attachments.add(attachment);
                                }
                                data.setAttachments(attachments);
                            }
                        }
                        if(data.getAttachments() == null && attachments.size() > 0) {
                            data.setAttachments(attachments);
                        }

                        // actions (кнопки/контентные блоки/поля ввода бота) — раньше история их
                        // НЕ парсила, из-за чего у повторно показанной первой ветки бота в
                        // существующем диалоге пропадали кнопки. Парсим тем же кодом, что и WSS.
                        java.util.ArrayList<ActionMessage> parsedActions =
                                io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt
                                        .parseMessageActions(joData, data.getId());
                        if (!parsedActions.isEmpty()) {
                            data.setActions(parsedActions);
                        }
                    }
                //}
                listData.add(data);
            }
            messagesResponse.setData(listData);
        }
        return messagesResponse;
    }
}
