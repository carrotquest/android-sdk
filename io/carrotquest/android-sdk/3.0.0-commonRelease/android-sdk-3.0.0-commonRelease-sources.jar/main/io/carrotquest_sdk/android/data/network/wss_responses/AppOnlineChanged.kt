package io.carrotquest_sdk.android.data.network.wss_responses

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class AppOnlineChanged : IRtsMessage {
    private val tag = "AppOnlineChanged"

    @SerializedName(F.STATUS)
    val statusOperators = "online"

    override fun process() {
        // Раньше: getSettings().take(1).subscribe{} (Rx) — теперь корутина + awaitSettings (remove_rx).
        CoroutineScope(SdkDispatchers.io).launch {
            try {
                val settings = SettingsRepository.getInstance().awaitSettings()
                val updatedSettings = SettingsEntity(
                    userId = settings.userId,
                    isShowVK = settings.isShowVK,
                    textLinkVK = settings.textLinkVK,
                    isShowViber = settings.isShowViber,
                    textLinkViber = settings.textLinkViber,
                    isShowFB = settings.isShowFB,
                    textLinkFB = settings.textLinkFB,
                    isShowTelegram = settings.isShowTelegram,
                    textLinkTelegram = settings.textLinkTelegram,
                    isShowInstagram = settings.isShowInstagram,
                    textLinkInstagram = settings.textLinkInstagram,
                    isShowWhatsapp = settings.isShowWhatsapp,
                    textLinkWhatsapp = settings.textLinkWhatsapp,
                    appColor = settings.appColor,
                    welcomeMessage = settings.welcomeMessage,
                    messengerAvatar = settings.messengerAvatar,
                    showPoweredBy = settings.showPoweredBy,
                    sourceData = settings.sourceData,
                    appName = settings.appName,
                    appId = settings.appId,
                    statusOperators = when (statusOperators) {
                        StatusOperators.ONLINE.value -> StatusOperators.ONLINE
                        StatusOperators.OFFLINE.value -> StatusOperators.OFFLINE
                        else -> StatusOperators.UNKNOWN
                    },
                    onlineMessage = settings.onlineMessage,
                    offlineMessage = settings.offlineMessage,
                    showOfflineMessage = settings.showOfflineMessage,
                    admins = settings.admins,
                    theme = settings.theme,
                    locale = settings.locale,
                )

                SettingsRepository.getInstance().saveSettings(updatedSettings)
            } catch (e: Throwable) {
                Log.e(tag, e.toString())
            }
        }
    }
}
