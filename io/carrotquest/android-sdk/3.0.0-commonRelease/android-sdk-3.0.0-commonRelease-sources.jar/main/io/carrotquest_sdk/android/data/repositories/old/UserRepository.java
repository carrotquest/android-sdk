package io.carrotquest_sdk.android.data.repositories.old;

import android.content.Context;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.HashSet;

import io.carrotquest_sdk.android.data.user.UserStateHolder;
import io.carrotquest_sdk.android.domain.entities.UserEntity;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys;


public class UserRepository implements IUserRepository {
    private User user;

    private final Context context;
    // Слушатели события «текущий юзер удалён» (раньше List<Observer<User>>; ветка remove_rx).
    private ArrayList<UserRemovedListener> removeUserListeners;

    public UserRepository(Context context) {
        this.context = context;
    }

    public void saveUser(User user) {
        //this.user = user;
        if (this.user == null) {
            this.user = new User();
        }
        if (user != null) {
            // Токен обновляем всегда, в т.ч. при пустом значении — иначе in-memory токен
            // остаётся устаревшим когда /connect возвращает ответ без auth_token.
            this.user.setToken(user.getToken());
            if (!TextUtils.isEmpty(user.getId())) {
                this.user.setId(user.getId());
            }
            if (user.getConversationsUnread() != null) {
                this.user.setConversationsUnread(user.getConversationsUnread());
            }
            this.user.setBanned(user.isBanned());
            this.user.setHasConversations(user.isHasConversations());
        }


        if (user != null && !TextUtils.isEmpty(user.getToken())) {
            SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_TOKEN, user.getToken());
        }
        else {
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN);
        }
        if(user != null) {
            SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_USER_ID, user.getId());
            ArrayList<String> l = new ArrayList<String>();
            if(user.getConversationsUnread() != null) {
                l = (ArrayList<String>) user.getConversationsUnread();
            }
            SharedPreferencesLib.saveStringSet(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS, new HashSet<>(l));
            SharedPreferencesLib.saveBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED, user.isBanned());
        }
        else {
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_ID);
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS);
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_BANNED);
        }

        if (this.user != null) {
            ArrayList<String> unread = this.user.getConversationsUnread() != null
                    ? this.user.getConversationsUnread()
                    : new ArrayList<>();
            UserEntity userEntity = new UserEntity(
                    this.user.getId() != null ? this.user.getId() : "",
                    this.user.getToken() != null ? this.user.getToken() : "",
                    this.user.isHasConversations(),
                    this.user.isBanned(),
                    unread
            );
            UserStateHolder.INSTANCE.update(userEntity);
        }
    }

    public void saveToken(String token) {
        if (this.user == null) {
            this.user = new User();
        }

        this.user.setToken(token);
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_USER_ID, this.user.getId());
    }

    @Override
    public void removeUsers(ArrayList<String> removedUsers) {
        if (user != null && removedUsers.contains(user.getId())) {
            User removed = user;
            this.user = null;
            if (removeUserListeners != null) {
                // Копия: слушатель (BaseSdkActivity) в onUserRemoved дёргает finish()/deInit().
                for (UserRemovedListener listener : new ArrayList<>(removeUserListeners)) {
                    listener.onUserRemoved(removed);
                }
                removeUserListeners.clear();
            }
        }
        UserStateHolder.INSTANCE.removeUsers(removedUsers);
    }

    @Override
    public void banUser(String userId) {
        if (userId != null && user != null && userId.equals(user.getId())) {
            user.setBanned(true);
        }
        UserStateHolder.INSTANCE.banUser(userId);
    }

    @Override
    public void unBanUser(String userId) {
        if (userId != null && user != null && userId.equals(user.getId())) {
            user.setBanned(false);
        }
        UserStateHolder.INSTANCE.unBanUser(userId);
    }


    public User getUser() {
        if (user == null || user.getId() == null || TextUtils.isEmpty(user.getToken())) {
            user = loadUser();
        }

        return user;
    }

    /**
     * Добавить слушателя события удаления юзера.
     */
    public void addRemoveUserObserver(UserRemovedListener listener) {
        if (removeUserListeners == null) {
            removeUserListeners = new ArrayList<>();
        }
        removeUserListeners.add(listener);
    }

    /**
     * Удалить слушателя события удаления юзера.
     */
    public void removeRemoveUserObserver(UserRemovedListener listener) {
        if (removeUserListeners != null) {
            removeUserListeners.remove(listener);
        }
    }


    private User loadUser() {
        User user = new User();
        user.setToken(SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_TOKEN));
        user.setId(SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_USER_ID));
        user.setConversationsUnread(SharedPreferencesLib.getPreferenceArray(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS));
        user.setBanned(SharedPreferencesLib.getBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED));
        return user;
    }
}
