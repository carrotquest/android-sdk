package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.models.UserProperty
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Suspend-версия setUserProperty (strangler, ветка remove_rx). Заменила Observable-ext из
 * UserPropertiesUseCase.kt. Ключ префиксуется "$" (как в оригинале: UserProperty("$$key", ...)).
 * Ошибка → false (как onErrorReturn { false }).
 */
suspend fun setUserProperty(userId: String, key: String, value: String): Boolean =
    withContext(Dispatchers.IO) {
        val userProperty = UserProperty("$$key", value)
        try {
            val res = CarrotInternal.getService().carrotLib
                .setPropertySuspend(userId, listOf(userProperty))
            res.status == 200
        } catch (e: Exception) {
            false
        }
    }
