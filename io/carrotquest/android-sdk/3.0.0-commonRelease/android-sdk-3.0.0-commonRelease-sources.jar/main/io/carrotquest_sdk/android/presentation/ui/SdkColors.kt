package io.carrotquest_sdk.android.presentation.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils

internal object SdkColors {
    // Фон карточек / поверхностей
    fun background(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFF2F2F2)
    // Фон страницы (контейнер)
    fun pageBackground(isDark: Boolean): Color = if (isDark) Color(0xFF333333) else Color(0xFFFFFFFF)
    // Заголовки, основной текст
    fun title(isDark: Boolean): Color = if (isDark) Color(0xFFFFFFFF) else Color(0xFF333333)
    // Вторичный текст, метаданные
    fun secondaryText(isDark: Boolean): Color = if (isDark) Color(0xFFF2F2F2) else Color(0xFF595959)
    // Рамки карточек
    fun cardBorder(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFF2F2F2)
    // Разделитель (линия)
    fun divider(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFE6E6E6)
    // Метка раздела (например, «История»)
    val sectionLabel: Color = Color(0xFF999999)
    // Время сообщения (мета рядом с баблом) — по макету #999999 в обеих темах
    val messageTime: Color = Color(0xFF999999)
    // Бейдж непрочитанных сообщений
    val unreadBadge: Color = Color(0xFFFF3B30)
    // Текст и иконки поверх акцентного цвета шапки/кнопок — чёрные на светлом accent,
    // белые на тёмном. Порог luminance 0.5 совпадает с логикой статус-бара.
    fun onAccent(accent: Color): Color =
        if (ColorUtils.calculateLuminance(accent.toArgb()) > 0.45) Color(0xFF333333) else Color.White
    // Полупрозрачный скрим под шторкой
    val scrim: Color = Color.Black.copy(alpha = 0.25f)
    // Вторичный текст поверх акцентного фона (исходящие сообщения)
    val secondaryOnAccent: Color = Color.White.copy(alpha = 0.7f)
    // Заглушка аватара отправителя
    val avatarPlaceholder: Color = Color(0xFFBDBDBD)
    // Фон карточки файла. Исходящие: акцент, осветлённый белым (альфа 0.1) — чуть светлее бабла.
    // Входящие (по макету): карточка контрастирует с баблом #F2F2F2/#4D4D4D — темнее в светлой
    // теме (#E6E6E6), светлее в тёмной (#595959).
    fun fileCardBg(isDark: Boolean, isOutgoing: Boolean, accent: Color): Color =
        if (isOutgoing) Color(ColorUtils.blendARGB(accent.toArgb(), Color.White.toArgb(), 0.1f))
        else if (isDark) Color(0xFF595959) else Color(0xFFE6E6E6)
    // Фон чипа с датой в списке сообщений
    fun dateChipBg(isDark: Boolean): Color = if (isDark) Color(0xFF2C2C2E) else Color.White
    // Фон карточки статьи из базы знаний
    fun articleCard(isDark: Boolean): Color = if (isDark) Color(0xFF5A5A5A) else Color(0xFFF1F2F4)
    // Рамка карточки оценки оператора
    fun voteBorder(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFE6E6E6)
    // Фон кружков-кнопок оценки
    fun voteButtonBg(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFFF2F2F2)
    // Рамка поля ввода комментария к оценке (светлее рамки карточки в тёмной теме)
    fun commentInputBorder(isDark: Boolean): Color = if (isDark) Color(0xFF595959) else Color(0xFFE6E6E6)
    // Фон поля ввода контактных данных (авто-ответ)
    fun contactInputBg(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color.White
    // Рамка поля ввода контактных данных
    fun contactInputBorder(isDark: Boolean): Color = if (isDark) Color(0xFF737373) else Color(0xFFE6E6E6)
}
