package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.Manifest
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.content.pm.PackageManager
import androidx.activity.result.contract.ActivityResultContracts.OpenDocument
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftMessageUseCase
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.chat.ChatEvent
import io.carrotquest_sdk.android.presentation.chat.ChatScreen
import io.carrotquest_sdk.android.presentation.chat.ChatScreenState
import io.carrotquest_sdk.android.presentation.chat.ChatViewModel
import io.carrotquest_sdk.android.presentation.chat.ContactInputType
import io.carrotquest_sdk.android.presentation.chat.ErrorKind
import io.carrotquest_sdk.android.presentation.chat.isPositiveVote
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.presentation.mvp.dialog.presenter.DialogPresenter
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper

class DialogFragment : Fragment(), IDialogView {

    companion object {
        private const val TAG = "DialogFragment"
        private const val ARG_CONVERSATION_ID = "conversation_id"

        fun newInstance(conversationId: String) = DialogFragment().apply {
            arguments = bundleOf(ARG_CONVERSATION_ID to conversationId)
        }
    }

    private val presenter = DialogPresenter()
    private val chatViewModel: ChatViewModel by viewModels()
    private var currentInputMod = InputMod.NORMAL
    // Акцентный цвет из SdkContainerViewModel (тот же, что в ChatScreen). Применяется к кнопке
    // отправки и FAB. Дефолт — на случай, если контейнер недоступен.
    private var accentColorInt: Int = 0xFF5C6BC0.toInt()
    // Контрастный цвет иконки поверх акцентного фона (белый/тёмный по яркости акцента),
    // как SdkColors.onAccent в Compose — чтобы стрелка отправки не была серой на тёмной теме.
    private var onAccentColorInt: Int = android.graphics.Color.WHITE

    private val documentPick = registerForActivityResult(OpenDocument()) { uri ->
        presenter.onOpenFile(uri)
    }

    // Запрос storage-разрешений для file picker (pre-T); раньше RxPermission, теперь AndroidX.
    private val storagePermissionLauncher = registerForActivityResult(RequestMultiplePermissions()) { results ->
        if (results.values.any { it }) {
            documentPick.launch(FilePickerHelper.mAllowMimeTypes)
        }
    }

    private val selectRegionLauncher = registerForActivityResult(
        io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries.SelectCountryContract()
    ) { country ->
        if (country != null) presenter.onCountrySelected(country)
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Layout с префиксом cq_sdk_, чтобы host-приложение/другая библиотека не могли перекрыть
        // его одноимённым ресурсом при merge (это давало null-вьюшки и NPE в initViews).
        return inflater.inflate(R.layout.cq_sdk_fragment_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val conversationId = arguments?.getString(ARG_CONVERSATION_ID) ?: ""
        chatViewModel.setConversationId(conversationId)

        applyTheme()

        try {
            presenter.attachView(this)
            presenter.onCreate()
        } catch (e: Exception) {
            Log.e(TAG, "$e")
        }

        initViews(conversationId)

        val isDark = getThemeUseCase(requireContext()) == ThemeSdk.DARK
        val accentColor = (activity as? io.carrotquest_sdk.android.presentation.container.SdkContainerActivity)
            ?.let {
                val vm = androidx.lifecycle.ViewModelProvider(it)[io.carrotquest_sdk.android.presentation.container.SdkContainerViewModel::class.java]
                vm.uiState.value.accentColor
            } ?: ComposeColor(0xFF5C6BC0.toInt())

        // Красим кнопку отправки и FAB акцентом из контейнера (initViews уже отработал — вьюхи есть).
        accentColorInt = accentColor.toArgb()
        onAccentColorInt = io.carrotquest_sdk.android.presentation.ui.SdkColors.onAccent(accentColor).toArgb()
        applyAccentColor(accentColorInt)

        // Плашка «Powered by» внизу тела чата — как в списке диалогов, по настройке аппа.
        val settings = io.carrotquest_sdk.android.data.repositories.SettingsRepository.getInstance().getSettingsObject()
        val showPoweredBy = settings?.showPoweredBy == true
        val appName = settings?.appName ?: ""

        val dialogContainer = view.findViewById<FrameLayout?>(R.id.dialog_container)
        ComposeView(requireContext()).also { composeView ->
            composeView.setViewCompositionStrategy(
                ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
            )
            composeView.setContent {
                ChatScreen(
                    viewModel = chatViewModel,
                    accentColor = accentColor,
                    isDark = isDark,
                    showPoweredBy = showPoweredBy,
                    appName = appName,
                    onEvent = { event -> handleChatEvent(event) },
                )
            }
            dialogContainer?.addView(
                composeView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        // 2) Скрытие клавиатуры системной кнопкой ↓ → editText сохраняет фокус, курсор
        //    продолжает моргать. Снимаем фокус явно, когда RootContainerForKeyboard
        //    зафиксировал увеличение окна (delta < 0 = клавиатура исчезла).
        view.findViewById<EditText?>(R.id.input_message_edit_text)?.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                val imm = v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(v.windowToken, 0)
            }
        }

        // Keyboard size detection
        view.findViewById<RootContainerForKeyboard?>(R.id.dialog_fragment_root)
            ?.setSizeListener { oldHeight, newHeight ->
                val delta = oldHeight - newHeight
                // Клавиатура была скрыта пользователем (стрелка вниз / system back).
                // EditText сам фокус не сбрасывает — синхронизируем здесь.
                // Порог 100px фильтрует мелкие переразметки (status bar, IME bar).
                if (delta < -100) {
                    requireView().findViewById<EditText?>(R.id.input_message_edit_text)?.clearFocus()
                }
            }

        presenter.onChangeConversationId(conversationId)
        presenter.onCreateWebView(conversationId)

        // Запускаем логику диалога напрямую — без ожидания загрузки WebView
        when {
            conversationId == "last_conversation" -> presenter.onOpenLastDialog()
            conversationId.isNotEmpty() -> presenter.onOpenDialog()
            else -> presenter.onOpenNewDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        presenter.onDestroy()
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun initViews(conversationId: String) {
        val view = requireView()

        // Все findViewById — null-safe. Раньше attach/send/input резолвились без ?. и падали
        // с NPE в setOnClickListener, если view отсутствовала в инфлейченном дереве. Главная причина —
        // переопределение layout-файла host-приложением при merge — закрыта префиксом cq_sdk_
        // (layout cq_sdk_fragment_dialog). Null-safety + лог оставлены как защита от прочих причин
        // (частичная инфляция / R8 / гонка lifecycle).
        val attachButton = view.findViewById<ImageButton?>(R.id.attach_file_image_button)
        val sendButton = view.findViewById<ImageButton?>(R.id.send_message_image_button)
        val inputEditText = view.findViewById<EditText?>(R.id.input_message_edit_text)

        if (attachButton == null || sendButton == null || inputEditText == null) {
            // Диагностика причины (по одной строке в логе клиента можно классифицировать проблему):
            //  - rootId != "dialog_fragment_root" ИЛИ dialogContainer/keyboardRoot=false → инфлейтится
            //    НЕ наш layout (не должно случаться после префикса cq_sdk_; если случилось — иная коллизия);
            //  - наш root, но часть вьюшек null → иная причина (частичная инфляция / R8 и т.п.).
            val rootIdName = runCatching {
                if (view.id != View.NO_ID) resources.getResourceEntryName(view.id) else "no-id"
            }.getOrDefault("?")
            val dialogContainerPresent = view.findViewById<View?>(R.id.dialog_container) != null
            val keyboardRoot = view.findViewById<View?>(R.id.dialog_fragment_root) != null
            Log.e(
                TAG,
                "initViews: chat views not found — rootId=$rootIdName, dialogContainer=$dialogContainerPresent, " +
                    "keyboardRoot=$keyboardRoot, attach=${attachButton != null}, send=${sendButton != null}, " +
                    "input=${inputEditText != null}. " +
                    "If rootId!=dialog_fragment_root → resource collision (wrong 'fragment_dialog' inflated)."
            )
        }

        attachButton?.setOnClickListener {
            presenter.onOpenPicker(getScreenHeight() * 2 / 3)
        }

        sendButton?.setOnClickListener {
            presenter.onTapSendMessage(inputEditText?.text?.toString() ?: "")
        }

        inputEditText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                presenter.onInputText(s.toString())
            }
        })

        view.findViewById<ConstraintLayout?>(R.id.phone_prefix)?.setOnClickListener {
            selectRegionLauncher.launch("")
        }

        disableInput()
    }

    private fun applyTheme() {
        val view = requireView()
        when (getThemeUseCase(requireContext())) {
            ThemeSdk.DARK -> {
                view.setBackgroundColor(Color.parseColor("#333333"))
                view.findViewById<ConstraintLayout?>(R.id.bottom_bar)
                    ?.setBackgroundColor(Color.parseColor("#333333"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setTextColor(Color.parseColor("#FFFFFF"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setHintTextColor(Color.parseColor("#B3B3B3"))
                view.findViewById<ImageView?>(R.id.phone_prefix_arrow)
                    ?.imageTintList = ColorStateList.valueOf(Color.parseColor("#999999"))
            }
            else -> {
                view.setBackgroundColor(Color.parseColor("#FFFFFF"))
                view.findViewById<ConstraintLayout?>(R.id.bottom_bar)
                    ?.setBackgroundColor(Color.parseColor("#FFFFFF"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setTextColor(Color.parseColor("#000000"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setHintTextColor(Color.parseColor("#B3B3B3"))
                view.findViewById<ImageView?>(R.id.phone_prefix_arrow)
                    ?.imageTintList = ColorStateList.valueOf(Color.parseColor("#5C6370"))
            }
        }
    }

    private fun getScreenHeight(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            requireActivity().windowManager.currentWindowMetrics.bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val size = Point()
            @Suppress("DEPRECATION")
            requireActivity().windowManager.defaultDisplay.getSize(size)
            size.y
        }
    }

    private fun changeEnabledSendButton(isEnabled: Boolean) {
        val editText = view?.findViewById<EditText>(R.id.input_message_edit_text) ?: return
        val text = editText.text.toString().trim()
        val isNotEmpty = text.isNotEmpty()

        val inputType = editText.inputType
        val correctEmail = if (inputType == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS) {
            android.util.Patterns.EMAIL_ADDRESS.matcher(text).matches()
        } else true
        val correctPhone = if (inputType == InputType.TYPE_CLASS_PHONE) {
            text.length > 5
        } else true

        val sendButton = view?.findViewById<ImageButton>(R.id.send_message_image_button) ?: return
        val enabled = isEnabled && correctEmail && correctPhone && isNotEmpty
        sendButton.isEnabled = enabled
        sendButton.alpha = if (enabled) 1f else 0.5f
    }

    override fun hideLoadError() {
        // Переходим в Loading только из Error — это семантика "скрыть оверлей ошибки".
        // Network observer вызывает hideLoadError() при каждом revalidate-пинге, и если
        // Content уже показан, сбрасывать его в Loading нельзя: setReady() после этого
        // не вызывается, и диалог зависает в вечной загрузке.
        if (chatViewModel.state.value is ChatScreenState.Error) {
            chatViewModel.setLoading()
        }
    }

    override fun hideLoading() {
        chatViewModel.setReady()
    }

    override fun showLoadingOlderMessages() {
        chatViewModel.setLoadingOlderMessages(true)
    }

    override fun hideLoadingOlderMessages() {
        val canLoadMore = MessagesRepository.getInstance().getCurrentAfter().isNotEmpty()
        chatViewModel.setLoadingOlderMessages(false, canLoadMore)
    }

    // ── IDialogView: Errors ───────────────────────────────────────────────────

    override fun showErrorNoInternet() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.NO_INTERNET)
        }
    }

    override fun showErrorAirplaneMode() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.AIRPLANE_MODE)
        }
    }

    override fun showErrorSomething() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.GENERIC)
        }
    }

    override fun showErrorFileNotFound() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showErrorSendMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showDataSavedMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_your_data_is_saved),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    // ── IDialogView: Input ────────────────────────────────────────────────────

    override fun enableInput() {
        requireActivity().runOnUiThread {
            val v = view ?: return@runOnUiThread
            v.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isEnabled = true
            v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.let { btn ->
                btn.isEnabled = true
                btn.alpha = 1f
            }
            v.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
                et.isEnabled = true
                et.alpha = 1f
            }
            changeEnabledSendButton(true)
        }
    }

    override fun disableInput() {
        val v = view ?: return
        v.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isEnabled = false
        v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.let { btn ->
            btn.isEnabled = false
            btn.alpha = 0.5f
        }
        v.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
            et.isEnabled = false
            et.alpha = 0.5f
        }
        changeEnabledSendButton(false)
    }

    override fun hideInput() {
        view?.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isGone = true
    }

    override fun showInput(conversationId: String) {
        val v = view ?: return
        val draftMessage = getDraftMessageUseCase(conversationId)
        val editText = v.findViewById<EditText?>(R.id.input_message_edit_text)
        if (draftMessage != null) {
            editText?.setText(draftMessage)
            editText?.setSelection(draftMessage.length)
        } else {
            clearInput()
        }
        v.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isVisible = true
        if (editText?.text.isNullOrEmpty()) {
            disableSendButton()
        }
    }

    override fun clearInput() {
        requireActivity().runOnUiThread {
            view?.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
                if (et.text.isNotEmpty()) et.text.clear()
            }
        }
    }

    override fun setInputMod(mod: InputMod) {
        currentInputMod = mod
        requireActivity().runOnUiThread {
            val v = view ?: return@runOnUiThread
            when (currentInputMod) {
                InputMod.NORMAL, InputMod.ALLOW_USER_REPLIES -> {
                    v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isVisible = true
                    v.findViewById<EditText?>(R.id.input_message_edit_text)?.hint =
                        getString(R.string.input_message_hint_text)
                }
                InputMod.BOT_INPUT -> {
                    v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isGone = true
                    v.findViewById<EditText?>(R.id.input_message_edit_text)?.hint = ""
                }
            }
        }
    }

    override fun updateHint(hint: String?) {
        view?.findViewById<EditText?>(R.id.input_message_edit_text)?.hint =
            hint ?: getString(R.string.input_message_hint_text)
    }

    override fun updateMaxLengthInput(maxLength: Int?) {
        view?.findViewById<EditText?>(R.id.input_message_edit_text)?.filters =
            if (maxLength != null) arrayOf(InputFilter.LengthFilter(maxLength)) else arrayOf()
    }

    override fun showSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isVisible = true
        }
    }

    override fun hideSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isGone = true
        }
    }

    override fun enableSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isVisible = true
            changeEnabledSendButton(true)
        }
    }

    override fun disableSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isVisible = true
            changeEnabledSendButton(false)
        }
    }

    override fun showAttachFileButton() {
        view?.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isVisible = true
    }

    override fun hideAttachFileButton() {
        view?.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isGone = true
    }

    override fun showPhonePrefix() {
        view?.findViewById<ConstraintLayout?>(R.id.phone_prefix)?.isVisible = true
    }

    override fun hidePhonePrefix() {
        view?.findViewById<ConstraintLayout?>(R.id.phone_prefix)?.isGone = true
    }

    override fun updatePhoneRegionFlag(flag: String) {
        view?.findViewById<TextView?>(R.id.phone_prefix_flag)?.text = flag
    }

    override fun updatePhoneRegionPrefix(prefix: String) {
        view?.findViewById<TextView?>(R.id.phone_prefix_first_symbol)?.text = prefix
    }

    override fun setKeyboardType(keyboardType: Int) {
        view?.findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.inputType = keyboardType
        view?.findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.requestFocus()
    }

    // ── IDialogView: File ─────────────────────────────────────────────────────

    override fun openFilePicker() {
        requireActivity().runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                documentPick.launch(FilePickerHelper.mAllowMimeTypes)
            } else {
                val act = requireActivity()
                val readGranted = ContextCompat.checkSelfPermission(
                    act, Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                val writeGranted = ContextCompat.checkSelfPermission(
                    act, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (!readGranted || !writeGranted) {
                    storagePermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        )
                    )
                } else {
                    documentPick.launch(FilePickerHelper.mAllowMimeTypes)
                }
            }
        }
    }

    override fun getCurrentContext(): Context? = context ?: activity

    override fun getSupportFragmentManager(): androidx.fragment.app.FragmentManager? =
        if (isAdded) parentFragmentManager else null

    override fun updateAppColor(color: Int) {
        // Единый источник акцента — SdkContainerViewModel (как в ChatScreen). Presenter-цвет из
        // настроек намеренно игнорируем: путь "#$color".toColorInt() ломался на двойном '#'
        // (getCorrectAccentColor может вернуть строку уже с '#') → исключение → кнопка серая.
        applyAccentColor(accentColorInt)
    }

    private fun applyAccentColor(colorInt: Int) {
        view?.findViewById<ImageButton>(R.id.send_message_image_button)?.let { btn ->
            btn.backgroundTintList = ColorStateList.valueOf(colorInt)
            // Стрелка — контрастная к акценту (белая на тёмном акценте), а не нейтрально-серая.
            btn.imageTintList = ColorStateList.valueOf(onAccentColorInt)
        }
    }

    private fun handleChatEvent(event: ChatEvent) {
        chatViewModel.onEvent(event)
        when (event) {
            is ChatEvent.BotOptionSelected -> presenter.onSelectBotBrunch(
                messageId = event.messageId,
                branchId = event.option.id,
                branchLinkId = event.option.branchId ?: "",
                answerBody = event.option.text,
                href = event.option.link ?: "",
                context = requireContext(),
            )
            // Позитивную оценку отправляем сразу — комментарий не нужен. Низкие оценки НЕ отправляем
            // по тапу: сначала показываем поле комментария (ChatViewModel.onEvent → setVotePending),
            // реальная отправка — в CommentVoteSent. Иначе оценка уходила бы без комментария и сервер
            // помечал сообщение как Rated, пока локальный оверрайд ещё Pending — карточка мигала и
            // откатывалась к выбору эмодзи (баг оценки оператора). Порог — isPositiveVote (не магия «5»).
            is ChatEvent.VoteSelected -> if (isPositiveVote(event.score)) presenter.sendVote(event.messageId, event.score)
            is ChatEvent.CommentVoteSent -> presenter.sendCommentVote(event.messageId, event.score, event.comment)
            is ChatEvent.ContactFormSubmitted -> {
                val type = when (event.inputType) {
                    ContactInputType.EMAIL -> "email"
                    ContactInputType.PHONE -> "phone"
                    ContactInputType.NAME  -> "name"
                    ContactInputType.TEXT  -> "text"
                }
                presenter.setContactDetails(event.messageId, type, event.value)
            }
            is ChatEvent.Retry -> presenter.retry()
            is ChatEvent.LoadOlderMessages -> presenter.paginationMessages()
            is ChatEvent.MessageTapped -> presenter.onTapMessage(requireContext(), event.messageId)
            is ChatEvent.LinkTapped -> presenter.onGoToLink(event.url, requireContext())
            else -> {}
        }
    }

}
