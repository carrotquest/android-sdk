package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import android.text.TextUtils
import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import kotlinx.coroutines.withContext
import org.json.JSONObject

// suspend-версия (strangler, ветка remove_rx). Бросает при meta.error / null-meta (как раньше
// Observable error → ловится в презентере). Пустой data = конец истории (не ошибка).
suspend fun paginationMessages(conversation: DataConversation): ArrayList<MessageData> {
    val conversationId = conversation.id ?: return ArrayList()

    val after = MessagesRepository.getInstance().getCurrentAfter()
    if (TextUtils.isEmpty(after)) {
        return ArrayList()
    }

    val response = CarrotInternal.getService().carrotLib.getMessagesSuspend(conversationId, after)
    // null meta = сетевая ошибка (getMessagesSuspend вернул пустой ответ; раньше NPE→onError).
    val meta = response.meta
        ?: throw Exception("Error load conversation by pagination: null meta")
    if (meta.error != null) {
        throw Exception("Error load conversation by pagination: ${meta.error}")
    }

    if (response.data == null) {
        // Старее сообщений нет — гасим курсор (canLoadOlderMessages станет false).
        MessagesRepository.getInstance().setCurrentAfter("")
        return ArrayList()
    }

    MessagesRepository.getInstance().setCurrentAfter(meta.nextAfter ?: "")

    // Файловый ввод-вывод + разбор JSON — на IO (вызыватель на SdkDispatchers.main).
    return withContext(SdkDispatchers.io) {
        val x = DownloadUtil.replaceFilesLocalUrl(response)
        val nArray = ArrayList<MessageData>()
        for (m in x.data) {
            val nm = x.sourceData.asJsonArray.find { p -> p.asJsonObject.get("id").asString == m.id }
            if (nm != null) {
                m.sourceJsonData = JSONObject(Gson().toJson(nm))
            }
            nArray.add(m)
        }

        MessagesRepository.getInstance().addMessages(nArray)
        nArray
    }
}