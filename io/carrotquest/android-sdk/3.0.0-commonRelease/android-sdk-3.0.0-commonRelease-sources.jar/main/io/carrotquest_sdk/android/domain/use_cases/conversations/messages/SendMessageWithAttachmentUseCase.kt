package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.saveErrorMessage
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.max

// suspend-версия (strangler, ветка remove_rx). Сетевая ошибка replyFile → 400-ответ (как раньше
// onErrorReturn) → onError(message) ветка, без throw. Всегда возвращает MessageData.
suspend fun sendMessageWithAttachment(message: MessageData): MessageData {
    val randomId = (System.currentTimeMillis() / 1000).toString()
    // attachment.url теперь хранит чистый локальный путь (без fake-префикса).
    val filePath = message.attachments?.get(0)?.url!!
    val it = try {
        CarrotInternal.getService().carrotLib.replyFileSuspend(
            message.conversation,
            File(filePath),
            message.messageFrom?.id,
            randomId
        )
    } catch (e: Throwable) {
        val errorResponse = ReplyFileResponse()
        val meta = Meta()
        meta.status = 400
        meta.error = e.message
        errorResponse.meta = meta
        errorResponse
    }
    // meta/data — nullable-поля Java-ответа: 200 без data (или null meta) роняли бы NPE мимо
    // onError. Требуем непустые meta(200)+data, иначе уходим в ветку ошибки (warning-бабл).
    val meta = it.meta
    val data = it.data
    return run {
                    if (meta?.error == null && meta?.status == 200 && data != null) {
                        val currentTimeStamp = (System.currentTimeMillis() / 1000)
                        val createdTS = when (message.created == null) {
                            true -> currentTimeStamp.toString()
                            else -> (max(
                                message.created.toLong() + 10,
                                currentTimeStamp
                            )).toString()
                        }

                        val arrayAttacments = ArrayList<Attachment>()
                        arrayAttacments.add(data.attachment)
                        val sendingMessage = MessageData()
                        //sendingMessage.id = message.id
                        sendingMessage.id = data.id
                        sendingMessage.status =
                            MessageStatus.LOADED.name.lowercase(Locale.getDefault())
                        sendingMessage.type = message.type
                        sendingMessage.isFirst = message.isFirst
                        sendingMessage.direction = message.direction
                        sendingMessage.sentVia = message.sentVia
                        sendingMessage.created = createdTS
                        sendingMessage.conversation = message.conversation
                        sendingMessage.body = message.body
                        sendingMessage.attachments = arrayAttacments
                        sendingMessage.bodyJson = message.bodyJson
                        sendingMessage.messageFrom = message.messageFrom
                        sendingMessage.messageMetaData = message.messageMetaData
                        sendingMessage.randomId = message.randomId
                        sendingMessage.read = message.read
                        sendingMessage.replyType = message.replyType

                        val sourceObject = message.sourceJsonData
                        if (sourceObject != null) {
                            if (sourceObject.has(F.STATUS)) {
                                sourceObject.remove(F.STATUS)
                            }
                            sourceObject.put(
                                F.STATUS,
                                MessageStatus.LOADED.name.lowercase(Locale.getDefault())
                            )


                            if (arrayAttacments.isNotEmpty()) {
                                if (sourceObject.has(F.ATTACHMENTS)) {
                                    sourceObject.remove(F.ATTACHMENTS)
                                }


                                val attachmentsJsonArray = JSONArray()
                                for (a in arrayAttacments) {
                                    val temp = Gson().toJson(a)
                                    val jObject = JSONObject(temp)
                                    attachmentsJsonArray.put(jObject)
                                }

                                sourceObject.put(F.ATTACHMENTS, attachmentsJsonArray)
                            }
                        }
                        sendingMessage.sourceJsonData = sourceObject

                        val conversation = ConversationsRepository.getInstance()
                            .getConversationById(message.conversation)
                        if (conversation != null) {
                            conversation.partLast = sendingMessage
                            conversation.lastUpdate = sendingMessage.created

                            val sourceConversation = conversation.sourceJsonData
                            if (sourceConversation != null) {
                                sourceConversation.remove(F.PART_LAST)
                                if (sendingMessage.sourceJsonData != null) {
                                    val jsonPartLastString: String =
                                        sendingMessage.sourceJsonData.toString()
                                    val jsonPartLast =
                                        JsonParser().parse(jsonPartLastString).asJsonObject
                                    sourceConversation.add(F.PART_LAST, jsonPartLast)
                                    conversation.sourceJsonData = sourceConversation
                                }

                                if (conversation.partsCount != null && conversation.partsCount >= 0) {
                                    if (sourceConversation.has(F.PARTS_COUNT)) {
                                        sourceConversation.remove(F.PARTS_COUNT)
                                    }
                                    sourceConversation.addProperty(
                                        F.PARTS_COUNT,
                                        conversation.partsCount.toString()
                                    )
                                }

                                if (sourceConversation.has(F.LAST_UPDATE)) {
                                    sourceConversation.remove(F.LAST_UPDATE)
                                }
                                sourceConversation.addProperty(
                                    F.LAST_UPDATE,
                                    conversation.lastUpdate
                                )
                            }

                            ConversationsRepository.getInstance()
                                .updateConversation(message.conversation, conversation)
                        }

                        MessagesRepository.getInstance().updateMessage(sendingMessage)
                        sendingMessage
                    } else {
                        onError(message, filePath)
                    }
    }
}

private fun onError(message: MessageData, filePath: String) : MessageData {
    val errorMessage = MessageData()
    errorMessage.id = message.id
    errorMessage.status = MessageStatus.WARNING.name.lowercase(Locale.getDefault())
    errorMessage.type = message.type
    errorMessage.isFirst = message.isFirst
    errorMessage.direction = message.direction
    errorMessage.sentVia = message.sentVia
    errorMessage.created = message.created
    errorMessage.conversation = message.conversation
    errorMessage.body = message.body
    errorMessage.attachments = message.attachments
    errorMessage.bodyJson = message.bodyJson
    errorMessage.messageFrom = message.messageFrom
    errorMessage.messageMetaData = message.messageMetaData
    errorMessage.randomId = message.randomId
    errorMessage.read = message.read
    errorMessage.replyType = message.replyType

    MessagesRepository.getInstance().updateMessage(errorMessage)

    saveErrorMessage(errorMessage, filePath)

    return errorMessage
}