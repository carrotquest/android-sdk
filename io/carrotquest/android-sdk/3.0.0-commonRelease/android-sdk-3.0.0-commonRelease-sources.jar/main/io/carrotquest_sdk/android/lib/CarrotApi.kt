package io.carrotquest_sdk.android.lib

import com.google.gson.JsonObject
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.lib.models.UserConversations
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit-интерфейс API. Переведён с RxJava2 `Observable<T>` на корутинные `suspend fun`
 * (ветка remove_rx, фаза 1). Сетевой слой больше не требует RxJava2CallAdapterFactory —
 * Retrofit 2.11 поддерживает suspend нативно.
 */
interface CarrotApi {

    @FormUrlEncoded
    @POST("connect")
    suspend fun connect(
        @Field("api_key") apiKey: String,
        @Field("include_auto_events") includeAutoEvents: Boolean?,
        @Field("include_js_scripts") includeJsScripts: Boolean?,
        @Field("include_push_domain") includePushDomain: Boolean?,
        @Field("browser") browser: String,
        @Field("os") os: String,
        @Field("device") device: String,
        @Field("device_type") deviceType: String,
        @Field("token_type") tokenType: String,
        @Field("referrer") referrer: String
    ): ConnectResponse

    @FormUrlEncoded
    @POST("connect")
    suspend fun connect(
        @Field("api_key") apiKey: String,
        @Field("include_auto_events") includeAutoEvents: Boolean?,
        @Field("include_js_scripts") includeJsScripts: Boolean?,
        @Field("include_push_domain") includePushDomain: Boolean?,
        @Field("browser") browser: String,
        @Field("os") os: String,
        @Field("device") device: String,
        @Field("device_type") deviceType: String,
        @Field("token_type") tokenType: String
    ): ConnectResponse

    @FormUrlEncoded
    @POST("users/app_auth/")
    suspend fun auth(
        @Field("user_id") userId: String,
        @Field("hash") hash: String,
        @Field("token_type") tokenType: String
    ): AuthResponse

    @POST("auth/jwt/refresh")
    suspend fun refresh(
        @Query("update_refresh_token") updateRefreshToken: Boolean?
    ): RefreshResponse

    @FormUrlEncoded
    @POST("users/{user_id}/events")
    suspend fun trackEvent(
        @Path("user_id") userId: String,
        @Field("event") event: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/{user_id}/events")
    suspend fun trackEvent(
        @Path("user_id") userId: String,
        @Field("event") event: String,
        @Field("params") params: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/{user_id}/props")
    suspend fun sendProps(
        @Path("user_id") userId: String,
        @Field("operations") operations: String
    ): NetworkResponse

    @GET("users/{user_id}")
    suspend fun getUser(
        @Path("user_id") userId: String,
        @Query("by_user_id") byUserId: Boolean?
    ): User

    @GET("users/{user_id}")
    suspend fun loadUser(
        @Path("user_id") userId: String,
        @Query("by_user_id") byUserId: Boolean?
    ): UserResponse

    @GET("users/{user_id}/conversations")
    suspend fun getConversations(
        @Path("user_id") userId: String
    ): UserConversations

    @GET("users/{user_id}/conversations")
    suspend fun getConversations(
        @Path("user_id") userId: String,
        // Курсор пагинации — paginate_position (как в /parts для сообщений), НЕ "after":
        // параметр "after" сервер игнорировал и отдавал ту же первую страницу.
        @Query("paginate_position") paginatePosition: String,
        @Query("paginate_including") paginateIncluding: Boolean?,
        @Query("paginate_direction") paginateDirection: String
    ): UserConversations

    @GET("conversations/{conversationId}")
    suspend fun getConversation(@Path("conversationId") conversationId: String): ConversationResponse

    @FormUrlEncoded
    @POST("users/{user_id}/startconversation")
    suspend fun startConversation(
        @Path("user_id") userId: String,
        @Field("body") messageText: String
    ): StartConversationResponse

    @Multipart
    @POST("users/{user_id}/startconversation")
    suspend fun startConversationWithFile(
        @Path("user_id") userId: String,
        @Part("boundary") requestFile: RequestBody,
        @Part("filename") filename: RequestBody,
        @Part file: MultipartBody.Part
    ): StartConversationResponse

    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String
    ): MessagesResponse

    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String,
        @Query("paginate_position") paginatePosition: String,
        @Query("paginate_including") paginateIncluding: Boolean?,
        @Query("paginate_direction") paginateDirection: String
    ): MessagesResponse

    @GET("conversations/{conversation_id}/parts")
    suspend fun getMessages(
        @Path("conversation_id") conversationId: String,
        @Query("paginate_position") paginatePosition: String,
        @Query("count") count: Int?,
        @Query("paginate_including") paginateIncluding: Boolean?,
        @Query("paginate_direction") paginateDirection: String
    ): MessagesResponse

    @FormUrlEncoded
    @POST("conversations/{conversation_id}/reply")
    suspend fun reply(
        @Path("conversation_id") conversationId: String,
        @Field("body") messageText: String,
        @Field("from_user") fromUser: Boolean,
        @Field("random_id") randomId: String
    ): ReplyResponse

    @FormUrlEncoded
    @POST("users/{userId}/pushes_subscribe")
    suspend fun sendPushToken(
        @Path("userId") userId: String,
        @Field("token") token: String,
        @Field("type") type: String,
        @Field("device_guid") deviceId: String,
        @Field("device") device: String,
        @Field("device_type") deviceType: String,
        @Field("os") os: String,
        @Field("browser") browser: String,
        @Field("user_agent") userAgent: String
    ): PushSubResponse

    @FormUrlEncoded
    @POST("users/{userId}/pushes_unsubscribe")
    suspend fun deletePushToken(
        @Path("userId") userId: String,
        @Query("device_guid") deviceId: String,
        @Field("type") type: String
    ): PushSubResponse

    @Multipart
    @POST("conversations/{conversationId}/replyfile")
    suspend fun replyFile(
        @Path("conversationId") conversationId: String,
        @Part("boundary") requestFile: RequestBody,
        @Part file: MultipartBody.Part,
        @Part("random_id") randomId: RequestBody,
        @Part("auto_assign") autoAssign: RequestBody,
        @Part("filename") fileName: RequestBody
    ): ReplyFileResponse

    @POST("conversations/{conversationId}/markread")
    suspend fun markRead(@Path("conversationId") conversationId: String): NetworkResponse

    @FormUrlEncoded
    @POST("conversationparts/{messageId}/meta_data")
    suspend fun conversationParts(
        @Path("messageId") messageId: String,
        @Field("meta_data") metaData: JsonObject
    ): NetworkResponse

    @FormUrlEncoded
    @POST("conversations/{conversationId}/settyping")
    suspend fun setTyping(
        @Path("conversationId") conversationId: String,
        @Field("body") messageBody: String,
        @Field("from_user") fromUser: Boolean
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/{user_id}/setpresence")
    suspend fun setPresence(
        @Path("user_id") userId: String,
        @Field("presence") presence: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/setpresence")
    suspend fun setPresenceCurrentScreen(
        @Field("presence") presence: String,
        @Field("current_sdk_page") currentScreen: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("conversationparts/{part_id}/meta_data")
    suspend fun setMetaData(
        @Path("part_id") partId: String,
        @Field("meta_data") metaData: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("messages/trackinteraction")
    suspend fun trackinteraction(
        @Field("conversation_id") conversationId: String,
        @Field("type") type: String
    ): NetworkResponse

    @GET("chatbots/routing/choose")
    suspend fun chooseRoutingBot(@Query("conversation") conversationId: String): ChooseRoutingBotResponse

    @FormUrlEncoded
    @POST("chatbots/routing/start")
    suspend fun startRoutingBot(
        @Field("chat_bot") botId: String,
        @Field("initial_answer_action") buttonActionId: String,
        @Field("initial_answer_body") buttonActionText: String,
        @Field("random_id") randomId: String?,
        @Field("conversation") conversationId: String?
    ): NetworkResponse

    @FormUrlEncoded
    @POST("chatbots/routing/start")
    suspend fun startRoutingBot(
        @Field("chat_bot") botId: String,
        @Field("initial_answer_action") buttonActionId: String,
        @Field("initial_answer_body") buttonActionText: String,
        @Field("random_id") randomId: String?
    ): NetworkResponse

    @FormUrlEncoded
    @POST("utils/logs")
    suspend fun sendLog(
        @Field("message_type") messageType: String,
        @Field("message") message: String,
        @Field("data") data: String
    ): NetworkResponse

    @GET("triggers/trigger_types")
    suspend fun getTriggers(): TriggersResponse

    @FormUrlEncoded
    @POST("users/\$self_user/triggers")
    suspend fun sendTrigger(
        @Field("trigger_types") triggerIds: List<String>
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/user_consent")
    suspend fun setUserConsentContact(
        @Field("contacts") contacts: String,
        @Field("part") partId: String,
        @Query("request_user") userId: String
    ): NetworkResponse

    @FormUrlEncoded
    @POST("users/\$self_user/user_consent")
    suspend fun setUserConsentDataProcessing(
        @Field("data_processing") dataProcessing: Boolean,
        @Query("request_user") userId: String
    ): NetworkResponse
}