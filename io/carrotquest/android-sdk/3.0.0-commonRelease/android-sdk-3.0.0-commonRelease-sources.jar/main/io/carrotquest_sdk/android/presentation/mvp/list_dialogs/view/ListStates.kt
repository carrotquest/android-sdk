package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.remember
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.ErrorContent
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ErrorType
import androidx.core.net.toUri

internal val WriteButtonHeight = 52.dp

// ── Ошибка (список диалогов) ──────────────────────────────────────────────────

@Composable
internal fun ListErrorContent(errorType: ErrorType, isDark: Boolean, onRetry: () -> Unit) {
    val (title, message) = when (errorType) {
        ErrorType.NO_INTERNET -> Pair(
            stringResource(R.string.title_load_error_str),
            stringResource(R.string.message_load_error_str)
        )
        ErrorType.AIRPLANE_MODE -> Pair(
            stringResource(R.string.title_air_mode_error_str),
            stringResource(R.string.message_air_mode_error_str)
        )
        ErrorType.SOMETHING_WENT_WRONG -> Pair(
            stringResource(R.string.title_load_other_error_str),
            stringResource(R.string.message_load_other_error_str)
        )
    }
    ErrorContent(
        title = title,
        message = message,
        retryText = stringResource(R.string.button_load_error_str),
        isDark = isDark,
        onRetry = onRetry
    )
}

// ── Пустой список ─────────────────────────────────────────────────────────────

@Composable
internal fun EmptyState(isDark: Boolean, navBarHeight: Dp = 0.dp, showPoweredBy: Boolean = false) {
    val cardBg = SdkColors.background(isDark)
    // 16dp gap + button height + (powered_by height if shown) + 16dp button bottom padding + navBar
    val bottomPadding = 16.dp + WriteButtonHeight + (if (showPoweredBy) PoweredByHeight else 0.dp) + 16.dp + navBarHeight
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = bottomPadding),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .background(cardBg)
                .padding(horizontal = 24.dp, vertical = 40.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.ic_cq_zero_conversations_list),
                contentDescription = null,
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = stringResource(R.string.empty_conversation_list_title),
                color = SdkColors.secondaryText(isDark),
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.empty_conversation_list_message),
                color = SdkColors.secondaryText(isDark).copy(alpha = 0.6f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Подложка с кнопкой «Написать» (+ опциональная плашка Powered by) ─────────

internal val PoweredByHeight = 33.dp

@Composable
internal fun WriteButtonTray(
    accentColor: Color,
    isDark: Boolean,
    navBarHeight: Dp,
    modifier: Modifier = Modifier,
    showPoweredBy: Boolean = false,
    appName: String = "",
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = 38.dp, topEnd = 38.dp))
            .background(SdkColors.pageBackground(isDark))
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = navBarHeight),
            //.padding(top = 16.dp, bottom = 16.dp + navBarHeight),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WriteButton(
            accentColor = accentColor,
            modifier = Modifier.fillMaxWidth(),
            onClick = onClick
        )
        if (showPoweredBy) {
            Spacer(modifier = Modifier.height(10.dp))
            PoweredByBar(appName = appName)
        }
    }
}

// ── Плашка «Работает на / Powered by» ────────────────────────────────────────

@Composable
internal fun PoweredByBar(appName: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val providerName = when (BuildConfig.FLAVOR) {
        "common" -> "Carrot quest"
        "us" -> "Dashly"
        else -> "Dashly"
    }
    val providerIcon = when (BuildConfig.FLAVOR) {
        "common" -> R.drawable.ic_cq_logo_carrot
        "us" -> R.drawable.ic_logo_dashly
        else -> R.drawable.ic_logo_dashly
    }
    val urlBase = when (BuildConfig.FLAVOR) {
        "common" -> "https://www.carrotquest.io/"
        "us" -> "https://www.dashly.io/"
        else -> "https://www.dashly.io/"
    }
    val url = "${urlBase}?utm_campaign=testdrive&utm_medium=outbound&utm_source=cqchat" +
            "&utm_term=mobile&app_name=${Uri.encode(appName)}&platform=android"

    Row(
        // Без fillMaxWidth: Row обворачивает контент по ширине — нужно, чтобы в чате плашку можно
        // было показать «плавающей» скруглённой пилюлей (фон/паддинги приходят через modifier).
        // В списке (WriteButtonTray) контент по-прежнему центрируется самим Column'ом.
        modifier = modifier
            .height(PoweredByHeight)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                context.startActivity(Intent(Intent.ACTION_VIEW, url.toUri()))
            },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = stringResource(R.string.popup_powered_by_start_text),
            color = SdkColors.sectionLabel,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            painter = painterResource(providerIcon),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = Color.Unspecified
        )
        if (providerName.isNotEmpty()) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = providerName,
                color = SdkColors.sectionLabel,
                fontSize = 12.sp
            )
        }
    }
}

// ── Кнопка «Написать» ─────────────────────────────────────────────────────────

@Composable
internal fun WriteButton(accentColor: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val onAccent = remember(accentColor) { SdkColors.onAccent(accentColor) }
    Button(
        onClick = onClick,
        modifier = modifier.height(WriteButtonHeight),
        shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.buttonColors(containerColor = accentColor),
        contentPadding = PaddingValues(horizontal = 24.dp)
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_cq_write),
            contentDescription = null,
            tint = onAccent,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = stringResource(R.string.list_write_button),
            color = onAccent,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
