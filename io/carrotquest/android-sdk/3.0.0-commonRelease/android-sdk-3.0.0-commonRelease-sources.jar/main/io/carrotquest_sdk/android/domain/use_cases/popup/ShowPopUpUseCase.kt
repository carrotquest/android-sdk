package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.markConversationAsReadById
import io.carrotquest_sdk.android.presentation.container.SdkContainerActivity
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper
import io.carrotquest_sdk.android.presentation.mvp.popup.view.IPopUp
import io.carrotquest_sdk.android.presentation.mvp.popup.view.PopupAlertDialog
import io.carrotquest_sdk.android.presentation.mvp.web_view.WebViewLoadListener
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull


// Подписка на смену текущей Activity (раньше Disposable от subscribeOnCurrentActivity; remove_rx).
private var loadingJob: Job? = null

// Страховка от зависшей подписки на смену Activity, если попап так и не загрузился.
private const val LOADING_SUBSCRIPTION_TIMEOUT_MS = 30_000L

// Скоуп для suspend use-cases внутри showPopup (markConversationAsReadById/getConversation +
// collect смены Activity), раньше — fire-and-forget Observable.subscribe внутри runOnUiThread.
private val popUpScope = CoroutineScope(SdkDispatchers.io + SupervisorJob())

suspend fun showPopup(entity: PopUpMessageEntity?) {
    if (entity == null) return

    val loadWebViewObserver = getLoadWebViewObserver(entity)
    loadingJob?.cancel()
    loadingJob = popUpScope.launch {
        // Страховочный таймаут: collect бесконечный, штатно его отменяет disposeLoading() из
        // load-колбэка. Но если попап так и не загрузился (ошибка/закрыт/не IPopUp) — collect висел
        // бы до следующего showPopup. withTimeoutOrNull снимает зависшую подписку.
        withTimeoutOrNull(LOADING_SUBSCRIPTION_TIMEOUT_MS) {
            SdkApp.getInstance().currentActivityChanges().collect { activity ->
                if (activity is IPopUp) {
                    activity.setLoadWebViewObserver(loadWebViewObserver)
                }
            }
        }
    }

    val currentActivity = SdkApp.getInstance().currentActivity ?: return
    withContext(SdkDispatchers.main) {
        if (currentActivity !is SdkContainerActivity
            && !PopupAlertDialog.isShowing()
        ) {
            val builder = PopupAlertDialog(currentActivity, R.style.popUpStyle)
            val x = builder.show()
            x.show()
            builder.setData(entity.id, entity.sourceBodyJson, entity.backgroundColor)

            val id = entity.id
            PushNotificationHelper.getInstance().clearNotifications(id)

            popUpScope.launch {
                try {
                    val conversationId = markConversationAsReadById(id)
                    SdkApp.getInstance().database.popUpDao().deleteById(conversationId)
                } catch (t: Throwable) {
                    Log.e("showPopup().markConversationAsReadById()", t)
                }
            }
        } else {
            //create and save conversation with popup
            val popUpId = entity.id
            popUpScope.launch {
                val conversation = getConversationSuspend(popUpId)
                if (conversation != null) {
                    ConversationsRepository.getInstance()
                        .updateInfoAboutConversation(conversation)
                }
            }
        }
    }
}

private fun getLoadWebViewObserver(popUpMessageEntity: PopUpMessageEntity): WebViewLoadListener =
    WebViewLoadListener { isShowed ->
        popUpScope.launch {
            try {
                saveState(popUpMessageEntity, isShowed)
            } catch (t: Throwable) {
                Log.e("showPopup()/getLoadWebViewObserver()", t)
            } finally {
                disposeLoading()
            }
        }
    }

private fun disposeLoading() {
    loadingJob?.cancel()
    loadingJob = null
}
