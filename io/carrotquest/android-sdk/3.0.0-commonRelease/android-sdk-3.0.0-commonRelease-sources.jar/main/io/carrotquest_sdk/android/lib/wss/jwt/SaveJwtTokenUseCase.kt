package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import java.util.Date

fun saveJwtToken(token: String, context: Context = CarrotLib.getLibComponents().getContext()) {
    val oldToken = getJwtToken()
    if(oldToken != token) {
        val currentTime = Date().time
        SharedPreferencesLib.saveLong(context, jwtTokenUpdateTimeStampKey, currentTime)
    }

    SharedPreferencesLib.saveString(context, jwtTokenKey, token)
    SdkLogger.log(
        SdkLogLevel.INFO, SdkLogCategory.AUTH, "TokenFlow",
        "saveJwtToken: access=${maskToken(token)} (changed=${oldToken != token})",
    )
}