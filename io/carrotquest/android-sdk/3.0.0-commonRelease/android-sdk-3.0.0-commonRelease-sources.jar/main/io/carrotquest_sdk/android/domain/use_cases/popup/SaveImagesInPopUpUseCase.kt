package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.lib.utils.isDashly
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Кэширует фоновые картинки попапа в локальный кэш — fire-and-forget на IO (downloadFilesToCash
 * блокирующий, без Rx; ветка remove_rx). Раньше — Single<PopUpMessage>.saveImages(appId).
 */
fun saveImages(popUpMessage: PopUpMessage, appId: String?) {
    val baseUrl = if (isDashly())
        "https://files.dashly.app/message-images/${appId ?: ""}/"
    else
        "https://files.carrotquest.io/message-images/${appId ?: ""}/"

    val needSavedFiles = ArrayList<String>()
    for (row in popUpMessage.rows) {
        for (block in row.blocks) {
            if (block.backgroundImage != null && block.backgroundImage.isNotEmpty()) {
                needSavedFiles.add(
                    if (!block.backgroundImage.contains("http://") && !block.backgroundImage.contains("https://"))
                        baseUrl + block.backgroundImage
                    else
                        block.backgroundImage
                )
            }
        }
    }

    if (needSavedFiles.isNotEmpty()) {
        CoroutineScope(SdkDispatchers.io).launch {
            try {
                DownloadUtil.downloadFilesToCash(needSavedFiles, baseUrl)
            } catch (t: Throwable) {
                Log.e("saveImages()", t)
            }
        }
    }
}
