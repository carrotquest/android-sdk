package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerComparison
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch


class TrackScreenUseCase {
    // fire-and-forget из CarrotSDK (Java). Внутри — корутина: presence → триггеры → sendTrigger.

    fun call(screenName: String) {
        scope.launch {
            try {
                SetPresenceCurrentScreenUseCase().call(screenName)

                val triggers = GetTriggersUseCase().call()
                val posTriggers =
                    triggers.filter { t -> t.comparison == TriggerComparison.Eq || t.comparison == TriggerComparison.Contains }
                val negTriggers =
                    triggers.filter { t -> t.comparison == TriggerComparison.Neq || t.comparison == TriggerComparison.NotContains }

                val posIds = getPosTriggersIds(posTriggers, screenName.lowercase())
                val negIds = getNegTriggersIds(negTriggers, screenName.lowercase())

                val trIds = posIds.plus(negIds)

                if (trIds.isNotEmpty()) {
                    val response = CarrotInternal.getService().carrotLib.sendTriggerSuspend(trIds)
                    Log.d("SEND_TRIGGER", "${response.meta?.status}")
                }
            } catch (t: Throwable) {
                Log.e("SEND_TRIGGER", "error trackScreen: $t")
            }
        }
    }

    private fun getPosTriggersIds(posTriggers: List<TriggerEntity>, screenName: String): List<String> {
        val eqIds =
            posTriggers.filter { t -> t.comparison == TriggerComparison.Eq }
                .filter { t -> t.url.lowercase() == screenName }.map { t -> t.id }
        val containsIds =
            posTriggers.filter { t -> t.comparison == TriggerComparison.Contains }
                .filter { t -> screenName.contains(t.url.lowercase()) }.map { t -> t.id }

        return eqIds.plus(containsIds)
    }

    private fun getNegTriggersIds(negTriggers: List<TriggerEntity>, screenName: String): List<String> {
        val neqIds =
            negTriggers.filter { t -> t.comparison == TriggerComparison.Neq }
                .filter { t -> t.url.lowercase() != screenName }.map { t -> t.id }

        val notContainsIds =
            negTriggers.filter { t -> t.comparison == TriggerComparison.NotContains }
                .filter { t -> !screenName.contains(t.url.lowercase()) }.map { t -> t.id }

        return neqIds.plus(notContainsIds)
    }

    companion object {
        // Один общий скоуп на все вызовы: CarrotSDK создаёт new TrackScreenUseCase() на каждый
        // trackScreen, поэтому скоуп-поле инстанса копился бы (Job не отменялся). Корутины здесь
        // одноразовые и завершаются сами.
        private val scope = CoroutineScope(SdkDispatchers.io + SupervisorJob())
    }
}
