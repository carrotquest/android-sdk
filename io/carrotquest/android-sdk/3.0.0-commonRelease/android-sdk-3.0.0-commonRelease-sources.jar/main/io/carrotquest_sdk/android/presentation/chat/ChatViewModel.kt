package io.carrotquest_sdk.android.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel
import io.carrotquest_sdk.android.domain.use_cases.bot.loadRoutingBot
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel : ViewModel() {

    private val _state = MutableStateFlow<ChatScreenState>(ChatScreenState.Loading)
    val state: StateFlow<ChatScreenState> = _state.asStateFlow()

    // Ответы на кнопки бота, отправленные в текущей сессии.
    // Нужно, т.к. сервер не проставляет replied=true на исходное сообщение с кнопками
    // до переоткрытия диалога. Очищается при уничтожении VM (при закрытии диалога).
    private val localBotAnswers = mutableMapOf<String, String>() // messageId → selectedOptionId

    // Локальное состояние голоса: выставляется в Loading при отправке, живёт до
    // тех пор, пока сервер не пришлёт Rated в сообщении. Нужно, чтобы rebuildList()
    // не откатывал Loading → Pending пока сервер обрабатывает запрос.
    private val localVoteStates = mutableMapOf<String, VoteState>() // messageId → VoteState

    // Локальное состояние формы контактов: Submitting при отправке, живёт до тех пор,
    // пока сервер не пришлёт replied=true → MessageMapper вернёт Submitted.
    private val localContactStates = mutableMapOf<String, ContactInputState>() // messageId → state

    // conversation_id, с которым диалог был открыт (для нового диалога — пустой).
    // @Volatile: пишется с Main (setConversationId), читается с IO (rebuildList) — как routingBotResolved.
    @Volatile private var conversationId: String = ""

    // Все id, относящиеся к текущей сессии диалога: исходный + живой из DialogViewModel
    // (routing bot создаёт сначала временный randomId, затем реальный id). Копим их, чтобы
    // при переходе randomId → реальный id уже показанные сообщения не пропадали из списка.
    // MessagesRepository глобальный, поэтому фильтрация по этим id обязательна.
    private val knownConversationIds = mutableSetOf<String>()

    // Ответ сервера на chooseRoutingBot — обновляется при каждом открытии диалога.
    // Если found=true, startBrunch включается в список сообщений.
    private val _routingBotData = MutableStateFlow<ChooseRoutingBotData?>(null)

    // true, когда наличие бота уже выяснено у бэкенда. До этого welcome не показываем,
    // чтобы он не мелькал перед ботом: сначала спрашиваем бота, потом решаем что рисовать.
    @Volatile private var routingBotResolved = false

    fun setConversationId(id: String) {
        conversationId = id
        fetchRoutingBot(id)
    }

    private fun fetchRoutingBot(convId: String) {
        viewModelScope.launch {
            try {
                // Источник истины — found=true от бэкенда, поэтому chooseRoutingBot запрашиваем для
                // ЛЮБОГО диалога (как презентер в commonSubscribes). Раньше тут стоял early-return для
                // LEAD_BOT/ROUTING_BOT по предположению «для них всегда found=false» — но оно неверно:
                // для routing_bot-диалога бэкенд может вернуть found=true и просить повторно показать
                // первую ветку, а early-return это глушил (первое сообщение бота не появлялось). Дубль
                // защищён serverHasFirstBranch в rebuildList.
                val data = loadRoutingBot(convId)
                // Проставляем conversationId в startBrunch сразу — у шаблонного сообщения он null.
                data?.bot?.startBrunch?.let { msg ->
                    if (msg.conversation.isNullOrEmpty()) msg.conversation = convId
                }
                _routingBotData.value = data
            } catch (e: Exception) {
                // Сеть/парсинг упали — считаем, что бота нет, показываем welcome.
            } finally {
                routingBotResolved = true
                triggerRebuild()
            }
        }
    }

    private var currentTypingIndicator: ChatListItem.TypingIndicator? = null

    // Единственный канал перестройки списка. DROP_OLDEST + collectLatest гарантируют:
    // — параллельных rebuildList() нет (предыдущий отменяется новым trigger-ом);
    // — если новый trigger приходит пока предыдущий ещё на IO, старый fetch отменяется
    //   и запускается свежий, поэтому в state всегда попадают актуальные данные.
    private val rebuildTrigger = MutableSharedFlow<Unit>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    init {
        viewModelScope.launch { rebuildTrigger.collectLatest { rebuildList() } }
        observeMessages()
    }

    private fun triggerRebuild() { rebuildTrigger.tryEmit(Unit) }

    private fun observeMessages() {
        val repo = MessagesRepository.getInstance()

        viewModelScope.launch {
            repo.newMessagesFlow.collect { triggerRebuild() }
        }
        viewModelScope.launch {
            repo.removedMessageFlow.collect { triggerRebuild() }
        }
        viewModelScope.launch {
            repo.typingIndicatorFlow.collect { pair ->
                currentTypingIndicator = pair?.let { (name, avatarUrl) ->
                    ChatListItem.TypingIndicator(name = name, avatarUrl = avatarUrl)
                }
                triggerRebuild()
            }
        }
        // setData() (bulk load) эмитит в dataFlow (раньше — только messagesSubject); собираем
        // напрямую корутинным Flow, чтобы порядок при переоткрытии диалога был верным.
        viewModelScope.launch {
            repo.dataFlow.collect { triggerRebuild() }
        }
    }

    private suspend fun rebuildList() = withContext(Dispatchers.IO) {
        val db = SdkApp.getInstance().database
        val repo = MessagesRepository.getInstance()
        // Снимок (а не живой data.data): итерация живого списка конкурентно с WSS-мутациями
        // кидала ConcurrentModificationException → пустой чат.
        val allMessages = repo.getMessagesSnapshot()
        // Живой id диалога держит presenter в DialogViewModel (он же по нему фильтрует свои
        // сообщения). Берём его и копим — это покрывает routing bot: новый диалог стартует с
        // пустым id, после выбора ветки бэкенд создаёт диалог (сначала временный randomId,
        // затем реальный id), и сообщения бота приходят уже с этим id.
        val liveId = DialogViewModel.getInstance().getCurrentConversationId()
        if (liveId.isNotEmpty()) knownConversationIds.add(liveId)
        if (conversationId.isNotEmpty() && conversationId != "last_conversation") {
            knownConversationIds.add(conversationId)
        }
        val ids = knownConversationIds
        // Сообщения чужих диалогов отсекаем; пустой conversation (оптимистичные/первое
        // сообщение нового диалога) показываем всегда; пока id ещё нет — только isFirst.
        val rawMessages = allMessages.filter { m ->
            m.conversation.isNullOrEmpty() ||
            m.conversation in ids ||
            (ids.isEmpty() && m.isFirst)
        }

        // Стартовая ветка routing-бота (шаблон из chooseRoutingBot) живёт только здесь — реальным
        // сообщением в репозиторий она не попадает (до перезахода), поэтому при общении с ботом её
        // надо держать, иначе пропадёт первая пачка (приветствие+кнопки). Источник истины — found=true
        // от бэкенда (как в старом WebView-теле, где презентер выставлял needStartRoutingBot=found).
        // Убираем шаблон в двух случаях:
        //  1) серверная первая ветка уже подгрузилась (на resume/reload) — иначе он дублирует серверные
        //     «Привет!» + кнопки. Детект: у какого-то сообщения answerActionId совпадает с branch-id
        //     опции шаблона (= сервер записал ответ на первую ветку);
        //  2) на НОВОМ диалоге (conversationId пуст) юзер напечатал своё сообщение (reply_user) — т.е.
        //     прервал бота и начал обычный диалог, не ответив кнопкой → первую ветку показывать не надо.
        //     На ПЕРЕОТКРЫТИИ существующего диалога (есть реальный conversationId) reply_user — это
        //     прошлая история, а не свежее прерывание: там решает found бэкенда, проверку не применяем.
        val template = _routingBotData.value?.takeIf { it.found == true }?.bot?.startBrunch
        val templateBranchIds = template?.actions?.mapNotNull { it.nextBranchId }?.toSet() ?: emptySet()
        val serverHasFirstBranch = templateBranchIds.isNotEmpty() && rawMessages.any { m ->
            m.messageMetaData?.answerActionId?.let { it in templateBranchIds } == true
        }
        val interruptedNewDialog = conversationId.isEmpty() &&
            rawMessages.any { it.type == ResponseFields.REPLY_USER }
        val startBrunch = if (!serverHasFirstBranch && !interruptedNewDialog) template else null

        // Позиционирование шаблона первой ветки зависит от того, КАК открыт диалог:
        //
        //  • ПЕРЕОТКРЫТИЕ существующего диалога (conversationId не пуст): бэкенд просит ПОВТОРНО
        //    показать первую ветку как актуальный промпт — он должен встать ВНИЗУ, под старой
        //    историей, с активными кнопками. Шаблон приходит без created/sortKey → по умолчанию
        //    (created→0) уехал бы наверх как «самое старое» и схлопнул бы кнопки (isAnswered =
        //    !isNewest). Поэтому делаем его новейшим: created = max среди сообщений, sortKey = maxId+1
        //    (как у оптимистичных исходящих, см. MessageMapper.sortKey). Фиксируем ОДИН раз
        //    (sortKey == null): после тапа приходит реальный ответ со свежим (бо́льшим) id и корректно
        //    встаёт НИЖЕ замороженного шаблона.
        //
        //  • НОВЫЙ диалог (conversationId пуст): шаблон — это ПЕРВОЕ приветствие бота, т.е. самое
        //    СТАРОЕ сообщение. Его НЕ пиним: с created=null (→0) он естественно встаёт наверх, а
        //    ответ пользователя и следующая реплика бота ложатся под ним по своим created. Если бы
        //    пинили — шаблон стал бы новейшим и выдавил реальную последнюю реплику бота наверх
        //    (сообщения routing-старта часто приходят одной секундой, тай-брейк по sortKey/id).
        if (startBrunch != null && startBrunch.sortKey == null &&
            rawMessages.isNotEmpty() && conversationId.isNotEmpty()) {
            // created/sortKey берём из тех же repo-хелперов, что и оптимистичные исходящие
            // (sendActionBot) — единый источник правил «последний created» и maxId+1, без дублирования
            // тай-брейка sortKey?:id здесь.
            startBrunch.created = repo.getLastMessageCreatedSeconds().toString()
            startBrunch.sortKey = repo.getMaxMessageId() + 1
        }

        // Welcome — заглушка пустого диалога. Показываем ТОЛЬКО после ответа бэкенда про бота
        // (routingBotResolved) и когда бота нет и нет реальных сообщений: при открытии пустого
        // чата либо бот (startBrunch), либо welcome — не оба, и без мелькания welcome перед ботом.
        val welcomeMsg = if (routingBotResolved && rawMessages.isEmpty() && startBrunch == null)
            repo.getWelcomeMessage() else null

        val messages = buildList {
            if (welcomeMsg != null) add(welcomeMsg) else addAll(rawMessages)
            if (startBrunch != null) add(startBrunch)
        }

        val mappedItems = MessageMapper.map(messages, db)
        withContext(Dispatchers.Main) {
            val current = _state.value
            if (current is ChatScreenState.Content) {
                val result = ChatStateReducer.applyLocalOverrides(
                    mapped = mappedItems,
                    botAnswers = localBotAnswers,
                    voteStates = localVoteStates,
                    contactStates = localContactStates,
                    typing = currentTypingIndicator,
                )
                // Сервер подтвердил оценку (Loading→Rated) / форму контактов (Submitting→Submitted) —
                // ПИНим подтверждённое состояние локально на сессию, а не снимаем оверрайд: иначе
                // последующий серверный reload без оценки/replied откатил бы карточку к исходному виду
                // (выбор эмодзи / поле ввода контакта).
                result.voteUpgrades.forEach { (id, rated) -> localVoteStates[id] = rated }
                result.contactUpgrades.forEach { (id, state) -> localContactStates[id] = state }
                _state.value = current.copy(items = result.items.ifEmpty { emptyList() })
            }
        }
    }

    fun showError(kind: ErrorKind) {
        _state.value = ChatScreenState.Error(kind)
    }

    fun setLoading() {
        _state.value = ChatScreenState.Loading
    }

    fun setReady() {
        if (_state.value !is ChatScreenState.Content) {
            val canLoad = MessagesRepository.getInstance().getCurrentAfter().isNotEmpty()
            _state.value = ChatScreenState.Content(canLoadOlderMessages = canLoad)
        }
        triggerRebuild()
    }

    fun setLoadingOlderMessages(isLoading: Boolean, canLoadMore: Boolean = true) {
        val current = _state.value as? ChatScreenState.Content ?: return
        _state.value = current.copy(
            isLoadingOlderMessages = isLoading,
            canLoadOlderMessages = if (isLoading) current.canLoadOlderMessages else canLoadMore,
        )
    }

    fun onEvent(event: ChatEvent) {
        when (event) {
            is ChatEvent.BotOptionSelected -> markBotGroupAnswered(event.messageId, event.option.id)
            is ChatEvent.VoteSelected -> {
                // score == 5 (позитивная оценка) — комментарий не нужен, сразу Loading.
                // score < 5 — показываем поле комментария, Loading выставим при его отправке.
                if (event.score == 5) setVoteLoading(event.messageId)
                else setVotePending(event.messageId)
            }
            is ChatEvent.CommentVoteSent -> setVoteLoading(event.messageId)
            is ChatEvent.ContactFormSubmitted -> setContactSubmitting(event.messageId)
            is ChatEvent.Retry -> setLoading()
            else -> {}
        }
    }

    private fun markBotGroupAnswered(messageId: String, selectedOptionId: String) {
        localBotAnswers[messageId] = selectedOptionId
        val current = _state.value as? ChatScreenState.Content ?: return
        val updatedItems = current.items.map { item ->
            if (item is ChatListItem.BotOptionsGroup && item.messageId == messageId)
                item.copy(isAnswered = true, selectedOptionId = selectedOptionId)
            else item
        }
        _state.value = current.copy(items = updatedItems)
    }

    // Резолв файла-вложения из текущего UI-состояния (не из MessagesRepository): модель уже
    // содержит url/size/mime, и lookup по item.id работает даже для бот-блоков (синтетический id).
    fun getFileAttachment(messageId: String, attachmentId: String): UiAttachment.FileAttachment? {
        val content = (_state.value as? ChatScreenState.Content) ?: return null
        val message = content.items
            .filterIsInstance<ChatListItem.Message>()
            .firstOrNull { it.id == messageId } ?: return null
        val files = (message.content as? MessageContent.TextContent)
            ?.attachments?.filterIsInstance<UiAttachment.FileAttachment>() ?: return null
        return files.firstOrNull { it.id == attachmentId }
    }

    private fun setContactSubmitting(messageId: String) {
        localContactStates[messageId] = ContactInputState.Submitting
        val current = _state.value as? ChatScreenState.Content ?: return
        val updatedItems = current.items.map { item ->
            if (item is ChatListItem.Message && item.id == messageId) {
                val content = item.content as? MessageContent.ContactInputContent ?: return@map item
                item.copy(content = content.copy(state = ContactInputState.Submitting))
            } else item
        }
        _state.value = current.copy(items = updatedItems)
    }

    private fun setVotePending(messageId: String) {
        localVoteStates[messageId] = VoteState.Pending
    }

    private fun setVoteLoading(messageId: String) {
        localVoteStates[messageId] = VoteState.Loading
        val current = _state.value as? ChatScreenState.Content ?: return
        val updatedItems = current.items.map { item ->
            if (item is ChatListItem.VoteCard && item.messageId == messageId)
                item.copy(voteState = VoteState.Loading)
            else item
        }
        _state.value = current.copy(items = updatedItems)
    }
}