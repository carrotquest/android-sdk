package io.carrotquest_sdk.android.core.init

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch

internal object OperationQueue {

    private const val TAG = "OperationQueue"
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Java interop: fire-and-forget, выполняется после готовности SDK
    fun enqueue(block: Runnable) {
        scope.launch {
            try {
                SdkStateManager.awaitReady()
                block.run()
            } catch (e: CancellationException) {
                // норма: deInit вызван пока операция ждала
            } catch (e: Exception) {
                Log.e(TAG, e.toString())
            }
        }
    }

    // Kotlin: suspend, возвращает результат блока
    suspend fun <T> execute(block: suspend () -> T): T {
        SdkStateManager.awaitReady()
        return block()
    }

    fun cancelAll() {
        scope.coroutineContext.cancelChildren()
    }
}
