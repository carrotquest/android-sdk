package io.carrotquest_sdk.android.presentation.chat

sealed class ChatEvent {
    data class BotOptionSelected(
        val messageId: String,
        val option: BotOption,
    ) : ChatEvent()

    data class VoteSelected(
        val messageId: String,
        val score: Int,
    ) : ChatEvent()

    data class ContactFormSubmitted(
        val messageId: String,
        val value: String,
        val inputType: ContactInputType,
    ) : ChatEvent()

    data class ImageTapped(val urls: List<String>, val initialIndex: Int) : ChatEvent()

    // Тап по карточке файла: начать загрузку / отменить / открыть — в зависимости от downloadState
    data class FileTapped(val messageId: String, val attachmentId: String) : ChatEvent()

    data class MessageTapped(val messageId: String) : ChatEvent()

    // Тап по ссылке внутри сообщения / кнопке статьи. Открытие и аналитика клика
    // (trackClick) выполняются в presenter.onGoToLink.
    data class LinkTapped(val url: String) : ChatEvent()

    data class CommentVoteSent(
        val messageId: String,
        val score: Int,
        val comment: String,
    ) : ChatEvent()

    data object Retry : ChatEvent()
    data object LoadOlderMessages : ChatEvent()
}
