package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.sql.Timestamp

class PopupRepository {

    companion object {
        // Горячий поток id истёкших попапов (раньше PublishSubject; ветка remove_rx).
        private val _expirationFlow = MutableSharedFlow<String>(extraBufferCapacity = 16)
        val expirationFlow: SharedFlow<String> = _expirationFlow.asSharedFlow()

        // Скоуп для отложенного удаления истёкших попапов (раньше Observable.delay.subscribe).
        private val expirationScope = CoroutineScope(SupervisorJob() + SdkDispatchers.io)

        fun savePopUp(popUp: PopUpDbEntity) {
            SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .insert(popUp)

            if (popUp.expirationTime > 0) {
                startPopUpExpiration(popUp.id, popUp.expirationTime)
            }
        }

        fun removePopUpById(id: String) {
            SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .deleteById(id)
        }

        fun getAllPopUps(): ArrayList<PopUpDbEntity> {
            val dbArray = SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .getAllPopUpsSync()

            return ArrayList(dbArray
                    .filterNotNull())
        }

        // Непрерывный поток всех попапов из БД (раньше Observable-мост для Java-SdkApp; remove_rx).
        fun getAllPopUpsFlow(): Flow<ArrayList<PopUpDbEntity>> {
            return SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .getAllPopUps()
                    .map { dbEntities -> ArrayList(dbEntities) }
                    .flowOn(SdkDispatchers.io)
        }

        private fun startPopUpExpiration(id: String, expirationTime: Long) {
            val correctExpirationTime: Long = expirationTime * 1000
            val currentTime = Timestamp(System.currentTimeMillis()).time
            val minExpirationTime = 30 * 1000L
            //Считаем разницу между временем, в которое надо удалить сообщение и текущим времененм
            val diff = if (correctExpirationTime - currentTime < minExpirationTime) {
                minExpirationTime
            } else {
                correctExpirationTime - currentTime
            }
            expirationScope.launch {
                delay(diff)
                removePopUpById(id)
                _expirationFlow.tryEmit(id)
            }
        }
    }
}
