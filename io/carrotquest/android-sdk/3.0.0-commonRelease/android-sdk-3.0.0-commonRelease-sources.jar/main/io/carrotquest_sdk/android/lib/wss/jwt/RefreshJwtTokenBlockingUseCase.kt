package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import kotlinx.coroutines.runBlocking

private const val TAG = "TokenFlow"

// Shared lock — serializes all callers (timer + HTTP 401 interceptor).
internal val refreshLock = Any()

/**
 * Синхронно обновляет JWT-токен. Безопасно при конкурентных вызовах:
 * если пока мы ждали lock другой поток уже обновил токен — возвращаем готовый.
 *
 * @param failedToken токен, с которым запрос получил 401 (null для timer-based refresh)
 */
internal fun refreshJwtTokenBlocking(failedToken: String? = null): String? {
    // Никогда не звать с главного потока: блокирующий сетевой вызов под общим локом = ANR.
    // Все текущие вызыватели вне main (OkHttp-интерсептор / ConnectionManager на IO) — guard
    // фиксирует контракт и громко падает в debug, если его нарушат.
    if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
        throw IllegalStateException("refreshJwtTokenBlocking() must not be called on the main thread")
    }
    synchronized(refreshLock) {
        val current = getJwtToken()
        if (!failedToken.isNullOrEmpty() && current.isNotEmpty() && current != failedToken) {
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "refreshBlocking: token already refreshed by another thread, reusing access=${maskToken(current)}",
            )
            return current
        }
        val updateRefresh = !isActualRefreshToken()
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "refreshBlocking: requesting /refresh (updateRefreshToken=$updateRefresh). State: ${tokenStateSummary()}",
        )
        return try {
            val carrotApi = CarrotLib.getLibComponents().carrotApi
            val response = runBlocking { carrotApi.refresh(updateRefresh) }
            if (response.meta.status == 200) {
                saveJwtToken(response.data.access)
                saveRefreshToken(response.data.refresh)
                SdkLogger.log(
                    SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                    "refreshBlocking: SUCCESS, new access=${maskToken(response.data.access)} (refresh token still alive)",
                )
                response.data.access
            } else {
                // Не-200: refresh-токен отвергнут сервером → оба токена мертвы → caller уйдёт в анонима.
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refreshBlocking: REJECTED status=${response.meta.status} error=${response.meta.error} → refresh token dead, will fall back to anonymous",
                )
                null
            }
        } catch (e: java.io.IOException) {
            // Сетевая ошибка — пробрасываем, чтобы caller мог отличить её от серверного отказа.
            // Токены при этом не трогаем: они могут быть валидны, просто сеть недоступна.
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "refreshBlocking: NETWORK error (tokens NOT touched): $e",
            )
            throw e
        } catch (e: Exception) {
            // Защита от обёрнутого checked IOException (если транспорт когда-либо завернёт его в
            // RuntimeException): разворачиваем и пробрасываем, иначе сетевой сбой выглядел бы как
            // «refresh мёртв» и приводил бы к сбросу токенов/анониму.
            val cause = e.cause
            if (cause is java.io.IOException) {
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refreshBlocking: NETWORK error (unwrapped, tokens NOT touched): $cause",
                )
                throw cause
            }
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "refreshBlocking: error $e")
            null
        }
    }
}
