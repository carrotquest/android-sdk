package io.carrotquest_sdk.android.lib.utils;

import android.content.Context;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import io.carrotquest_sdk.android.core.util.Log;

/**
 * Обёртка над SharedPreferences: все I/O операции обёрнуты в try/catch, чтобы сбой диска
 * (ENOSPC, permission denied, commit backpressure, SecurityException при context==null)
 * не валил SDK по пути сохранения токенов / настроек / UTM. При ошибке чтение возвращает
 * дефолт, запись — молча фейлится с логом.
 */
public class SharedPreferencesLib {
    public static final String NAME_SHARED_PREFERENCES = "io.carrotquest.utils";
    private static final String TAG = "SharedPreferencesLib";

    public SharedPreferencesLib() {
    }

    public static void saveBoolean(Context context, String key, boolean value) {
        try {
            android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
            if (editor == null) return;
            editor.putBoolean(key, value);
            editor.apply();
        } catch (Throwable t) {
            Log.e(TAG, "saveBoolean '" + key + "' failed: " + t);
        }
    }

    public static void saveString(Context context, String key, String value) {
        try {
            android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
            if (editor == null) return;
            editor.putString(key, value);
            editor.apply();
        } catch (Throwable t) {
            Log.e(TAG, "saveString '" + key + "' failed: " + t);
        }
    }

    public static void saveInt(Context context, String key, int value) {
        try {
            android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
            if (editor == null) return;
            editor.putInt(key, value);
            editor.apply();
        } catch (Throwable t) {
            Log.e(TAG, "saveInt '" + key + "' failed: " + t);
        }
    }

    public static void saveLong(Context context, String key, long value) {
        try {
            android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
            if (editor == null) return;
            editor.putLong(key, value);
            editor.apply();
        } catch (Throwable t) {
            Log.e(TAG, "saveLong '" + key + "' failed: " + t);
        }
    }

    private static android.content.SharedPreferences.Editor getSharedEditor(Context context, String key) {
        if (context == null) return null;
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        android.content.SharedPreferences.Editor editor = sharedPreferences.edit();
        if (sharedPreferences.contains(key)) {
            editor.remove(key);
        }

        return editor;
    }

    public static String getString(Context context, String key) {
        try {
            if (context == null) return "";
            android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
            return sharedPreferences.getString(key, "");
        } catch (Throwable t) {
            Log.e(TAG, "getString '" + key + "' failed: " + t);
            return "";
        }
    }

    public static boolean getBoolean(Context context, String key) {
        try {
            if (context == null) return false;
            android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
            return sharedPreferences.getBoolean(key, false);
        } catch (Throwable t) {
            Log.e(TAG, "getBoolean '" + key + "' failed: " + t);
            return false;
        }
    }

    public static long getLong(Context context, String key) {
        try {
            if (context == null) return 0L;
            android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
            return sharedPreferences.getLong(key, 0);
        } catch (Throwable t) {
            Log.e(TAG, "getLong '" + key + "' failed: " + t);
            return 0L;
        }
    }

    public static int getInt(Context context, String key) {
        try {
            if (context == null) return 0;
            android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
            return sharedPreferences.getInt(key, 0);
        } catch (Throwable t) {
            Log.e(TAG, "getInt '" + key + "' failed: " + t);
            return 0;
        }
    }

    public static void saveStringSet(Context context, String key, Set<String> value) {
        try {
            android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
            if (editor == null) return;
            editor.putStringSet(key, value);
            editor.apply();
        } catch (Throwable t) {
            Log.e(TAG, "saveStringSet '" + key + "' failed: " + t);
        }
    }

    public static Set<String> getStringSet(Context context, String key) {
        try {
            if (context == null) return new HashSet<>();
            android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
            // Возвращаем КОПИЮ: инстанс из getStringSet модифицировать нельзя (контракт Android —
            // "you must not modify the instance returned"), а вызыватели (SdkApp/FindPopUp) делают .add().
            Set<String> stored = sharedPreferences.getStringSet(key, null);
            return stored == null ? new HashSet<>() : new HashSet<>(stored);
        } catch (Throwable t) {
            Log.e(TAG, "getStringSet '" + key + "' failed: " + t);
            return new HashSet<>();
        }
    }

    public static ArrayList<String> getPreferenceArray(Context context, String key) {
        try {
            if (context == null) return new ArrayList<>();
            android.content.SharedPreferences prefs = context.getSharedPreferences(NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE);
            Set<String> unreadConversations = prefs.getStringSet(key, null);
            if (unreadConversations == null) {
                return new ArrayList<>();
            }
            return new ArrayList<>(Objects.requireNonNull(unreadConversations));
        } catch (Throwable t) {
            Log.e(TAG, "getPreferenceArray '" + key + "' failed: " + t);
            return new ArrayList<>();
        }
    }

    public static void clearPreference(Context context, String key) {
        try {
            if (context == null) return;
            android.content.SharedPreferences prefs = context.getSharedPreferences(NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE);
            prefs.edit().remove(key).apply();
        } catch (Throwable t) {
            Log.e(TAG, "clearPreference '" + key + "' failed: " + t);
        }
    }
}
