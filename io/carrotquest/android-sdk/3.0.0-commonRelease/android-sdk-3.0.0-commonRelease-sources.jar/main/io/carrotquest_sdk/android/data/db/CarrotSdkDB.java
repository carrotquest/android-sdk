package io.carrotquest_sdk.android.data.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import io.carrotquest_sdk.android.data.db.files.SavedFile;
import io.carrotquest_sdk.android.data.db.files.SavedFileDao;
import io.carrotquest_sdk.android.data.db.messages.BotActionsDao;
import io.carrotquest_sdk.android.data.db.messages.BotActionsEntity;
import io.carrotquest_sdk.android.data.db.messages.ClosedMessage;
import io.carrotquest_sdk.android.data.db.messages.ClosedMessageDao;
import io.carrotquest_sdk.android.data.db.messages.ExpirationMessage;
import io.carrotquest_sdk.android.data.db.messages.ExpirationMessageDao;
import io.carrotquest_sdk.android.data.db.messages.FailSendingMessage;
import io.carrotquest_sdk.android.data.db.messages.FailSendingMessageDao;
import io.carrotquest_sdk.android.data.db.messages.ReadMessage;
import io.carrotquest_sdk.android.data.db.messages.ReadMessageDao;
import io.carrotquest_sdk.android.data.db.messages.SendingMessageToBroadcastReceiver;
import io.carrotquest_sdk.android.data.db.messages.SendingMessageToBroadcastReceiverDao;
import io.carrotquest_sdk.android.data.db.messages.ShowedPush;
import io.carrotquest_sdk.android.data.db.messages.ShowedPushDao;
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity;
import io.carrotquest_sdk.android.data.db.popup.PopUpDao;
import io.carrotquest_sdk.android.data.db.triggers.TriggerDao;
import io.carrotquest_sdk.android.data.db.triggers.TriggerDbEntity;

@Database(
        entities = {
                ReadMessage.class,
                SendingMessageToBroadcastReceiver.class,
                SavedFile.class,
                ClosedMessage.class,
                ExpirationMessage.class,
                FailSendingMessage.class,
                ShowedPush.class,
                PopUpDbEntity.class,
                TriggerDbEntity.class,
                BotActionsEntity.class
        },
        version = 26,
        exportSchema = false)
public abstract class CarrotSdkDB extends RoomDatabase {
    public abstract ReadMessageDao readMessageDao();

    public abstract SendingMessageToBroadcastReceiverDao sendingMessageToBroadcastReceiverDao();

    public abstract SavedFileDao savedFileDao();

    public abstract ClosedMessageDao closedMessageDao();

    public abstract ExpirationMessageDao expirationMessageDao();

    public abstract FailSendingMessageDao failSendingMessageDao();

    public abstract ShowedPushDao showedPushDao();

    public abstract PopUpDao popUpDao();
    public abstract TriggerDao triggerDao();

    public abstract BotActionsDao botActionsDao();
}
