package io.carrotquest_sdk.android.data.repositories

import android.os.Build
import android.text.Html
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.ExpirationMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.addNewMessage
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import java.sql.Timestamp
import java.util.Locale

class MessagesRepository private constructor() {
    private var data = MessagesResponse()
    private var currentAfter = ""
    private var welcomeMessage: MessageData? = null

    // Замена Rx Subject-ов на Flow (ветка remove_rx, фаза 4). BehaviorSubject.create() ≡
    // SharedFlow(replay=1) (реплей последнего, без начальной эмиссии); PublishSubject ≡
    // SharedFlow(replay=0). getData наружу мостится через asObservable.
    // replay=1 — снапшот текущего состояния списка; при переполнении буфера осознанно
    // отбрасываем самый старый снапшот (важна последняя версия данных, а не история).
    private val _dataFlow = MutableSharedFlow<MessagesResponse>(
        replay = 1,
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    // Корутинный API «данные изменились» для Compose-потребителей (ChatViewModel) — без моста getData()->Observable.
    val dataFlow: SharedFlow<MessagesResponse> = _dataFlow.asSharedFlow()
    // addMessagesSubject и removeMessageSubject схлопнуты в существующие _newMessagesFlow /
    // _removedMessageFlow (см. getAddedMessages/getRemovedMessage).

    // Flow — modern API for Compose/Coroutines consumers
    private val _newMessagesFlow = MutableSharedFlow<List<MessageData>>(extraBufferCapacity = 16)
    val newMessagesFlow: SharedFlow<List<MessageData>> = _newMessagesFlow.asSharedFlow()

    private val _removedMessageFlow = MutableSharedFlow<MessageData?>(extraBufferCapacity = 16)
    val removedMessageFlow: SharedFlow<MessageData?> = _removedMessageFlow.asSharedFlow()

    // Pair<name, avatarUrl> пока печатает оператор, null — когда остановился.
    private val _typingIndicatorFlow = MutableStateFlow<Pair<String?, String?>?>(null)
    val typingIndicatorFlow: StateFlow<Pair<String?, String?>?> = _typingIndicatorFlow.asStateFlow()

    private var endTypingJob: Job? = null
    private var typingObserverJob: Job? = null

    // Долгоживущие фоновые обработчики потока новых сообщений (бывшие Observable-ext
    // onAddConversation/onAddExpirationMessages, ветка remove_rx). Отменяются в deInit().
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        // Максимум записей в кэше actions бот-кнопок (bot_actions). Сверх — самые старые (по created)
        // эвиктятся; восстановление кнопок в очень старых переписках при этом деградирует мягко.
        private const val BOT_ACTIONS_CACHE_LIMIT = 300

        @Volatile
        private var instance: MessagesRepository? = null
        fun getInstance(): MessagesRepository {
            // Double-checked locking — после deInit() instance=null, и параллельный
            // re-init может попытаться создать его дважды.
            val existing = instance
            if (existing != null) return existing
            return synchronized(MessagesRepository::class.java) {
                val cur = instance
                if (cur != null) cur
                else {
                    val fresh = MessagesRepository()
                    instance = fresh

                    // Корутинные обработчики потока новых сообщений (раньше — Observable-ext
                    // onAddConversation/onAddExpirationMessages, подписанные тут же).
                    fresh.startMessageHandlers()

                    // Подписываемся на индикатор печати из CarrotService
                    fresh.initTypingObserver()
                    fresh
                }
            }
        }
    }

    private fun initTypingObserver() {
        // collect на Main: addMessageTyping/removeMessageTyping обновляют UI-flow (ветка remove_rx).
        // Job в repoScope → отменяется в deInit (repoScope.cancel()).
        typingObserverJob = repoScope.launch(SdkDispatchers.main) {
            CarrotInternal.getLibComponent().carrotService.adminTypingEvents.collect { message ->
                val currentOpenedId = ConversationsRepository.getInstance().getOpenedConversationId()
                if (message.conversation == currentOpenedId) {
                    addMessageTyping(message)

                    endTypingJob?.cancel()
                    endTypingJob = repoScope.launch(SdkDispatchers.main) {
                        delay(3000L)
                        removeMessageTyping()
                    }
                }
            }
        }
    }

    /**
     * Запускает фоновые обработчики потока новых сообщений. Раньше это были две подписки на
     * Observable-ext onAddConversation/onAddExpirationMessages в getInstance().
     */
    private fun startMessageHandlers() {
        // Догрузка беседы, если сообщение пришло для ещё не загруженной беседы
        // (getConversationSuspend имеет сайд-эффект подгрузки беседы в ConversationsRepository).
        repoScope.launch {
            _newMessagesFlow.collect { messages ->
                for (m in messages) {
                    try {
                        getConversationSuspend(m.conversation)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // догрузка беседы не критична
                    }
                }
            }
        }

        // Планирование удаления «протухающих» сообщений.
        repoScope.launch {
            _newMessagesFlow.collect { messages ->
                try {
                    handleExpirationMessages(messages)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // обработка протухания не критична
                }
            }
        }
    }

    private fun handleExpirationMessages(messages: List<MessageData>) {
        if (messages.size != 1) return
        val message = messages[0]
        val expirationTime = message.expirationTime ?: return

        addExpirationMessage(message.id)

        val correctExpirationTime = expirationTime * 1000
        val currentTime = Timestamp(System.currentTimeMillis()).time
        val minExpirationTime = (30 * 1000).toLong()
        // Разница между моментом удаления и текущим временем (не меньше минимума).
        val diff: Long = when (correctExpirationTime - currentTime < minExpirationTime) {
            true -> minExpirationTime
            else -> correctExpirationTime - currentTime
        }

        repoScope.launch {
            delay(diff)
            val expirationMessageIds = getExpirationMessageIds()
            if (!expirationMessageIds.contains(message.id)) return@launch

            val openedConversationId = ConversationsRepository.getInstance().getOpenedConversationId()
            if (message.conversation != openedConversationId) {
                removeMessage(message.id)
            }
            removeExpirationMessage(message.id)

            val conversation = getConversationSuspend(message.conversation)
            if (conversation != null && conversation.id != null
                && conversation.partsCount == 1 && conversation.partLast?.id == message.id
            ) {
                ConversationsRepository.getInstance().removeConversation(conversation.id)
            }
        }
    }

    /**
     * Полный teardown для re-init сценария (Carrot.deInit() → setup()).
     * Diosposes подписок, обнуляет состояние, сбрасывает singleton, чтобы при следующем
     * getInstance() создался свежий instance, заново подписанный на новые Subject'ы
     * перезапущенного CarrotService.
     */
    fun deInit() {
        // repoScope.cancel() отменяет все фоновые задачи, включая typingObserverJob/endTypingJob
        // и отложенные задачи удаления протухших сообщений.
        typingObserverJob = null
        endTypingJob = null
        repoScope.cancel()
        messageTyping = null
        _typingIndicatorFlow.value = null

        data = MessagesResponse()
        welcomeMessage = null
        currentAfter = ""

        synchronized(MessagesRepository::class.java) {
            instance = null
        }
    }


    // getData() Observable-мост удалён — Compose-потребители на dataFlow (SharedFlow) напрямую.

    fun getDataSingle(): List<MessageData> {
        // Возвращаем копию под общим lock: раньше отдавали ЖИВОЙ ArrayList, и его итерация
        // у вызывающих (например, GetAttachmentUseCase) конкурентно с WSS-мутациями давала
        // ConcurrentModificationException. То же решение, что и getMessagesSnapshot().
        return synchronized(lock) { ArrayList(this.data.data ?: emptyList<MessageData>()) }
    }

    fun setData(messages: MessagesResponse) {
        synchronized(lock) {
            val currentData = this.data.data ?: ArrayList()
            // Если в репозитории уже больше сообщений, чем пришло — не сбрасываем список:
            // это первая страница при онResume-рефреше поверх ранее загруженной пагинации.
            // Мерджим, чтобы избежать shrink-флика в LazyColumn.
            val newData = messages.data ?: ArrayList()
            // Мерджим только если новый список непустой и меньше текущего — это признак
            // того, что пришла первая страница поверх уже загруженной пагинации (onResume-рефреш).
            // Если newData пуст — это намеренный сброс (новый диалог, CreateMessageUseCase и т.п.).
            if (currentData.isNotEmpty() && newData.isNotEmpty() && newData.size < currentData.size) {
                addMessages(ArrayList(newData), hardUpdate = false) // addMessages реентрантно берёт lock
                return
            }

            this.data = messages
            this.welcomeMessage = null
            // При намеренном сбросе (пустой список = новый диалог) очищаем курсор пагинации.
            // Иначе canLoadOlderMessages остаётся true от предыдущего диалога,
            // и LazyColumn сразу тригерит paginationMessages() → ошибку.
            if (newData.isEmpty()) {
                currentAfter = ""
            }
        }
        _dataFlow.tryEmit(this.data)
    }

    fun getMessages() = this.data

    // Потокобезопасный снимок списка сообщений. getMessages().data отдаёт ЖИВОЙ ArrayList,
    // и его итерация (например, в ChatViewModel.rebuildList) конкурентно с мутациями из WSS
    // приводила к ConcurrentModificationException → пустой чат. Копия под общим lock безопасна.
    fun getMessagesSnapshot(): List<MessageData> =
        synchronized(lock) { ArrayList(this.data.data ?: emptyList<MessageData>()) }

    /**
     * created (в секундах) самого позднего сообщения в текущем диалоге; 0 если пусто.
     * Нужно как защита от перекоса системных часов устройства: исходящее сообщение не
     * должно визуально вставать раньше уже существующих (чат сортируется по created).
     */
    fun getLastMessageCreatedSeconds(): Long = synchronized(lock) {
        (this.data.data ?: emptyList()).maxOfOrNull { it.created?.toLongOrNull() ?: 0L } ?: 0L
    }

    /**
     * Максимальный id-снежинка среди сообщений текущего диалога; 0 если пусто. Используется
     * для расчёта sortKey оптимистичного исходящего сообщения (maxId+1) — чтобы оно встало
     * строго после текущего последнего сообщения, но перед будущими серверными (их снежинки
     * больше). Учитываем и собственный sortKey уже добавленных оптимистичных сообщений.
     */
    fun getMaxMessageId(): Long = synchronized(lock) {
        (this.data.data ?: emptyList()).maxOfOrNull {
            it.sortKey ?: it.id?.toLongOrNull() ?: 0L
        } ?: 0L
    }

    fun setCurrentAfter(after: String) {
        this.currentAfter = after
    }

    fun getCurrentAfter() = this.currentAfter

    fun findMessageById(messageId: String): MessageData? {
        // Чтение под общим lock: .find{} итерирует список, который WSS-мутации меняют
        // структурно → иначе ConcurrentModificationException.
        return synchronized(lock) { this.data.data?.find { x -> x.id == messageId } }
    }

    fun removeMessage(message: MessageData) {
        synchronized(lock) {
            if (this.data.data != null) {
                this.data.data.remove(message)
            } else {
                this.data.data = ArrayList()
            }
        }
        _dataFlow.tryEmit(this.data)
        _removedMessageFlow.tryEmit(message)
    }

    fun removeMessage(messageId: String) {
        val message = synchronized(lock) {
            val m = this.data.data.find { x -> x.id == messageId }
            this.data.data.remove(m)
            m
        }
        if (message != null) {
            _removedMessageFlow.tryEmit(message)
        }
        _dataFlow.tryEmit(this.data)
    }

    // Кэшируем кнопки (actions) бот-сообщений в БД: история с сервера их не отдаёт, а
    // приходят они только вживую по WSS. Восстанавливаем при загрузке истории (getMessages).
    private fun cacheBotActions(message: MessageData) {
        val actions = message.actions
        if (actions.isNullOrEmpty()) return
        val id = message.id ?: return
        val conv = message.conversation ?: return
        val created = message.created?.toLongOrNull() ?: 0L
        repoScope.launch {
            try {
                val json = com.google.gson.Gson().toJson(actions)
                val dao = CarrotInternal.getLibComponent().sdkDataBase.botActionsDao()
                dao.insert(io.carrotquest_sdk.android.data.db.messages.BotActionsEntity(id, conv, json, created))
                // Ограничиваем кэш — иначе таблица растёт без предела за всю жизнь БД.
                dao.trimToLatest(BOT_ACTIONS_CACHE_LIMIT)
            } catch (e: Exception) {
                // кэш кнопок — не критично, молча игнорируем сбой
            }
        }
    }

    fun addMessage(message: MessageData) {
        cacheBotActions(message)
        synchronized(lock) {
            if (this.data.data == null) {
                this.data.data = ArrayList()
            }
            // Дедупликация: не добавляем если сообщение с таким id уже есть
            if (message.id != null && this.data.data.any { it.id == message.id }) return
            this.data.data.add(message)
        }
        val addMessages = ArrayList<MessageData>()
        addMessages.add(message)
        _newMessagesFlow.tryEmit(addMessages)
        _dataFlow.tryEmit(this.data)
    }

    private val lock = Any()
    fun addMessages(messages: ArrayList<MessageData>, hardUpdate: Boolean = false) {
        if (this.data.data == null) {
            this.data.data = ArrayList()
        }

        messages.forEach { cacheBotActions(it) }
        synchronized(lock) {
            val diffMessages = ArrayList<MessageData>()
            diffMessages.addAll(messages.filterNot { x ->
                this.data.data.map { a -> a.id }.contains(x.id)
            })

            this.data.data.addAll(diffMessages)
            if (hardUpdate) {
                val allMessages = ArrayList<MessageData>()
                allMessages.addAll(this.data.data)
                _newMessagesFlow.tryEmit(allMessages)
            } else {
                _newMessagesFlow.tryEmit(diffMessages)
            }

            _dataFlow.tryEmit(this.data)
        }
    }

    fun addWssMessage(message: MessageData) {
        repoScope.launch { addNewMessage(message) }
        val conversation = ConversationsRepository.getInstance().getConversationById(message.conversation)
        if (conversation != null && conversation.id != null) {
            val sourceConversation = conversation.sourceJsonData
            if (sourceConversation != null) {
                sourceConversation.remove(F.PARTS_COUNT)
                sourceConversation.addProperty(F.PARTS_COUNT, conversation.partsCount.toString())
                sourceConversation.remove(F.UNREAD_PARTS_COUNT)
                sourceConversation.addProperty(
                    F.UNREAD_PARTS_COUNT,
                    conversation.unreadPartsCount.toString()
                )
                sourceConversation.remove(F.LAST_UPDATE)
                sourceConversation.addProperty(F.LAST_UPDATE, conversation.lastUpdate)
                conversation.sourceJsonData = sourceConversation
            }

            val conversationId = conversation.id
            if (conversationId != null) {
                ConversationsRepository.getInstance()
                    .updateConversation(conversationId, conversation)
            }
        }

        var body = message.body
        if (message.type == ResponseFields.ARTICLE) {
            if (message.bodyJson != null && message.bodyJson.isJsonObject) {
                if (message.bodyJson.asJsonObject.has(F.NAME)) {
                    body = message.bodyJson.asJsonObject[F.NAME].asString
                }
            }
        } else if(message.type == ResponseFields.VOTE) {
            body = CarrotLib.getLibComponents().context.getString(R.string.plese_vote_operator)
        }

        body = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(body, Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            Html.fromHtml(body).toString()
        }

        if(message.attachments != null && message.attachments.isNotEmpty()) {
            val firstAttachment = message.attachments.first()
            val trueBody = message.body.ifEmpty {
                if (firstAttachment.mimeType.lowercase(Locale.getDefault()).contains("image")) {
                    CarrotLib.getLibComponents().context.getString(R.string.image_str)
                } else {
                    CarrotLib.getLibComponents().context.getString(R.string.file_str)
                }
            }

            val imageStr =  if (firstAttachment.mimeType.lowercase(Locale.getDefault()).contains("image")) {
                "🖼 "
            } else {
                "📎 "
            }

            body = imageStr + trueBody
        }

        val isFromBot = (message.type == "chat_bot_user" && !message.actions.isNullOrEmpty())
        if(!isFromBot) {
            val conversationType = conversation?.type
            PushNotificationHelper.getInstance().postNotification(message.id.toString(),
                    if (message.messageFrom == null) "" else message.messageFrom.name,
                    body, message.conversation.toString(), message.sentVia, conversationType, null, null)
        }

        replaceMessageTyping(message)
        updateMessage(message)
    }

    // Observable-мосты getAddedMessages/getUpdatedMessage/getRemovedMessage/getAddedBatch удалены —
    // Compose-потребители на newMessagesFlow/removedMessageFlow напрямую (ветка remove_rx).

    fun updateMessage(message: MessageData) {
        cacheBotActions(message)
        if(this.data == null || this.data.data == null) {
            return
        }
        val updated = synchronized(lock) {
            val index = this.data.data.indexOfFirst { x ->
                x.id == message.id
                        || (x.randomId !=  null && x.randomId != "0" && x.randomId == message.randomId)
                        || (x.randomId !=  null && x.randomId != "0" &&x.id == message.randomId)
                        || (x.randomId !=  null && x.randomId != "0" &&x.randomId == message.id)
            }
            if (index >= 0) {
                this.data.data[index] = message
                true
            } else {
                false
            }
        }

        if (updated) {
            _dataFlow.tryEmit(this.data)
        }
    }

    private var messageTyping: MessageData? = null
    fun addMessageTyping(message: MessageData) {
        if (messageTyping == null && message.messageFrom != null) {
            messageTyping = message
            _typingIndicatorFlow.value = Pair(message.messageFrom?.name, message.messageFrom?.avatar)
            val addMessages = ArrayList<MessageData>()
            addMessages.add(message)
            _newMessagesFlow.tryEmit(addMessages)
        }
    }

    fun removeMessageTyping() {
        if(this.data.data != null) {
            this.data.data.remove(messageTyping)
            if (messageTyping != null) {
                _typingIndicatorFlow.value = null
                _removedMessageFlow.tryEmit(messageTyping)
                messageTyping = null
            }
            _dataFlow.tryEmit(this.data)
        }
    }

    fun replaceMessageTyping(message: MessageData) {
        if (this.data.data != null && messageTyping != null) {
            removeMessageTyping()
        }
        addMessage(message)
    }

    fun saveWelcomeMessage(message: MessageData?) {
        this.welcomeMessage = message
    }

    fun getWelcomeMessage(): MessageData? {
        return this.welcomeMessage
    }

    private fun getExpirationMessageIds(): ArrayList<String> {
        val db: CarrotSdkDB = SdkApp.getInstance().database
        val ids = ArrayList<String>()
        val tempArray = db.expirationMessageDao().all
        for (message in tempArray) {
            ids.add(message.id)
        }
        return ids
    }

    // getExpirationMessages() Observable-мост удалён — внутри используется getExpirationMessageIds().

    fun addExpirationMessage(messageId: String) {
        val db: CarrotSdkDB = SdkApp.getInstance().database
        db.expirationMessageDao().insert(ExpirationMessage(messageId))
    }

    fun removeExpirationMessage(messageId: String) {
        val db: CarrotSdkDB = SdkApp.getInstance().database
        db.expirationMessageDao().remove(messageId)
    }
}
