package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun saveRefreshToken(token: String, context: Context = CarrotLib.getLibComponents().getContext()) {
    SharedPreferencesLib.saveString(context, refreshTokenKey, token)
}