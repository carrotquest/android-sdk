package io.carrotquest_sdk.android.lib;

import com.google.gson.JsonObject;

import java.io.File;
import java.util.List;

import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse;
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse;
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse;
import io.reactivex.Observable;

public interface ICarrotLib {

    /**
     * Подключение к сервису
     *
     * @param apiKey       API ключ
     * @param referrer     Utm-метки
     * @param startSession влияет, в числе прочего, на появление автособытия "Начал сессию"
     * @return Поток с ответом о подключении
     */
    Observable<ConnectResponse> connect(String apiKey, String browser, String tokenType, String referrer, boolean startSession);

    /**
     * Авторизация пользователя
     *
     * @param userId      Идентификатор пользователя
     * @param userAuthKey Пользовательский ключ авторизации
     * @return Поток с ответом об авторизации
     */
    Observable<AuthResponse> auth(String userId, String userAuthKey);

    /**
     * Авторизация пользователя
     *
     * @param userId      Идентификатор пользователя
     * @param hash Хэш
     * @return Поток с ответом об авторизации
     */
    Observable<AuthResponse> hashedAuth(String userId, String hash);

    /**
     * Получить информацию о пользователе
     *
     * @param userId Идентификатор пользователя
     * @return Поток с отетом
     */
    Observable<User> getUser(String userId);

    Observable<UserResponse> loadUser(String userId);


    /**
     * Установить настройки пользователя
     *
     * @param userId       Идентификатор пользователя
     * @param userProperty Настройки
     * @return Поток с ответом об установке настроек
     */
    Observable<NetworkResponse> setProperty(String userId, UserProperty userProperty);

    /**
     * Установить настройки пользователя
     *
     * @param userId       Идентификатор пользователя
     * @param userProperty Настройки
     * @return Поток с ответом об установке настроек
     */
    Observable<NetworkResponse> setProperty(String userId, List<UserProperty> userProperty);

    /**
     * Передать информацию о действии
     *
     * @param userId      Идентификатор пользователя
     * @param eventName   Наименование действия
     * @param eventParams Параметры действия
     * @return Поток с ответом о передачи информации о действии
     */
    Observable<NetworkResponse> trackEvent(String userId, String eventName, String eventParams);


    /**
     * Возвращает список диалогов пользователя
     *
     * @param userId Идентификатор пользователя
     * @return Объект со всей информацией
     */
    Observable<UserConversations> getConservations(String userId);

    /**
     * Возвращает список диалогов пользователя
     *
     * @param userId Идентификатор пользователя
     * @param after  Курсор для пагинации
     * @return Объект со всей информацией
     */
    Observable<UserConversations> getConservations(String userId, String after);

    /**
     * Начало нового диалога со стороны пользователя
     *
     * @return Ответ с сервера
     */
    Observable<StartConversationResponse> startConversation(String userId, String messageText);

    Observable<StartConversationResponse> startConversation(String userId, File file);

    /**
     * Возвращает список сообщений в диалоге
     *
     * @param userId Идентификатор пользователя
     * @return Объект со всей информацией
     */
    Observable<MessagesResponse> getMessages(String userId);

    /**
     * Возвращает список сообщений в диалоге
     *
     * @param userId Идентификатор пользователя
     * @param after  После какого сообщения нужно получить данные
     * @return Объект со всей информацией
     */
    Observable<MessagesResponse> getMessages(String userId, String after);

    /**
     * Возвращает список сообщений в диалоге
     *
     * @param userId Идентификатор пользователя
     * @param after  Пагинация. Курсор, с которого нужно начать.
     * @param count  Пагинация. Максимальное количество сообщений, которое нужно вернуть (от 1 до 50).
     * @return Объект со всей информацией
     */
    Observable<MessagesResponse> getMessages(String userId, String after, Integer count);


    /**
     * ОТправка сообщения в диалог от пользователя
     *
     * @param conversationId Идентификатор диалога
     * @param messageText    Текст сообщения
     * @param fromUser       Флаг, от юзера или нет
     * @param randomId       Случайный идентификатор
     * @return Объект с ответом
     */
    Observable<ReplyResponse> reply(String conversationId, String messageText, boolean fromUser, String randomId);

    /**
     * отправить токен для пушей
     *
     * @param userId   Идентификатор админа
     * @param token    Токен
     * @param deviceId Идентификатор устройства
     * @param type     Тип устройства (всегда mobile)
     * @return Строка с ответом
     */
    Observable<PushSubResponse> sendPushToken(String userId,
                                              String token,
                                              String deviceId,
                                              String type,
                                              String userAgent);

    /**
     * Удалить токен для пушей
     *
     * @param userId   Идентификатор админа
     * @param deviceId Идентификатор устройства
     * @param type     Тип устройства (всегда mobile)
     * @return Строка с ответом
     */
    Observable<PushSubResponse> deletePushToken(String userId,
                                                String deviceId,
                                                String type);

    /**
     * Отправка файла
     */
    Observable<ReplyFileResponse> replyFile(String conversationId,
                                            File file,
                                            String autoAssign,
                                            String randomId);


    /**
     * Отметить диалог как прочитанный
     *
     * @param conversationId Идентификатор диалога
     * @return Результат
     */
    Observable<NetworkResponse> markRead(String conversationId);

    /**
     * Оценка оператора
     *
     * @param messageId Идентификатор сообщения (?)
     * @param meta_data Объект с оценкой и комментарием
     * @return Результат
     */
    Observable<NetworkResponse> conversationParts(String messageId, JsonObject meta_data);


    /**
     * Получить опредедленный диалог
     *
     * @param conversationId Идентификатор диалога
     * @return Ответ
     */
    Observable<ConversationResponse> getConservation(String conversationId);


    /**
     * Пользователь печатает сообщение в чате
     *
     * @param conversationId Идентификатор диалога
     * @param messageBody    Текст сообщения
     * @return Ответ
     */
    Observable<NetworkResponse> setTyping(String conversationId,
                                          String messageBody);


    /**
     * Отправить meta_data для сообщения
     *
     * @param metaData meta_data
     * @return Ответ
     */
    Observable<NetworkResponse> setMetaData(String messageId, String metaData);

    /**
     * Отправить событие для статистики тригерных сообщений
     *
     * @param conversationId идентификатор диалога
     * @param type           тип события
     * @return -
     */
    Observable<NetworkResponse> trackInteraction(String conversationId, String type);


    /**
     * Запрос нужен для того, чтобы узнать, нужно ли запускать бота для этого диалога
     * @param conversationId Идентификатор диалога
     * @return Довольно сложная структура
     */
    Observable<ChooseRoutingBotResponse> chooseRoutingBot(String conversationId);

    /**
     * Старт роутинг-бота
     * @param botId Идентификатор бота
     * @param buttonActionId Идентификатор выбранного действия (кнопки/поля ввода)
     * @param buttonActionText Текст кнопки/ответа пользователя
     * @param randomId Временный id диалога, чтобы сматчиться с rts когда диалог будет таки создан
     * @param conversationId Идентификатор диалога (если есть)
     * @return Пока смотрим
     */
    Observable<NetworkResponse> startRoutingBot(String botId,
                                                String buttonActionId,
                                                String buttonActionText,
                                                String randomId,
                                                String conversationId);

    /**
     * Старт роутинг-бота
     * @param botId Идентификатор бота
     * @param buttonActionId Идентификатор выбранного действия (кнопки/поля ввода)
     * @param buttonActionText Текст кнопки/ответа пользователя
     * @param randomId Временный id диалога, чтобы сматчиться с rts когда диалог будет таки создан
     * @return Пока смотрим
     */
    Observable<NetworkResponse> startRoutingBot(String botId,
                                                String buttonActionId,
                                                String buttonActionText,
                                                String randomId);

    /**
     * Сбросить сессию
     */
    void clearSession();

    String getOkHttpVersion();

    Observable<TriggersResponse> getTriggers();
    Observable<NetworkResponse> sendTrigger(List<String> triggerIds);

    Observable<NetworkResponse> setPresenceCurrentScreen(String presence, String currentScreen);

    Observable<RefreshResponse> refresh();
}
