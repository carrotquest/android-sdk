package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import java.util.Collections

class ConversationsRepository private constructor() {
    private var currentAfter = ""
    
    private val conversations = Collections.synchronizedList(ArrayList<DataConversation>())
    private val conversationsSubject: BehaviorSubject<ArrayList<DataConversation>> = BehaviorSubject.createDefault(ArrayList(conversations))
    private val assignedConversationSubject = BehaviorSubject.create<DataConversation>()

    private val unreadConversationsIDs = ArrayList<String>()
    private val unreadConversationsSubject: BehaviorSubject<ArrayList<String>> = BehaviorSubject.createDefault(unreadConversationsIDs)

    private var openedConversation: String = ""
    private var lastOpenedConversation: String = ""
    private val openedConversationIdSubject: BehaviorSubject<String> = BehaviorSubject.create()

    private val addConversationSubject: PublishSubject<DataConversation> = PublishSubject.create()

    companion object {
        private var instance: ConversationsRepository? = null
        fun getInstance(): ConversationsRepository {
            if (instance == null) {
                instance = ConversationsRepository()
            }
            return instance!!
        }
    }

    fun getConversations(): Observable<ArrayList<DataConversation>> {
        return conversationsSubject
    }

    fun getConversationsSync(): ArrayList<DataConversation> {
        return ArrayList(this.conversations)
    }

    fun getConversationById(id: String): DataConversation? {
        return this.conversations.find { x->x.id != null && x.id == id }
    }


    fun saveConversations(data: ArrayList<DataConversation>) {
        try {
            synchronized(this.conversations) {
                for (conversation in data) {
                    if (this.conversations.find { x -> x.id != null && x.id == conversation.id } == null) {
                        this.conversations.add(conversation)
                    }
                }

                conversationsSubject.onNext(ArrayList(this.conversations))
            }
        } catch (e: Exception){

        }
    }

    fun clearConversations() {
        synchronized(this.conversations) {
            this.conversations.clear()
            conversationsSubject.onNext(ArrayList(this.conversations))
        }
    }

    fun addConversation(conversation: DataConversation) {
        if(conversation == null) {
            return
        }
        //synchronized(this.conversations) {
            if (this.conversations.find { it.id != null && it.id == conversation.id } == null) {
                val resAdd = this.conversations.add(conversation)
                if (resAdd) {
                    this.addConversationSubject.onNext(conversation)
                }
            }
        //}
    }

    fun updateInfoAboutConversation(conversation: DataConversation) {
        if(conversation.id != null) {
            this.updateConversation(conversation.id, conversation)
        }
    }

    fun removeConversation(id: String) {
        synchronized(this.conversations) {
            val resRemove = this.conversations.remove(this.conversations.find { it.id != null && it.id == id })

            if (resRemove) {
                conversationsSubject.onNext(ArrayList(this.conversations))
            }
        }
    }
    
    fun assignedConversation() : Observable<DataConversation> {
        return this.assignedConversationSubject
    }

    fun removeUnreadConversation(conversationId: String) {
        synchronized(this.conversations) {
            val c = this.conversations.find { x -> x.id == conversationId } ?: return
            val index = this.conversations.indexOf(c)
            c.unreadPartsCount = 0

            if(c.sourceJsonData != null) {
                val sJd = c.sourceJsonData
                if(sJd.has(F.UNREAD_PARTS_COUNT)) {
                    sJd.remove(F.UNREAD_PARTS_COUNT)
                    sJd.addProperty(F.UNREAD_PARTS_COUNT, 0)
                }
                c.sourceJsonData = sJd
            }

            this.conversations[index] = c
            this.conversationsSubject.onNext(ArrayList(this.conversations))
        }
    }

    fun saveOpenedConversation(id: String) {
        if(id.isNotEmpty()) {
            lastOpenedConversation = id
        }
        this.openedConversation = id
        openedConversationIdSubject.onNext(id)
    }

    fun getOpenedConversationId() : String {
        return openedConversation
    }

    fun getLastOpenedConversationId() : String {
        return lastOpenedConversation
    }

    fun updateConversation(conversationId: String, conversation: DataConversation) {
        synchronized(this.conversations) {
            val foundConversation = this.conversations.find { x -> x.id != null && x.id == conversationId }
                    ?: return

            this.conversations.remove(foundConversation)
            this.conversations.add(0, conversation)

            this.conversationsSubject.onNext(ArrayList(this.conversations))

            if (foundConversation.lastAdmin?.id != conversation.lastAdmin?.id) {
                this.assignedConversationSubject.onNext(conversation)
            }

            if(foundConversation.randomId == openedConversation) {
                saveOpenedConversation(conversation.id)
            }
        }
    }
    
    fun assignedConversation(conversation: DataConversation) {
        updateConversation(conversation.id, conversation)
        assignedConversationSubject.onNext(conversation)
    }

    fun getAddedConversation(): Observable<DataConversation> {
        return addConversationSubject
    }

    fun setCurrentAfter(after: String) {
        this.currentAfter = after
    }

    fun getCurrentAfter() = this.currentAfter
}