package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log
import java.util.Date

fun saveJwtToken(token: String, context: Context = CarrotLib.getLibComponents().getContext()) {
    val oldToken = getJwtToken()
    if(oldToken != token) {
        val currentTime = Date().time
        SharedPreferencesLib.saveLong(context, jwtTokenUpdateTimeStampKey, currentTime)
    }

    SharedPreferencesLib.saveString(context, jwtTokenKey, token)
}