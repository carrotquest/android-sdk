package io.carrotquest_sdk.android.application

import android.app.Activity
import android.app.Application
import android.os.Bundle
import io.reactivex.functions.Consumer
import io.reactivex.subjects.BehaviorSubject

class FTActivityLifecycleCallbacks : Application.ActivityLifecycleCallbacks{
    private var currentActivity: Activity? = null
    private val currentActivityBehaviorSubject : BehaviorSubject<Activity> = BehaviorSubject.create()

    fun getCurrentActivity() = currentActivity

    override fun onActivityPaused(activity: Activity) {
        println("TEST_LAGS: onActivityPaused")
        this.currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        println("TEST_LAGS: onActivityResumed")
        this.currentActivity = activity
        if(activity != null) {
            println("TEST_LAGS: onActivityResumed 2")
            currentActivityBehaviorSubject.onNext(activity)
        }
    }

    override fun onActivityStarted(activity: Activity) {
        println("TEST_LAGS: onActivityStarted")
        this.currentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {
        println("TEST_LAGS: onActivityDestroyed ${activity.localClassName}")
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        println("TEST_LAGS: onActivitySaveInstanceState")
    }

    override fun onActivityStopped(activity: Activity) {
        println("TEST_LAGS: onActivityStopped")
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        println("TEST_LAGS: onActivityCreated")
        this.currentActivity = activity
    }

    fun subscribeOnChangeCurrentActivity(onNext: Consumer<Activity>, onError: Consumer<Throwable>) = currentActivityBehaviorSubject.subscribe(onNext, onError)
}