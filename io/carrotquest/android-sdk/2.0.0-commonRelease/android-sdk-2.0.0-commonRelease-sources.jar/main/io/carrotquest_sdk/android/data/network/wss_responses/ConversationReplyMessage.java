package io.carrotquest_sdk.android.data.network.wss_responses;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.core.constants.Flags;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.repositories.MessagesRepository;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsAllHelper;
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ConversationReplyMessage extends MessageData implements IRtsMessage {

    public Boolean conversationClosed = false;

    private UserRepository userRepository;
    private MessagesRepository messagesRepository;
    private ConversationsRepository conversationsRepository;

    public ConversationReplyMessage(MessageData messageData) {
        this.setId(messageData.getId());
        this.setBody(messageData.getBody());
        this.setActions(messageData.getActions());
        this.setRandomId(messageData.getRandomId());
        this.setReplyType(messageData.getReplyType());
        this.setSentVia(messageData.getSentVia());
        this.setType(messageData.getType());
        this.setRead(messageData.getRead());
        this.setDirection(messageData.getDirection());
        this.setBodyJson(messageData.getBodyJson());
        this.setConversation(messageData.getConversation());
        this.setCreated(messageData.getCreated());
        this.setMessageMetaData(messageData.getMessageMetaData());
        this.setMessageFrom(messageData.getMessageFrom());
        this.setAttachments(messageData.getAttachments());
        this.setExpiraionTime(messageData.getExpiraionTime());
        this.setFirst(messageData.isFirst());
        this.setSourceJsonData(messageData.getSourceJsonData());
        this.setStatus(messageData.getStatus());
        this.setRemoved(messageData.getRemoved());
        this.setConversationType(messageData.getConversationType());
    }

    @Override
    public void process() {
        if (userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }
        if (conversationsRepository == null) {
            conversationsRepository = ConversationsRepository.Companion.getInstance();
        }
        if (messagesRepository == null) {
            messagesRepository = MessagesRepository.Companion.getInstance();
        }

        //TODO: LEAD_BOT
//        if("lead_bot".equals(this.getConversationType())) {
//            return;
//        }

        if ((getRead() == null || !getRead())
                && (conversationClosed == null || !conversationClosed)
                && messagesRepository != null) {
            if (fromAdminToUser() || isInputBotAction() || isButtonsBotAction()) {
                if (userRepository != null) {
                    User user = userRepository.getUser();
                    if (user != null
                            && !getConversation().equals(conversationsRepository.getOpenedConversationId())
                            && !Flags.NEW_CONVERSATION_ID_ARG.equals(conversationsRepository.getOpenedConversationId())
                    ) {
                        ArrayList<String> conversationsUnread = new ArrayList<>(user.getConversationsUnread());
                        conversationsUnread.remove(getConversation());
                        conversationsUnread.add(getConversation());
                        user.setConversationsUnread(conversationsUnread);
                        user.hasConversations = true;
                    }

                    userRepository.saveUser(user);
                    if (this.getBodyJson() != null && this.getBodyJson().isJsonObject()) {
                        if (this.getBodyJson().getAsJsonObject().has("is_first_branch")) {
                            if (!this.getBodyJson().getAsJsonObject().get("is_first_branch").getAsBoolean()) {
                                messagesRepository.addWssMessage(this);
                            }
                        } else {
                            messagesRepository.addWssMessage(this);
                        }
                    }

                } else {
                    if ("message_chat_bot".equals(this.getSentVia()) && this.getActions() != null && this.getActions().size() > 0) {
                        ActionMessage firstAction = this.getActions().get(0);
                        if ("property_field".equals(firstAction.getType())) {

                        }
                    }
                }
                messagesRepository.updateMessage(this);
            } else {
                Disposable x = Single.just(true)
                        .delay(2, TimeUnit.SECONDS)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .subscribe(aBoolean -> {
                            messagesRepository.updateMessage(this);
                        });
            }

        }

        IncomingMessage.DirectionMessage directionMessage = IncomingMessage.DirectionMessage.USER_TO_ADMIN;
        if (ResponseFields.ADMIN_2_USER.equals(getDirection())) {
            directionMessage = IncomingMessage.DirectionMessage.ADMIN_TO_USER;
        }

        IncomingMessage.MessageType messageType = IncomingMessage.MessageType.TEXT;
        if (getAttachments() != null && getAttachments().size() > 0) {
            messageType = IncomingMessage.MessageType.ATTACHMENT;
        }

        Log.i("ClientWebSocket", "Body = " + getBody());

        IncomingMessage message = new IncomingMessage(IncomingMessage.IncomingMessageSourceType.RTS, getId(), getConversation(), getBody(), directionMessage, messageType);
        NotificationsAllHelper.getInstance().pushMessage(message);
    }

    private boolean isInputBotAction() {
        if ("message_chat_bot".equals(this.getSentVia()) && this.getActions() != null && this.getActions().size() > 0) {
            ActionMessage firstAction = this.getActions().get(0);
            return "property_field".equals(firstAction.getType());
        }

        return false;
    }

    private boolean isButtonsBotAction() {
        if ("message_chat_bot".equals(this.getSentVia()) && this.getActions() != null && this.getActions().size() > 0) {
            ActionMessage firstAction = this.getActions().get(0);
            return "button".equals(firstAction.getType());
        }

        return false;
    }

    private boolean fromAdminToUser() {
        return getDirection() != null && ResponseFields.ADMIN_2_USER.equals(getDirection().toLowerCase());
    }
}