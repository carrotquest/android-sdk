package io.carrotquest_sdk.android.data.repositories.old;

import android.content.Context;
import android.text.TextUtils;
import android.util.Pair;

import java.util.ArrayList;
import java.util.HashSet;

import io.carrotquest_sdk.android.data.user.UserStateHolder;
import io.carrotquest_sdk.android.domain.entities.UserEntity;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.subjects.BehaviorSubject;


public class UserRepository implements IUserRepository {
    private User user;

    private final Context context;
    private ArrayList<Observer<User>> removeUserObservers;
    private Observer<Boolean> removeUserCompletedObserver;

    private ArrayList<Observer<Boolean>> banUserObservers;

    private BehaviorSubject<User> saveUserBehaviorSubject;

    private DataConversation lastUnreadConversation = null;

    public UserRepository(Context context) {
        this.context = context;
    }

    public void saveUser(User user) {
        //this.user = user;
        if (this.user == null) {
            this.user = new User();
        }
        if (user != null) {
            // Токен обновляем всегда, в т.ч. при пустом значении — иначе in-memory токен
            // остаётся устаревшим когда /connect возвращает ответ без auth_token.
            this.user.setToken(user.getToken());
            if (!TextUtils.isEmpty(user.getId())) {
                this.user.setId(user.getId());
            }
            if (user.getConversationsUnread() != null) {
                this.user.setConversationsUnread(user.getConversationsUnread());
            }
            this.user.setBanned(user.isBanned());
            this.user.setHasConversations(user.isHasConversations());
        }


        if (user != null && !TextUtils.isEmpty(user.getToken())) {
            SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_TOKEN, user.getToken());
        }
        else {
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN);
        }
        if(user != null) {
            SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_USER_ID, user.getId());
            ArrayList<String> l = new ArrayList<String>();
            if(user.getConversationsUnread() != null) {
                l = (ArrayList<String>) user.getConversationsUnread();
            }
            SharedPreferencesLib.saveStringSet(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS, new HashSet<>(l));
            SharedPreferencesLib.saveBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED, user.isBanned());
        }
        else {
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_ID);
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS);
            SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_USER_BANNED);
        }


        updateCurrentCountUnreadConversations(new ArrayList<>(), user, user == null || user.getConversationsUnread() == null ? 0 : user.getConversationsUnread().size());

        if (this.user != null) {
            ArrayList<String> unread = this.user.getConversationsUnread() != null
                    ? this.user.getConversationsUnread()
                    : new ArrayList<>();
            UserEntity userEntity = new UserEntity(
                    this.user.getId() != null ? this.user.getId() : "",
                    this.user.getToken() != null ? this.user.getToken() : "",
                    this.user.isHasConversations(),
                    this.user.isBanned(),
                    unread
            );
            UserStateHolder.INSTANCE.update(userEntity);
        }
    }

    private void updateCurrentCountUnreadConversations(ArrayList<Pair<String,String>> currentUnreadConversations, User user, int actualCount) {
        /*final ArrayList<Pair<String,String>> currentUnread = currentUnreadConversations;
        if (conversationsRepository == null) {
            conversationsRepository = CarrotInternal.getLibComponent().getConversationsRepository();
        }

        String after = "";
        if (conversationsRepository != null && conversationsRepository.getUserConversations() != null && conversationsRepository.getUserConversations().getMeta() != null) {
            after = conversationsRepository.getUserConversations().getMeta().getNextAfter();
        }

        DisposableObserver<UserConversations> observer = new DisposableObserver<UserConversations>() {
            @Override
            public void onNext(UserConversations userConversations) {
                if(userConversations.getConversations() == null) {
                    userConversations.setConversations(new ArrayList<>());
                }

                for (DataConversation conversation : userConversations.getConversations()) {
                    if (conversation.getUserUnreadCount() > 0) {
                        if(lastUnreadConversation == null) {
                            lastUnreadConversation = conversation;
                            conversationsRepository.setLastConversationUnread(conversation);
                        }

                        currentUnread.add( new Pair<>(conversation.getId(), conversation.getType()));
                    }
                }

                conversationsRepository.appendConversations(userConversations);
                if (currentUnread.size() < actualCount) {
                    updateCurrentCountUnreadConversations(currentUnread, user, actualCount);
                } else {
                   ArrayList<String> convers = new ArrayList<>();
                    for(Pair<String, String> p : currentUnread) {
                        if((ConversationType.CHAT.getStringValue()).equals(p.second)) {
                            convers.add(p.first);
                        }
                    }

                    if (user != null) {
                        user.setConversationsUnread(convers);
                        if (saveUserBehaviorSubject == null) {
                            saveUserBehaviorSubject = BehaviorSubject.createDefault(user);
                        }

                        saveUserBehaviorSubject.onNext(user);
                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        };
        if (after != null) {
            if (after.isEmpty()) {
                CarrotInternal.getService().getConversations(user.getId(), observer);
            } else {
                CarrotInternal.getService().getConversations(user.getId(), after, observer);
            }
        }
        else {
            saveUserBehaviorSubject.onNext(user);
            SentryCQ_SDK.setUser(this.user);
        }*/
    }

    public void saveToken(String token) {
        if (this.user == null) {
            this.user = new User();
        }

        this.user.setToken(token);
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.CARROT_USER_ID, this.user.getId());

        if (this.user != null) {
            if (saveUserBehaviorSubject == null) {
                saveUserBehaviorSubject = BehaviorSubject.createDefault(this.user);
            }

            saveUserBehaviorSubject.onNext(this.user);
        }
    }

    public BehaviorSubject<User> getSaveUserObservable() {
        if (saveUserBehaviorSubject == null) {
            if (user == null) {
                user = new User();
            }
            saveUserBehaviorSubject = BehaviorSubject.createDefault(user);
        }
        return saveUserBehaviorSubject;
    }

    @Override
    public void removeUsers(ArrayList<String> removedUsers) {
        if (removedUsers.contains(user.getId())) {
            if (removeUserObservers.size() > 0) {
                Observable<User> removeUserObservable = Observable.just(user);
                removeUserObservable.subscribe(removeUserObservers.get(0));
                removeRemoveUserObserver(removeUserObservers.get(0));
                //Recursion!!
                removeUsers(removedUsers);
            } else {
                this.user = null;
                if (removeUserCompletedObserver != null) {
                    Observable.just(true).subscribe(removeUserCompletedObserver);
                }
            }
        }
        UserStateHolder.INSTANCE.removeUsers(removedUsers);
    }

    @Override
    public void banUser(String userId) {
        if (userId != null && userId.equals(user.getId())) {
            user.setBanned(true);
            Observable<Boolean> banUserObservable = Observable.just(true)
                    .subscribeOn(AndroidSchedulers.mainThread())
                    .observeOn(AndroidSchedulers.mainThread());
            for (Observer<Boolean> userObserver : banUserObservers) {
                banUserObservable.subscribe(userObserver);
            }
        }
        UserStateHolder.INSTANCE.banUser(userId);
    }

    @Override
    public void unBanUser(String userId) {
        if (userId != null && userId.equals(user.getId())) {
            user.setBanned(false);

            Observable<Boolean> unBanUserObservable = Observable.just(false)
                    .subscribeOn(AndroidSchedulers.mainThread())
                    .observeOn(AndroidSchedulers.mainThread());
            for (Observer<Boolean> userObserver : banUserObservers) {
                unBanUserObservable.subscribe(userObserver);
            }
        }
        UserStateHolder.INSTANCE.unBanUser(userId);
    }


    public User getUser() {
        if (user == null || user.getId() == null || TextUtils.isEmpty(user.getToken())) {
            user = loadUser();
        }

        return user;
    }

    /**
     * Добавить наблюдателя за событием удаления юзера
     *
     * @param removeUserObserver Объект-наблюдатель
     */
    public void addRemoveUserObserver(Observer<User> removeUserObserver) {
        if (removeUserObservers == null) {
            removeUserObservers = new ArrayList<>();
        }
        removeUserObservers.add(removeUserObserver);
    }

    /**
     * Удалить наблюдателя за событием удаления юзера
     *
     * @param removeUserObserver Объект-наблюдатель
     */
    public void removeRemoveUserObserver(Observer<User> removeUserObserver) {
        if (removeUserObservers != null) {
            removeUserObservers.remove(removeUserObserver);
        }
    }

    public void setRemoveUserCompletedObserver(Observer<Boolean> observer) {
        this.removeUserCompletedObserver = observer;
    }

    /**
     * Добавить наблюдателя за событием бана юзера
     *
     * @param banUserObserver Объект-наблюдатель
     */
    public void addBanUserObserver(Observer<Boolean> banUserObserver) {
        if (banUserObservers == null) {
            banUserObservers = new ArrayList<>();
        }
        banUserObservers.add(banUserObserver);
    }

    /**
     * Удалить наблюдателя за событием бана юзера
     *
     * @param banUserObserver Объект-наблюдатель
     */
    public void removeBanUserObserver(Observer<Boolean> banUserObserver) {
        if (banUserObservers != null) {
            banUserObservers.remove(banUserObserver);
        }
    }


    private User loadUser() {
        User user = new User();
        user.setToken(SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_TOKEN));
        user.setId(SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_USER_ID));
        user.setConversationsUnread(SharedPreferencesLib.getPreferenceArray(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS));
        user.setBanned(SharedPreferencesLib.getBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED));
        return user;
    }
}
