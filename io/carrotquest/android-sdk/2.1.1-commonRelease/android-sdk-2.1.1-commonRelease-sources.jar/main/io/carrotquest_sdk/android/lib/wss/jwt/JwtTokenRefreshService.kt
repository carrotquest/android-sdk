package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import java.util.Date
import java.util.Timer
import java.util.TimerTask

class JwtTokenRefreshService private constructor() {

    companion object {

        private var instance: JwtTokenRefreshService? = null

        fun getInstance(): JwtTokenRefreshService {
            if(instance == null) {
                instance = JwtTokenRefreshService()
            }

            return instance!!
        }
    }

    // var, не val — после stop() Timer отменяется навсегда (JVM), поэтому в start() создаём новый.
    private var refreshTimer = Timer()
    private var isAlreadyStarted = false

    val updateJwtTokenObservable = BehaviorSubject.create<String>()

    fun start() {
        if (isAlreadyStarted) {
            return
        }
        isAlreadyStarted = true
        // Предыдущий Timer мог быть cancel()-ован через stop() (после deInit).
        // Cancelled Timer нельзя переиспользовать — schedule() бросает IllegalStateException.
        refreshTimer = Timer()

        val delayMilliseconds = getDelayStartTime()
        Log.d("JWT", "delayMilliseconds = $delayMilliseconds")
        refreshTimer.schedule(object : TimerTask() {
            override fun run() {
                // Любое непойманное исключение внутри TimerTask.run() убивает ВЕСЬ Timer
                // (JVM документация). Оборачиваем — иначе после одного сбоя JWT не обновляется
                // никогда, и воскресить Timer можно только через deInit()/setup().
                try {
                    val d = updateJwtTokenObservable
                        .subscribeOn(Schedulers.io())
                        .take(1)
                        .subscribe(
                            { token ->
                                try {
                                    val user = CarrotLib.getLibComponents().userRep.user
                                    user.token = token
                                    CarrotLib.getLibComponents().userRep.saveUser(user)
                                } catch (t: Throwable) {
                                    Log.e("JWT", "saveUser after refresh failed: $t")
                                }
                            },
                            { t -> Log.e("JWT", "refresh subject error: $t") }
                        )

                    refreshJwtToken(updateJwtTokenObservable)
                } catch (t: Throwable) {
                    Log.e("JWT", "TimerTask tick failed: $t")
                }
            }
        }, delayMilliseconds, jwtTokenLiveTime)

    }

    fun stop() {
        refreshTimer.cancel()
        isAlreadyStarted = false
    }

    private fun getDelayStartTime(): Long {
        val nowMilliseconds = Date().time
        val lastUpdateJwtTokenTimeMilliseconds = getLastUpdateJwtTokenTime()

        return if(lastUpdateJwtTokenTimeMilliseconds <= 0 || nowMilliseconds > (lastUpdateJwtTokenTimeMilliseconds + jwtTokenLiveTime)) {
            0L
        } else {
            (lastUpdateJwtTokenTimeMilliseconds + jwtTokenLiveTime) - nowMilliseconds
        }
    }
}