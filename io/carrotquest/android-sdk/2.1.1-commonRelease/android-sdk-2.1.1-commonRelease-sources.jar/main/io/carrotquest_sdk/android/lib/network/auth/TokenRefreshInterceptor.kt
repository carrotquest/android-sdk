package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.repositories.IUserRepository
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlocking
import okhttp3.Interceptor
import okhttp3.Response

internal class TokenRefreshInterceptor(
    private val userRepository: IUserRepository
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())
        val url = chain.request().url.toString()

        if (url.contains("refresh")) return response
        if (response.code != 401 && response.code != 403) return response

        response.close()

        val oldToken = chain.request().url.queryParameter(F.AUTH_TOKEN)
        // Для 401: передаём упавший токен — если JWT_TOKEN_KEY уже обновлён другим потоком,
        //          refreshJwtTokenBlocking вернёт его сразу (оптимизация для конкурентных 401).
        // Для 403: передаём null — форсируем реальный /refresh запрос.
        //          Причина: JWT_TOKEN_KEY (connect-jwt) может отличаться от user.token (auth-jwt),
        //          и оптимизация `current != failedToken` вернула бы connect-jwt без рефреша,
        //          что тоже просрочено и дало бы повторный 403.
        val failedToken = if (response.code == 403) null else oldToken
        val newToken = try {
            refreshJwtTokenBlocking(failedToken)
        } catch (e: java.io.IOException) {
            // Сетевая ошибка во время refresh — повторяем оригинальный запрос как есть,
            // он тоже упадёт с IOException, и caller получит сетевую ошибку. Токены не трогаем.
            return chain.proceed(chain.request())
        }
        if (newToken == null) {
            // Refresh провален — refresh-токен мёртв. Сигналим клиенту, что сессия истекла,
            // возвращаем оригинальный ответ (без бесконечных retry).
            SdkStateManager.notifySessionExpired()
            return chain.proceed(chain.request())
        }

        userRepository.getUser()?.let { user ->
            user.token = newToken
            userRepository.saveUser(user)
        }

        val newUrl = chain.request().url.newBuilder()
            .setQueryParameter(F.AUTH_TOKEN, newToken)
            .build()
        return chain.proceed(chain.request().newBuilder().url(newUrl).build())
    }
}
