package io.carrotquest_sdk.android.core.connection

import android.content.Context
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.wss.jwt.clearRtsDataIfNeed
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlocking
import io.carrotquest_sdk.android.lib.wss.jwt.saveJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.saveRefreshToken
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.IOException

internal object ConnectionManager {

    private const val TAG = "ConnectionManager"
    private const val MAX_RETRIES = 3

    private var retryCount = 0

    fun connect(
        apiKey: String,
        appId: String,
        sdkVersion: String,
        referrer: String,
        startSession: Boolean,
        context: Context,
        carrotLib: CarrotLib,
        userRepository: UserRepository
    ): Observable<ConnectResponse> {
        if (retryCount > MAX_RETRIES) {
            return Observable.error(IllegalStateException("Too many connection attempts"))
        }

        clearRtsDataIfNeed(context, appId)

        return if (isActualJwtToken(context)) {
            retryCount = 0
            carrotLib.connect(apiKey, "sdk $sdkVersion", "sdk_user_android", referrer, startSession)
        } else {
            refreshToken()
                .flatMap { token ->
                    val user = userRepository.getUser()
                    user.token = token
                    userRepository.saveUser(user)
                    retryCount++
                    connect(apiKey, appId, sdkVersion, referrer, startSession, context, carrotLib, userRepository)
                }
                .onErrorResumeNext { error: Throwable ->
                    if (error is IOException) {
                        // Сетевая ошибка — refresh-токен может быть валиден, просто нет сети.
                        // Не очищаем токены: при восстановлении сети NetworkManager перезапустит
                        // setup() и refresh пройдёт успешно.
                        Log.e(TAG, "refresh failed due to network error, not clearing tokens: $error")
                        Observable.error(error)
                    } else {
                        // Сервер отклонил refresh (4xx) — токены действительно мертвы.
                        // Чистим и подключаемся как новая сессия.
                        Log.e(TAG, "refresh rejected by server, clearing tokens and falling back to /connect: $error")
                        saveJwtToken("")
                        saveRefreshToken("")
                        userRepository.getUser()?.let { u ->
                            u.token = ""
                            userRepository.saveUser(u)
                        }
                        retryCount++
                        if (retryCount > MAX_RETRIES) {
                            Observable.error(error)
                        } else {
                            carrotLib.connect(apiKey, "sdk $sdkVersion", "sdk_user_android", referrer, startSession)
                        }
                    }
                }
        }
    }

    fun reset() {
        retryCount = 0
    }

    /**
     * Получает новый JWT-токен через blocking refresh (под shared lock).
     * Возвращает Observable с явным error path — если refresh провален (refresh-токен протух,
     * сервер вернул не-200), Observable эмитит onError и caller может обработать fallback.
     */
    private fun refreshToken(): Observable<String> =
        Observable.fromCallable {
            refreshJwtTokenBlocking()
                ?: throw IllegalStateException("refresh failed: null token returned")
        }.subscribeOn(Schedulers.io())
}