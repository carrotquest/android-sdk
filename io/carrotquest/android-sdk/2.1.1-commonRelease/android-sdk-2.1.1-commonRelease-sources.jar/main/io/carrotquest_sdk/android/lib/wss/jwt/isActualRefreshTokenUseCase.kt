package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import java.util.Date

fun isActualRefreshToken(context: Context = CarrotLib.getLibComponents().getContext()): Boolean {
    val refreshToken = getRefreshToken()
    //Если refresh-токен не найден, то он не актуальный
    if(refreshToken.isNullOrEmpty()) {
        return false
    }

    val updateTokenTimeStamp = getLastUpdateRefreshToken()
    //Если не найден таймштамп сохранения токена, то токен не актуальный
    if(updateTokenTimeStamp <= 0) {
        return false
    }

    val nowTime = Date().time

    //Токен актуальный, если разница между текущим временем и временем обновления токена меньше 30 дней
    return nowTime - updateTokenTimeStamp < refreshTokenLiveTime
}