package io.carrotquest_sdk.android.presentation.mvp.button.presenter

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.TypedArray
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.text.Html
import android.text.TextUtils
import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.util.ExternalAppsUtil
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.getLastConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.getNotPopupConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.getUnreadConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.closeLastMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getLastUnreadMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversations.onCreateConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.openConversation
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.domain.use_cases.theme.getTheme
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.button.model.FloatingButtonViewModel
import io.carrotquest_sdk.android.presentation.mvp.button.model.StateLastMessage
import io.carrotquest_sdk.android.presentation.mvp.button.view.FloatingButton
import io.carrotquest_sdk.android.presentation.mvp.button.view.LocationFloatingButton
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

class FloatingButtonPresenter : BasePresenter() {

    private val tag = "FloatingButtonPresenter"
    private val compositeDisposable = CompositeDisposable()
    private val viewModel = FloatingButtonViewModel.getInstance()

    private var state: StateFabButton = StateFabButton.COLLAPSED
    private var isSetAttributes = false

    private var settings: SettingsEntity? = null

    fun onStart() {
        getView()?.doGone()
        compositeDisposable.add(
                Carrot
                        .getInitObservable()
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                                {
                                    when (it) {
                                        true -> {
                                            initThis()

                                            Observable.just(true)
                                                    .getCurrentUser()
                                                    .loadConversations()
                                                    .take(1)
                                                    .doOnNext { conversations ->
                                                        ConversationsRepository.getInstance().saveConversations(conversations)
                                                    }
                                                    .doOnError { t ->
                                                        Log.e(tag, t)
                                                    }
                                                    .subscribe()


                                            getView()?.initView()
                                            getView()?.show()
                                        }
                                        else -> {
                                            getView()?.hide()
                                            //compositeDisposable.dispose()
                                        }
                                    }
                                },
                                {
                                    getView()?.hide()
                                    Log.e(tag, it.toString())
                                }
                        ))

        compositeDisposable.add(
                Observable.just(true)
                        .getSettings()
                        .subscribe({
                            settings = it
                        }, {

                        })
        )
    }

    fun onCreatedView() {
        compositeDisposable.add(subscribeOnLastUnreadMessage())
        compositeDisposable.add(
                Observable.just(true)
                        .onCreateConversation()
                        .subscribe({
                            updateButtonView(ConversationsRepository.getInstance().getConversationsSync())
                        }, { t ->
                            Log.e(tag, t)
                        })
        )

        NetworkManager.getInstance(getView()?.context).addObserver(
                { isConnect ->
                    if (viewModel.isAutoHide()) {
                        if (isConnect) {
                            getView()?.show()
                            if (viewModel.getLastMessage().state == StateLastMessage.HIDDEN) {
                                getView()?.showLastMessage()
                                viewModel.updateStateLastMessage(StateLastMessage.SHOW)
                            }
                        } else {
                            getView()?.hide()
                            if (viewModel.getLastMessage().state == StateLastMessage.SHOW) {
                                getView()?.hideLastMessage()
                                viewModel.updateStateLastMessage(StateLastMessage.HIDDEN)
                            }
                        }
                    }
                },
                { t ->
                    Log.e(tag, t)
                },
                {
                    Log.d(tag, "Network observable is complete")
                }
        )
    }

    fun onTapFloatingButton() {
        state = when (state) {
            StateFabButton.COLLAPSED -> {
                compositeDisposable.add(Observable.just(true).getTheme(getView()?.context).take(1).subscribe {theme->
                    getView()?.updateTheme(theme)
                })

                expandButton()
                StateFabButton.EXPANDED
            }
            StateFabButton.EXPANDED -> {
                collapseButton()
                goToLastDialog()
                StateFabButton.COLLAPSED
            }
            StateFabButton.NOT_SOCIAL_NETWORKS -> {
                goToLastDialog()
                StateFabButton.NOT_SOCIAL_NETWORKS
            }
        }
    }

    fun onTapLastMessage() {
        Observable.just(true)
                .getLastUnreadMessageUseCase()
                .filter { x->x.value != null }
                .take(1)
                //.getLastConversation()
                .doOnNext { messageOpt ->
                    val conversationId = messageOpt.value?.conversation ?: ""
                    openConversation(conversationId)
                }
                .doOnError {

                }
                .subscribe()
    }

    fun onTapFB() {
        tapOnSocialNetworkButton()
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .subscribe(
                        { settings ->
                            run {
                                if (settings != null && !TextUtils.isEmpty(settings.textLinkFB)) {
                                    val intentVK = Intent(Intent.ACTION_VIEW,
                                            Uri.parse(getView()?.context?.getString(R.string.facebook_base_url_str) + settings.textLinkFB))
                                    getView()?.context?.startActivity(intentVK)
                                }
                            }

                        }, {
                    Log.e(tag, it)
                }))
    }

    fun onTapTelegram() {
        tapOnSocialNetworkButton()
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .subscribe(
                        { settings ->
                            run {
                                if (settings != null && !TextUtils.isEmpty(settings.textLinkTelegram)) {
                                    val intentVK = Intent(Intent.ACTION_VIEW,
                                            Uri.parse(getView()?.context?.getString(R.string.telegram_base_url_str) + settings.textLinkTelegram))
                                    getView()?.context?.startActivity(intentVK)
                                }
                            }

                        }, {
                    Log.e(tag, it)
                }))

    }

    fun onTapViber() {
        tapOnSocialNetworkButton()
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .subscribe(
                        { settings ->
                            run {
                                if (getView() != null) {
                                    if (settings != null && !TextUtils.isEmpty(settings.textLinkViber)) {
                                        if (ExternalAppsUtil.isAppAvailable(getView()?.context, getView()?.context?.getString(R.string.viber_app_name_str))) {
                                            val intentViber = Intent(Intent.ACTION_VIEW,
                                                    Uri.parse(getView()?.context?.getString(R.string.viber_base_url_str) + settings.textLinkViber))
                                            getView()?.context?.startActivity(intentViber)
                                        } else {
                                            val intentViber = Intent(Intent.ACTION_VIEW,
                                                    Uri.parse(getView()?.context?.getString(R.string.viber_base_url_str) + settings.textLinkViber))
                                            getView()?.context?.startActivity(intentViber)
                                        }
                                    }
                                }
                            }

                        }, {
                    Log.e(tag, it)
                }))
    }

    fun onTapVK() {
        tapOnSocialNetworkButton()
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .subscribe(
                        { settings ->
                            run {
                                if (settings != null && !TextUtils.isEmpty(settings.textLinkVK)) {
                                    val intentVK = Intent(Intent.ACTION_VIEW,
                                            Uri.parse(getView()?.context?.getString(R.string.vk_base_url_str) + settings.textLinkVK))
                                    getView()?.context?.startActivity(intentVK)
                                }
                            }

                        }, {
                    Log.e(tag, it)
                }))
    }

    fun onTapInstagram() {
        tapOnSocialNetworkButton()
        compositeDisposable.add(Observable.just(true)
            .getSettings()
            .subscribe(
                { settings ->
                    run {
                        if (settings != null && !TextUtils.isEmpty(settings.textLinkInstagram)) {
                            val intentInsta = Intent(Intent.ACTION_VIEW,
                                Uri.parse(getView()?.context?.getString(R.string.instagram_base_url_str) + settings.textLinkInstagram))
                            getView()?.context?.startActivity(intentInsta)
                        }
                    }

                }, {
                    Log.e(tag, it)
                }))
    }

    fun onTapWhatsapp() {
        tapOnSocialNetworkButton()
        compositeDisposable.add(Observable.just(true)
            .getSettings()
            .subscribe(
                { settings ->
                    run {
                        if (settings != null && !TextUtils.isEmpty(settings.textLinkWhatsapp)) {
                            val intentWhatsapp = Intent(Intent.ACTION_VIEW,
                                Uri.parse(getView()?.context?.getString(R.string.whatsapp_base_url_str) + settings.textLinkWhatsapp))
                            getView()?.context?.startActivity(intentWhatsapp)
                        }
                    }

                }, {
                    Log.e(tag, it)
                }))
    }

    fun onTapEmptySpace() {
        if (state == StateFabButton.EXPANDED) {
            state = StateFabButton.COLLAPSED
            collapseButton()
        }
    }

    fun onTapCloseLastMessage() {
        compositeDisposable.add(Observable.just(true)
                .getLastUnreadMessageUseCase()
                .filter { x->x.value != null/* && !x.value.isByBotWithActions()*/}
                .closeLastMessage()
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .doOnNext {
                    getView()?.hideLastMessage()
                    viewModel.updateStateLastMessage(StateLastMessage.CLOSED)
                }
                .doOnError {
                    getView()?.hideLastMessage()
                    viewModel.updateStateLastMessage(StateLastMessage.CLOSED)
                }
                .subscribe())

    }

    fun onCollapseEnd() {
        if (viewModel.getLastMessage().state == StateLastMessage.HIDDEN
            && NetworkManager.getInstance(getView()?.context).hasConnect) {
            getView()?.showLastMessage()
        }
    }

    fun onDestroy() {
        compositeDisposable.dispose()

        super.detachView()
        state = StateFabButton.COLLAPSED
    }

    override fun getView(): FloatingButton? {
        return super.getView() as FloatingButton?
    }

    private fun initThis() {
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        { settings ->
                            if (settings != null) {
                                run {
                                    state = if (hasSocialNetwork(settings)) {
                                        StateFabButton.COLLAPSED
                                    } else {
                                        StateFabButton.NOT_SOCIAL_NETWORKS
                                    }

                                    try {
                                        compositeDisposable.add(Observable.just(true).getTheme(getView()?.context).take(1).subscribe {theme->
                                            getView()?.updateTheme(theme)
                                        })

                                        val buttonBkg = ColorStateList.valueOf(Color.parseColor("#" + settings.originalAppColor))
                                        getView()?.updateColor(buttonBkg)
                                        getView()?.doVisible()
                                    } catch (e: Exception) {
                                        Log.e(tag, e)
                                    }
                                }
                            }

                        },
                        { error ->
                            Log.e(tag, error)
                            getView()?.doGone()
                        }
                ))
    }

    private fun updateButtonView(conversations: ArrayList<DataConversation>) {
        compositeDisposable.add(Observable.just(conversations)
                .getNotPopupConversations()
                .getUnreadConversations()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .subscribe(
                        {
                            if (it != null) {
                                val size = it.size
                                if (size > 0) {
                                    getView()?.showUnreadCounter()

                                    compositeDisposable.add(Observable.just(true)
                                            .getLastUnreadMessageUseCase()
                                            .take(1)
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .doOnNext { lastUnreadMessage ->
                                                updateLastMessage(lastUnreadMessage.value)
                                            }
                                            .doOnComplete {
                                                Log.d(tag, "onComplete getLastUnreadMessageUseCase(): $it")
                                            }
                                            .doOnError { e ->
                                                Log.e(tag, e)
                                            }
                                            .subscribe({}, {}))
                                } else {
                                    getView()?.hideUnreadCounter()
                                    getView()?.hideLastMessage()
                                    viewModel.updateStateLastMessage(StateLastMessage.UNKNOWN)
                                    viewModel.updateAdminIconLastMessage("")
                                    viewModel.updateTextLastMessage("")
                                }
                                getView()?.updateUnreadCount(size.toString())
                            } else {
                                getView()?.hideUnreadCounter()
                            }

                        },
                        { e ->
                            Log.e(tag, e)
                        }
                ))
    }

    private fun subscribeOnLastUnreadMessage(): Disposable {
        return Observable.just(true)
                .getConversations()
                .subscribe({
                    updateButtonView(it)
                },{t->
                    Log.e(tag, t)
                })
    }

    private fun updateLastMessage(lastUnreadMessage: MessageData?) {
        if (lastUnreadMessage != null) {
            var updatedText: String = when(lastUnreadMessage.type) {
                ResponseFields.ARTICLE -> lastUnreadMessage.bodyJson?.asJsonObject?.get(F.NAME)?.asString ?: ""
                ResponseFields.VOTE -> getView()?.context?.getString(R.string.plese_vote_operator) ?: ""
                else -> lastUnreadMessage.body ?: ""
            }

            val needShowAvatar = when(lastUnreadMessage.type) {
                ResponseFields.VOTE -> false
                else -> true
            }

            updatedText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(updatedText, Html.FROM_HTML_MODE_LEGACY).toString()
            } else {
                Html.fromHtml(updatedText).toString()
            }

            updatedText = updatedText.replace(160.toChar(), 32.toChar()).replace(65532.toChar(), 32.toChar()).trim()
            updatedText = EmojiParser.parseToUnicode(updatedText)
            if (TextUtils.isEmpty(updatedText)) {
                updatedText = "..."
            }

            getView()?.updateTextLastMessage(updatedText)
            viewModel.updateTextLastMessage(updatedText)

            val admin = lastUnreadMessage.messageFrom
            viewModel.updateAdminIconLastMessage(admin?.avatar ?: "")
            if (admin?.avatar != null) {
                getView()?.updateLastAdminIcon(admin.avatar!!)
            }

            if (viewModel.getLastMessage().state != StateLastMessage.HIDDEN) {
                if(needShowAvatar) {
                    getView()?.showLastMessage()
                } else {
                    getView()?.showLastMessageWithoutAvatar()
                }
                viewModel.updateStateLastMessage(StateLastMessage.SHOW)
            }

        } else {
            getView()?.hideLastMessage()
            viewModel.updateStateLastMessage(StateLastMessage.UNKNOWN)
        }
    }

    private fun expandButton() {
        getView()?.expand()
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .subscribe(
                        { settings ->
                            run {
                                if (settings != null) {
                                    if (settings.isShowFB) {
                                        getView()?.showFbButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showFbLabelButton()
                                        }
                                    }
                                    if (settings.isShowVK) {
                                        getView()?.showVkButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showVkLabelButton()
                                        }
                                    }
                                    if (settings.isShowTelegram) {
                                        getView()?.showTelegramButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showTelegramLabelButton()
                                        }
                                    }
                                    if (settings.isShowViber) {
                                        getView()?.showViberButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showViberLabelButton()
                                        }
                                    }
                                    if (settings.isShowInstagram) {
                                        getView()?.showInstagramButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showInstagramLabelButton()
                                        }
                                    }
                                    if (settings.isShowWhatsapp) {
                                        getView()?.showWhatsappButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showWhatsappLabelButton()
                                        }
                                    }

                                }
                                if (viewModel.getLastMessage().state == StateLastMessage.SHOW) {
                                    viewModel.updateStateLastMessage(StateLastMessage.HIDDEN)
                                }
                                if (viewModel.getFlagShowSocialLabels()) {
                                    getView()?.showOpenChatLabel()
                                }
                            }
                        },
                        {
                            Log.e(tag, it)
                        }))
    }

    private fun collapseButton() {
        hideSocialNetworks()
        getView()?.collapse()
    }

    private fun hideSocialNetworks() {
        getView()?.hideFbButton()
        getView()?.hideFbLabelButton()

        getView()?.hideVkButton()
        getView()?.hideVkLabelButton()

        getView()?.hideTelegramButton()
        getView()?.hideTelegramLabelButton()

        getView()?.hideViberButton()
        getView()?.hideViberLabelButton()

        getView()?.hideInstagramButton()
        getView()?.hideInstagramLabelButton()

        getView()?.hideWhatsappButton()
        getView()?.hideWhatsappLabelButton()

        getView()?.hideOpenChatLabel()
    }

    private fun goToLastDialog() {
        compositeDisposable.add(Observable.just(true)
                .getLastConversation()
                .map { x -> if(x.value == null || x.value.id == null) "" else x.value.id }
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext { conversationId ->
                    if (conversationId != "") {
                        openConversationById(conversationId)
                    } else {
                        compositeDisposable.add(
                                Observable.just(true)
                                        .getConversations()
                                        .take(1)
                                        .subscribe({ conversations ->
                                            if (conversations.size > 0) {
                                                var savedConvId = false
                                                for(conv in conversations) {
                                                    if(conv.type != ConversationType.BLOCK_POPUP_SMALL.stringValue
                                                            && conv.type != ConversationType.BLOCK_POPUP_BIG.stringValue) {
                                                        openConversationById(conv.id)
                                                        savedConvId = true
                                                        break
                                                    }
                                                }
                                                if(!savedConvId) {
                                                    openConversationById("")
                                                }
                                            } else {
                                                openConversationById("")
                                            }

                                        }, { t ->
                                            Log.e(tag, t)
                                        })
                        )
                    }

                }
                .doOnError {
                    Log.e(tag, it)
                }
                .subscribe()
        )
    }

    private fun openConversationById(conversationId: String) {
        compositeDisposable.add(
            Observable.just(true)
                .openConversation(conversationId)
                .subscribe()
        )
        openConversation(conversationId)
    }

    private fun openConversation(conversationId: String) {
        val intent = Intent(getView()?.context, DialogActivity::class.java)
        //val intent = Intent(getView().context, io.carrotquest_sdk.android.ui.dialog.views.DialogActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        //intent.putExtra(io.carrotquest_sdk.android.ui.dialog.views.DialogActivity.CONVERSATION_ID_ARG, conversationId)
        intent.putExtra(DialogActivity.CONVERSATION_ID_ARG, conversationId)
        getView()?.context?.startActivity(intent)
    }

    private fun tapOnSocialNetworkButton() {
        collapseButton()
        state = StateFabButton.COLLAPSED
    }

    private fun hasSocialNetwork(settingsEntity: SettingsEntity?): Boolean {
        if (settingsEntity == null) {
            return false
        }
        return settingsEntity.isShowFB
                || settingsEntity.isShowTelegram
                || settingsEntity.isShowVK
                || settingsEntity.isShowViber
                || settingsEntity.isShowInstagram
                || settingsEntity.isShowWhatsapp
    }

    @SuppressLint("Recycle")
    fun onSetAttributes(typedArray: TypedArray) {
        if (!isSetAttributes) {
            isSetAttributes = true

            var locationFloatingButton = LocationFloatingButton.BOTTOM_RIGHT
            var isShowSocialLabels = true
            var iconFloatingButtonOnExpandState = getView()?.resources?.getDrawable(R.drawable.ic_cq_message)
            var marginFAB = GraphicUtils.dpToPx(getView()?.context, 16.0f).toFloat()
            var autoHide = false

            val attrsCount = typedArray.indexCount
            if (attrsCount > 0) {
                for (i in 0 until attrsCount) {
                    val attr = typedArray.getIndex(i)

                    if (attr == R.styleable.FloatingButton_cq_location_fab) {
                        val locationId = typedArray.getInt(attr, 0)
                        locationFloatingButton = LocationFloatingButton.fromId(locationId)
                    } else if (attr == R.styleable.FloatingButton_cq_margin_fab) {
                        marginFAB = typedArray.getDimension(attr, marginFAB)
                    } else if (attr == R.styleable.FloatingButton_cq_icon_fab) {
                        iconFloatingButtonOnExpandState = typedArray.getDrawable(attr)
                    } else if (attr == R.styleable.FloatingButton_cq_visibility_background) {
                        val visibilityBack = typedArray.getBoolean(attr, true)
                        if (!visibilityBack) {
                            getView()?.updateMainBackgroundAlpha(0.0f)
                        }
                    } else if (attr == R.styleable.FloatingButton_cq_auto_hide_fab) {
                        autoHide = typedArray.getBoolean(attr, false)
                    } else if (attr == R.styleable.FloatingButton_cq_show_social_labels) {
                        isShowSocialLabels = typedArray.getBoolean(attr, true)
                    }
                }
            }

            viewModel.updateAutoHide(autoHide)
            viewModel.updateFlagShowSocialLabels(isShowSocialLabels)
            getView()?.updateIconOnFloatingButton(iconFloatingButtonOnExpandState)
            getView()?.setLocationFloatingButton(locationFloatingButton)
            getView()?.setMarginFloatingButton(marginFAB)
        }
    }

    fun onHideButton() {
        if (viewModel.getLastMessage().state == StateLastMessage.SHOW) {
            getView()?.hideLastMessage()
            viewModel.getLastMessage().state = StateLastMessage.HIDDEN
        }
    }

    fun onShowButton() {
        if (viewModel.getLastMessage().state == StateLastMessage.HIDDEN) {
            getView()?.showLastMessage()
            viewModel.getLastMessage().state = StateLastMessage.SHOW
        }
    }

    internal enum class StateFabButton {
        COLLAPSED,
        EXPANDED,
        NOT_SOCIAL_NETWORKS
    }
}