package io.carrotquest_sdk.android.presentation.mvp.notifications.tracking

import android.content.Context
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log
import kotlin.collections.emptySet

object PushStorage {
    private const val KEY_PENDING_PUSHES = "cq_pending_pushes_set"

    // Добавляем ID пуша в очередь
    fun savePushId(context: Context, conversationId: String) {
        Log.d("PushStorage", "saveConversationId: $conversationId")
        val currentPushes =
            SharedPreferencesLib.getStringSet(context, KEY_PENDING_PUSHES) ?: emptySet()

        // Создаем новую копию Set, так как изменять возвращенный Set напрямую нельзя
        val updatedPushes = HashSet(currentPushes)
        updatedPushes.add(conversationId)

        SharedPreferencesLib.saveStringSet(context, KEY_PENDING_PUSHES, updatedPushes)
    }

    // Удаляем ID пуша после успешной отправки
    fun removePushId(context: Context, conversationId: String) {
        Log.d("PushStorage", "removeConversationId: $conversationId")
        val currentPushes =
            SharedPreferencesLib.getStringSet(context, KEY_PENDING_PUSHES) ?: emptySet()

        val updatedPushes = HashSet(currentPushes)
        updatedPushes.remove(conversationId)

        SharedPreferencesLib.saveStringSet(context, KEY_PENDING_PUSHES, updatedPushes)
    }

    // Получаем все зависшие ID
    fun getPendingPushes(context: Context): Set<String> {
        val pendingPushes = SharedPreferencesLib.getStringSet(context, KEY_PENDING_PUSHES) ?: emptySet()
        Log.d("PushStorage", "getPendingPushes: $pendingPushes")
        return pendingPushes
    }
}