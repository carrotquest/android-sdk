package io.carrotquest_sdk.android.models

/**
 * Operation applied when setting a user property via Carrot.setUserProperty(...).
 *
 * [wireValue] is the exact string sent to the API — keep it in sync with the backend contract.
 */
enum class Operation(val wireValue: String) {
    UPDATE_OR_CREATE("update_or_create"),
    SET_ONCE("set_once"),
    ADD("add"),
    DELETE("delete"),
    APPEND("append"),
    UNION("union"),
    EXCLUDE("exclude"),
}
