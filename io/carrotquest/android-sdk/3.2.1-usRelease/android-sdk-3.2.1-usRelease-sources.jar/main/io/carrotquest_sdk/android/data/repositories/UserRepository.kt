package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.data.user.UserStateHolder
import io.carrotquest_sdk.android.domain.entities.UserEntity

class UserRepository {

    companion object {
        private var instance: UserRepository? = null
        fun getInstance(): UserRepository {
            if (instance == null) instance = UserRepository()
            return instance!!
        }
    }

    fun getUserSync(): UserEntity? = UserStateHolder.current()

    fun saveUser(user: UserEntity) {
        UserStateHolder.update(user)
    }
}
