package io.carrotquest_sdk.android.models;

import androidx.annotation.Keep;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Typed parameters for {@code Carrot.trackEvent(eventName, EventParams)}. Build it with the fluent
 * {@link Builder} — the SDK serializes the values to JSON internally, so integrators never assemble
 * JSON strings by hand.
 *
 * <pre>{@code
 * Carrot.trackEvent("purchase", EventParams.builder()
 *     .put("item", "book")
 *     .put("price", 9.99)
 *     .put("gift", true)
 *     .build());
 * }</pre>
 */
@Keep
public final class EventParams {

    private final Map<String, Object> params;

    private EventParams(Map<String, Object> params) {
        this.params = params;
    }

    /** Accumulated key/value pairs, in insertion order. Used by the SDK to serialize the event. */
    public Map<String, Object> getParams() {
        return params;
    }

    /** {@code true} if no parameters were added. */
    public boolean isEmpty() {
        return params.isEmpty();
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Fluent builder. Each {@code put} overload preserves the value's type for correct JSON output. */
    @Keep
    public static final class Builder {
        private final Map<String, Object> params = new LinkedHashMap<>();

        public Builder put(String key, String value) { return set(key, value); }
        public Builder put(String key, boolean value) { return set(key, value); }
        public Builder put(String key, int value) { return set(key, value); }
        public Builder put(String key, long value) { return set(key, value); }
        public Builder put(String key, double value) { return set(key, value); }

        private Builder set(String key, Object value) {
            // Пустой/null-ключ молча игнорируем — публичный API SDK не бросает (см. контракт ошибок).
            if (key != null && !key.isEmpty()) {
                params.put(key, value);
            }
            return this;
        }

        public EventParams build() {
            return new EventParams(Collections.unmodifiableMap(new LinkedHashMap<>(params)));
        }
    }
}