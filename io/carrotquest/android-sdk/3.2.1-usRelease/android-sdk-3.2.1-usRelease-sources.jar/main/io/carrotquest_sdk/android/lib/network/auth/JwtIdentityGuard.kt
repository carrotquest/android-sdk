package io.carrotquest_sdk.android.lib.network.auth

import android.util.Base64
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * Барьер идентичности: сверяет владельца JWT (claim'ы `user_id`/`roles`) с тем user_id, который
 * реально уходит в путь запроса (`users/{id}/...`).
 *
 * Зачем. Путь запроса и auth_token берутся из РАЗНЫХ мест и в РАЗНЫЕ моменты: `{id}` вызывающий код
 * захватывает заранее (например, в FCM-колбэке), а токен подставляется живьём в интерсепторе перед
 * отправкой. Если между этими моментами сменилась идентичность (auth-склейка, token-less реконнект,
 * session recovery), запрос уходит с путём одного юзера и токеном другого — сервер отвечает
 * `403 PermissionDeniedError: auth_token does not have some of scopes`.
 *
 * Принцип — fail-open: барьер срабатывает ТОЛЬКО когда владелец токена распознан однозначно и точно
 * не совпадает с id в пути. Легаси-токен `CarrotToken` (непрозрачная строка, не JWT), незнакомый
 * формат claim'ов, путь без явного user_id (`$self_user`, `connect`, `auth/jwt/refresh`) — всё это
 * проходит как раньше.
 *
 * ВАЖНО: user_id сравнивается ТОЛЬКО как строка. Реальные id 19-значные
 * (`2302664930261729520`), и любое приведение к Double/Long по пути теряет точность —
 * бэкенд сам присылает в JSON `"user_id": 2302664930261729500` рядом с точным значением в `roles`.
 */
internal object JwtIdentityGuard {

    /** `user.$app_id:3060.$user_id:1691658445947668331` — вытаскиваем хвост после `$user_id:`. */
    private val ROLE_USER_ID = Regex("""\${'$'}user_id:(\d+)""")

    /** `users/{id}/что-угодно` — id берём только если это цифры (не `$self_user`). */
    private val PATH_USER_ID = Regex("""(?:^|/)users/(\d+)(?:/|$)""")

    /**
     * Все user_id, которыми владеет токен: top-level claim `user_id` + все id из `roles`.
     * После auth-склейки бэкенд кладёт в `roles` ОБА id (целевого юзера и присоединённого анонима),
     * поэтому владельцев может быть несколько — и это нормально.
     *
     * @return null, если токен не JWT или ни одного user_id распознать не удалось (fail-open).
     */
    fun tokenOwnerIds(token: String?): Set<String>? {
        val payload = decodePayload(token) ?: return null
        val ids = linkedSetOf<String>()

        // Top-level claim. asString у Gson отдаёт исходное написание числа (LazilyParsedNumber),
        // поэтому точность 19-значного id не теряется — в отличие от asLong/asDouble.
        runCatching {
            payload.get("user_id")?.takeIf { it.isJsonPrimitive }?.asString
        }.getOrNull()?.let { if (it.isNotEmpty()) ids.add(it) }

        runCatching {
            val roles = payload.get("roles") ?: return@runCatching
            val raw = when {
                roles.isJsonArray -> roles.asJsonArray.mapNotNull { it.takeIf { e -> e.isJsonPrimitive }?.asString }
                roles.isJsonPrimitive -> listOf(roles.asString)
                else -> emptyList()
            }
            raw.forEach { role -> ROLE_USER_ID.findAll(role).forEach { ids.add(it.groupValues[1]) } }
        }

        return ids.takeIf { it.isNotEmpty() }
    }

    /**
     * user_id, адресуемый путём запроса.
     * @return null для путей, не привязанных к конкретному юзеру (`$self_user`, `connect`, `refresh`).
     */
    fun requestUserId(encodedPath: String?): String? {
        if (encodedPath.isNullOrEmpty()) return null
        return PATH_USER_ID.find(encodedPath)?.groupValues?.get(1)
    }

    /**
     * true — токен ТОЧНО принадлежит не тому юзеру, к которому адресован запрос.
     * При любой неопределённости — false (не мешаем запросу уйти).
     */
    fun isMismatch(token: String?, encodedPath: String?): Boolean {
        val requestId = requestUserId(encodedPath) ?: return false
        val owners = tokenOwnerIds(token) ?: return false
        return requestId !in owners
    }

    /** Декодирует payload JWT. null — не JWT (в т.ч. легаси CarrotToken) или битая база64. */
    private fun decodePayload(token: String?): JsonObject? {
        if (token.isNullOrEmpty()) return null
        val parts = token.split('.')
        if (parts.size != 3) return null
        return runCatching {
            // java.util.Base64 недоступен: minSdk 21 (появился в API 26).
            val bytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            JsonParser.parseString(String(bytes, Charsets.UTF_8)) as? JsonObject
        }.getOrNull()
    }
}
