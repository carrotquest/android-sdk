package io.carrotquest_sdk.android.core.auth

import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Рассинхрон: личность, которой SDK себя считает, не входит во владельцев токена запросов. */
internal data class IdentityMismatch(val currentId: String, val owners: Set<String>)

/**
 * Инвариант идентичности и его ремонт.
 *
 * ИНВАРИАНТ: личность, от имени которой строятся пути запросов ([currentId] — она же подставляется
 * в `users/{user_id}/...`), обязана входить во множество владельцев токена, который в этих запросах
 * уходит ([tokenOwners], claims JWT).
 *
 * Зачем: личность и токены пишут несколько независимых хранилищ, ни одно из которых не сверяет
 * владельца. Разойдясь, они не сходились обратно НИКОГДА: барьер идентичности блокирует запрос ДО
 * отправки, поэтому 403 от сервера не приходит, а 403 — единственный триггер пересоздания сессии.
 * Наружу это выглядело как «нет соединения» при живой сети, вечно, до переустановки приложения.
 *
 * Лестница ремонта — по возрастанию цены, после каждой ступени инвариант перепроверяется:
 *  1. [refreshAccess] — перевыпуск access. Дёшево, анонимов не плодит. Access выпускается заново из
 *     ТЕКУЩЕГО состояния сервера, поэтому если склейка уже произошла, новые claims содержат оба id
 *     и инвариант восстанавливается сам.
 *  2. [reAuthStoredCreds] — повторная авторизация сохранёнными кредами (в обход shouldSkipAuth:
 *     в залипшем состоянии именно он глушит сетевой auth).
 *  3. [rebuildSession] — полный пересбор сессии (token-less /connect + реавторизация). Последняя
 *     инстанция: это то же, что делает переустановка, но без потери кред. Асинхронна, поэтому
 *     подтвердить починку в этом же вызове нельзя — только запускаем.
 *
 * Ступень, которая помогла, попадает в лог: по полям видно, был ли токен реально мёртв (нужна была
 * ступень 2-3) или сервер уже принимал старый токен, а мешали устаревшие claims (хватило ступени 1).
 *
 * Кулдаун и лимит попыток обязательны: ступень 3 создаёт нового анонима, и ремонт без ограничителя
 * сам стал бы источником «размножения анонимов», ради которого барьер и вводился.
 */
internal class IdentityRepairer(
    private val currentId: () -> String,
    private val tokenOwners: () -> Set<String>?,
    private val refreshAccess: suspend () -> Unit,
    private val reAuthStoredCreds: suspend () -> Boolean,
    private val rebuildSession: suspend () -> Unit,
    private val elapsedMs: () -> Long,
    private val log: (SdkLogLevel, String) -> Unit,
    private val cooldownMs: Long = DEFAULT_COOLDOWN_MS,
    private val maxRepairs: Int = DEFAULT_MAX_REPAIRS,
) {
    companion object {
        const val DEFAULT_COOLDOWN_MS = 30_000L
        const val DEFAULT_MAX_REPAIRS = 3
    }

    private val mutex = Mutex()
    private var lastRepairAtMs: Long? = null
    private var repairsDone = 0

    /** null — инвариант соблюдён ЛИБО проверить нечем (нет личности / токен не JWT) → fail-open. */
    fun mismatch(): IdentityMismatch? {
        val id = currentId()
        if (id.isEmpty()) return null
        val owners = tokenOwners() ?: return null
        return if (id in owners) null else IdentityMismatch(id, owners)
    }

    /** true — инвариант соблюдён (сразу или после ремонта). */
    suspend fun repair(reason: String): Boolean = mutex.withLock {
        val mismatch = mismatch() ?: return@withLock true

        if (repairsDone >= maxRepairs) {
            log(SdkLogLevel.WARN, "identity repair skipped ($reason): limit $maxRepairs reached for this session")
            return@withLock false
        }
        val now = elapsedMs()
        val last = lastRepairAtMs
        if (last != null && now - last < cooldownMs) {
            log(SdkLogLevel.INFO, "identity repair skipped ($reason): cooldown ${cooldownMs}ms")
            return@withLock false
        }
        lastRepairAtMs = now
        repairsDone++
        log(
            SdkLogLevel.WARN,
            "identity desync ($reason): currentId=${mismatch.currentId}, tokenOwners=${mismatch.owners} → repairing",
        )

        // Ступень 1 — перевыпуск access. Отмена (deInit отменяет скоуп ремонта) обязана убивать
        // всю лестницу: проглоченная CancellationException доводила отменённый ремонт до ступени 3,
        // и пересбор сессии воскрешал SDK, который хост только что выключил.
        runCatching { refreshAccess() }
            .onFailure {
                if (it is CancellationException) throw it
                log(SdkLogLevel.WARN, "identity repair step=refresh failed: $it")
            }
        if (mismatch() == null) {
            onRepaired("refresh")
            return@withLock true
        }

        // Ступень 2 — повторный auth сохранёнными кредами.
        val reAuthRan = runCatching { reAuthStoredCreds() }
            .getOrElse {
                if (it is CancellationException) throw it
                log(SdkLogLevel.WARN, "identity repair step=reauth failed: $it")
                false
            }
        if (mismatch() == null) {
            onRepaired("reauth")
            return@withLock true
        }

        // Ступень 3 — пересбор сессии. Асинхронный: подтверждения в этом вызове не будет.
        // Перед самой деструктивной ступенью — явная проверка отмены: лямбды ступеней 1-2 могли
        // завершиться до доставки отмены, а между ступенями точек приостановки нет.
        currentCoroutineContext().ensureActive()
        runCatching { rebuildSession() }
            .onFailure {
                if (it is CancellationException) throw it
                log(SdkLogLevel.ERROR, "identity repair step=rebuild failed to start: $it")
            }
        log(
            SdkLogLevel.ERROR,
            "identity repair: refresh and reauth (ran=$reAuthRan) did not restore the invariant " +
                "(currentId=${mismatch.currentId}, tokenOwners=${mismatch.owners}) → session rebuild triggered",
        )
        false
    }

    /** Сброс кулдауна и счётчика — на deInit/новую сессию. */
    fun reset() {
        lastRepairAtMs = null
        repairsDone = 0
    }

    private fun onRepaired(step: String) {
        log(SdkLogLevel.INFO, "identity repaired by step=$step (currentId=${currentId()})")
        // Починились — следующий (новый) рассинхрон должен лечиться с полным бюджетом попыток.
        repairsDone = 0
    }
}
