package io.carrotquest_sdk.android.data.network

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.wss_responses.BlockPopUpNet
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.network.wss_responses.Row
import java.lang.reflect.Type

class PopUpDeserializer : JsonDeserializer<PopUpMessage> {

    override fun deserialize(json: JsonElement?, typeOfT: Type?, context: JsonDeserializationContext?): PopUpMessage? {
        // Malformed popup JSON — пропускаем этот пакет, вся RTS-подписка продолжает работать.
        return try {
            parse(json)
        } catch (t: Throwable) {
            Log.e("PopUpDeserializer", "deserialize failed: $t")
            null
        }
    }

    private fun parse(json: JsonElement?): PopUpMessage? {
        val jsonObject = json?.asJsonObject ?: run {
            Log.e("PopUpDeserializer", "skipped: json is null or not an object")
            return null
        }
        if (!jsonObject.has(ResponseFields.BLOCKS)) {
            Log.e("PopUpDeserializer", "skipped: BLOCKS field missing")
            return null
        }

        val topArray = jsonObject.get(ResponseFields.BLOCKS).asJsonArray ?: return null
        val rows = ArrayList<Row>()
        for (js in topArray) {
            val rowsArray = js.asJsonArray ?: continue
            if (rowsArray.size() == 0) continue
            val blocksArray = rowsArray.get(0).asJsonArray ?: continue
            val blocks = ArrayList<BlockPopUpNet>()
            for (blockJson in blocksArray) {
                val blockObject = blockJson.asJsonObject ?: continue

                val type = if (blockObject.has(ResponseFields.TYPE)) {
                    blockObject.get(ResponseFields.TYPE).asString
                } else ""

                val image = if (blockObject.has(ResponseFields.PARAMS)) {
                    val params = blockObject.get(ResponseFields.PARAMS).asJsonObject
                    if (params != null && params.has(ResponseFields.BACKGROUND_IMAGE)) {
                        params.get(ResponseFields.BACKGROUND_IMAGE).asString
                    } else ""
                } else ""

                blocks.add(BlockPopUpNet(type, image))
            }
            rows.add(Row(blocks))
        }

        val expiration = if (jsonObject.has(ResponseFields.EXPIRATION_TIME) &&
            !jsonObject.get(ResponseFields.EXPIRATION_TIME).isJsonNull
        ) {
            jsonObject.get(ResponseFields.EXPIRATION_TIME).asLong
        } else 0L

        var backColor = ""
        if (jsonObject.has(ResponseFields.PARAMS)) {
            val params = jsonObject.get(ResponseFields.PARAMS).asJsonObject
            if (params != null && params.has(ResponseFields.BACKGROUND_COLOR)) {
                backColor = params.get(ResponseFields.BACKGROUND_COLOR).asString
            }
        }

        val id = if (jsonObject.has(ResponseFields.ID) && !jsonObject.get(ResponseFields.ID).isJsonNull) {
            jsonObject.get(ResponseFields.ID).asString
        } else return null

        return PopUpMessage(
            id,
            json.toString(),
            rows,
            expiration,
            backColor
        )
    }
}
