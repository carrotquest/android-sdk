package io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.presentation.chat.QuoteAttachment
import io.carrotquest_sdk.android.presentation.chat.input.ReplyPreviewUi
import org.json.JSONObject

/**
 * Драфт режима ответа (цитирование) — зеркало текстового драфта: если пользователь начал
 * отвечать на сообщение и закрыл диалог, при повторном открытии чип «Ответ на сообщение»
 * восстанавливается. Персистим ГОТОВОЕ превью (сниппет + вид вложения), а не только id:
 * оригинал после переоткрытия может быть ещё не загружен (глубокая история), и чип должен
 * восстановиться без похода в репозиторий.
 */

private const val KEY_MESSAGE_ID = "message_id"
private const val KEY_SNIPPET = "snippet"
private const val KEY_ATT_KIND = "att_kind"
private const val KEY_ATT_COUNT = "att_count"
private const val KEY_ATT_NAME = "att_name"

// Чистая сериализация превью (без контекста/prefs) — покрыта DraftReplyJsonTest.
internal fun replyPreviewToJson(replyTo: ReplyPreviewUi): String = JSONObject().apply {
    put(KEY_MESSAGE_ID, replyTo.messageId)
    replyTo.snippet?.let { put(KEY_SNIPPET, it) }
    when (val att = replyTo.attachment) {
        is QuoteAttachment.Images -> { put(KEY_ATT_KIND, "images"); put(KEY_ATT_COUNT, att.count) }
        is QuoteAttachment.Voice -> put(KEY_ATT_KIND, "voice")
        is QuoteAttachment.File -> { put(KEY_ATT_KIND, "file"); att.name?.let { put(KEY_ATT_NAME, it) } }
        is QuoteAttachment.Files -> { put(KEY_ATT_KIND, "files"); put(KEY_ATT_COUNT, att.count) }
        null -> {}
    }
}.toString()

// null — пустая строка/битый JSON/нет message_id (драфта нет либо он нечитаем).
internal fun replyPreviewFromJson(raw: String): ReplyPreviewUi? = runCatching {
    val json = JSONObject(raw)
    val attachment = when (json.optString(KEY_ATT_KIND)) {
        "images" -> QuoteAttachment.Images(json.optInt(KEY_ATT_COUNT, 1))
        "voice" -> QuoteAttachment.Voice
        "file" -> QuoteAttachment.File(json.optString(KEY_ATT_NAME).ifEmpty { null })
        "files" -> QuoteAttachment.Files(json.optInt(KEY_ATT_COUNT, 2))
        else -> null
    }
    ReplyPreviewUi(
        messageId = json.getString(KEY_MESSAGE_ID),
        snippet = json.optString(KEY_SNIPPET).ifEmpty { null },
        attachment = attachment,
    )
}.getOrNull()

fun saveDraftReplyUseCase(replyTo: ReplyPreviewUi, conversationId: String) {
    val context = CarrotLib.getLibComponents().context
    SharedPreferencesLib.saveString(context, DRAFT_REPLY_KEY + conversationId, replyPreviewToJson(replyTo))
}

fun getDraftReplyUseCase(conversationId: String): ReplyPreviewUi? {
    val context = CarrotLib.getLibComponents().context
    val raw = SharedPreferencesLib.getString(context, DRAFT_REPLY_KEY + conversationId).ifEmpty { return null }
    return replyPreviewFromJson(raw)
}

fun clearDraftReplyUseCase(conversationId: String) {
    val context = CarrotLib.getLibComponents().context
    SharedPreferencesLib.saveString(context, DRAFT_REPLY_KEY + conversationId, "")
}
