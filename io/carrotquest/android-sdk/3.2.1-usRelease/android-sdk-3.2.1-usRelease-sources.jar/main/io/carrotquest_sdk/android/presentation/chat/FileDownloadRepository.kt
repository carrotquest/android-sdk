package io.carrotquest_sdk.android.presentation.chat

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.db.files.SavedFile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

internal object FileDownloadRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jobs   = ConcurrentHashMap<String, Job>()
    private val states = ConcurrentHashMap<String, MutableStateFlow<DownloadState>>()

    // Возвращает Flow состояния для вложения. initialState берётся из UiAttachment при первом
    // обращении (уже учитывает данные из БД, заполненные MessageMapper-ом).
    fun stateFor(attachmentId: String, initialState: DownloadState): Flow<DownloadState> =
        states.getOrPut(attachmentId) { MutableStateFlow(initialState) }

    fun currentStateFor(attachmentId: String, initialState: DownloadState): DownloadState =
        (states[attachmentId] ?: MutableStateFlow(initialState)).value

    fun download(scope: CoroutineScope, attachmentId: String, url: String?, declaredSize: Long) {
        if (url.isNullOrEmpty()) return
        if (jobs.containsKey(attachmentId)) return

        val state = states.getOrPut(attachmentId) { MutableStateFlow(DownloadState.NotDownloaded) }

        val job = scope.launch(Dispatchers.IO) {
            var outputFile: File? = null
            try {
                val db = CarrotInternal.getLibComponent().sdkDataBase
                val existing = db.savedFileDao().getByURL(url)
                if (existing != null && File(existing.localUri).exists()) {
                    state.value = DownloadState.Downloaded(existing.localUri)
                    return@launch
                }

                state.value = DownloadState.Downloading(0f)

                val request = Request.Builder().url(url).build()
                val call = client.newCall(request)
                coroutineContext[Job]?.invokeOnCompletion { call.cancel() }

                call.execute().use { response ->
                    if (!response.isSuccessful) {
                        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, "FileDownload", "attachment download failed: HTTP ${response.code}")
                        state.value = DownloadState.NotDownloaded
                        return@use
                    }
                    val body = response.body ?: run {
                        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, "FileDownload", "attachment download: empty response body")
                        state.value = DownloadState.NotDownloaded
                        return@use
                    }

                    val totalBytes = if (declaredSize > 0) declaredSize else body.contentLength()
                    val fileName = freeName(url.substringAfterLast('/').ifEmpty { "file" })
                    outputFile = File(downloadDir(), fileName)

                    var bytesRead = 0L
                    outputFile!!.outputStream().use { out ->
                        body.byteStream().use { stream ->
                            val buffer = ByteArray(8 * 1024)
                            var read: Int
                            while (stream.read(buffer).also { read = it } != -1) {
                                ensureActive()
                                out.write(buffer, 0, read)
                                bytesRead += read
                                if (totalBytes > 0) {
                                    state.value = DownloadState.Downloading(
                                        (bytesRead.toFloat() / totalBytes).coerceIn(0f, 1f)
                                    )
                                }
                            }
                        }
                    }

                    val saved = SavedFile(System.currentTimeMillis().toString())
                    saved.localUri = outputFile!!.absolutePath
                    saved.url = url
                    db.savedFileDao().insert(saved)

                    state.value = DownloadState.Downloaded(outputFile!!.absolutePath)
                }

            } catch (e: CancellationException) {
                outputFile?.delete()
                state.value = DownloadState.NotDownloaded
                throw e
            } catch (e: Exception) {
                outputFile?.delete()
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, "FileDownload", "attachment download failed", e)
                state.value = DownloadState.NotDownloaded
            } finally {
                jobs.remove(attachmentId)
            }
        }

        jobs[attachmentId] = job
    }

    fun cancel(attachmentId: String) {
        jobs.remove(attachmentId)?.cancel()
    }

    fun openFile(context: Context, localPath: String, mimeType: String) {
        val file = File(localPath)
        if (!file.exists()) return

        val resolvedMime = mimeType.ifEmpty {
            val ext = MimeTypeMap.getFileExtensionFromUrl(localPath)
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "*/*"
        }

        try {
            val authority = "${context.packageName}.io.carrotquest_sdk.android.GenericFileProvider"
            val uri = FileProvider.getUriForFile(context, authority, file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, resolvedMime)
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NO_HISTORY
            }
            context.startActivity(
                Intent.createChooser(intent, "").apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            )
        } catch (e: Exception) {
            io.carrotquest_sdk.android.core.util.Log.e("FileDownloadRepository", "Cannot open file: $e")
        }
    }

    private fun downloadDir(): File {
        val ctx = CarrotInternal.getLibComponent().contextSdk
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(ctx.filesDir, Environment.DIRECTORY_DOWNLOADS)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun freeName(fileName: String): String {
        val dir = downloadDir()
        if (!File(dir, fileName).exists()) return fileName

        val dot = fileName.lastIndexOf('.')
        val name = if (dot != -1) fileName.substring(0, dot) else fileName
        val ext  = if (dot != -1) fileName.substring(dot) else ""

        var suffix = 1
        while (File(dir, "$name ($suffix)$ext").exists()) suffix++
        return "$name ($suffix)$ext"
    }
}
