package io.carrotquest_sdk.android.presentation.mvp.notifications;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys;
import io.carrotquest_sdk.android.core.logging.SdkLogCategory;
import io.carrotquest_sdk.android.core.logging.SdkLogLevel;
import io.carrotquest_sdk.android.core.logging.SdkLogger;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;

public class SdkFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "SDk Firebase Cloud Messaging Service";

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push received (" + remoteMessage.getData().size() + " data keys)");
        // Пользователь вышел (Carrot.deInit) и нового setup не было — не показываем пуши
        // предыдущему юзеру. Флаг persist, поэтому гейт работает и после холодного старта
        // процесса от пуша (когда SDK ещё/уже не в памяти). Проверяем ДО libComponent:
        // buildComponentsWithoutConnect мог поднять граф ради показа пуша, не снимая флаг.
        if (SharedPreferencesLib.getBoolean(getApplicationContext(), SharedPreferenceKeys.SDK_DEINITIALIZED)) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "push dropped: SDK deinitialized (logged out)");
            return;
        }
        SdkLibComponent libComponent = CarrotInternal.getLibComponent();
        if (libComponent != null) {
            libComponent.getNotificationHelper().postNotification(remoteMessage.getData());
        } else {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "push dropped: SDK not initialized");
        }
    }
}
