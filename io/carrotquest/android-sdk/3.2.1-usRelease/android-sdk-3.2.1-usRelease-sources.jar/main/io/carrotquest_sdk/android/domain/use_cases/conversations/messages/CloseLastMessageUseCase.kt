package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.ClosedMessage
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.util.Log
import kotlinx.coroutines.withContext

// suspend (ветка remove_rx) — Observable-ext убрана. Помечает сообщение закрытым (в БД).
suspend fun closeLastMessage(message: MessageData?) = withContext(SdkDispatchers.io) {
    if (message == null) return@withContext
    val db: CarrotSdkDB = SdkApp.getInstance().database
    val newId = message.id
    if (db.closedMessageDao().getById(newId) == null) {
        // строки нет (раньше — Single.onError EmptyResultSetException) → сохраняем
        db.closedMessageDao().insert(ClosedMessage(newId))
    } else {
        Log.d("closeLastMessage", "write new closed message")
    }
}
