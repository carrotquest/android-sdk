package io.carrotquest_sdk.android.domain.use_cases.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun saveAuthedUserIdUseCase(authId: String, userId: String, context: Context = CarrotLib.getLibComponents().context) {
    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.AUTHED_AUTH_ID_KEY, authId)
    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.AUTHED_SDK_USER_ID_KEY, userId)
}

fun saveConnectedUserIdUseCase(userId: String, context: Context = CarrotLib.getLibComponents().context) {
    val key = SharedPreferenceKeys.CONNECTED_USER_ID_KEY
    SharedPreferencesLib.saveString(context, key, userId)
}