package io.carrotquest_sdk.android.domain.use_cases.user

import android.text.TextUtils
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessage
import io.carrotquest_sdk.android.core.constants.MessageStatus
import org.json.JSONObject
import java.util.Locale

// suspend-ядра голосования (ветка remove_rx, фаза 3). Потребляются только DialogPresenter.

suspend fun sendVoteOperator(messageId: String, vote: Int, comment: String = ""): Boolean {
    val bodyMetaDataObject = JsonObject()
    bodyMetaDataObject.addProperty("vote", vote)
    if (!TextUtils.isEmpty(comment)) {
        bodyMetaDataObject.addProperty("comment", comment)
    }
    val response = CarrotInternal.getService().carrotLib
        .conversationPartsSuspend(messageId, bodyMetaDataObject)
    return response.status == 200
}

suspend fun wrongVoting(messageId: String): Boolean {
    val message = getMessage(messageId) ?: return false
    message.status = MessageStatus.WARNING.name.lowercase(Locale.getDefault())
    MessagesRepository.getInstance().updateMessage(message)
    return true
}

// doneVoting и doneVotingComment имели идентичные тела — общая реализация.
private suspend fun applyVote(messageId: String, vote: Int): Boolean {
    val message = getMessage(messageId) ?: return false
    message.messageMetaData?.vote = vote

    val sourceJson = message.sourceJsonData
    val metaJson = JSONObject()
    metaJson.put(F.VOTE, vote)
    if (sourceJson.has(F.META_DATA)) {
        sourceJson.remove(F.META_DATA)
    }
    sourceJson.put(F.META_DATA, metaJson)

    MessagesRepository.getInstance().updateMessage(message)
    return true
}

suspend fun doneVoting(messageId: String, vote: Int): Boolean = applyVote(messageId, vote)

suspend fun doneVotingComment(messageId: String, vote: Int): Boolean = applyVote(messageId, vote)
