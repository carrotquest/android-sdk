package io.carrotquest_sdk.android.data.db.messages

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Кэш кнопок (actions) бот-сообщений. История с сервера (getMessages) их не возвращает —
 * actions приходят только вживую по WSS. Сохраняем их по messageId, чтобы восстановить
 * при перезаходе в диалог / перезапуске приложения.
 */
@Keep
@Entity(tableName = "bot_actions")
data class BotActionsEntity(
    @PrimaryKey val messageId: String,
    val conversationId: String,
    val actionsJson: String,
    val created: Long,
)