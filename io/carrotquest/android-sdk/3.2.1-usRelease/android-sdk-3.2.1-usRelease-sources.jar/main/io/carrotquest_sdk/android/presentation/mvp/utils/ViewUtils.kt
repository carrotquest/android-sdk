package io.carrotquest_sdk.android.presentation.mvp.utils

import android.content.Context
import android.view.View

internal fun bubbleToFront(view: View) {
    view.elevation = 57f // Это магическое число выбрано из-за того, что по дефолту elevation у FAB = 56
    view.bringToFront()
}

internal fun isTablet(context: Context): Boolean {
    return context.resources.configuration.smallestScreenWidthDp >= 600
}
