package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Suspend-версии createConversation (strangler, ветка remove_rx). Возвращают id созданной
 * беседы или "" (как Observable-ext: пустая строка при ошибке/отсутствии беседы).
 * Сосуществуют с Observable-ext в CreateConversationUseCase.kt — разные сигнатуры.
 */

suspend fun createConversationSuspend(textMessage: String, attachmentsCached: String? = null): String = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext ""

    val res = CarrotInternal.getService().carrotLib
        .startConversationSuspend(user.id, textMessage.replace("\n", "<br/>"), attachmentsCached)
    if (res.meta.error != null) return@withContext ""

    val conversationId = res.data.conversationId
    ConversationsRepository.getInstance().saveOpenedConversation(conversationId)

    val conversation = getConversationSuspend(conversationId)
    if (conversation != null && conversation.id != null) {
        ConversationsRepository.getInstance().addConversation(conversation)
        conversation.id
    } else {
        ""
    }
}

suspend fun createConversationSuspend(file: File): String = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext ""

    val res = CarrotInternal.getService().carrotLib
        .startConversationSuspend(user.id, file)
    if (res.meta.error != null) return@withContext ""

    // Внимание: в file-варианте Observable-ext saveOpenedConversation НЕ вызывался — сохраняем 1:1.
    val conversationId = res.data.conversationId
    val conversation = getConversationSuspend(conversationId)
    if (conversation != null) {
        ConversationsRepository.getInstance().addConversation(conversation)
        conversation.id ?: ""
    } else {
        ""
    }
}
