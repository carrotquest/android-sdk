package io.carrotquest_sdk.android.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.coroutines.SdkCoroutineExceptionHandler
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.HistoryGap
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentKind
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel : ViewModel() {

    private val _state = MutableStateFlow<ChatScreenState>(ChatScreenState.Loading)
    val state: StateFlow<ChatScreenState> = _state.asStateFlow()

    // Ответы на кнопки бота, отправленные в текущей сессии.
    // Нужно, т.к. сервер не проставляет replied=true на исходное сообщение с кнопками
    // до переоткрытия диалога. Очищается при уничтожении VM (при закрытии диалога).
    private val localBotAnswers = mutableMapOf<String, String>() // messageId → selectedOptionId

    // Текстовые ответы боту (инпут в режиме BOT_INPUT), отправленные в текущей сессии:
    // id части-вопроса → текст ответа. Симметрия с localBotAnswers для кнопок: оптимистичное
    // reply_user-сообщение в репозиторий больше не кладём (оно дублировало пузырь, который
    // MessageMapper рисует из meta_data.answer_body той же части), а до подтверждения сервером
    // рисуем пузырь отсюда. Оверрайд НЕ снимаем: маппер и так предпочитает серверный answer_body,
    // а локальный служит страховкой, если getMessages→setData вернёт часть без него.
    // @Volatile + copy-on-write: пишется с Main (setBotTextAnswer), читается с IO (rebuildList).
    @Volatile private var localBotTextAnswers: Map<String, String> = emptyMap()

    // Локальное состояние голоса: выставляется в Loading при отправке, живёт до
    // тех пор, пока сервер не пришлёт Rated в сообщении. Нужно, чтобы rebuildList()
    // не откатывал Loading → Pending пока сервер обрабатывает запрос.
    private val localVoteStates = mutableMapOf<String, VoteState>() // messageId → VoteState

    // Локальное состояние формы контактов: Submitting при отправке, живёт до тех пор,
    // пока сервер не пришлёт replied=true → MessageMapper вернёт Submitted.
    private val localContactStates = mutableMapOf<String, ContactInputState>() // messageId → state

    // Отмеченные пользователем чекбоксы согласия по каждому сообщению-контакт-форме.
    // MessageMapper пересобирает consent при каждом rebuild с checked=false, поэтому отметки
    // держим здесь и накатываем поверх (applyConsentOverrides). Живёт до закрытия диалога.
    private val localConsentChecked = mutableMapOf<String, MutableSet<ConsentKind>>() // messageId → checked kinds

    // conversation_id, с которым диалог был открыт (для нового диалога — пустой).
    // @Volatile: пишется с Main (setConversationId), читается с IO (rebuildList) — как routingBotResolved.
    @Volatile private var conversationId: String = ""

    // Все id, относящиеся к текущей сессии диалога: исходный + живой из DialogViewModel
    // (routing bot создаёт сначала временный randomId, затем реальный id). Копим их, чтобы
    // при переходе randomId → реальный id уже показанные сообщения не пропадали из списка.
    // MessagesRepository глобальный, поэтому фильтрация по этим id обязательна.
    private val knownConversationIds = mutableSetOf<String>()

    // Ответ сервера на chooseRoutingBot — приходит от презентера (setRoutingBotResolved).
    // Если found=true, startBrunch включается в список сообщений.
    private val _routingBotData = MutableStateFlow<ChooseRoutingBotData?>(null)

    // true, когда наличие бота уже выяснено у бэкенда. До этого welcome не показываем,
    // чтобы он не мелькал перед ботом: сначала спрашиваем бота, потом решаем что рисовать.
    // Своего запроса chooseRoutingBot здесь БОЛЬШЕ НЕТ: два независимых запроса (тут и в
    // презентере) расходились в ответах — при сетевом флейке презентер после ретрая узнавал
    // «бот есть», а этот запрос падал навсегда (повторять его было некому) и в чате
    // оставалось дефолтное приветствие вместо дерева бота.
    @Volatile private var routingBotResolved = false

    fun setConversationId(id: String) {
        conversationId = id
    }

    /**
     * Единственный вход для ответа chooseRoutingBot (презентер → DialogFragment → сюда).
     *
     * Сам факт вызова означает «состояние бота выяснено» → дефолтное приветствие разрешено.
     * [data] == null — узнать не удалось при живой сети (деградация: бота считаем отсутствующим,
     * прежний успешный ответ не затираем). Пока вызова не было, welcome не рисуем: в офлайне
     * презентер молчит и повторит запрос после возврата сети.
     */
    fun setRoutingBotResolved(data: ChooseRoutingBotData?) {
        // Проставляем conversationId в startBrunch сразу — у шаблонного сообщения он null.
        data?.bot?.startBrunch?.let { msg ->
            if (msg.conversation.isNullOrEmpty()) msg.conversation = conversationId
        }
        val replace = shouldReplaceRoutingBotData(_routingBotData.value, data)
        Log.d(
            "CQ_BotOrder",
            "setRoutingBotResolved convId='$conversationId' found=${data?.found} " +
                "hasStartBrunch=${data?.bot?.startBrunch != null} " +
                "hadTemplate=${hasStartBrunchTemplate(_routingBotData.value)} replace=$replace",
        )
        if (replace) _routingBotData.value = data
        routingBotResolved = true
        triggerRebuild()
    }

    /**
     * Пользователь отправил текстовый ответ на вопрос бота с property_field
     * (презентер → DialogFragment → сюда, тем же путём, что setRoutingBotResolved).
     *
     * [partId] — id части-вопроса (ActionMessage.message_id): именно на ней MessageMapper
     * рисует исходящий пузырь с ответом.
     */
    fun setBotTextAnswer(partId: String, answer: String) {
        if (partId.isEmpty() || answer.isBlank()) return
        localBotTextAnswers = localBotTextAnswers + (partId to answer)
        triggerRebuild()
    }

    private var currentTypingIndicator: ChatListItem.TypingIndicator? = null

    // Единственный канал перестройки списка. DROP_OLDEST + collectLatest гарантируют:
    // — параллельных rebuildList() нет (предыдущий отменяется новым trigger-ом);
    // — если новый trigger приходит пока предыдущий ещё на IO, старый fetch отменяется
    //   и запускается свежий, поэтому в state всегда попадают актуальные данные.
    private val rebuildTrigger = MutableSharedFlow<Unit>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    init {
        viewModelScope.launch(SdkCoroutineExceptionHandler) { rebuildTrigger.collectLatest { rebuildList() } }
        observeMessages()
    }

    private fun triggerRebuild() { rebuildTrigger.tryEmit(Unit) }

    private fun observeMessages() {
        val repo = MessagesRepository.getInstance()

        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            repo.newMessagesFlow.collect { triggerRebuild() }
        }
        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            repo.removedMessageFlow.collect { triggerRebuild() }
        }
        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            repo.typingIndicatorFlow.collect { pair ->
                currentTypingIndicator = pair?.let { (name, avatarUrl) ->
                    ChatListItem.TypingIndicator(name = name, avatarUrl = avatarUrl)
                }
                triggerRebuild()
            }
        }
        // setData() (bulk load) эмитит в dataFlow (раньше — только messagesSubject); собираем
        // напрямую корутинным Flow, чтобы порядок при переоткрытии диалога был верным.
        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            repo.dataFlow.collect { triggerRebuild() }
        }
    }

    private suspend fun rebuildList() = withContext(Dispatchers.IO) {
        val db = SdkApp.getInstance().database
        val repo = MessagesRepository.getInstance()
        // Снимок (а не живой data.data): итерация живого списка конкурентно с WSS-мутациями
        // кидала ConcurrentModificationException → пустой чат.
        val allMessages = repo.getMessagesSnapshot()
        // Живой id диалога держит presenter в DialogViewModel (он же по нему фильтрует свои
        // сообщения). Берём его и копим — это покрывает routing bot: новый диалог стартует с
        // пустым id, после выбора ветки бэкенд создаёт диалог (сначала временный randomId,
        // затем реальный id), и сообщения бота приходят уже с этим id.
        val liveId = DialogViewModel.getInstance().getCurrentConversationId()
        if (liveId.isNotEmpty()) knownConversationIds.add(liveId)
        if (conversationId.isNotEmpty() && conversationId != "last_conversation") {
            knownConversationIds.add(conversationId)
        }
        val ids = knownConversationIds
        // Сообщения чужих диалогов отсекаем; пустой conversation (оптимистичные/первое
        // сообщение нового диалога) показываем всегда; пока id ещё нет — только isFirst.
        val rawMessages = allMessages.filter { m ->
            m.conversation.isNullOrEmpty() ||
            m.conversation in ids ||
            (ids.isEmpty() && m.isFirst)
        }

        // Стартовая ветка routing-бота (шаблон из chooseRoutingBot) живёт только здесь — реальным
        // сообщением в репозиторий она не попадает (до перезахода), поэтому при общении с ботом её
        // надо держать, иначе пропадёт первая пачка (приветствие+кнопки). Источник истины — found=true
        // от бэкенда (как в старом WebView-теле, где презентер выставлял needStartRoutingBot=found).
        // Убираем шаблон в двух случаях:
        //  1) серверная первая ветка уже подгрузилась (на resume/reload) — иначе он дублирует серверные
        //     «Привет!» + кнопки. Детект: у какого-то сообщения answerActionId совпадает с branch-id
        //     опции шаблона (= сервер записал ответ на первую ветку);
        //  2) на НОВОМ диалоге (conversationId пуст) юзер напечатал своё сообщение (reply_user) — т.е.
        //     прервал бота и начал обычный диалог, не ответив кнопкой → первую ветку показывать не надо.
        //     На ПЕРЕОТКРЫТИИ существующего диалога (есть реальный conversationId) reply_user — это
        //     прошлая история, а не свежее прерывание: там решает found бэкенда, проверку не применяем.
        val template = _routingBotData.value?.takeIf { it.found == true }?.bot?.startBrunch
        val templateBranchIds = template?.actions?.mapNotNull { it.nextBranchId }?.toSet() ?: emptySet()
        val serverHasFirstBranch = templateBranchIds.isNotEmpty() && rawMessages.any { m ->
            m.messageMetaData?.answerActionId?.let { it in templateBranchIds } == true
        }
        val interruptedNewDialog = conversationId.isEmpty() &&
            rawMessages.any { it.type == ResponseFields.REPLY_USER }
        val startBrunch = if (!serverHasFirstBranch && !interruptedNewDialog) template else null

        // Позиционирование шаблона первой ветки зависит от того, КАК открыт диалог:
        //
        //  • ПЕРЕОТКРЫТИЕ существующего диалога (conversationId не пуст): бэкенд просит ПОВТОРНО
        //    показать первую ветку как актуальный промпт — он должен встать ВНИЗУ, под старой
        //    историей, с активными кнопками. Шаблон приходит без created/sortKey → по умолчанию
        //    (created→0) уехал бы наверх как «самое старое» и схлопнул бы кнопки (isAnswered =
        //    !isNewest). Поэтому делаем его новейшим: created = max среди сообщений, sortKey = maxId+1
        //    (как у оптимистичных исходящих, см. MessageMapper.sortKey). Фиксируем ОДИН раз
        //    (sortKey == null): после тапа приходит реальный ответ со свежим (бо́льшим) id и корректно
        //    встаёт НИЖЕ замороженного шаблона.
        //
        //  • НОВЫЙ диалог (conversationId пуст): шаблон — это ПЕРВОЕ приветствие бота, т.е. самое
        //    СТАРОЕ сообщение. Его НЕ пиним: с created=null (→0) он естественно встаёт наверх, а
        //    ответ пользователя и следующая реплика бота ложатся под ним по своим created. Если бы
        //    пинили — шаблон стал бы новейшим и выдавил реальную последнюю реплику бота наверх
        //    (сообщения routing-старта часто приходят одной секундой, тай-брейк по sortKey/id).
        if (startBrunch != null && startBrunch.sortKey == null &&
            rawMessages.isNotEmpty() && conversationId.isNotEmpty()) {
            // created/sortKey берём из тех же repo-хелперов, что и оптимистичные исходящие
            // (sendActionBot) — единый источник правил «последний created» и maxId+1, без дублирования
            // тай-брейка sortKey?:id здесь.
            startBrunch.created = repo.getLastMessageCreatedSeconds().toString()
            startBrunch.sortKey = repo.getMaxMessageId() + 1
        }

        val welcomeMsg = if (shouldShowWelcome(
                routingBotResolved = routingBotResolved,
                hasMessages = rawMessages.isNotEmpty(),
                hasStartBrunch = startBrunch != null,
            )
        ) repo.getWelcomeMessage() else null

        val messages = buildList {
            if (welcomeMsg != null) add(welcomeMsg) else addAll(rawMessages)
            if (startBrunch != null) add(startBrunch)
        }

        val mappedItems = MessageMapper.map(messages, db, localBotTextAnswers)
        val historyGap = repo.getHistoryGap()
        withContext(Dispatchers.Main) {
            val current = _state.value
            if (current is ChatScreenState.Content) {
                val result = ChatStateReducer.applyLocalOverrides(
                    mapped = mappedItems,
                    botAnswers = localBotAnswers,
                    voteStates = localVoteStates,
                    contactStates = localContactStates,
                    typing = currentTypingIndicator,
                )
                // Сервер подтвердил оценку (Loading→Rated) / форму контактов (Submitting→Submitted) —
                // ПИНим подтверждённое состояние локально на сессию, а не снимаем оверрайд: иначе
                // последующий серверный reload без оценки/replied откатил бы карточку к исходному виду
                // (выбор эмодзи / поле ввода контакта).
                result.voteUpgrades.forEach { (id, rated) -> localVoteStates[id] = rated }
                result.contactUpgrades.forEach { (id, state) -> localContactStates[id] = state }
                // canLoadOlderMessages пересчитываем из курсора при КАЖДОЙ пересборке, а не
                // единожды в setReady: setReady гонялся с getMessages хвоста (курсор ещё пуст →
                // флаг замерзал в false, триггер пагинации глох навсегда — «упёрся в верх, а
                // запросов нет»). rebuild гарантированно идёт после setData, курсор уже записан.
                _state.value = current.copy(
                    items = insertGapMarker(
                        applyConsentOverrides(result.items.ifEmpty { emptyList() }),
                        historyGap,
                    ),
                    canLoadOlderMessages =
                        MessagesRepository.getInstance().getCurrentAfter().isNotEmpty(),
                )
            }
        }
    }

    fun showError(kind: ErrorKind) {
        _state.value = ChatScreenState.Error(kind)
    }

    fun setLoading() {
        _state.value = ChatScreenState.Loading
    }

    fun setReady() {
        // Error не затираем: hideLoading() дёргается из finally любых загрузок (в т.ч. упавших
        // офлайн — например, onResume→loadMessages при открытии диалога без сети), и безусловный
        // переход в Content прятал оверлей «нет интернета». Выход из ошибки — только явный
        // hideLoadError() (Error→Loading) или setLoading() по Retry.
        if (_state.value is ChatScreenState.Error) return
        if (_state.value !is ChatScreenState.Content) {
            // Начальное значение не важно (rebuildList тут же пересчитает из курсора), но
            // false избегает мгновенного ложного триггера пагинации на пустом курсоре.
            _state.value = ChatScreenState.Content(canLoadOlderMessages = false)
        }
        triggerRebuild()
    }

    fun setLoadingOlderMessages(isLoading: Boolean, canLoadMore: Boolean = true) {
        val current = _state.value as? ChatScreenState.Content ?: return
        _state.value = current.copy(
            isLoadingOlderMessages = isLoading,
            canLoadOlderMessages = if (isLoading) current.canLoadOlderMessages else canLoadMore,
        )
    }

    fun onEvent(event: ChatEvent) {
        when (event) {
            is ChatEvent.BotOptionSelected -> markBotGroupAnswered(event.messageId, event.option.id)
            is ChatEvent.VoteSelected -> {
                // score == 5 (позитивная оценка) — комментарий не нужен, сразу Loading.
                // score < 5 — показываем поле комментария, Loading выставим при его отправке.
                if (event.score == 5) setVoteLoading(event.messageId)
                else setVotePending(event.messageId)
            }
            is ChatEvent.CommentVoteSent -> setVoteLoading(event.messageId)
            is ChatEvent.ContactFormSubmitted -> setContactSubmitting(event.messageId)
            is ChatEvent.ConsentToggled -> toggleConsent(event.messageId, event.kind)
            is ChatEvent.Retry -> setLoading()
            // Тап по цитате: оригинал уже загружен → сразу скролл+подсветка. Не загружен —
            // прыжок (around-загрузку) делает DialogFragment через презентер.
            is ChatEvent.QuoteTapped -> {
                if (hasLoadedMessage(event.originalId)) requestScrollTo(event.originalId)
            }
            is ChatEvent.ScrolledToMessage -> {
                val current = _state.value as? ChatScreenState.Content ?: return
                if (current.pendingScrollToMessageId == event.messageId) {
                    _state.value = current.copy(pendingScrollToMessageId = null)
                }
            }
            else -> {}
        }
    }

    /** Сообщение (по id) уже есть в собранном списке? Для решения «скроллим или прыгаем». */
    fun hasLoadedMessage(messageId: String): Boolean {
        val current = _state.value as? ChatScreenState.Content ?: return false
        return current.items.any { it is ChatListItem.Message && it.id == messageId }
    }

    /**
     * Скролл к сообщению + временная подсветка его строки (тап по цитате / завершённый прыжок).
     * pending снимает ScrolledToMessage; подсветка гаснет по таймеру (тайминги как в вебе).
     */
    fun requestScrollTo(messageId: String) {
        val current = _state.value as? ChatScreenState.Content ?: return
        _state.value = current.copy(
            pendingScrollToMessageId = messageId,
            highlightedMessageId = messageId,
        )
        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            kotlinx.coroutines.delay(HIGHLIGHT_DURATION_MS)
            val s = _state.value as? ChatScreenState.Content ?: return@launch
            if (s.highlightedMessageId == messageId) {
                _state.value = s.copy(highlightedMessageId = null)
            }
        }
    }

    private fun toggleConsent(messageId: String, kind: ConsentKind) {
        val checked = localConsentChecked.getOrPut(messageId) { mutableSetOf() }
        if (!checked.add(kind)) checked.remove(kind)
        val current = _state.value as? ChatScreenState.Content ?: return
        _state.value = current.copy(items = applyConsentOverrides(current.items))
    }

    // Накатывает отметки чекбоксов согласия из localConsentChecked поверх собранных маппером
    // строк (у которых чекбоксы всегда стартуют неотмеченными). Неявные строки не трогаем.
    private fun applyConsentOverrides(items: List<ChatListItem>): List<ChatListItem> {
        if (localConsentChecked.isEmpty()) return items
        return items.map { item ->
            if (item !is ChatListItem.Message) return@map item
            val content = item.content as? MessageContent.ContactInputContent ?: return@map item
            val consent = content.consent ?: return@map item
            val checked = localConsentChecked[item.id] ?: return@map item
            val newLines = consent.lines.map { line ->
                if (line.withCheckbox) line.copy(checked = line.kind in checked) else line
            }
            item.copy(content = content.copy(consent = consent.copy(lines = newLines)))
        }
    }

    private fun markBotGroupAnswered(messageId: String, selectedOptionId: String) {
        localBotAnswers[messageId] = selectedOptionId
        val current = _state.value as? ChatScreenState.Content ?: return
        val updatedItems = current.items.map { item ->
            if (item is ChatListItem.BotOptionsGroup && item.messageId == messageId)
                item.copy(isAnswered = true, selectedOptionId = selectedOptionId)
            else item
        }
        _state.value = current.copy(items = updatedItems)
    }

    // Резолв файла-вложения из текущего UI-состояния (не из MessagesRepository): модель уже
    // содержит url/size/mime, и lookup по item.id работает даже для бот-блоков (синтетический id).
    fun getFileAttachment(messageId: String, attachmentId: String): UiAttachment.FileAttachment? {
        val content = (_state.value as? ChatScreenState.Content) ?: return null
        val message = content.items
            .filterIsInstance<ChatListItem.Message>()
            .firstOrNull { it.id == messageId } ?: return null
        val files = (message.content as? MessageContent.TextContent)
            ?.attachments?.filterIsInstance<UiAttachment.FileAttachment>() ?: return null
        return files.firstOrNull { it.id == attachmentId }
    }

    private fun setContactSubmitting(messageId: String) {
        localContactStates[messageId] = ContactInputState.Submitting
        val current = _state.value as? ChatScreenState.Content ?: return
        val updatedItems = current.items.map { item ->
            if (item is ChatListItem.Message && item.id == messageId) {
                val content = item.content as? MessageContent.ContactInputContent ?: return@map item
                item.copy(content = content.copy(state = ContactInputState.Submitting))
            } else item
        }
        _state.value = current.copy(items = updatedItems)
    }

    private fun setVotePending(messageId: String) {
        localVoteStates[messageId] = VoteState.Pending
    }

    private fun setVoteLoading(messageId: String) {
        localVoteStates[messageId] = VoteState.Loading
        val current = _state.value as? ChatScreenState.Content ?: return
        val updatedItems = current.items.map { item ->
            if (item is ChatListItem.VoteCard && item.messageId == messageId)
                item.copy(voteState = VoteState.Loading)
            else item
        }
        _state.value = current.copy(items = updatedItems)
    }
}

// Подсветка строки после скролла к цитируемому сообщению: удержание ~как в вебе.
private const val HIGHLIGHT_DURATION_MS = 1600L

/**
 * Вставляет маркер незагруженной середины (разрыв после прыжка к цитате) в собранный список.
 * Список отсортирован по убыванию (reverseLayout): элемент gap.lowerBoundId — самый новый из
 * верхнего (старого) окна, маркер встаёт непосредственно ПЕРЕД ним в массиве (визуально — под
 * ним, между окнами). Сравнение по строковому id, без числовых допущений (optimistic id —
 * секунды, не снежинки). Чистая функция — покрыта тестом.
 */
internal fun insertGapMarker(items: List<ChatListItem>, gap: HistoryGap?): List<ChatListItem> {
    if (gap == null) return items
    val lowerIdStr = gap.lowerBoundId.toString()
    val idx = items.indexOfFirst { it is ChatListItem.Message && it.id == lowerIdStr }
    if (idx < 0) return items
    return items.toMutableList().apply { add(idx, ChatListItem.HistoryGapMarker(gap.lowerBoundId, gap.upperBoundId)) }
}

/**
 * Показывать ли дефолтное приветствие («Приветствие при открытии чата» из настроек аппа).
 *
 * Оно — заглушка ПУСТОГО диалога без бота, поэтому требует всех трёх условий:
 *  • [routingBotResolved] — бэкенд уже ответил, есть ли welcome-бот. Пока не ответил (в т.ч.
 *    когда запрос упал в офлайне и будет повторён), приветствие показывать НЕЛЬЗЯ: при
 *    включённом welcome-боте оно подменяло его дерево кнопок и оставалось насовсем;
 *  • нет реальных сообщений;
 *  • нет шаблона первой ветки бота — иначе приветствие мелькало бы перед ботом.
 */
internal fun shouldShowWelcome(
    routingBotResolved: Boolean,
    hasMessages: Boolean,
    hasStartBrunch: Boolean,
): Boolean = routingBotResolved && !hasMessages && !hasStartBrunch

/** Есть ли в ответе бэкенда шаблон первой ветки бота — то, чем рисуется первая пачка. */
internal fun hasStartBrunchTemplate(data: ChooseRoutingBotData?): Boolean =
    data?.takeIf { it.found == true }?.bot?.startBrunch != null

/**
 * Принимать ли новый ответ chooseRoutingBot вместо уже сохранённого.
 *
 * Ответ приходит НЕ один раз за сессию: `commonSubscribes` вызывается повторно — в частности сразу
 * после того, как пользователь ответил на первый вопрос бота и появился реальный диалог. Для
 * реального диалога бэкенд «стартовать бота» больше не просит, поэтому поздний ответ приходит без
 * шаблона первой ветки. Шаблон при этом — ЕДИНСТВЕННЫЙ источник первой пачки бота (реальными
 * сообщениями она попадает в репозиторий только при перезаходе), так что затирать его нельзя:
 * иначе приветствие бота и его кнопки исчезают из списка прямо в момент ответа. Убрать шаблон —
 * задача serverHasFirstBranch в rebuildList: он снимает его, когда серверные сообщения первой
 * ветки реально пришли.
 *
 * Поэтому: шаблон никогда не «понижается» до его отсутствия; во всём остальном берём свежий ответ.
 * null (узнать не удалось) не заменяет ничего.
 */
internal fun shouldReplaceRoutingBotData(
    current: ChooseRoutingBotData?,
    incoming: ChooseRoutingBotData?,
): Boolean = when {
    incoming == null -> false
    hasStartBrunchTemplate(incoming) -> true
    hasStartBrunchTemplate(current) -> false
    else -> true
}
