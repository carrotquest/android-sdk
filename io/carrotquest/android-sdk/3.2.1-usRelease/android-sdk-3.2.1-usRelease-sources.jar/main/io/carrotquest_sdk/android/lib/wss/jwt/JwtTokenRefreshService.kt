package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.loging.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.util.Date
import java.util.Timer
import java.util.TimerTask

class JwtTokenRefreshService private constructor() {

    companion object {

        private var instance: JwtTokenRefreshService? = null

        fun getInstance(): JwtTokenRefreshService {
            if(instance == null) {
                instance = JwtTokenRefreshService()
            }

            return instance!!
        }
    }

    // var, не val — после stop() Timer отменяется навсегда (JVM), поэтому в start() создаём новый.
    private var refreshTimer = Timer()
    private var isAlreadyStarted = false

    private val scope = sdkScope(SdkDispatchers.io)

    // Замена BehaviorSubject.create() (ветка remove_rx, фаза 5): replay=1 реплеит последний токен.
    // Эмитим сюда после успешного refresh — JwtWssService слушает и переподключает сокеты.
    private val _updateJwtTokenFlow = MutableSharedFlow<String>(replay = 1, extraBufferCapacity = 1)
    val updateJwtTokenFlow: SharedFlow<String> = _updateJwtTokenFlow.asSharedFlow()

    fun start() {
        if (isAlreadyStarted) {
            return
        }
        isAlreadyStarted = true
        // Предыдущий Timer мог быть cancel()-ован через stop() (после deInit).
        // Cancelled Timer нельзя переиспользовать — schedule() бросает IllegalStateException.
        refreshTimer = Timer()

        val delayMilliseconds = getDelayStartTime()
        Log.d("JWT", "delayMilliseconds = $delayMilliseconds")
        refreshTimer.schedule(object : TimerTask() {
            override fun run() {
                // Любое непойманное исключение внутри TimerTask.run() убивает ВЕСЬ Timer
                // (JVM документация). Оборачиваем — иначе после одного сбоя JWT не обновляется
                // никогда, и воскресить Timer можно только через deInit()/setup().
                try {
                    scope.launch {
                        SdkLogger.log(
                            SdkLogLevel.INFO, SdkLogCategory.AUTH, "TokenFlow",
                            "JwtTokenRefreshService: scheduled refresh tick. State: ${tokenStateSummary()}",
                        )
                        val token = refreshJwtToken()
                        if (token != null) {
                            try {
                                val user = CarrotLib.getLibComponents().userRep.user
                                user.token = token
                                CarrotLib.getLibComponents().userRep.saveUser(user)
                            } catch (t: Throwable) {
                                Log.e("JWT", "saveUser after refresh failed: $t")
                            }
                            SdkLogger.log(
                                SdkLogLevel.INFO, SdkLogCategory.AUTH, "TokenFlow",
                                "JwtTokenRefreshService: refresh OK, notifying sockets with new access=${maskToken(token)}",
                            )
                            // Уведомляем подписчиков (JwtWssService) — переподключить сокеты под новый токен.
                            _updateJwtTokenFlow.tryEmit(token)
                        } else {
                            // Фоновый refresh молча вернул null — раньше следа в диагностике не оставалось.
                            SdkLogger.log(
                                SdkLogLevel.WARN, SdkLogCategory.AUTH, "TokenFlow",
                                "JwtTokenRefreshService: refresh returned null — access not updated (refresh dead or network)",
                            )
                        }
                    }
                } catch (t: Throwable) {
                    Log.e("JWT", "TimerTask tick failed: $t")
                    SdkLogger.log(
                        SdkLogLevel.ERROR, SdkLogCategory.AUTH, "TokenFlow",
                        "JwtTokenRefreshService: tick failed", t,
                    )
                }
            }
        }, delayMilliseconds, jwtTokenLiveTime)

    }

    fun stop() {
        refreshTimer.cancel()
        isAlreadyStarted = false
    }

    private fun getDelayStartTime(): Long {
        val nowMilliseconds = Date().time
        val lastUpdateJwtTokenTimeMilliseconds = getLastUpdateJwtTokenTime()

        return if(lastUpdateJwtTokenTimeMilliseconds <= 0 || nowMilliseconds > (lastUpdateJwtTokenTimeMilliseconds + jwtTokenLiveTime)) {
            0L
        } else {
            (lastUpdateJwtTokenTimeMilliseconds + jwtTokenLiveTime) - nowMilliseconds
        }
    }
}