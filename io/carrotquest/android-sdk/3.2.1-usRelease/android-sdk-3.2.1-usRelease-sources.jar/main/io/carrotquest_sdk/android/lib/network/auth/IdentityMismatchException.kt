package io.carrotquest_sdk.android.lib.network.auth

import java.io.IOException

/**
 * Запрос заблокирован барьером идентичности: user_id в пути не принадлежит владельцу auth_token.
 *
 * Наследует [IOException], потому что бросается из интерсептора (OkHttp разрешает только его), но
 * это НЕ сетевая ошибка: сеть жива, отказ клиентский. Отдельный тип нужен, чтобы вызывающий код
 * (в первую очередь UI) не путал его с отсутствием интернета и не показывал «Нет соединения» —
 * раньше классификатор ошибок различал только `HttpException` (бэкенд) и `IOException` (сеть).
 */
internal class IdentityMismatchException(message: String) : IOException(message)
