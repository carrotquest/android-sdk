package io.carrotquest_sdk.android.presentation.chat

sealed class ChatListItem {

    data class DateDivider(val dateLabel: DateLabel) : ChatListItem()

    data class TypingIndicator(
        val name: String?,
        val avatarUrl: String?,
    ) : ChatListItem()

    data class Message(
        val id: String,
        val direction: Direction,
        val sender: Sender?,
        val timestampMs: Long,
        val deliveryStatus: DeliveryStatus?,
        val content: MessageContent,
        // Сообщение порождено ботом (auto_reply/chat_bot/article/блок с actions), а не оператором.
        // Используется автоскроллом: на сообщение бота всегда скроллим к низу.
        val isBot: Boolean = false,
        // Цитата (replied_to): блок с процитированным оригиналом над контентом бабла.
        // На уровне Message, не MessageContent — цитату может нести любой тип контента.
        val replyTo: QuotedMessageUi? = null,
        // На это сообщение можно ответить (гейт свайпа и пункта «Ответить»): тип из белого
        // списка бэкенда, не удалено, есть серверный id. См. MessageMapper.isQuotable.
        val isQuotable: Boolean = false,
    ) : ChatListItem()

    data class BotOptionsGroup(
        val messageId: String,
        val options: List<BotOption>,
        val isAnswered: Boolean,
        val selectedOptionId: String? = null,
    ) : ChatListItem()

    data class VoteCard(
        val messageId: String,
        val voteState: VoteState,
        val questionText: String = "",
    ) : ChatListItem()

    /**
     * Маркер незагруженной середины диалога после прыжка к цитате (CAR-75966): спиннер между
     * around-окном и хвостом. Его появление на экране триггерит дозагрузку страницы середины
     * (с ближайшего к пользователю края). Границы меняются с каждой страницей — перезапускают
     * триггер в MessageList, пока окна не сомкнутся.
     */
    data class HistoryGapMarker(val lowerBoundId: Long, val upperBoundId: Long) : ChatListItem()
}

enum class Direction { INCOMING, OUTGOING }

data class Sender(
    val name: String?,
    val avatarUrl: String?,
)

enum class DeliveryStatus { SENDING, SENT, READ, FAILED }

data class BotOption(
    val id: String,
    val branchId: String?,
    val text: String,
    // Ссылка, зашитая в кнопку бота (если есть): открывается при выборе ветки.
    val link: String? = null,
    // Тип экшена ("button"/"meet" — бот, "quick_reply" — реплика админа из public API).
    // От него зависит, как отправляется выбор: бот-ветка или обычная реплика пользователя.
    val actionType: String? = null,
    // meta_data кнопки быстрого ответа (сырой JSON): уезжает в реплику пользователя.
    val metaData: String? = null,
)

sealed class DateLabel {
    data object Today : DateLabel()
    data object Yesterday : DateLabel()
    data class Exact(val formatted: String) : DateLabel()
}

sealed class VoteState {
    data object Pending : VoteState()
    data object Loading : VoteState()
    data class Rated(val score: Int) : VoteState()
}

/**
 * UI-модель цитаты (replied_to) внутри бабла. Сниппет — уже очищенный от HTML однострочный
 * текст (partial_text приоритетнее body); при isRemoved вместо сниппета рисуется плашка
 * «Сообщение удалено»; при пустом сниппете с вложениями — иконка+лейбл по типу вложения
 * (по Figma миниатюр в цитате нет).
 */
data class QuotedMessageUi(
    val originalId: String,
    val senderName: String?,
    val snippet: String?,
    val isRemoved: Boolean = false,
    val attachment: QuoteAttachment? = null,
)

sealed class QuoteAttachment {
    data class Images(val count: Int) : QuoteAttachment()
    data object Voice : QuoteAttachment()
    /** Одиночный файл — показывается именем (как в превью списка диалогов). */
    data class File(val name: String?) : QuoteAttachment()
    /** Несколько файлов или смесь файлы+картинки — «N файлов» (семантика превью списка). */
    data class Files(val count: Int) : QuoteAttachment()
}
