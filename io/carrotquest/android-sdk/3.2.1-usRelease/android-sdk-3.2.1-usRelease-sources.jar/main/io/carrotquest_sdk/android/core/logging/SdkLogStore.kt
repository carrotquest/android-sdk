package io.carrotquest_sdk.android.core.logging

import android.content.Context
import io.carrotquest_sdk.android.core.SdkGlobalHandlers
import java.io.File
import java.util.concurrent.Executors

/**
 * Кольцевой буфер последних логов SDK (уровня INFO и важнее) с персистентностью в файл — переживает
 * перезапуск/краш приложения. Снапшот отдаётся из памяти (быстро, потокобезопасно), запись на диск —
 * в фоне на одном потоке. Файл лежит в приватном filesDir приложения; logcat это не задевает.
 */
internal object SdkLogStore {

    private const val CAPACITY = 100              // сколько строк держим в памяти и отдаём
    private const val FILE_TRIM_THRESHOLD = 300   // выше этого числа строк файл подрезаем до CAPACITY
    private const val FILE_NAME = "carrot_sdk_log.txt"

    private val lock = Any()
    private val buffer = ArrayDeque<String>()     // доступ под lock

    // uncaughtExceptionHandler: поток наш, поэтому сбой в нём глушим с логом, а не роняем хост
    // (глобальный default-handler для этого не годится — см. SdkGlobalHandlers).
    private val io = Executors.newSingleThreadExecutor { r ->
        Thread(r, "cq-logstore").apply {
            isDaemon = true
            uncaughtExceptionHandler = SdkGlobalHandlers.sdkThreadUncaughtHandler
        }
    }

    @Volatile
    private var file: File? = null
    private var appendsSinceTrim = 0              // только io-поток

    fun attach(context: Context) = attachDir(context.filesDir)

    internal fun attachDir(dir: File) {
        io.execute {
            val f = File(dir, FILE_NAME)
            val prev = runCatching { if (f.exists()) f.readLines() else emptyList() }.getOrDefault(emptyList())
            synchronized(lock) {
                // Хвост прошлой сессии (из файла) + накопленное до attach (из памяти) → последние CAPACITY.
                val merged = (prev + buffer).takeLast(CAPACITY)
                buffer.clear()
                buffer.addAll(merged)
                runCatching {
                    f.writeText(if (merged.isEmpty()) "" else merged.joinToString("\n", postfix = "\n"))
                }
            }
            file = f
            appendsSinceTrim = 0
        }
    }

    fun append(rawLine: String) {
        val line = rawLine.replace('\n', ' ')
        synchronized(lock) {
            buffer.addLast(line)
            while (buffer.size > CAPACITY) buffer.removeFirst()
        }
        val f = file ?: return
        io.execute {
            runCatching {
                f.appendText(line + "\n")
                if (++appendsSinceTrim >= CAPACITY) {
                    appendsSinceTrim = 0
                    val lines = f.readLines()
                    if (lines.size > FILE_TRIM_THRESHOLD) {
                        f.writeText(lines.takeLast(CAPACITY).joinToString("\n", postfix = "\n"))
                    }
                }
            }
        }
    }

    /** Последние строки (до CAPACITY) — для снапшота диагностики. */
    fun snapshot(): List<String> = synchronized(lock) { buffer.toList() }

    internal fun resetForTest() {
        synchronized(lock) { buffer.clear() }
        file = null
        appendsSinceTrim = 0
    }

    /** Блокирует, пока фоновые файловые операции не завершатся (для тестов). */
    internal fun flushForTest() {
        io.submit { }.get()
    }
}
