package io.carrotquest_sdk.android.lib.full_image_view.view

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.google.android.material.snackbar.Snackbar
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback
import io.carrotquest_sdk.android.lib.view.full_image_view.presenter.FullImageViewPresenter
import java.io.File

class FullImageViewDialogFragment : DialogFragment() {

    private val presenter = FullImageViewPresenter()

    private var controlsVisible by mutableStateOf(true)
    private val pageDrawables = mutableMapOf<Int, Drawable>()
    private var currentPage = 0

    companion object {
        private const val URL_IMAGE = "url_image_for_full_view"
        private const val FILE_PATH = "file_path_for_full_view"
        private const val BITMAP = "bitmap_for_full_view"
        private const val URLS = "urls_for_full_view"
        private const val INITIAL_INDEX = "initial_index_for_full_view"

        fun newInstance(url: String) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also { it.putString(URL_IMAGE, url) }
        }

        fun newInstance(file: File) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also { it.putString(FILE_PATH, file.path) }
        }

        fun newInstance(bitmap: Bitmap) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also { it.putParcelable(BITMAP, bitmap) }
        }

        fun newInstance(urls: List<String>, initialIndex: Int = 0) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also {
                it.putStringArrayList(URLS, ArrayList(urls))
                it.putInt(INITIAL_INDEX, initialIndex)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val images = resolveImageSources()
        currentPage = arguments?.getInt(INITIAL_INDEX, 0) ?: 0

        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                FullImageViewScreen(
                    images = images,
                    initialIndex = currentPage,
                    controlsVisible = controlsVisible,
                    onBack = { dismiss() },
                    onDismiss = { dismiss() },
                    onDragOffsetChanged = { offset -> updateWindowAlpha(offset) },
                    onImageTap = { controlsVisible = !controlsVisible },
                    onShare = { handleShare() },
                    onSave = { handleSave() },
                    onImageLoaded = { pageIndex, drawable ->
                        pageDrawables[pageIndex] = drawable
                        if (pageIndex == currentPage) {
                            presenter.onLoadResource(drawable, requireContext())
                        }
                    },
                    onImageLoadFailed = { /* Screen shows error overlay */ },
                    onPageChanged = { index ->
                        currentPage = index
                        pageDrawables[index]?.let { presenter.onLoadResource(it, requireContext()) }
                    },
                )
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewLifecycleOwner.lifecycleScope.launch {
            snapshotFlow { controlsVisible }.collect { visible ->
                val window = dialog?.window ?: return@collect
                val controller = WindowInsetsControllerCompat(window, window.decorView)
                if (visible) {
                    controller.show(WindowInsetsCompat.Type.statusBars())
                } else {
                    controller.systemBarsBehavior =
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.statusBars())
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.let { window ->
            window.setBackgroundDrawableResource(android.R.color.transparent)
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.setWindowAnimations(R.style.DialogAnimationFade)
            window.attributes = window.attributes.also { it.alpha = 1f }
            WindowInsetsControllerCompat(window, window.decorView)
                .show(WindowInsetsCompat.Type.statusBars())
        }
    }

    private fun updateWindowAlpha(offset: Float) {
        dialog?.window?.let { window ->
            window.attributes = window.attributes.also {
                it.alpha = (1f - offset / 1200f).coerceIn(0f, 1f)
            }
        }
    }

    private fun resolveImageSources(): List<ImageSource> {
        val args = arguments ?: return listOf(ImageSource.FromUrl(""))
        return when {
            args.getStringArrayList(URLS) != null ->
                args.getStringArrayList(URLS)!!.map { ImageSource.FromUrl(it) }
            args.getString(URL_IMAGE) != null ->
                listOf(ImageSource.FromUrl(args.getString(URL_IMAGE)!!))
            args.getString(FILE_PATH) != null ->
                listOf(ImageSource.FromFile(File(args.getString(FILE_PATH)!!)))
            @Suppress("DEPRECATION")
            args.getParcelable<Bitmap>(BITMAP) != null ->
                @Suppress("DEPRECATION")
                listOf(ImageSource.FromBitmap(args.getParcelable(BITMAP)!!))
            else -> listOf(ImageSource.FromUrl(""))
        }
    }

    private fun handleShare() {
        val intent = presenter.createShareIntent(requireContext()) ?: return
        startActivity(Intent.createChooser(intent, getString(R.string.cq_lib_share_intent_title)))
    }

    // Запрос WRITE_EXTERNAL_STORAGE (pre-T); раньше RxPermission, теперь AndroidX.
    // saveImage вызываем независимо от результата — как в оригинале (subscribe { _ -> save }).
    private val savePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { saveImageInternal() }

    private fun handleSave() {
        // На Android 13+ WRITE_EXTERNAL_STORAGE не действует (scoped storage) — сохраняем напрямую.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            savePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            saveImageInternal()
        }
    }

    private fun saveImageInternal() {
        presenter.saveImage(
            requireActivity().contentResolver,
            object : SaveImageCallback {
                override fun done() {
                    view?.let { Snackbar.make(it, getString(R.string.cq_lib_save_success), Snackbar.LENGTH_LONG).show() }
                }
                override fun fail() {
                    view?.let { Snackbar.make(it, getString(R.string.cq_lib_something_wrong), Snackbar.LENGTH_LONG).show() }
                }
            }
        )
    }
}