package io.carrotquest_sdk.android.presentation.chat

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import android.view.HapticFeedbackConstants
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentKind
import io.carrotquest_sdk.android.presentation.chat.consent.ConsentBlock
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view.AvatarImage
import io.carrotquest_sdk.android.presentation.mvp.utils.toAnnotatedHtml
import io.carrotquest_sdk.android.presentation.mvp.utils.withContactLinks
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import java.util.Date
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val CORNER_LARGE = 16.dp
private val CORNER_SMALL = 6.dp
internal val AVATAR_SIZE = 40.dp
// Зазор между аватаром и баблом сообщения.
internal val AVATAR_GAP = 10.dp
// Вертикальный паддинг строки входящего сообщения (см. Row ниже) — нужен оверлею аватара,
// чтобы попасть в низ бабла пиксель-в-пиксель.
internal val MESSAGE_ROW_VPADDING = 8.dp

// Свайп влево «ответить» (CAR-75966): порог срабатывания, максимальный увод строки и круг иконки.
private val SWIPE_REPLY_THRESHOLD = 64.dp
private val SWIPE_REPLY_MAX_DRAG = 88.dp
private val SWIPE_REPLY_CIRCLE = 40.dp

/**
 * Клик по контенту сообщения БЕЗ ripple-индикации: касание сообщения не должно менять его
 * внешний вид (решение дизайна). Для настоящих кнопок (send, кнопки бота) ripple остаётся.
 */
@Composable
internal fun Modifier.noRippleClickable(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        enabled = enabled,
        onClick = onClick,
    )

@SuppressLint("UnusedBoxWithConstraintsScope")
@Composable
fun MessageBubble(
    item: ChatListItem.Message,
    accentColor: Color,
    isDark: Boolean,
    onEvent: (ChatEvent) -> Unit = {},
    hasPrevIncoming: Boolean = false,
    hasNextIncoming: Boolean = false,
    // Текущее смещение строки от свайпа «ответить» (px): MessageList двигает по нему плавающий
    // аватар, чтобы тот не «отрывался» от бабла.
    onSwipeOffset: (String, Int) -> Unit = { _, _ -> },
    // Временная подсветка строки после скролла к цитируемому сообщению.
    isHighlighted: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val isOutgoing = item.direction == Direction.OUTGOING

    // Свайп влево «ответить» (только quotable): строка уводится пальцем (offset ≤ 0), справа
    // проявляется круг с reply-стрелкой; на пороге — haptic, на отпускании — ReplyRequested и
    // пружинный возврат. Горизонтальная ось не конфликтует с вертикальным скроллом LazyColumn.
    //
    // Смещение — синхронный mutableFloatStateOf, НЕ Animatable.snapTo в launch: отставшая
    // snapTo-корутина перетирала запущенную пружину возврата (MutatorMutex отменял animateTo),
    // и строка зависала в крайнем левом положении.
    var dragOffsetPx by remember(item.id) { mutableFloatStateOf(0f) }
    val dragScope = rememberCoroutineScope()
    var springBackJob by remember(item.id) { mutableStateOf<Job?>(null) }
    val hapticView = LocalView.current
    val density = LocalDensity.current
    val thresholdPx = with(density) { SWIPE_REPLY_THRESHOLD.toPx() }
    val maxDragPx = with(density) { SWIPE_REPLY_MAX_DRAG.toPx() }
    var thresholdCrossed by remember(item.id) { mutableStateOf(false) }
    val swipeModifier = if (item.isQuotable) {
        Modifier
            .offset { IntOffset(dragOffsetPx.roundToInt(), 0) }
            .draggable(
                orientation = Orientation.Horizontal,
                state = rememberDraggableState { delta ->
                    // Повторный захват пальцем во время возврата — пружину отменяем.
                    springBackJob?.cancel()
                    springBackJob = null
                    // Только влево; после порога тянем с «резиновым» сопротивлением (в треть силы).
                    val current = dragOffsetPx
                    val resisted = if (current <= -thresholdPx && delta < 0) delta / 3f else delta
                    val target = (current + resisted).coerceIn(-maxDragPx, 0f)
                    dragOffsetPx = target
                    onSwipeOffset(item.id, target.roundToInt())
                    val crossed = -target >= thresholdPx
                    if (crossed && !thresholdCrossed) {
                        // Виброотклик как в Telegram (ChatActivity.processTouchEvent): короткий
                        // KEYBOARD_TAP (не LONG_PRESS — тот тяжелее) с FLAG_IGNORE_GLOBAL_SETTING,
                        // чтобы «тик» ощущался и при выключенной системной haptic-настройке.
                        // Compose LocalHapticFeedback KEYBOARD_TAP не умеет — зовём View напрямую;
                        // try/catch как в оригинале (на части прошивок вызов бросает).
                        runCatching {
                            @Suppress("DEPRECATION")
                            hapticView.performHapticFeedback(
                                HapticFeedbackConstants.KEYBOARD_TAP,
                                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
                            )
                        }
                    }
                    thresholdCrossed = crossed
                },
                onDragStopped = {
                    if (thresholdCrossed) onEvent(ChatEvent.ReplyRequested(item.id))
                    thresholdCrossed = false
                    // Пружина в компонентном scope (переживает завершение жеста); аватар едет
                    // назад вместе со строкой — репортим смещение каждый кадр.
                    springBackJob = dragScope.launch {
                        animate(dragOffsetPx, 0f, animationSpec = spring()) { value, _ ->
                            dragOffsetPx = value
                            onSwipeOffset(item.id, value.roundToInt())
                        }
                        dragOffsetPx = 0f
                        onSwipeOffset(item.id, 0)
                    }
                },
            )
    } else {
        Modifier
    }

    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val maxBubbleWidth = maxWidth * 0.75f

        // Круг с reply-стрелкой за строкой: проявляется по прогрессу свайпа (alpha + scale).
        if (item.isQuotable && dragOffsetPx < -1f) {
            val progress = (-dragOffsetPx / thresholdPx).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
                    .size(SWIPE_REPLY_CIRCLE)
                    .graphicsLayer {
                        alpha = progress
                        scaleX = 0.6f + 0.4f * progress
                        scaleY = 0.6f + 0.4f * progress
                    }
                    .background(SdkColors.background(isDark), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.cq_ic_reply),
                    contentDescription = null,
                    tint = SdkColors.title(isDark),
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        // Подсветка перехода к цитируемому сообщению: фон строки accent 14%, быстрое появление,
        // медленное затухание (тайминги как в вебе). Прозрачный — в обычном состоянии не рисуется.
        val highlightColor by animateColorAsState(
            targetValue = if (isHighlighted) accentColor.copy(alpha = 0.14f) else Color.Transparent,
            animationSpec = tween(durationMillis = if (isHighlighted) 150 else 1200),
            label = "quoteJumpHighlight",
        )

        // Шторка действий доступна и для сообщений без текста (файлы/картинки/статьи), если на
        // них можно ответить; область тапа — ВСЯ строка (тап сбоку от картинки тоже открывает
        // шторку), визуально ничего не меняется (noRipple). Вложенные кликабельные элементы
        // (картинки/файлы/ссылки/цитата/кнопка статьи) перехватывают свои тапы как раньше.
        val textContent = item.content as? MessageContent.TextContent
        val canShowActions = textContent?.body?.isNotBlank() == true || item.isQuotable

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(swipeModifier)
                .background(highlightColor)
                .then(
                    if (canShowActions) Modifier.noRippleClickable { onEvent(ChatEvent.MessageTapped(item.id)) }
                    else Modifier
                )
                // Горизонтальный отступ строки сообщения от края экрана — 16dp по макету.
                .padding(horizontal = 16.dp, vertical = MESSAGE_ROW_VPADDING),
            horizontalArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Bottom,
        ) {
            if (!isOutgoing) {
                // Сам аватар рисуется плавающим оверлеем поверх списка (см. MessageList),
                // здесь лишь резервируем под него место, чтобы баблы не съезжали влево.
                Spacer(modifier = Modifier.width(AVATAR_SIZE + AVATAR_GAP))
            }

            // Сообщение в процессе отправки рисуем чуть прозрачным (мета/прогресс — нет).
            val isSending = item.deliveryStatus == DeliveryStatus.SENDING

            if (isOutgoing) {
                BubbleMeta(item, isDark, accentColor)
                Spacer(modifier = Modifier.width(10.dp))
            }

            Column(
                modifier = Modifier
                    // Для входящих: weight(1f, fill=false) — Row сначала измеряет BubbleMeta,
                    // остаток отдаёт Column. Для исходящих weight не нужен (мета слева, Arrangement.End).
                    .then(if (!isOutgoing) Modifier.weight(1f, fill = false) else Modifier)
                    .then(if (isSending) Modifier.alpha(0.6f) else Modifier)
                    .widthIn(max = maxBubbleWidth),
                horizontalAlignment = if (isOutgoing) Alignment.End else Alignment.Start,
            ) {
                BubbleBody(item, accentColor, isDark, onEvent, hasPrevIncoming, hasNextIncoming)
            }

            if (!isOutgoing) {
                Spacer(modifier = Modifier.width(10.dp))
                BubbleMeta(item, isDark, accentColor)
            }
        }
    }
}

@Composable
private fun BubbleBody(
    item: ChatListItem.Message,
    accentColor: Color,
    isDark: Boolean,
    onEvent: (ChatEvent) -> Unit,
    hasPrevIncoming: Boolean,
    hasNextIncoming: Boolean,
) {
    val isOutgoing = item.direction == Direction.OUTGOING
    val isArticle = item.content is MessageContent.ArticleLinkContent
    val bubbleBg = when {
        isOutgoing -> accentColor
        isArticle  -> SdkColors.articleCard(isDark)
        else       -> SdkColors.background(isDark)
    }
    val textColor = if (isOutgoing) SdkColors.onAccent(accentColor) else SdkColors.title(isDark)
    // Ссылки/контакты: во входящих — акцентом; в исходящих фон = accent, поэтому красить им
    // нельзя (сливается) — берём цвет текста, чтобы email/телефоны были видны (просто не выделены).
    val linkColor = if (isOutgoing) textColor else accentColor

    val shape = if (isOutgoing) {
        RoundedCornerShape(CORNER_LARGE)
    } else {
        RoundedCornerShape(
            topStart    = if (hasPrevIncoming) CORNER_SMALL else CORNER_LARGE,
            topEnd      = CORNER_LARGE,
            bottomEnd   = CORNER_LARGE,
            bottomStart = if (hasNextIncoming) CORNER_SMALL else CORNER_LARGE,
        )
    }

    // Клик по ссылке внутри сообщения → событие наверх (там trackClick + открытие).
    val onLinkClick: (String) -> Unit = { url -> onEvent(ChatEvent.LinkTapped(url)) }

    val textContent = item.content as? MessageContent.TextContent
    val attachments = textContent?.attachments ?: emptyList()
    val images = attachments.filterIsInstance<UiAttachment.ImageAttachment>()
    // Файлы и голосовые рисуются в одном столбце (с сохранением исходного порядка):
    // голос — это тоже вложение, просто с другим визуалом (плеер вместо карточки файла).
    val docs = attachments.filterNot { it is UiAttachment.ImageAttachment }
    val hasAttachments = images.isNotEmpty() || docs.isNotEmpty()

    // Тап «действия над сообщением» живёт на ВСЕЙ строке (см. MessageBubble) — здесь клика нет,
    // иначе бабл перехватывал бы его и зона сбоку от картинки не работала.
    Box(
        modifier = Modifier
            .background(bubbleBg, shape)
            .clip(shape)
            .then(if (hasAttachments || isArticle) Modifier else Modifier.padding(horizontal = 14.dp, vertical = 8.dp)),
    ) {
        // width(IntrinsicSize.Max) — для бабла с цитатой: ширина колонки = самый широкий ребёнок
        // (текст ответа, цитата, одиночная картинка, файловые карточки), а fillMaxWidth цитаты
        // растягивает её до этой ширины, НЕ раздувая бабл до максимума (короткая цитата+короткий
        // контент = узкий бабл). НЕ интринсик-дружелюбны только: гриды 2+ картинок (weight-
        // раскладка сама занимает ширину) и голосовые (waveform с weight, интринсик 0 —
        // схлопнулись бы) — у них ширину по-прежнему задаёт контент.
        val intrinsicFriendly = images.size <= 1 && docs.none { it is UiAttachment.VoiceAttachment }
        Column(
            modifier = if (item.replyTo != null && !isArticle && intrinsicFriendly)
                Modifier.width(IntrinsicSize.Max) else Modifier,
        ) {
        val quote = item.replyTo
        if (quote != null) {
            QuoteBlock(
                quote = quote,
                textColor = textColor,
                bubbleColor = bubbleBg,
                onClick = { onEvent(ChatEvent.QuoteTapped(quote.originalId)) },
                // Бокс с вложениями/статьёй не имеет собственного паддинга (дети инсетят сами) —
                // цитате нужен свой; у текстового бокса паддинг уже есть, добавляем только зазор.
                modifier = if (hasAttachments || isArticle)
                    Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp)
                else
                    Modifier.padding(bottom = 6.dp),
            )
        }
        when (val content = item.content) {
            is MessageContent.TextContent -> {
                if (!hasAttachments) {
                    BubbleText(body = content.body, textColor = textColor, linkColor = linkColor, onLinkClick = onLinkClick)
                } else {
                    Column {
                        if (content.body.isNotBlank()) {
                            BubbleText(
                                body = content.body,
                                textColor = textColor,
                                linkColor = linkColor,
                                onLinkClick = onLinkClick,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            )
                        }
                        if (images.isNotEmpty()) {
                            MessageImages(
                                images = images,
                                modifier = Modifier.padding(
                                    start = 14.dp,
                                    end = 14.dp,
                                    top = if (content.body.isNotBlank()) 2.dp else 14.dp,
                                    bottom = if (docs.isNotEmpty()) 0.dp else 14.dp,
                                ),
                                onImageTapped = { url ->
                                    onEvent(ChatEvent.ImageTapped(
                                        urls = images.map { it.url },
                                        initialIndex = images.indexOfFirst { it.url == url }.coerceAtLeast(0),
                                    ))
                                },
                            )
                        }
                        if (docs.isNotEmpty()) {
                            // Голосовое рисуется без подложки и инсетит контент собственным паддингом
                            // от края бабла (по макету 10/16/10/10). Поэтому общий 12dp паддинг столбца
                            // для voice-only НЕ применяем — иначе отступы складываются. Файловым
                            // карточкам (с подложкой) инсет 12dp нужен.
                            val voiceOnly = docs.all { it is UiAttachment.VoiceAttachment }
                            val docsPadding = if (voiceOnly) PaddingValues(0.dp) else PaddingValues(
                                start = 12.dp,
                                end = 12.dp,
                                top = when {
                                    images.isNotEmpty()          -> 10.dp
                                    content.body.isNotBlank()    -> 2.dp
                                    else                         -> 12.dp
                                },
                                bottom = 12.dp,
                            )
                            Column(
                                modifier = Modifier.padding(docsPadding),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                docs.forEach { att ->
                                    when (att) {
                                        is UiAttachment.FileAttachment -> FileCard(
                                            file = att,
                                            isDark = isDark,
                                            accentColor = accentColor,
                                            isOutgoing = isOutgoing,
                                            // Ширину задаёт картинка — тогда карточка тянется под неё;
                                            // файл без картинки обнимает контент (бабл не раздувается).
                                            fillWidth = images.isNotEmpty(),
                                            onTap = { onEvent(ChatEvent.FileTapped(item.id, att.id)) },
                                        )
                                        is UiAttachment.VoiceAttachment -> VoiceCard(
                                            voice = att,
                                            accentColor = accentColor,
                                            isOutgoing = isOutgoing,
                                        )
                                        is UiAttachment.ImageAttachment -> {} // картинки рисуются выше
                                    }
                                }
                            }
                        }
                    }
                }
            }
            is MessageContent.ContactInputContent -> {
                ContactInputBubble(
                    content = content,
                    textColor = textColor,
                    accentColor = accentColor,
                    isDark = isDark,
                    onLinkClick = onLinkClick,
                    onConsentToggle = { kind ->
                        onEvent(ChatEvent.ConsentToggled(messageId = item.id, kind = kind))
                    },
                    onSubmit = { value ->
                        onEvent(ChatEvent.ContactFormSubmitted(
                            messageId = item.id,
                            value = value,
                            inputType = content.inputType,
                        ))
                    },
                )
            }
            is MessageContent.ArticleLinkContent -> {
                ArticleCard(content = content, accentColor = accentColor, isDark = isDark, onLinkClick = onLinkClick)
            }
            is MessageContent.UnknownContent -> {
                // Неподдерживаемый тип рисуем как обычное текстовое сообщение, но КУРСИВОМ.
                // textColor уже адаптируется к направлению (исходящие → onAccent, видно на акценте).
                Text(
                    text = stringResource(R.string.chat_unsupported_message),
                    color = textColor,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    fontStyle = FontStyle.Italic,
                )
            }
            is MessageContent.RemovedContent -> {
                // Плашка «Сообщение удалено» бледно-серым (тот же тон, что у времени сообщения);
                // на акцентном фоне исходящего серый не читается — onAccent с той же бледностью.
                Text(
                    text = stringResource(R.string.cq_quote_removed_message),
                    color = if (isOutgoing) textColor.copy(alpha = 0.7f) else SdkColors.messageTime,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                )
            }
        }
        }
    }
}

/**
 * Блок цитаты (replied_to) над контентом бабла. Визуал по Figma «Цитирование сообщений»:
 * radius 5, полоса 2dp слева, имя 12sp Medium + сниппет 12sp в одну строку с эллипсисом;
 * удалённый оригинал — плашка «Сообщение удалено» приглушённым цветом; вложения без текста —
 * иконка 13dp + лейбл (миниатюр нет). Тап — скролл к оригиналу (Э6).
 */
@Composable
private fun QuoteBlock(
    quote: QuotedMessageUi,
    textColor: Color,
    bubbleColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(5.dp))
            .background(SdkColors.quoteBg(bubbleColor))
            .noRippleClickable(onClick = onClick)
            .height(IntrinsicSize.Min),
    ) {
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(SdkColors.quoteBar(bubbleColor)),
        )
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            if (!quote.senderName.isNullOrBlank()) {
                Text(
                    text = quote.senderName,
                    color = textColor,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            when {
                quote.isRemoved -> QuoteSnippetText(
                    text = stringResource(R.string.cq_quote_removed_message),
                    color = textColor.copy(alpha = 0.7f),
                )
                quote.snippet != null -> QuoteSnippetText(text = quote.snippet, color = textColor)
                quote.attachment != null -> QuoteAttachmentLabel(quote.attachment, textColor)
                else -> {} // пустая цитата — рисуем только имя
            }
        }
    }
}

@Composable
private fun QuoteSnippetText(text: String, color: Color) {
    Text(
        text = text,
        color = color,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
private fun QuoteAttachmentLabel(attachment: QuoteAttachment, textColor: Color) {
    val (iconRes, label) = when (attachment) {
        is QuoteAttachment.Images -> R.drawable.ic_cq_photo to
            pluralStringResource(R.plurals.cq_quote_images, attachment.count, attachment.count)
        is QuoteAttachment.Voice -> R.drawable.ic_cq_play to stringResource(R.string.cq_quote_voice)
        is QuoteAttachment.File -> R.drawable.ic_cq_attach_file to
            (attachment.name?.takeIf { it.isNotBlank() } ?: stringResource(R.string.cq_quote_file))
        is QuoteAttachment.Files -> R.drawable.ic_cq_attach_file to
            pluralStringResource(R.plurals.cq_quote_files, attachment.count, attachment.count)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(13.dp),
        )
        QuoteSnippetText(text = label, color = textColor)
    }
}

@Composable
private fun BubbleText(
    body: String,
    textColor: Color,
    linkColor: Color,
    onLinkClick: (String) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val annotated = remember(body, linkColor) {
        body.toAnnotatedHtml(linkColor = linkColor, onLinkClick = onLinkClick)
            .withContactLinks(linkColor, onLinkClick)
    }
    Text(
        text = annotated,
        color = textColor,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        modifier = modifier,
    )
}

@Composable
private fun BubbleMeta(item: ChatListItem.Message, isDark: Boolean, accentColor: Color) {
    val context = LocalContext.current
    val isOutgoing = item.direction == Direction.OUTGOING
    Row(verticalAlignment = Alignment.CenterVertically) {
        when {
            // В процессе отправки — круглый прогресс (акцент в светлой теме / белый в тёмной),
            // вместо времени.
            isOutgoing && item.deliveryStatus == DeliveryStatus.SENDING -> {
                CircularProgressIndicator(
                    modifier = Modifier.size(12.dp),
                    color = if (isDark) Color.White else accentColor,
                    strokeWidth = 1.5.dp,
                )
            }
            // Ошибка отправки — красная иконка вместо времени.
            isOutgoing && item.deliveryStatus == DeliveryStatus.FAILED -> {
                Icon(
                    painter = painterResource(R.drawable.cq_ic_error),
                    contentDescription = null,
                    tint = SdkColors.unreadBadge,
                    modifier = Modifier.size(13.dp),
                )
            }
            // Доставлено / прочитано / входящее — время отправки.
            else -> {
                Text(
                    text = formatTime(item.timestampMs, context),
                    color = SdkColors.messageTime,
                    fontSize = 11.sp,
                )
            }
        }
    }
}

@Composable
private fun ContactInputBubble(
    content: MessageContent.ContactInputContent,
    textColor: Color,
    accentColor: Color,
    isDark: Boolean,
    onLinkClick: (String) -> Unit = {},
    onConsentToggle: (ConsentKind) -> Unit = {},
    onSubmit: (String) -> Unit,
) {
    Column {
        if (content.body.isNotBlank()) {
            Text(
                text = content.body.toAnnotatedHtml(linkColor = accentColor, onLinkClick = onLinkClick),
                color = textColor,
                fontSize = 15.sp,
                lineHeight = 20.sp,
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        when (content.state) {
            is ContactInputState.Submitted  -> ContactThanksPill(isDark)
            is ContactInputState.Submitting -> ContactInputField(
                inputType = content.inputType,
                placeholder = content.placeholder,
                accentColor = accentColor,
                isDark = isDark,
                isSubmitting = true,
                onSubmit = {},
            )
            is ContactInputState.Idle       -> {
                val consent = content.consent
                if (consent != null && consent.isVisible) {
                    ConsentBlock(
                        state = consent,
                        accentColor = accentColor,
                        isDark = isDark,
                        onToggle = onConsentToggle,
                        onLinkClick = onLinkClick,
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
                ContactInputField(
                    inputType = content.inputType,
                    placeholder = content.placeholder,
                    accentColor = accentColor,
                    isDark = isDark,
                    isSubmitting = false,
                    // Кнопку отправки гейтим согласием: пока обязательные чекбоксы не отмечены — нельзя.
                    consentSatisfied = consent?.allRequiredChecked ?: true,
                    onSubmit = onSubmit,
                )
            }
        }
    }
}

@Composable
private fun ContactThanksPill(isDark: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(SdkColors.pageBackground(isDark), RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = stringResource(R.string.contact_input_thanks),
            color = SdkColors.secondaryText(isDark),
            fontSize = 14.sp,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun ContactInputField(
    inputType: ContactInputType,
    placeholder: String?,
    accentColor: Color,
    isDark: Boolean,
    isSubmitting: Boolean = false,
    consentSatisfied: Boolean = true,
    onSubmit: (String) -> Unit,
) {
    var value by remember { mutableStateOf("") }
    var isFocused by remember { mutableStateOf(false) }
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val imeVisible = WindowInsets.isImeVisible

    LaunchedEffect(imeVisible) {
        if (imeVisible && isFocused) bringIntoViewRequester.bringIntoView()
    }

    val keyboardType = when (inputType) {
        ContactInputType.EMAIL -> KeyboardType.Email
        ContactInputType.PHONE -> KeyboardType.Phone
        ContactInputType.NAME, ContactInputType.TEXT -> KeyboardType.Text
    }
    val capitalization = when (inputType) {
        ContactInputType.NAME -> KeyboardCapitalization.Words
        ContactInputType.TEXT -> KeyboardCapitalization.Sentences
        else -> KeyboardCapitalization.None
    }
    val defaultHint = when (inputType) {
        ContactInputType.EMAIL -> stringResource(R.string.contact_hint_email)
        ContactInputType.PHONE -> stringResource(R.string.contact_hint_phone)
        ContactInputType.NAME  -> stringResource(R.string.contact_hint_name)
        ContactInputType.TEXT  -> stringResource(R.string.contact_hint_text)
    }
    val canSend = computeSendEnabled(value, inputType, allowed = !isSubmitting) && consentSatisfied

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(SdkColors.contactInputBg(isDark), RoundedCornerShape(20.dp))
            .border(1.dp, SdkColors.contactInputBorder(isDark), RoundedCornerShape(20.dp))
            .padding(start = 15.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        BasicTextField(
            value = value,
            onValueChange = { value = it },
            enabled = !isSubmitting,
            modifier = Modifier
                .weight(1f)
                .bringIntoViewRequester(bringIntoViewRequester)
                .onFocusChanged { isFocused = it.isFocused },
            textStyle = LocalTextStyle.current.copy(
                color = SdkColors.title(isDark),
                fontSize = 14.sp,
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                capitalization = capitalization,
                imeAction = ImeAction.Send,
            ),
            keyboardActions = KeyboardActions(onSend = {
                if (canSend) { onSubmit(value); value = "" }
            }),
            singleLine = true,
            decorationBox = { innerTextField ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text(
                            text = placeholder ?: defaultHint,
                            color = SdkColors.sectionLabel,
                            fontSize = 14.sp,
                        )
                    }
                    innerTextField()
                }
            },
        )
        Box(
            modifier = Modifier
                .size(30.dp)
                .alpha(if (canSend) 1f else 0.3f)
                .clip(CircleShape)
                .background(accentColor)
                .clickable(enabled = canSend) { onSubmit(value); value = "" },
            contentAlignment = Alignment.Center,
        ) {
            if (isSubmitting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = SdkColors.onAccent(accentColor),
                    strokeWidth = 2.dp,
                )
            } else {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = SdkColors.onAccent(accentColor),
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}


@Composable
private fun ArticleCard(
    content: MessageContent.ArticleLinkContent,
    accentColor: Color,
    isDark: Boolean,
    onLinkClick: (String) -> Unit = {},
) {
    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)) {
        if (content.name.isNotBlank()) {
            Text(
                text = content.name,
                color = SdkColors.title(isDark),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 20.sp,
            )
        }
        if (!content.shortDescription.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = content.shortDescription,
                color = SdkColors.secondaryText(isDark),
                fontSize = 13.sp,
                lineHeight = 18.sp,
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = { if (content.url.isNotBlank()) onLinkClick(content.url) },
            // По макету кнопка обнимает контент (не на всю ширину) и слегка компактнее Material.
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        ) {
            Icon(
                painter = painterResource(R.drawable.cq_ic_link),
                contentDescription = null,
                tint = SdkColors.onAccent(accentColor),
                modifier = Modifier.size(11.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = stringResource(R.string.chat_open_article),
                color = SdkColors.onAccent(accentColor),
                fontSize = 14.sp,
            )
        }
    }
}

// Декоративная форма волны (нормированные амплитуды 0..1) — точный паттерн из макета Figma
// (38 палочек, высоты 2..20px → /20). Размер списка задаёт и плотность реальной волны из
// WaveformExtractor (он сэмплит файл в VOICE_BARS.size столбцов).
private val VOICE_BARS = listOf(
    0.10f, 0.25f, 0.75f, 0.50f, 0.10f, 0.25f, 0.10f, 0.10f, 0.50f, 1.00f,
    0.75f, 0.10f, 0.10f, 0.25f, 0.10f, 0.10f, 0.25f, 0.10f, 0.25f, 0.50f,
    0.25f, 0.75f, 0.50f, 0.25f, 0.10f, 0.10f, 0.10f, 0.25f, 0.25f, 0.50f,
    0.50f, 0.25f, 0.50f, 0.75f, 0.10f, 0.10f, 0.10f, 0.10f,
)

@Composable
private fun VoiceCard(
    voice: UiAttachment.VoiceAttachment,
    accentColor: Color,
    isOutgoing: Boolean = false,
    modifier: Modifier = Modifier,
) {
    // Без подложки: контролы, волна и время рисуются прямо на фоне бабла. На акцентном
    // (исходящее) — белые; на нейтральном (входящее) — акцентного цвета.
    val controlColor = if (isOutgoing) SdkColors.onAccent(accentColor) else accentColor
    // Непрослушанная волна — яркая (как в макете в покое); прослушанная (слева) тускнеет.
    val consumedColor = controlColor.copy(alpha = 0.35f)

    var prepared by remember(voice.url) { mutableStateOf(false) }
    var isPlaying by remember(voice.url) { mutableStateOf(false) }
    var isPreparing by remember(voice.url) { mutableStateOf(false) }
    var positionMs by remember(voice.url) { mutableIntStateOf(0) }
    var durationMs by remember(voice.url) { mutableIntStateOf(voice.durationSeconds * 1000) }
    // Реальная волна из WAV (если распарсилась); до готовности — фиксированный плейсхолдер.
    var bars by remember(voice.url) { mutableStateOf(VOICE_BARS) }
    // Скраб-перемотка по волне (как в Telegram): пока палец на волне — прогресс/время рисуются
    // по пальцу (non-null), seek применяется на отпускании. Воспроизведение при этом не
    // останавливается — прыжок в момент отпускания.
    var scrubFraction by remember(voice.url) { mutableStateOf<Float?>(null) }
    // Перемотка неподготовленного плеера: seekTo до prepare бросает IllegalStateException —
    // запоминаем цель как fraction (durationMs может быть ещё 0) и применяем в onPrepared.
    var pendingSeekFraction by remember(voice.url) { mutableStateOf<Float?>(null) }

    val player = remember(voice.url) { MediaPlayer() }

    // Строим волну (и узнаём реальную длительность) в фоне, один раз на url. Не-WAV, битый
    // файл или сетевая ошибка → extractor вернёт null, остаётся плейсхолдер VOICE_BARS.
    LaunchedEffect(voice.url) {
        val wf = withContext(Dispatchers.IO) {
            WaveformExtractor.fromSource(voice.url, VOICE_BARS.size)
        }
        if (wf != null) {
            bars = wf.amplitudes
            if (durationMs <= 0 && wf.durationMs > 0) durationMs = wf.durationMs
        }
    }

    // Готовим/освобождаем плеер привязанно к url. Длительность узнаём только из плеера —
    // в attachment её нет, поэтому до первой подготовки durationMs может быть 0.
    DisposableEffect(voice.url) {
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        player.setOnPreparedListener { mp ->
            prepared = true
            isPreparing = false
            durationMs = mp.duration
            // Отложенная перемотка (скраб/тап по волне до подготовки): встаём в точку до start.
            pendingSeekFraction?.let { f ->
                val target = (f * mp.duration).toInt()
                runCatching { mp.seekTo(target) }
                positionMs = target
            }
            pendingSeekFraction = null
            mp.start()
            isPlaying = true
        }
        player.setOnCompletionListener { mp ->
            isPlaying = false
            positionMs = 0
            runCatching { mp.seekTo(0) }
        }
        player.setOnErrorListener { _, _, _ ->
            isPlaying = false
            isPreparing = false
            prepared = false
            true
        }
        onDispose { player.release() }
    }

    // Тик позиции только пока играем. При остановке корутина завершается сама.
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            positionMs = runCatching { player.currentPosition }.getOrDefault(positionMs)
            delay(60)
        }
    }

    val onToggle: () -> Unit = onToggle@{
        if (voice.url.isBlank()) return@onToggle
        when {
            isPlaying -> { runCatching { player.pause() }; isPlaying = false }
            prepared -> { runCatching { player.start() }; isPlaying = true }
            !isPreparing -> {
                isPreparing = true
                runCatching {
                    player.reset()
                    player.setDataSource(voice.url)
                    player.prepareAsync()
                }.onFailure { isPreparing = false }
            }
        }
    }

    /** Перемотка в fraction [0..1]: на готовом плеере — сразу, иначе — отложенно через prepare. */
    val seekToFraction: (Float) -> Unit = seek@{ f ->
        if (voice.url.isBlank()) return@seek
        when {
            prepared -> {
                val target = (f * durationMs).toInt()
                runCatching { player.seekTo(target) }
                // Сразу в состояние, не дожидаясь тика: иначе прогресс на кадр прыгал бы назад.
                positionMs = target
            }
            isPreparing -> pendingSeekFraction = f
            else -> {
                // Перемотка неигравшего голосового: готовим плеер, seek применится в onPrepared
                // (и воспроизведение начнётся с выбранной точки — как в Telegram).
                pendingSeekFraction = f
                isPreparing = true
                runCatching {
                    player.reset()
                    player.setDataSource(voice.url)
                    player.prepareAsync()
                }.onFailure {
                    isPreparing = false
                    pendingSeekFraction = null
                }
            }
        }
    }

    val playedFraction = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    // Во время скраба прогресс и время рисуются по пальцу, seek применится на отпускании.
    val fraction = scrubFraction ?: playedFraction
    // Во время прослушивания показываем прошедшее время, иначе — полную длительность.
    val shownMs = when {
        scrubFraction != null && durationMs > 0 -> (scrubFraction!! * durationMs).toInt()
        isPlaying || positionMs > 0 -> positionMs
        else -> durationMs
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        // Отступы по макету голосового: слева 10, справа 16, сверху/снизу 10.
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 10.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
    ) {
        Box(
            // 30dp — самый высокий элемент строки; с паддингом голосового 10/10 даёт высоту бабла 50.
            modifier = Modifier
                .size(30.dp)
                .noRippleClickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            if (isPreparing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = controlColor,
                    strokeWidth = 2.dp,
                )
            } else {
                Icon(
                    painter = painterResource(if (isPlaying) R.drawable.ic_cq_pause else R.drawable.ic_cq_play),
                    contentDescription = null,
                    tint = controlColor,
                    // Тач-таргет — 32dp (бокс выше), сама иконка 14dp.
                    modifier = Modifier.size(14.dp),
                )
            }
        }
        Spacer(modifier = Modifier.width(6.dp))
        VoiceWaveform(
            bars = bars,
            progress = fraction,
            playedColor = consumedColor,
            unplayedColor = controlColor,
            modifier = Modifier
                .weight(1f)
                .height(20.dp),
            onScrub = { f -> scrubFraction = f },
            onScrubEnd = { f ->
                scrubFraction = null
                seekToFraction(f)
            },
            onScrubCancel = { scrubFraction = null },
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = formatDuration(shownMs),
            color = controlColor,
            fontSize = 12.sp,
        )
    }
}

/**
 * Волна голосового. При ненулевых скраб-колбэках волна интерактивна — перемотка как в Telegram:
 * тап = мгновенный переход в точку, горизонтальное ведение = скраб с применением на отпускании.
 * Жест живёт на самой волне: дочерний pointerInput перехватывает горизонталь раньше
 * свайпа-ответа строки (draggable родителя), поэтому reply-свайп продолжает работать со всей
 * остальной площади строки — конфликта жестов нет по построению.
 */
@Composable
private fun VoiceWaveform(
    bars: List<Float>,
    progress: Float,
    playedColor: Color,
    unplayedColor: Color,
    modifier: Modifier = Modifier,
    // Палец ведут по волне: fraction [0..1] по x — рисовать прогресс по пальцу.
    onScrub: ((Float) -> Unit)? = null,
    // Палец отпущен: применить перемотку в fraction.
    onScrubEnd: ((Float) -> Unit)? = null,
    // Жест перехвачен (например, вертикальный скролл) — сбросить скраб без перемотки.
    onScrubCancel: (() -> Unit)? = null,
) {
    val gestureModifier = if (onScrub != null && onScrubEnd != null) {
        Modifier
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    onScrubEnd((offset.x / size.width.toFloat()).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                var lastFraction = 0f
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        lastFraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        onScrub(lastFraction)
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        lastFraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                        onScrub(lastFraction)
                    },
                    onDragEnd = { onScrubEnd(lastFraction) },
                    onDragCancel = { onScrubCancel?.invoke() },
                )
            }
    } else {
        Modifier
    }
    Canvas(modifier = modifier.then(gestureModifier)) {
        val n = bars.size
        if (n == 0) return@Canvas
        val barWidth = 2.dp.toPx()
        val gap = if (n > 1) ((size.width - barWidth * n) / (n - 1)).coerceAtLeast(0f) else 0f
        val step = barWidth + gap
        bars.forEachIndexed { i, amp ->
            val x = i * step
            val barH = (amp * size.height).coerceAtLeast(barWidth)
            val top = (size.height - barH) / 2f
            val played = (i + 1).toFloat() / n <= progress
            drawRoundRect(
                color = if (played) playedColor else unplayedColor,
                topLeft = Offset(x, top),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}

private fun formatDuration(ms: Int): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSec / 60, totalSec % 60)
}

private fun formatTime(timestampMs: Long, context: Context): String {
    if (timestampMs == 0L) return ""
    return android.text.format.DateFormat.getTimeFormat(context).format(Date(timestampMs))
}
