package io.carrotquest_sdk.android.presentation.chat

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BotOptionsGroupItem(
    item: ChatListItem.BotOptionsGroup,
    accentColor: Color,
    isDark: Boolean,
    onOptionSelected: (BotOption) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    // Весь блок кнопок меняется через crossfade:
    // isAnswered=false → все кнопки outlined
    // isAnswered=true  → только выбранная, заполненная акцентом
    // targetState = item (весь объект), а не item.isAnswered (Boolean).
    // Compose при exit-анимации передаёт в лямбду previousState того же типа, что targetState.
    // Если targetState — Boolean, а состояние переходит с false→true, exit-анимация получит
    // старый Boolean, но тип лямбды в следующей рекомпозиции уже другой → ClassCastException.
    AnimatedContent(
        targetState = item,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "botGroup",
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
    ) { currentItem ->
        if (currentItem.isAnswered) {
            val selected = currentItem.options.find { it.id == currentItem.selectedOptionId }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                if (selected != null) {
                    BotOptionChip(
                        option = selected,
                        accentColor = accentColor,
                        isDark = isDark,
                        isSelected = true,
                        enabled = false,
                        onClick = {},
                    )
                }
            }
        } else {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                currentItem.options.forEach { option ->
                    BotOptionChip(
                        option = option,
                        accentColor = accentColor,
                        isDark = isDark,
                        isSelected = false,
                        enabled = true,
                        onClick = { onOptionSelected(option) },
                    )
                }
            }
        }
    }
}

@Composable
private fun BotOptionChip(
    option: BotOption,
    accentColor: Color,
    isDark: Boolean,
    isSelected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val unselectedColor = if (isDark) Color.White else accentColor
    val containerColor by animateColorAsState(
        targetValue = if (isSelected) accentColor else Color.Transparent,
        label = "chipBg",
    )
    val contentColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else unselectedColor,
        label = "chipContent",
    )

    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, if (isSelected) accentColor else unselectedColor),
        // Внутренние отступы как у обычного текстового сообщения (MessageBubble: 14/8),
        // вместо дефолтных Material3 (24/8) — иначе кнопки выглядят с лишними большими отступами.
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = containerColor,
            disabledContentColor = contentColor,
        ),
    ) {
        // Иконка-индикатор внешней ссылки перед текстом, если в кнопку зашит url.
        // Цвет — как у текста кнопки: акцент (светлая тема) / белый (тёмная или выбранная).
        if (!option.link.isNullOrBlank()) {
            Icon(
                painter = painterResource(R.drawable.cq_ic_link),
                contentDescription = null,
                tint = if (isSelected) Color.White else unselectedColor,
                modifier = Modifier.size(11.dp),
            )
            Spacer(modifier = Modifier.width(7.dp))
        }
        Text(
            text = option.text,
            fontSize = 14.sp,
        )
    }
}
