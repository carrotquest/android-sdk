package io.carrotquest_sdk.android.domain.use_cases.agreements

import io.carrotquest_sdk.android.Callback

import com.google.gson.JsonObject
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.data.service.CarrotService
import io.carrotquest_sdk.android.lib.CarrotLib

data class TrackContacts(
    val email: String?,
    val phone: String?,
)

/**
 * Запрос на создание свойства и события о разрешении сбора контактных данных.
 * onResult — итог сохранения (false: не ушло/бэкенд отверг) для реакции UI-слоя.
 */
fun allowTrackContactsUseCase(contacts: TrackContacts, partId: String, onResult: (Boolean) -> Unit = {}) {
    val userId = CarrotLib.getLibComponents().userRep.user.id ?: ""
    if(userId.isEmpty()) {
        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
            "consent contact skipped: empty userId (partId=$partId)"
        }
        onResult(false)
        return
    }

    val jsContacts = JsonObject()
    val hasPhone = contacts.phone != null
    if (hasPhone) {
        jsContacts.addProperty("phone", contacts.phone)
    }

    val hasEmail = contacts.email != null
    if (hasEmail) {
        jsContacts.addProperty("email", contacts.email)
    }


    CarrotService.getInstance()
        .setUserConsentContact(jsContacts.toString(), userId, partId, object : Callback<Boolean> {
            override fun onResponse(result: Boolean) {
                SdkLogger.log(
                    if (result) SdkLogLevel.INFO else SdkLogLevel.WARN,
                    SdkLogCategory.NETWORK, TAG
                ) {
                    "consent contact result=$result phone=$hasPhone email=$hasEmail partId=$partId"
                }
                if(result) {
                    if(hasPhone) {
                        updateAppSettings("phone_storage_is_allowed", true)
                    }

                    if(hasEmail) {
                        updateAppSettings("email_storage_is_allowed", true)
                    }
                }
                onResult(result)
            }

            override fun onFailure(t: Throwable) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                    "consent contact failed: $t (partId=$partId)"
                }
                onResult(false)
            }
        })

}

private const val TAG = "UserConsent"