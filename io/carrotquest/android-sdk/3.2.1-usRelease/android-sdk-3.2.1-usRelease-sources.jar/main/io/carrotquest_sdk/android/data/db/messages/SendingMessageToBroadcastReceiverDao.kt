package io.carrotquest_sdk.android.data.db.messages

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SendingMessageToBroadcastReceiverDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(message: SendingMessageToBroadcastReceiver)

    // suspend + nullable вместо Single<...> (room-rxjava2): пустой результат -> null.
    @Query("SELECT * FROM SendingMessageToBroadcastReceiver WHERE id = :idxxx")
    suspend fun getById(idxxx: String): SendingMessageToBroadcastReceiver?
}
