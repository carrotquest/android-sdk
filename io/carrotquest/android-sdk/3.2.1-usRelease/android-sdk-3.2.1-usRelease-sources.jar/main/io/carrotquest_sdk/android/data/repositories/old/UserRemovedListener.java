package io.carrotquest_sdk.android.data.repositories.old;

import io.carrotquest_sdk.android.lib.models.User;

// Java-friendly колбэк «текущий юзер удалён» (раньше io.reactivex.Observer<User>; ветка remove_rx).
public interface UserRemovedListener {
    void onUserRemoved(User user);
}
