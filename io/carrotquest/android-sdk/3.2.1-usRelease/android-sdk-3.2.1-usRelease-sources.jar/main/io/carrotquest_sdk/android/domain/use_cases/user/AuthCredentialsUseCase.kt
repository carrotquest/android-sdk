package io.carrotquest_sdk.android.domain.use_cases.user

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

/**
 * Креды последней успешной авторизации — чтобы SDK мог сам переиграть auth после того, как
 * пересоздал сессию (token-less /connect выдаёт НОВОГО анонима).
 *
 * Без этого каждое восстановление сессии молча теряло идентичность пользователя до следующего
 * вызова auth() хост-приложением: на бэкенде копились анонимы, а склейка выглядела сломанной.
 *
 * Хранятся там же, где access/refresh JWT и легаси CarrotToken, — уровень защиты секретов не
 * меняется. Чистятся в deInit (logout), иначе SDK восстановил бы уже вышедшего пользователя.
 */
private const val AUTH_EXTERNAL_ID_KEY = "auth_external_id_key"
private const val AUTH_SECRET_KEY = "auth_secret_key"
private const val AUTH_IS_HASHED_KEY = "auth_is_hashed_key"

internal data class AuthCredentials(
    val externalId: String,
    val secret: String,
    /** true — hashedAuth(id, hash), false — authUser(id, userAuthKey): разные эндпоинты. */
    val isHashed: Boolean,
)

internal fun saveAuthCredentials(
    externalId: String,
    secret: String,
    isHashed: Boolean,
    context: Context = CarrotLib.getLibComponents().context,
) {
    if (externalId.isEmpty() || secret.isEmpty()) return
    SharedPreferencesLib.saveString(context, AUTH_EXTERNAL_ID_KEY, externalId)
    SharedPreferencesLib.saveString(context, AUTH_SECRET_KEY, secret)
    SharedPreferencesLib.saveBoolean(context, AUTH_IS_HASHED_KEY, isHashed)
}

internal fun getAuthCredentials(context: Context = CarrotLib.getLibComponents().context): AuthCredentials? {
    val externalId = SharedPreferencesLib.getString(context, AUTH_EXTERNAL_ID_KEY)
    val secret = SharedPreferencesLib.getString(context, AUTH_SECRET_KEY)
    if (externalId.isNullOrEmpty() || secret.isNullOrEmpty()) return null
    return AuthCredentials(
        externalId = externalId,
        secret = secret,
        isHashed = SharedPreferencesLib.getBoolean(context, AUTH_IS_HASHED_KEY),
    )
}

internal fun clearAuthCredentials(context: Context = CarrotLib.getLibComponents().context) {
    SharedPreferencesLib.clearPreference(context, AUTH_EXTERNAL_ID_KEY)
    SharedPreferencesLib.clearPreference(context, AUTH_SECRET_KEY)
    SharedPreferencesLib.clearPreference(context, AUTH_IS_HASHED_KEY)
}
