package io.carrotquest_sdk.android.domain.use_cases.settings

import android.content.Context
import io.carrotquest_sdk.android.data.settings.SettingsManager

/**
 * Настройка аппа messenger_enable_new_conversation_button.
 *
 * true (и значение по умолчанию) — кнопка «Написать» создаёт новый пустой диалог, как раньше.
 * false — апп запретил создавать новые диалоги: кнопка открывает последний диалог, если он есть.
 *
 * Источники по порядку: настройки в памяти → кэш SharedPreferences (настройки ещё не пришли:
 * cold start через push, обрыв сети) → true. Кэш пишет [SettingsManager] при каждом connect.
 */
fun isNewConversationButtonEnabled(context: Context): Boolean {
    getSettings()?.let { return it.enableNewConversationButton }
    return SettingsManager.cachedFlagOrTrue(
        context,
        SettingsManager.CACHED_ENABLE_NEW_CONVERSATION_BUTTON
    )
}
