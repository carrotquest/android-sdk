package io.carrotquest_sdk.android.core.main;

import android.content.Context;

import io.carrotquest_sdk.android.Callback;

import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.data.service.CarrotService;

public class CarrotInternal {

    /**
     * Builds the SDK dependency graph. For internal entry points that may run before
     * {@code setup(...)} has been called (e.g. handling a push tap after the process was killed).
     * Not part of the public API.
     */
    public static void bootstrap(Context context) {
        new CarrotSDK(context);
    }

    /**
     * Builds the SDK dependency graph (including the notification helper) without contacting the
     * backend. For internal push/tracking entry points that may run before {@code setup(...)}.
     * Not part of the public API.
     */
    public static void setupWithoutConnect(Context context) {
        CarrotSDK.buildComponentsWithoutConnect(context);
    }

    private static Callback<Boolean> closeChatCallback;
    public static Callback<Boolean> getCloseChatCallback() {
        return closeChatCallback;
    }
    public static void updateCloseChatCallback(Callback<Boolean> callback) {
        closeChatCallback = callback;
    }

    public static CarrotService getService() {
        return CarrotSDK.libComponent.getCarrotService();
    }
    public static SdkLibComponent getLibComponent() {
        return CarrotSDK.libComponent;
    }
}

