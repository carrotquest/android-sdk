package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.data.repositories.triggers.TriggersRepository

class LoadTriggersUseCase {
    // suspend (ветка remove_rx) — Observable убран; вызывается из корутины InitCoordinator.
    suspend fun call(): Boolean {
        return TriggersRepository.getInstance().loadTriggers()
    }
}
