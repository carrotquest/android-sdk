package io.carrotquest_sdk.android.presentation.chat

sealed class ChatScreenState {
    data object Loading : ChatScreenState()
    data class Error(val kind: ErrorKind) : ChatScreenState()
    data class Content(
        val items: List<ChatListItem> = emptyList(),
        val isLoadingOlderMessages: Boolean = false,
        val canLoadOlderMessages: Boolean = true,
        // Transient-состояние прыжка к цитате: скролл к сообщению (снимается ScrolledToMessage)
        // и временная подсветка его строки (снимается таймером в ChatViewModel).
        val pendingScrollToMessageId: String? = null,
        val highlightedMessageId: String? = null,
    ) : ChatScreenState()
}

enum class ErrorKind {
    NO_INTERNET,
    AIRPLANE_MODE,
    GENERIC,
}
