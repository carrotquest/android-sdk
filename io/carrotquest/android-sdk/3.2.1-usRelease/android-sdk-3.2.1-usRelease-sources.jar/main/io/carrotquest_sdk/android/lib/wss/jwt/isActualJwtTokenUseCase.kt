package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import java.util.Date

fun isActualJwtToken(context: Context = CarrotLib.getLibComponents().getContext()): Boolean {
    val jwtToken = getJwtToken()
    val refreshToken = getRefreshToken()

    val result: Boolean
    val reason: String
    //Если токен не найден, то он актуальный
    if (jwtToken.isEmpty()) {
        val oldToken = SharedPreferencesLib.getString(context, "CarrotToken")
        if (oldToken.isNotEmpty()) {
            result = false; reason = "legacy_CarrotToken_present"
        } else {
            result = refreshToken.isNullOrEmpty()
            reason = if (result) "no_tokens (token-less connect)" else "no_access_but_refresh_present"
        }
    } else {
        val updateTokenTimeStamp = getLastUpdateJwtTokenTime()
        //Если не найден таймштамп сохранения токена, то токен актуальный
        if (updateTokenTimeStamp <= 0) {
            result = refreshToken.isNullOrEmpty()
            reason = if (result) "no_access_timestamp_no_refresh" else "no_access_timestamp_refresh_present"
        } else {
            //Токен актуальный, если разница между текущим временем и временем обновления токена
            // меньше 40 минут и если refresh-токен актуальный
            val ageMs = Date().time - updateTokenTimeStamp
            val refreshActual = isActualRefreshToken(context)
            result = ageMs < jwtTokenLiveTime && refreshActual
            reason = when {
                ageMs >= jwtTokenLiveTime -> "access_expired_by_age"
                !refreshActual -> "refresh_not_actual"
                else -> "valid"
            }
        }
    }

    // DEBUG (не попадает в always-on буфер getDiagnostics): видно в logcat, когда клиент поднял
    // уровень логов для разбора, — чтобы было ясно, ПОЧЕМУ SDK выбрал refresh/анонима/прямой connect.
    // Сообщение строим лениво (не дёргаем maskToken на каждый вызов, пока DEBUG выключен).
    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.AUTH, "TokenFlow") {
        "isActualJwtToken=$result (reason=$reason), access=${maskToken(jwtToken)}, refresh=${maskToken(refreshToken)}"
    }
    return result
}