package io.carrotquest_sdk.android.presentation.mvp.dialog.model

import io.carrotquest_sdk.android.core.util.Log

class DialogViewModel {
    companion object {
        private var instance: DialogViewModel? = null
        fun getInstance(): DialogViewModel {
            if (instance == null) {
                instance = DialogViewModel()
            }
            return instance!!
        }
    }

    // @Volatile: пишется/читается с разных диспатчеров (Main и IO) — как ChatViewModel.conversationId.
    @Volatile private var currentConversationId: String = ""
    private var needStartRoutingBot = false
    private var botId: String = ""

    fun updateCurrentConversationId(id: String) {
        this.currentConversationId = id
    }

    fun getCurrentConversationId() = this.currentConversationId

    fun needStartRoutingBot() = this.needStartRoutingBot

    fun setNeedStartRoutingBot(needStartRoutingBot: Boolean) {
        // Тег CQ_BotInput (а не println): смена флага должна быть видна в отфильтрованном
        // логкате — по репорту welcome-bot-phone-input-missing именно её не хватало.
        Log.d("CQ_BotInput", "setNeedStartRoutingBot $needStartRoutingBot (was ${this.needStartRoutingBot})")
        this.needStartRoutingBot = needStartRoutingBot
    }

    fun setRoutingBotId(botId: String) {
        this.botId = botId
    }

    fun getRoutingBotId() = this.botId
}