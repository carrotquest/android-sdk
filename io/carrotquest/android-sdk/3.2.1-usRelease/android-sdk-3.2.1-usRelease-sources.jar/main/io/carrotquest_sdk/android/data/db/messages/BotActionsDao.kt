package io.carrotquest_sdk.android.data.db.messages

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface BotActionsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(entity: BotActionsEntity)

    @Query("SELECT * FROM bot_actions WHERE messageId = :messageId LIMIT 1")
    fun getById(messageId: String): BotActionsEntity?

    /**
     * Удерживает в кэше только [keep] самых свежих записей (по created), остальные удаляет.
     * Без этого таблица растёт без предела (одна строка на каждый бот-messageId за всю жизнь БД).
     * Эвикция безопасна: restoreBotActions штатно переживает отсутствие кэша (просто нет actions).
     */
    @Query("DELETE FROM bot_actions WHERE messageId NOT IN (SELECT messageId FROM bot_actions ORDER BY created DESC LIMIT :keep)")
    fun trimToLatest(keep: Int)
}