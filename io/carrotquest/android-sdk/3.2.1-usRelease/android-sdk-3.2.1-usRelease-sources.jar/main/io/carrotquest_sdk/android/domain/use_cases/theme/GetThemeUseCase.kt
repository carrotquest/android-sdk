package io.carrotquest_sdk.android.domain.use_cases.theme

import android.content.Context
import android.content.res.Configuration
import android.content.res.Configuration.UI_MODE_NIGHT_YES
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.data.repositories.SettingsRepository

// Observable-ext getTheme удалена (ветка remove_rx) — потребители (FloatingButtonPresenter)
// переведены на синхронный getThemeUseCase, который и так существовал рядом.

/**
 * Resolves the configured [ThemeSdk] to a concrete [ThemeSdk.LIGHT] or [ThemeSdk.DARK] for
 * rendering: LIGHT/DARK pass through, FROM_WEB reads the web-admin setting, FROM_DEVICE follows the
 * system dark mode. Java callers that only need the light/dark flag can use [isDarkTheme].
 */
fun getThemeUseCase(context: Context?): ThemeSdk {
    val theme: ThemeSdk? = CarrotSDK.getTheme()
    if (theme == null || theme == ThemeSdk.LIGHT) {
        return ThemeSdk.LIGHT
    }

    if (theme == ThemeSdk.DARK) {
        return ThemeSdk.DARK
    }

    if (theme == ThemeSdk.FROM_WEB) {
        val settings = SettingsRepository.getInstance().getSettingsObject()
        if (settings?.theme == "dark") {
            return ThemeSdk.DARK
        }
        return ThemeSdk.LIGHT
    }


    if (theme == ThemeSdk.FROM_DEVICE) {
        if (context != null && context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == UI_MODE_NIGHT_YES) {
            return ThemeSdk.DARK
        } else {
            return ThemeSdk.LIGHT
        }
    }

    return ThemeSdk.LIGHT
}

/**
 * Convenience for Java callers (e.g. CarrotWebView): {@code true} if the resolved theme is dark.
 */
fun isDarkTheme(context: Context?): Boolean = getThemeUseCase(context) == ThemeSdk.DARK
