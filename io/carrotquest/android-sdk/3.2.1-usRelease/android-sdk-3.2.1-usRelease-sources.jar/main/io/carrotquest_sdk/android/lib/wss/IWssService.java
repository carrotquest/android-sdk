package io.carrotquest_sdk.android.lib.wss;

import java.util.List;

public interface IWssService {

    void startSocket(String appId, List<Channel> channels, WssMessageListener listener);
    void stopSocket(String appId);
    void deInit();
}
