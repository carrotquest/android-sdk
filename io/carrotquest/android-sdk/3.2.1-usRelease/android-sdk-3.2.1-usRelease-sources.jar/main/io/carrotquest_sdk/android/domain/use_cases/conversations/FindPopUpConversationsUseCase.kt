package io.carrotquest_sdk.android.domain.use_cases.conversations

import com.google.gson.GsonBuilder
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.network.PopUpDeserializer
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.domain.entities.UserEntity

const val SHOWED_POPUP_IDS = "SHOWED_POPUP_IDS_KEY"

// suspend (ветка remove_rx) — Observable-ext убрана. Грузит беседы юзера, фильтрует непрочитанные
// попапы, отсекает уже показанные (SHOWED_POPUP_IDS), сортирует по created, маппит в PopUpMessage.
suspend fun findLastUnreadPopup(userEntity: UserEntity): List<PopUpMessage>? {
    loadConversations(userEntity.id)

    val popUpUnreadConversations = currentConversations().unread().popup().toMutableList()

    val context = CarrotInternal.getLibComponent().contextSdk
    val exitedSet = SharedPreferencesLib.getStringSet(context, SHOWED_POPUP_IDS)
    popUpUnreadConversations.removeAll { x -> x.id == null || exitedSet.contains(x.id) }

    if (popUpUnreadConversations.isEmpty()) {
        return null
    }

    popUpUnreadConversations.sortBy { x -> x.created.toLong() }
    return popUpUnreadConversations.mapNotNull { x -> popUpMessageFromConversation(x) }
}

// internal: переиспользуется в reshowPopup() для восстановления контента поп-апа из беседы,
// когда его уже нет в PopUpDao (Вариант B — баг #11).
internal fun popUpMessageFromConversation(conversation: DataConversation) : PopUpMessage?{
    if(conversation.id == null) {
        return null
    }

    val messageData = conversation.partLast
    val jsonBody = messageData?.bodyJson?.asJsonObject
    if (jsonBody != null) {
        jsonBody.addProperty("id", conversation.id)
        jsonBody.addProperty("expiration_time", conversation.expirationTime)
        val gson = GsonBuilder()
            .registerTypeAdapter(PopUpMessage::class.java, PopUpDeserializer())
            .create()
        return gson.fromJson(jsonBody, PopUpMessage::class.java)
    }

    return null
}