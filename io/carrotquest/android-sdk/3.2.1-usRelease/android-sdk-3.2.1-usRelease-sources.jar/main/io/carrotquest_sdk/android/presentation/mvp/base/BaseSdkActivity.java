package io.carrotquest_sdk.android.presentation.mvp.base;


import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import javax.inject.Inject;


import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;
import io.carrotquest_sdk.android.data.repositories.old.UserRemovedListener;

public class BaseSdkActivity extends AppCompatActivity {

    @Inject
    UserRepository userRepository;

    private UserRemovedListener removeObserver;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        removeObserver = user -> {
            if (user != null) {
                finish();
                if (Carrot.isInit()) {
                    Carrot.deInit();
                }
            }
        };

        if(CarrotInternal.getLibComponent() != null){
            if (userRepository == null) {
                userRepository = CarrotInternal.getLibComponent().getUserRepository();
            }
            userRepository.addRemoveUserObserver(removeObserver);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }
        userRepository.removeRemoveUserObserver(removeObserver);
    }
}
