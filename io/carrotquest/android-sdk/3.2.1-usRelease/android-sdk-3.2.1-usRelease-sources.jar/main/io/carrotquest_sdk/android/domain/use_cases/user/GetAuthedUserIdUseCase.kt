package io.carrotquest_sdk.android.domain.use_cases.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun getAuthedUserIdUseCase(context: Context = CarrotLib.getLibComponents().context): List<String>? {
    val authId = SharedPreferencesLib.getString(context, SharedPreferenceKeys.AUTHED_AUTH_ID_KEY)
    val userId = SharedPreferencesLib.getString(context, SharedPreferenceKeys.AUTHED_SDK_USER_ID_KEY)

    if (authId.isEmpty() && userId.isEmpty()) {
        val legacy = SharedPreferencesLib.getString(context, SharedPreferenceKeys.AUTHED_USER_ID_KEY)
        if (legacy.contains(":")) {
            val parts = legacy.split(":", limit = 2)
            if (parts.size == 2) {
                saveAuthedUserIdUseCase(parts[0], parts[1], context)
                return listOf(parts[0], parts[1])
            }
        }
        return null
    }

    return listOf(authId, userId)
}

fun getConnectedUserIdUseCase(context: Context = CarrotLib.getLibComponents().context): String? {
    val key = SharedPreferenceKeys.CONNECTED_USER_ID_KEY
    val id: String = SharedPreferencesLib.getString(context, key)

    if(id.isEmpty()) {
        return null
    }

    return id
}