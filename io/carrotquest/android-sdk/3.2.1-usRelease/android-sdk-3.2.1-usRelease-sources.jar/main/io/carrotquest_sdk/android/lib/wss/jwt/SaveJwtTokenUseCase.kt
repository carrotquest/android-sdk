package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import java.util.Date

fun saveJwtToken(token: String, context: Context = CarrotLib.getLibComponents().getContext()) {
    val oldToken = getJwtToken()
    if (oldToken != token) {
        // Токен и время его записи — одной транзакцией: раздельные apply() пережили бы kill
        // процесса частично, и свежий таймстемп при старом токене выдавал бы вердикт
        // «access актуален» для токена предыдущей личности (isActualJwtToken судит по времени).
        SharedPreferencesLib.saveStringWithLong(
            context, jwtTokenKey, token, jwtTokenUpdateTimeStampKey, Date().time,
        )
    } else {
        SharedPreferencesLib.saveString(context, jwtTokenKey, token)
    }
    SdkLogger.log(
        SdkLogLevel.INFO, SdkLogCategory.AUTH, "TokenFlow",
        "saveJwtToken: access=${maskToken(token)} (changed=${oldToken != token})",
    )
}