package io.carrotquest_sdk.android.lib.full_image_view.view

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.github.chrisbanes.photoview.PhotoView
import io.carrotquest_sdk.android.R
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import androidx.core.net.toUri

internal sealed class ImageSource {
    data class FromUrl(val url: String) : ImageSource()
    data class FromFile(val file: File) : ImageSource()
    data class FromBitmap(val bitmap: Bitmap) : ImageSource()
}

private data class PageState(
    val isLoading: Boolean = true,
    val hasError: Boolean = false,
    val hasDrawable: Boolean = false,
)

private val ControlsOverlayColor = Color(0x4C000000)
private val ErrorTextColor = Color(0xFFB3FFFFFF)

@Composable
internal fun FullImageViewScreen(
    images: List<ImageSource>,
    initialIndex: Int,
    controlsVisible: Boolean,
    onBack: () -> Unit,
    onImageTap: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
    onDragOffsetChanged: (Float) -> Unit,
    onImageLoaded: (pageIndex: Int, drawable: Drawable) -> Unit,
    onImageLoadFailed: (pageIndex: Int) -> Unit,
    onPageChanged: (pageIndex: Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val offsetY = remember { Animatable(0f) }
    val pagerState = rememberPagerState(initialPage = initialIndex) { images.size }
    val pageStates = remember { mutableStateListOf(*Array(images.size) { PageState() }) }

    LaunchedEffect(Unit) {
        snapshotFlow { offsetY.value }.collect { onDragOffsetChanged(it) }
    }

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .graphicsLayer { translationY = offsetY.value }
            .pointerInput(Unit) {
                val dismissThresholdPx = 200.dp.toPx()
                val velocityThreshold = 800.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val velocityTracker = VelocityTracker()
                    velocityTracker.addPosition(down.uptimeMillis, down.position)
                    var accumulated = 0f
                    var activated = false
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        val dy = change.position.y - change.previousPosition.y
                        val dx = change.position.x - change.previousPosition.x
                        velocityTracker.addPosition(change.uptimeMillis, change.position)
                        if (!activated) {
                            if (dy > 0) accumulated += dy
                            if (accumulated > viewConfiguration.touchSlop && accumulated > abs(dx)) activated = true
                        }
                        if (activated) {
                            change.consume()
                            scope.launch { offsetY.snapTo((offsetY.value + dy).coerceAtLeast(0f)) }
                        }
                        if (!change.pressed) break
                    }
                    if (activated) {
                        val velocity = velocityTracker.calculateVelocity().y
                        scope.launch {
                            if (offsetY.value > dismissThresholdPx || velocity > velocityThreshold) {
                                offsetY.animateTo(size.height.toFloat(), animationSpec = tween(250))
                                onDismiss()
                            } else {
                                offsetY.animateTo(0f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium))
                            }
                        }
                    }
                }
            }
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            val ps = pageStates[page]
            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        PhotoView(ctx).apply {
                            setOnPhotoTapListener { _, _, _ -> onImageTap() }
                            val listener = glideListener(
                                onLoaded = { drawable ->
                                    pageStates[page] = PageState(isLoading = false, hasDrawable = true)
                                    onImageLoaded(page, drawable)
                                },
                                onFailed = {
                                    pageStates[page] = PageState(isLoading = false, hasError = true)
                                    onImageLoadFailed(page)
                                },
                            )
                            when (val src = images[page]) {
                                is ImageSource.FromUrl    -> Glide.with(ctx).load(src.url.toUri()).listener(listener).into(this)
                                is ImageSource.FromFile   -> Glide.with(ctx).load(src.file).listener(listener).into(this)
                                is ImageSource.FromBitmap -> Glide.with(ctx).load(src.bitmap).listener(listener).into(this)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                )
                if (ps.isLoading) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = Color.White)
                }
                if (ps.hasError) {
                    Text(
                        text = stringResource(R.string.cq_lib_something_wrong),
                        color = ErrorTextColor,
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 32.dp),
                    )
                }
            }
        }

        // Top controls: back button + page indicator dots
        AnimatedVisibility(
            visible = controlsVisible,
            modifier = Modifier.align(Alignment.TopStart).fillMaxWidth(),
            enter = fadeIn(tween(400)),
            exit = fadeOut(tween(200)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ControlsOverlayColor)
                    .statusBarsPadding(),
            ) {
                IconButton(onClick = onBack, modifier = Modifier.padding(4.dp)) {
                    Icon(
                        painter = painterResource(R.drawable.ic_cq_lib_back_arrow),
                        contentDescription = null,
                        tint = Color.White,
                    )
                }
            }
        }

        // Bottom controls: share + save
        val canSaveShare = pageStates.getOrNull(pagerState.currentPage)?.hasDrawable == true
        AnimatedVisibility(
            visible = controlsVisible,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            enter = fadeIn(tween(400)),
            exit = fadeOut(tween(200)),
        ) {
            val iconTint = if (canSaveShare) Color.White else Color.White.copy(alpha = 0.4f)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ControlsOverlayColor)
                    .navigationBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                IconButton(onClick = onShare, enabled = canSaveShare) {
                    Icon(
                        painter = painterResource(R.drawable.ic_cq_lib_share),
                        contentDescription = null,
                        tint = iconTint,
                    )
                }
                IconButton(onClick = onSave, enabled = canSaveShare) {
                    Icon(
                        painter = painterResource(R.drawable.ic_cq_lib_save_image),
                        contentDescription = null,
                        tint = iconTint,
                    )
                }
            }
        }
    }
}

private fun glideListener(
    onLoaded: (Drawable) -> Unit,
    onFailed: () -> Unit,
) = object : RequestListener<Drawable> {
    override fun onLoadFailed(
        e: GlideException?,
        model: Any?,
        target: Target<Drawable>,
        isFirstResource: Boolean,
    ): Boolean {
        onFailed()
        return false
    }

    override fun onResourceReady(
        resource: Drawable,
        model: Any,
        target: Target<Drawable>,
        dataSource: DataSource,
        isFirstResource: Boolean,
    ): Boolean {
        onLoaded(resource)
        return false
    }
}