package io.carrotquest_sdk.android.data.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

internal object UserStateHolder {

    private val _state: MutableStateFlow<UserEntity?> = MutableStateFlow(null)
    val state: StateFlow<UserEntity?> = _state.asStateFlow()

    fun update(user: UserEntity?) {
        _state.value = user
    }

    fun current(): UserEntity? = _state.value

    fun currentId(): String = _state.value?.id ?: ""

    fun currentToken(): String = _state.value?.token ?: ""

    fun banUser(userId: String?) {
        if (userId.isNullOrEmpty()) return
        val current = _state.value ?: return
        if (current.id == userId) {
            _state.value = current.copy(isBanned = true)
        }
    }

    fun unBanUser(userId: String?) {
        if (userId.isNullOrEmpty()) return
        val current = _state.value ?: return
        if (current.id == userId) {
            _state.value = current.copy(isBanned = false)
        }
    }

    fun removeUsers(removedUserIds: Collection<String>?) {
        if (removedUserIds.isNullOrEmpty()) return
        val current = _state.value ?: return
        if (removedUserIds.contains(current.id)) {
            _state.value = null
        }
    }

    fun clear() {
        _state.value = null
    }

    fun restoreFromPrefs(context: Context) {
        val token = SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_TOKEN)
        val id = SharedPreferencesLib.getString(context, SharedPreferenceKeys.CARROT_USER_ID)
        if (token.isEmpty() && id.isEmpty()) return
        _state.value = UserEntity(
            id = id,
            token = token,
            isBanned = SharedPreferencesLib.getBoolean(context, SharedPreferenceKeys.CARROT_USER_BANNED),
            conversationsUnread = SharedPreferencesLib.getPreferenceArray(context, SharedPreferenceKeys.CARROT_USER_UNREAD_CONVERSATIONS)
        )
    }
}
