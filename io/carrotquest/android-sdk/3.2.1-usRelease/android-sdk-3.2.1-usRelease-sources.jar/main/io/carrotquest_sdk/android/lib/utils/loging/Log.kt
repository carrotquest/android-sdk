package io.carrotquest_sdk.android.lib.utils.loging

import io.carrotquest_sdk.android.core.logging.SdkLogger

/**
 * Легаси-фасад логирования (lib-слой). Делегирует в [SdkLogger]; весь вывод гейтится уровнем
 * (по умолчанию NONE). Оставлен ради существующих call-site'ов.
 */
class Log {
    companion object {
        fun i(tag: String?, msg: String?) = SdkLogger.i(tag ?: "", msg ?: "")
        fun e(tag: String?, msg: String?) = SdkLogger.e(tag ?: "", msg ?: "")
        fun e(tag: String?, e: Exception) = SdkLogger.e(tag ?: "", e.toString(), e)
        fun e(tag: String?, t: Throwable) = SdkLogger.e(tag ?: "", t.toString(), t)
        fun w(tag: String?, msg: String?) = SdkLogger.w(tag ?: "", msg ?: "")
        fun d(tag: String?, msg: String?) = SdkLogger.d(tag ?: "", msg ?: "")
        fun v(tag: String?, msg: String?) = SdkLogger.v(tag ?: "", msg ?: "")
    }
}
