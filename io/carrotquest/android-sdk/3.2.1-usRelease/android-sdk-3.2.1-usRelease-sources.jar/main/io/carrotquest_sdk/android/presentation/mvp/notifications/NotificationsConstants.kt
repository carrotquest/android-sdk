package io.carrotquest_sdk.android.presentation.mvp.notifications

object NotificationsConstants {
    const val CQ_SDK_NEW_MESSAGE_ARG = "NEW_MESSAGE_ARG"
    const val CQ_SDK_NEW_MESSAGE_ACTION = "io.carrotquest_sdk.android.CQ_SDK_NEW_MESSAGE_ACTION"
    const val CQ_SDK_PUSH = "is_carrot"

    const val CQ_SDK_PUSH_BODY_JSON = "body_json"
    const val CQ_SDK_PUSH_CLICK_ACTION = "click_action"

    const val CQ_SDK_AUTO_MESSAGE = "message_auto"
    const val CQ_SDK_SENT_VIA = "sent_via"
}