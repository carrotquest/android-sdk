package io.carrotquest_sdk.android.presentation.mvp.file_picker

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import io.carrotquest_sdk.android.core.util.Log
import android.app.Activity
import io.carrotquest_sdk.android.R
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

class FilePickerHelper(private val activity: Activity) {
    companion object {
        const val maxSize = 10

        val mAllowFileTypes = arrayListOf(
            "jpg",
            "jpeg",
            "png",
            "gif",
            "txt",
            "pdf",
            "rar",
            "zip",
            "html",
            "csv",
            "docx",
            "doc",
            "xlsx",
            "xls",
            "sig",
            "mp4",
            "rtf",
            "mov",
            "tiff",
            "tif",
            "m4v",
            "mp3",
            "mpeg",
            "webm"
        )

        val mAllowMimeTypes = arrayOf(
            "image/jpg",
            "image/jpeg",
            "image/png",
            "image/gif",
            "text/plain",
            "application/pdf",
            "application/vnd.rar",
            "application/rar",
            "application/x-rar-compressed",
            "application/zip",
            "text/html",
            "text/txt",
            "text/csv",
            "text/comma-separated-values",
            "application/excel",
            "text/x-csv",
            "application/csv",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "application/sig",
            "video/mp4",
            "application/rtf",
            "video/mov",
            "image/tiff",
            "video/m4v",
            "audio/m4v",
            "audio/mp3",
            "audio/mpeg",
            "video/mpeg",
            "video/mp4",
            "video/webm"
        )
    }


    fun getFile(uri: Uri?): File {
        // Если uri null или openInputStream вернул null (revoked permission, файл удалён),
        // возвращаем пустой File. Раньше тут были !! и крэши при кривом uri.
        if (uri == null) {
            return File(activity.filesDir.path)
        }
        val name = queryName(activity, uri) ?: "cq_attachment_${System.currentTimeMillis()}"
        val destinationFilename = File(activity.filesDir.path + File.separatorChar + name)
        try {
            activity.contentResolver.openInputStream(uri)?.use { ins ->
                createFileFromStream(ins, destinationFilename)
            } ?: Log.e("Save File", "openInputStream returned null for uri=$uri")
        } catch (ex: java.lang.Exception) {
            Log.e("Save File", ex)
        }
        return destinationFilename
    }

    private fun createFileFromStream(ins: InputStream, destination: File?) {
        try {
            FileOutputStream(destination).use { os ->
                val buffer = ByteArray(4096)
                var length: Int
                while (ins.read(buffer).also { length = it } > 0) {
                    os.write(buffer, 0, length)
                }
                os.flush()
            }
        } catch (ex: Exception) {
            Log.e("Save File", ex)
        }
    }

    private fun queryName(context: Context, uri: Uri): String? {
        // ContentResolver.query() может вернуть null (provider удалён, permission revoked),
        // а нагон сюда из cursor.getString может выкинуть на пустом курсоре.
        val cursor = try {
            context.contentResolver.query(uri, null, null, null, null)
        } catch (e: Exception) {
            Log.e("FilePickerHelper", "query failed for $uri: $e")
            null
        } ?: return null
        return try {
            cursor.use { c ->
                val nameIndex = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex < 0 || !c.moveToFirst()) null
                else c.getString(nameIndex)
            }
        } catch (e: Exception) {
            Log.e("FilePickerHelper", "queryName failed: $e")
            null
        }
    }

    /**
     * Ошибка по вложению в форме боттомшита (мультиаттачи): слишком большой файл / неподдерживаемый
     * тип / не удалось загрузить / превышен лимит. Открывает Compose-боттомшит [ErrorBottomSheetActivity].
     */
    fun showErrorBottomSheet(title: String, message: String) {
        // Compose-боттомшит (визуал как у actions-шита, кнопка Ok — под исходящий бабл чата).
        activity.startActivity(
            io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.ErrorBottomSheetActivity
                .intent(activity, title, message)
        )
    }

    fun fileTypeIsCorrect(pathFile: String): Boolean {
        val dotPos: Int = pathFile.lastIndexOf('.')
        val type = if (0 <= dotPos) {
            pathFile.substring(dotPos + 1)
        } else ""

        return mAllowFileTypes.contains(type.lowercase(Locale.getDefault()))
    }

    fun fileIsImage(path: String): Boolean {
        if (path.isEmpty()) {
            return false
        }

        // tiff здесь намеренно нет: отправлять его можно (см. mAllowFileTypes), но Android его
        // не декодирует — превью рисуем как файл, не как картинку.
        val imageTypes: ArrayList<String> = arrayListOf("png", "jpg", "jpeg")
        imageTypes.forEach { type ->
            if (path.endsWith(type)) {
                return true
            }
        }

        return false
    }
}