package io.carrotquest_sdk.android.core.logging

/**
 * Verbosity of the SDK's logs.
 *
 * NONE (the default) disables logging entirely: nothing is written to logcat, no sink is invoked,
 * and there is no overhead. A higher level also includes all more-severe ones (e.g. ERROR is still
 * emitted at WARN / INFO / DEBUG / VERBOSE).
 */
enum class SdkLogLevel { NONE, ERROR, WARN, INFO, DEBUG, VERBOSE }
