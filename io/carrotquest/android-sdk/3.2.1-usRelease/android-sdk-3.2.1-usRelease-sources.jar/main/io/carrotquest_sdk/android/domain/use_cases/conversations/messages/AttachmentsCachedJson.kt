package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import org.json.JSONArray
import org.json.JSONObject

/**
 * Строит JSON для form-поля `attachments_cached` при отправке сообщения с уже загруженными
 * вложениями (upload-on-select). Формат СТРОГО по контракту бэкенда — массив объектов
 * {type, id, filename, mime_type, size, url} (поле `created` опускаем). Пустой список → null
 * (поле не отправляется). Имена ключей зафиксированы тестом: опечатка молча сломала бы отправку.
 */
fun buildAttachmentsCachedJson(refs: List<Attachment>): String? {
    if (refs.isEmpty()) return null
    val arr = JSONArray()
    for (a in refs) {
        arr.put(
            JSONObject().apply {
                put("type", a.type)
                put("id", a.id)
                put("filename", a.filename)
                put("mime_type", a.mimeType)
                put("size", a.size)
                put("url", a.url)
            }
        )
    }
    return arr.toString()
}
