package io.carrotquest_sdk.android.presentation.chat

import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentKind

sealed class ChatEvent {
    data class BotOptionSelected(
        val messageId: String,
        val option: BotOption,
    ) : ChatEvent()

    data class VoteSelected(
        val messageId: String,
        val score: Int,
    ) : ChatEvent()

    data class ContactFormSubmitted(
        val messageId: String,
        val value: String,
        val inputType: ContactInputType,
    ) : ChatEvent()

    // Переключение чекбокса согласия внутри бабла контакт-формы.
    data class ConsentToggled(
        val messageId: String,
        val kind: ConsentKind,
    ) : ChatEvent()

    data class ImageTapped(val urls: List<String>, val initialIndex: Int) : ChatEvent()

    // Тап по карточке файла: начать загрузку / отменить / открыть — в зависимости от downloadState
    data class FileTapped(val messageId: String, val attachmentId: String) : ChatEvent()

    data class MessageTapped(val messageId: String) : ChatEvent()

    // Тап по ссылке внутри сообщения / кнопке статьи. Открытие и аналитика клика
    // (trackClick) выполняются в presenter.onGoToLink.
    data class LinkTapped(val url: String) : ChatEvent()

    data class CommentVoteSent(
        val messageId: String,
        val score: Int,
        val comment: String,
    ) : ChatEvent()

    // Тап по блоку цитаты в бабле: скролл к оригиналу + подсветка (обработчик — этап Э6;
    // до него событие маршрутизируется, но никем не потребляется).
    data class QuoteTapped(val originalId: String) : ChatEvent()

    // Запрос «ответить на сообщение» — общая точка для свайпа (Э5) и пункта bottom sheet.
    // DialogFragment строит превью и включает режим ответа в MessageInputViewModel.
    data class ReplyRequested(val messageId: String) : ChatEvent()

    data object Retry : ChatEvent()
    data object LoadOlderMessages : ChatEvent()

    // Маркер разрыва истории показался на экране — грузим страницу середины диалога с того
    // края, с которого подошёл пользователь: fromTail=true — снизу (before от верхней границы
    // хвоста, сообщения появляются сразу над юзером), false — сверху (after от низа around-окна).
    data class LoadGapMessages(val fromTail: Boolean) : ChatEvent()

    // Список доскроллил к сообщению из pendingScrollToMessageId — VM снимает pending
    // (подсветка живёт дольше, по своему таймеру).
    data class ScrolledToMessage(val messageId: String) : ChatEvent()
}
