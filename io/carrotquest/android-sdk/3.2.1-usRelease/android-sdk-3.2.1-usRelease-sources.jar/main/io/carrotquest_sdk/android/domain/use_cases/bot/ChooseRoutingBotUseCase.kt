package io.carrotquest_sdk.android.domain.use_cases.bot

import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.core.main.CarrotInternal
import kotlinx.coroutines.CancellationException

/**
 * suspend-ядро (ветка remove_rx). Возвращает данные роутинг-бота для диалога.
 *
 * Контракт по ошибкам: null = «узнать не удалось» (сеть/парсинг), это НЕ «бота нет»
 * (бота нет — это data.found == false). Раньше ошибка молча превращалась в пустой
 * [ChooseRoutingBotData] (found=null), потребители трактовали его как «бота нет» и
 * даунгрейдили needStartRoutingBot true→false при видимых кнопках первой ветки —
 * клик уходил в meta_data по шаблонному id сообщения бота и ловил 400 (репорт
 * welcome-bot-phone-input-missing). Потребители обязаны НЕ трогать состояние при null.
 *
 * CancellationException пробрасываем: отменённая корутина не должна успевать
 * записать «результат» в общий флаг.
 */
suspend fun loadRoutingBot(conversationId: String): ChooseRoutingBotData? =
    loadRoutingBot(conversationId) { cId ->
        CarrotInternal.getService().carrotLib.chooseRoutingBotSuspend(cId).data
    }

internal suspend fun loadRoutingBot(
    conversationId: String,
    fetch: suspend (String) -> ChooseRoutingBotData?,
): ChooseRoutingBotData? {
    val cId = if (conversationId == "last_conversation") "" else conversationId
    return try {
        fetch(cId)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, "RoutingBot", throwable = e) {
            "chooseRoutingBot failed, bot state unknown (convId='$cId')"
        }
        null
    }
}
