package io.carrotquest_sdk.android.core

import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

internal object SdkStateManager {

    private const val TAG = "SdkStateManager"

    private val _state: MutableStateFlow<SdkState> = MutableStateFlow(SdkState.Idle)
    val state: StateFlow<SdkState> = _state.asStateFlow()

    private val _publicState: MutableStateFlow<CarrotState> = MutableStateFlow(CarrotState.Idle)
    val publicState: StateFlow<CarrotState> = _publicState.asStateFlow()

    /**
     * Сигнал «сессия недействительна и не восстановима через refresh» (refresh отвергнут ИЛИ
     * 403 absent_scopes). Наружу НЕ выставляется (flow восстановления скрыт от клиента) —
     * восстановление автоматическое: запускаем token-less пересоздание сессии прямо в текущем
     * процессе ([CarrotService.recoverSession]), не дожидаясь перезапуска приложения. Внутри —
     * single-flight + cooldown, поэтому серия 403 безопасна.
     */
    fun notifySessionExpired() {
        SdkLogger.log(
            SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
            "session expired/invalid scopes → triggering token-less session recovery",
        )
        try {
            CarrotInternal.getService()?.recoverSession()
        } catch (t: Throwable) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "session recovery trigger failed", throwable = t)
        }
    }

    @Volatile
    private var readyDeferred: CompletableDeferred<Unit> = CompletableDeferred()

    fun isInit(): Boolean = _state.value is SdkState.Ready
    fun isInitializing(): Boolean = _state.value is SdkState.Initializing

    /**
     * Атомарный check-and-set перехода в Initializing.
     * Возвращает true если переход состоялся, false — если SDK уже инициализируется или готов.
     * Защищает от гонки параллельных setup()-вызовов.
     */
    @Synchronized
    fun onInitStarted(): Boolean {
        val current = _state.value
        if (current is SdkState.Initializing || current is SdkState.Ready) {
            return false
        }
        _state.value = SdkState.Initializing
        _publicState.value = CarrotState.Initializing
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.LIFECYCLE, TAG,
            "SDK initializing (v${BuildConfig.VERSION_SDK_NAME})",
            fields = mapOf("sdkVersion" to BuildConfig.VERSION_SDK_NAME),
        )
        return true
    }

    @Synchronized
    fun onReady() {
        val current = _state.value
        if (current !is SdkState.Initializing) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.LIFECYCLE, TAG, "onReady() ignored, unexpected state: $current")
            return
        }
        _state.value = SdkState.Ready
        _publicState.value = CarrotState.Ready
        readyDeferred.complete(Unit)
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.LIFECYCLE, TAG, "SDK ready")
    }

    @Synchronized
    fun onFailed(error: Throwable) {
        val current = _state.value
        if (current !is SdkState.Initializing) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.LIFECYCLE, TAG, "onFailed() ignored, unexpected state: $current")
            return
        }
        SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.LIFECYCLE, TAG, "SDK init failed", throwable = error)
        _state.value = SdkState.Failed(error)
        _publicState.value = CarrotState.Failed(error)
        readyDeferred.completeExceptionally(error)
        readyDeferred = CompletableDeferred()
    }

    @Synchronized
    fun onInitAborted() {
        if (_state.value is SdkState.Initializing) {
            _state.value = SdkState.Idle
            _publicState.value = CarrotState.Idle
        }
    }

    @Synchronized
    fun onDeInit() {
        if (!readyDeferred.isCompleted) readyDeferred.cancel()
        readyDeferred = CompletableDeferred()
        _state.value = SdkState.Idle
        _publicState.value = CarrotState.Idle
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.LIFECYCLE, TAG, "SDK deinitialized")
    }

    suspend fun awaitReady() {
        if (_state.value is SdkState.Ready) return
        readyDeferred.await()
    }
}
