package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.Gson
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import io.carrotquest_sdk.android.data.repositories.HistoryGap
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Прыжок к цитируемому сообщению (CAR-75966): загрузка окна ВОКРУГ оригинала
 * (paginate_direction=around) и последующее заполнение разрыва истории (direction=after),
 * пока верхнее окно не сомкнётся с хвостом. Позиции пагинации — id-снежинки сообщений.
 */

// id-снежинки серверных сообщений ~2e18; id оптимистичных — локальные секунды (~2e9).
// Порог отделяет одно от другого при вычислении границ окон.
private const val SNOWFLAKE_MIN_ID = 1_000_000_000_000L

/**
 * Разрыв после прыжка. [loadedIds] — id пришедшего around-окна, [existingMinId] — минимальный
 * серверный id уже загруженных сообщений (верх нижнего окна). null — разрыва нет: либо нечего
 * было сравнивать, либо окна смежны/пересеклись (дедуп по id склеил их бесшовно).
 */
internal fun computeGapAfterJump(loadedIds: List<Long>, existingMinId: Long?): HistoryGap? {
    if (existingMinId == null) return null
    val loadedMax = loadedIds.maxOrNull() ?: return null
    if (loadedMax >= existingMinId) return null
    return HistoryGap(lowerBoundId = loadedMax, upperBoundId = existingMinId)
}

/**
 * Сдвиг разрыва после after-страницы (заполнение от ВЕРХНЕГО края вниз). null — разрыв закрыт:
 * страница пуста (середины больше нет — иначе маркер зациклится) либо достигла нижнего окна.
 */
internal fun advanceGapFromTop(gap: HistoryGap, pageIds: List<Long>): HistoryGap? {
    val pageMax = pageIds.maxOrNull() ?: return null
    if (pageMax >= gap.upperBoundId) return null
    return gap.copy(lowerBoundId = pageMax)
}

/**
 * Сдвиг разрыва после before-страницы (заполнение от НИЖНЕГО края вверх — пользователь подошёл
 * к разрыву со стороны хвоста). null — разрыв закрыт (пустая страница / достигли верхнего окна).
 */
internal fun advanceGapFromBottom(gap: HistoryGap, pageIds: List<Long>): HistoryGap? {
    val pageMin = pageIds.minOrNull() ?: return null
    if (pageMin <= gap.lowerBoundId) return null
    return gap.copy(upperBoundId = pageMin)
}

// Восстановление sourceJsonData у распарсенных сообщений (как в paginationMessages) + addMessages.
private fun mergeResponseIntoRepo(response: MessagesResponse): List<Long> {
    val nArray = ArrayList<MessageData>()
    for (m in response.data) {
        val nm = response.sourceData.asJsonArray.find { p -> p.asJsonObject.get("id").asString == m.id }
        if (nm != null) {
            m.sourceJsonData = JSONObject(Gson().toJson(nm))
        }
        nArray.add(m)
    }
    MessagesRepository.getInstance().addMessages(nArray)
    return nArray.mapNotNull { it.id?.toLongOrNull() }
}

/**
 * Грузит окно вокруг [targetMessageId] и регистрирует разрыв истории. Возвращает true, если
 * оригинал после мерджа есть в репозитории. Бросает при null meta / meta.error (как пагинация).
 */
suspend fun loadMessagesAround(conversation: DataConversation, targetMessageId: String): Boolean {
    val conversationId = conversation.id ?: return false
    val repo = MessagesRepository.getInstance()

    // Верх нижнего (хвостового) окна — до мерджа around-ответа. Только серверные снежинки:
    // id оптимистичных сообщений — локальные секунды, они бы ложно занизили границу.
    val existingMinId = repo.getMessagesSnapshot()
        .filter { it.conversation == conversationId }
        .mapNotNull { it.id?.toLongOrNull() }
        .filter { it >= SNOWFLAKE_MIN_ID }
        .minOrNull()

    val response = CarrotInternal.getService().carrotLib.getMessagesAroundSuspend(conversationId, targetMessageId)
    val meta = response.meta ?: throw Exception("Error load messages around: null meta")
    if (meta.error != null) {
        throw Exception("Error load messages around: ${meta.error}")
    }
    if (response.data == null) return false

    return withContext(SdkDispatchers.io) {
        val loadedIds = mergeResponseIntoRepo(DownloadUtil.replaceFilesLocalUrl(response))

        val gap = computeGapAfterJump(loadedIds, existingMinId)
        repo.setHistoryGap(gap)

        // Пагинация вверх теперь идёт от верха around-окна: курсор = минимальный id окна
        // (существующая older-пагинация шлёт position&direction=before). Не поднимаем курсор,
        // если around-окно оказалось не старее уже загруженного.
        val newMin = loadedIds.filter { it >= SNOWFLAKE_MIN_ID }.minOrNull()
        if (newMin != null && (existingMinId == null || newMin < existingMinId)) {
            repo.setCurrentAfter(newMin.toString())
        }

        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
            "jump around: target=$targetMessageId loaded=${loadedIds.size} gap=$gap cursor=${repo.getCurrentAfter()}"
        }
        repo.findMessageById(targetMessageId) != null
    }
}

/**
 * Грузит одну страницу середины диалога и сдвигает/закрывает разрыв. Заполняем с того края,
 * с которого пользователь подошёл к маркеру: [fromTail]=true — before от верхней границы хвоста
 * (сообщения появляются сразу над пользователем), false — after от низа верхнего окна.
 * Ничего не делает, если разрыва нет.
 */
suspend fun loadGapPage(conversation: DataConversation, fromTail: Boolean) {
    val conversationId = conversation.id ?: return
    val repo = MessagesRepository.getInstance()
    val gap = repo.getHistoryGap() ?: return

    val carrotLib = CarrotInternal.getService().carrotLib
    val response = if (fromTail) {
        // Существующий before-запрос (including=false): сообщения старее верхней границы хвоста.
        carrotLib.getMessagesSuspend(conversationId, gap.upperBoundId.toString())
    } else {
        carrotLib.getMessagesAfterSuspend(conversationId, gap.lowerBoundId.toString())
    }
    val meta = response.meta ?: throw Exception("Error load gap page: null meta")
    if (meta.error != null) {
        throw Exception("Error load gap page: ${meta.error}")
    }
    if (response.data == null) {
        // Середины больше нет — снимаем разрыв, чтобы маркер не зациклился.
        repo.setHistoryGap(null)
        return
    }

    withContext(SdkDispatchers.io) {
        val pageIds = mergeResponseIntoRepo(DownloadUtil.replaceFilesLocalUrl(response))
        val next = if (fromTail) advanceGapFromBottom(gap, pageIds) else advanceGapFromTop(gap, pageIds)
        repo.setHistoryGap(next)
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
            "gap page: fromTail=$fromTail loaded=${pageIds.size} gap=$next"
        }
    }
}
