package io.carrotquest_sdk.android.core.logging

import android.util.Log

/**
 * Sink по умолчанию: пишет в Android logcat с тегом "CQ_<tag>". Категория (если не GENERAL) и
 * stacktrace добавляются в текст сообщения.
 */
internal class LogcatSink : SdkLogSink {
    override fun onLog(entry: SdkLogEntry) {
        val tag = "CQ_" + entry.tag
        val prefix = if (entry.category != SdkLogCategory.GENERAL) "[${entry.category.name}] " else ""
        val stack = entry.throwable?.let { "\n" + Log.getStackTraceString(it) } ?: ""
        val msg = prefix + entry.message + stack
        when (entry.level) {
            SdkLogLevel.ERROR -> Log.e(tag, msg)
            SdkLogLevel.WARN -> Log.w(tag, msg)
            SdkLogLevel.INFO -> Log.i(tag, msg)
            SdkLogLevel.DEBUG -> Log.d(tag, msg)
            SdkLogLevel.VERBOSE -> Log.v(tag, msg)
            SdkLogLevel.NONE -> {}
        }
    }
}
