package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.currentConversations
import kotlinx.coroutines.withContext
import java.util.Locale

// suspend (ветка remove_rx) — Observable-ext убрана. Возвращает последнее непрочитанное
// сообщение (не из попапа, не закрытое, нужного направления/от бота) или null.
suspend fun getLastUnreadMessage(): MessageData? = withContext(SdkDispatchers.io) {
    val conversations = currentConversations()
    val db: CarrotSdkDB = SdkApp.getInstance().database
    val closedMessages = db.closedMessageDao().getAll()
    if (closedMessages.size > 50) {
        db.closedMessageDao().clear()
    }

    val sortedConversations = conversations
        .filter { x -> x.lastUpdate != null }
        .filter { x -> x.type != ConversationType.BLOCK_POPUP_SMALL.stringValue }
        .filter { x -> x.type != ConversationType.BLOCK_POPUP_BIG.stringValue }
        .sortedByDescending { x -> x.lastUpdate }

    for (conversation in sortedConversations) {
        if (conversation.id != null && conversation.unreadPartsCount > 0
            && closedMessages.findLast { x -> x.id == conversation.partLast?.id } == null
        ) {
            val lastMessage = if (conversation.partLast.actions.isNullOrEmpty()) {
                conversation.partLast
            } else {
                val noActionMessages = MessagesRepository.getInstance().getMessages()
                    .data
                    .filter { m -> m.conversation == conversation.id }
                    .filter { m -> m.actions == null || m.actions.isEmpty() }
                if (noActionMessages.isNotEmpty()) noActionMessages.last() else null
            }

            if (lastMessage != null
                && isNotRemoved(lastMessage)
                && (isRightDirection(lastMessage) || isFromBot(lastMessage))
            ) {
                return@withContext lastMessage
            }
        }
    }

    null
}

private fun isFromBot(message: MessageData): Boolean {
    if (message.sentVia == null || message.type == null) {
        return false
    }

    return message.sentVia.lowercase() == "message_chat_bot"
            && message.type.lowercase() == "chat_bot_admin"
}

private fun isNotRemoved(message: MessageData): Boolean {
    return message.removed == null
}

private fun isRightDirection(message: MessageData): Boolean {
    return message.direction == null || message.direction!!.lowercase(Locale.getDefault()) == "a2u"
}
