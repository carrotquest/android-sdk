package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.data.user.UserStateHolder
import io.carrotquest_sdk.android.lib.network.auth.JwtIdentityGuard

private const val TAG = "TokenFlow"

/**
 * Сохранение пары токенов, полученной РЕФРЕШЕМ, — в отличие от [saveJwtToken]/[saveRefreshToken],
 * применяет их только если они принадлежат текущему пользователю.
 *
 * Зачем. Токены лежат в глобальных ключах prefs, не привязанных к user_id, а рефреш умеют запускать
 * пять независимых мест (таймер, HTTP-интерсептор, реконнект RTS, загрузка сообщений, пре-auth).
 * Рефреш, стартовавший под прежней идентичностью и финишировавший уже после её смены (auth-склейка,
 * пересоздание сессии), затирал свежую пару старой — причём вместе с refresh-токеном, поэтому
 * сессия откатывалась на прежнего юзера НАВСЕГДА: каждый следующий рефреш воспроизводил его роль.
 * Снаружи это выглядело как «склейка не работает»: запросы идут к новому user_id, а токен — от
 * старого, сервер отвечает 403 PermissionDeniedError.
 *
 * Плановая смена идентичности (ответ /connect или /auth) сюда НЕ идёт — она приносит и нового юзера,
 * и его токены, и пишется напрямую через [saveJwtToken]/[saveRefreshToken].
 *
 * @return true, если пара применена.
 */
internal fun saveRefreshedTokens(access: String?, refresh: String?): Boolean {
    if (access.isNullOrEmpty()) return false

    val currentUserId = UserStateHolder.currentId()
    val owners = JwtIdentityGuard.tokenOwnerIds(access)

    // Владельца не распознали (легаси-токен, незнакомый формат) или юзера ещё нет — защищать нечего.
    if (currentUserId.isNotEmpty() && owners != null && currentUserId !in owners) {
        SdkLogger.log(
            SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
            "refreshed tokens DISCARDED: they belong to $owners, but the current user is " +
                "$currentUserId (identity changed while the refresh was in flight)",
        )
        return false
    }

    saveJwtToken(access)
    if (!refresh.isNullOrEmpty()) saveRefreshToken(refresh)
    return true
}
