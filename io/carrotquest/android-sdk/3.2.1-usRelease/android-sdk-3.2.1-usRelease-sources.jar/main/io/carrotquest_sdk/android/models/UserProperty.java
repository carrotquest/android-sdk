package io.carrotquest_sdk.android.models;

import androidx.annotation.Keep;

/**
 * A user property to set via Carrot.setUserProperty(...). Immutable; the same type is used by the
 * SDK end to end (there is no longer a separate internal copy).
 */
@Keep
public class UserProperty {

    private final Operation operation;
    private final String key;
    private final String value;

    public UserProperty(String key, String value) {
        this(Operation.UPDATE_OR_CREATE, key, value);
    }

    public UserProperty(Operation operation, String key, String value) {
        this.operation = operation != null ? operation : Operation.UPDATE_OR_CREATE;
        this.key = key;
        this.value = value;
    }

    public Operation getOperation() {
        return operation;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }
}
