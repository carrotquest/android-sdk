package io.carrotquest_sdk.android;

/**
 * Generic asynchronous result callback used across the SDK's public API.
 *
 * <p>The brand facades expose it under their own name as well — {@link Carrot.Callback} and
 * {@link Dashly.Callback} — so integrators can use the name that matches their product. All three
 * are interchangeable.
 *
 * @param <T> type of the successful result
 */
public interface Callback<T> {
    void onResponse(T result);

    void onFailure(Throwable t);
}