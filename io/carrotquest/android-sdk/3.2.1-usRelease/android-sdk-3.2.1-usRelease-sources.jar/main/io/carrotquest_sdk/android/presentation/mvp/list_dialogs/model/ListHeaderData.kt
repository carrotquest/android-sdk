package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model

import androidx.compose.runtime.Immutable

@Immutable
data class ListHeaderData(
    val appName: String = "",
    val statusMessage: String = "",   // полный on/offline message для шапки списка
    val isOnline: Boolean? = null,    // null = статус неизвестен
    val adminAvatarUrls: List<String> = emptyList(),
    val showPoweredBy: Boolean = false
)
