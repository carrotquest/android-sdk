package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.settings.SettingsManager
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val ANIM_ENTER_MS = 300
private const val ANIM_EXIT_MS = 250

/**
 * Боттомшит ошибки по вложению (слишком большой файл / неподдерживаемый тип / превышен лимит).
 * Визуально повторяет [MessageActionsBottomSheetActivity] (углы, фон, скрим, слайд, drag-handle),
 * а кнопка подтверждения стилизована под исходящий бабл чата (акцентный фон, скруглённые края).
 */
class ErrorBottomSheetActivity : AppCompatActivity() {

    companion object {
        private const val ARG_TITLE = "title"
        private const val ARG_MESSAGE = "message"

        fun intent(context: Context, title: String, message: String): Intent =
            Intent(context, ErrorBottomSheetActivity::class.java)
                .putExtra(ARG_TITLE, title)
                .putExtra(ARG_MESSAGE, message)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0) // анимацию окна делаем сами в Compose

        val title = intent.getStringExtra(ARG_TITLE) ?: ""
        val message = intent.getStringExtra(ARG_MESSAGE) ?: ""
        val isDark = getThemeUseCase(this) == ThemeSdk.DARK
        val accentColor = Color(resolveAccentColor())

        setContent {
            ErrorSheet(
                title = title,
                message = message,
                isDark = isDark,
                accentColor = accentColor,
                onFinish = { finish() },
            )
        }
    }

    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    // Акцентный цвет — той же формулой, что и тело чата (SdkContainerViewModel), чтобы Ok-кнопка
    // совпадала с цветом исходящего бабла. Standalone-активити, настройки читаем из репозитория/кэша.
    private fun resolveAccentColor(): Int {
        val settings = SettingsRepository.getInstance().getSettingsObject()
        val rawColor = (settings?.originalAppColor ?: settings?.appColor)?.takeIf { it.isNotEmpty() }
            ?: SharedPreferencesLib.getString(this, SettingsManager.CACHED_ORIGINAL_APP_COLOR).takeIf { !it.isNullOrEmpty() }
            ?: SharedPreferencesLib.getString(this, SettingsManager.CACHED_APP_COLOR).takeIf { !it.isNullOrEmpty() }
        val normalizedColor = rawColor?.removePrefix("#")?.takeIf { it.isNotEmpty() }
        return if (normalizedColor != null) {
            val contrastHex = AppColorUtils.getColorPalette(this, normalizedColor).contrastAccentColor
            "#$contrastHex".toColorInt()
        } else {
            ContextCompat.getColor(this, R.color.colorButton)
        }
    }
}

@Composable
private fun ErrorSheet(
    title: String,
    message: String,
    isDark: Boolean,
    accentColor: Color,
    onFinish: () -> Unit,
) {
    val surfaceColor = SdkColors.pageBackground(isDark)
    val titleColor = SdkColors.title(isDark)
    val scope = rememberCoroutineScope()

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    val dismiss: () -> Unit = {
        scope.launch {
            visible = false
            delay(ANIM_EXIT_MS.toLong())
            onFinish()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Скрим — только fade
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(ANIM_ENTER_MS)),
            exit = fadeOut(tween(ANIM_EXIT_MS)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SdkColors.scrim)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = dismiss,
                    )
            )
        }

        // Шторка — слайд снизу вверх
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically(tween(ANIM_ENTER_MS, easing = FastOutSlowInEasing)) { it } +
                    fadeIn(tween(ANIM_ENTER_MS)),
            exit = slideOutVertically(tween(ANIM_EXIT_MS, easing = FastOutSlowInEasing)) { it } +
                    fadeOut(tween(ANIM_EXIT_MS)),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(surfaceColor)
                    .navigationBarsPadding()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {},
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // Drag handle — как в actions-шите
                Box(
                    modifier = Modifier
                        .padding(top = 12.dp, bottom = 4.dp)
                        .size(32.dp, 4.dp)
                        .clip(CircleShape)
                        .background(titleColor.copy(alpha = 0.18f))
                )

                if (title.isNotBlank()) {
                    Text(
                        text = title,
                        color = titleColor,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 24.dp, end = 24.dp, top = 12.dp),
                    )
                }

                if (message.isNotBlank()) {
                    Text(
                        text = message,
                        color = titleColor.copy(alpha = 0.75f),
                        fontSize = 15.sp,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 24.dp, end = 24.dp, top = 8.dp),
                    )
                }

                // Кнопка Ok — стилизована под исходящий бабл чата (акцентный фон, скруглённые края,
                // текст в onAccent-цвете). По центру внизу.
                Box(
                    modifier = Modifier
                        .padding(top = 20.dp, bottom = 16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(accentColor)
                        .clickable(onClick = dismiss)
                        .padding(horizontal = 40.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(R.string.cq_ok_button),
                        color = SdkColors.onAccent(accentColor),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}
