package io.carrotquest_sdk.android.core.logging

/** Category of a log event, used for filtering/grouping. GENERAL is for untyped messages. */
enum class SdkLogCategory { GENERAL, NETWORK, CONNECTIVITY, AUTH, REALTIME, LIFECYCLE, DATABASE, PUSH }
