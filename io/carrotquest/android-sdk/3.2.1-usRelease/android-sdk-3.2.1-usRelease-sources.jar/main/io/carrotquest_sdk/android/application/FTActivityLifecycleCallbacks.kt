package io.carrotquest_sdk.android.application

import android.app.Activity
import android.app.Application
import android.os.Bundle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class FTActivityLifecycleCallbacks : Application.ActivityLifecycleCallbacks{
    private var currentActivity: Activity? = null
    // Замена BehaviorSubject.create() (ветка remove_rx, фаза 6): replay=1 реплеит последнюю Activity.
    private val currentActivityFlow = MutableSharedFlow<Activity>(replay = 1, extraBufferCapacity = 1)

    fun getCurrentActivity() = currentActivity

    override fun onActivityPaused(activity: Activity) {
        this.currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        this.currentActivity = activity
        if(activity != null) {
            currentActivityFlow.tryEmit(activity)
        }
    }

    override fun onActivityStarted(activity: Activity) {
        this.currentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
    }

    override fun onActivityStopped(activity: Activity) {
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        this.currentActivity = activity
    }

    // Поток смены текущей Activity (раньше subscribeOnChangeCurrentActivity → Disposable; remove_rx).
    fun currentActivityChanges(): Flow<Activity> = currentActivityFlow.asSharedFlow()
}