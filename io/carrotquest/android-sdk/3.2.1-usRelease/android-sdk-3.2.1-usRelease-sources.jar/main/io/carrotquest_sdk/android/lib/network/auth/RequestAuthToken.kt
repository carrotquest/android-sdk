package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.wss.jwt.getJwtToken

/**
 * Токен, который РЕАЛЬНО уходит в auth_token обычного запроса: приоритет — user.token (легаси
 * CarrotToken), фолбэк — глобальный JWT access.
 *
 * Единственное определение этого приоритета: им пользуются и сборка запроса (paramAdds), и проверка
 * инварианта идентичности. Раньше приоритет жил только внутри paramAdds, поэтому «чей токен уйдёт»
 * приходилось угадывать: при непустом user.token он затенял JWT-пару, и вердикт барьера идентичности
 * зависел от того, какое из двух хранилищ непусто (один и тот же запрос то проходил, то блокировался).
 */
internal fun effectiveRequestAuthToken(userToken: String?): String =
    if (!userToken.isNullOrEmpty()) userToken else getJwtToken()

/** [effectiveRequestAuthToken] для кода вне интерсептора: user.token читается из репозитория. */
internal fun currentRequestAuthToken(): String = effectiveRequestAuthToken(
    runCatching { CarrotLib.getLibComponents().userRep.user?.token }.getOrNull(),
)
