package io.carrotquest_sdk.android.presentation.chat

import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Строит «настоящую» звуковую волну из WAV-файла голосового сообщения.
 *
 * Поддерживается только несжатый WAV (PCM int 8/16/24/32 бит, IEEE float 32 бит) — именно
 * в таком формате SDK записывает голос. Любой другой формат, битый файл, сетевые/IO-ошибки
 * приводят к `null` — вызывающий код в этом случае рисует фиксированный паттерн-плейсхолдер.
 * Ничего не бросает наружу (всё обёрнуто в runCatching).
 */
internal object WaveformExtractor {

    data class Waveform(
        // Нормированные амплитуды столбиков (0..1), длина = barCount.
        val amplitudes: List<Float>,
        // Длительность по заголовку WAV (мс). 0 = не удалось посчитать.
        val durationMs: Int,
    )

    // Защита от OOM на патологически больших/некорректных файлах.
    private const val MAX_BYTES = 30 * 1024 * 1024
    // Минимальная высота столбика, чтобы тишина не выглядела пустотой.
    private const val MIN_BAR = 0.08f

    fun fromSource(url: String, barCount: Int): Waveform? = runCatching {
        if (url.isBlank() || barCount <= 0) return null
        val bytes = readBytes(url) ?: return null
        extract(bytes, barCount)
    }.getOrNull()

    // --- Чтение байтов (локальный файл или http) с ограничением размера ---

    private fun readBytes(url: String): ByteArray? = runCatching {
        val stream = if (url.startsWith("http://") || url.startsWith("https://")) {
            (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 15_000
            }.inputStream
        } else {
            val file = File(url.removePrefix("file://"))
            if (!file.exists()) return null
            file.inputStream()
        }
        stream.use { input ->
            val buffer = ByteArray(16 * 1024)
            val out = ByteArrayOutputStream()
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (out.size() + read > MAX_BYTES) return null // слишком большой — fallback
                out.write(buffer, 0, read)
            }
            out.toByteArray()
        }
    }.getOrNull()

    // --- Разбор WAV ---

    private fun extract(b: ByteArray, barCount: Int): Waveform? {
        if (b.size < 44) return null
        // RIFF .... WAVE
        if (!tagEquals(b, 0, "RIFF") || !tagEquals(b, 8, "WAVE")) return null

        var audioFormat = 0
        var channels = 0
        var sampleRate = 0
        var bitsPerSample = 0
        var dataStart = -1
        var dataSize = 0

        // Идём по чанкам начиная с offset 12.
        var offset = 12
        while (offset + 8 <= b.size) {
            val chunkSize = readU32LE(b, offset + 4)
            val body = offset + 8
            when {
                tagEquals(b, offset, "fmt ") && body + 16 <= b.size -> {
                    audioFormat = readU16LE(b, body)
                    channels = readU16LE(b, body + 2)
                    sampleRate = readU32LE(b, body + 4)
                    bitsPerSample = readU16LE(b, body + 14)
                }
                tagEquals(b, offset, "data") -> {
                    dataStart = body
                    dataSize = minOf(chunkSize, b.size - body) // защита от обрезанной загрузки
                }
            }
            if (dataStart >= 0 && sampleRate > 0) break
            // Чанки выровнены по чётной границе.
            offset = body + chunkSize + (chunkSize and 1)
            if (chunkSize <= 0) break // некорректный размер — не зацикливаемся
        }

        if (dataStart < 0 || sampleRate <= 0 || channels <= 0 || bitsPerSample <= 0) return null
        val bytesPerSample = bitsPerSample / 8
        if (bytesPerSample <= 0) return null
        val frameSize = bytesPerSample * channels
        if (frameSize <= 0) return null
        val totalFrames = dataSize / frameSize
        if (totalFrames <= 0) return null

        // Читалка одного сэмпла канала 0 → нормированное значение [-1, 1]. null = формат не поддержан.
        val sampleAt: (Int) -> Float = when {
            audioFormat == 1 && bitsPerSample == 16 -> { i -> readS16LE(b, i) / 32768f }
            audioFormat == 1 && bitsPerSample == 8  -> { i -> ((b[i].toInt() and 0xFF) - 128) / 128f } // 8-bit WAV беззнаковый
            audioFormat == 1 && bitsPerSample == 24 -> { i -> readS24LE(b, i) / 8_388_608f }
            audioFormat == 1 && bitsPerSample == 32 -> { i -> readS32LE(b, i) / 2_147_483_648f }
            audioFormat == 3 && bitsPerSample == 32 -> { i -> Float.fromBits(readS32LE(b, i)) }
            else -> return null
        }

        val peaks = FloatArray(barCount)
        for (bar in 0 until barCount) {
            val from = (bar.toLong() * totalFrames / barCount).toInt()
            val to = ((bar + 1).toLong() * totalFrames / barCount).toInt()
            // На больших бакетах прореживаем, чтобы не сканировать миллионы сэмплов.
            val step = maxOf(1, (to - from) / 1000)
            var peak = 0f
            var frame = from
            while (frame < to) {
                val sampleIndex = dataStart + frame * frameSize
                if (sampleIndex + bytesPerSample > b.size) break
                val v = kotlin.math.abs(sampleAt(sampleIndex))
                if (v > peak) peak = v
                frame += step
            }
            peaks[bar] = peak
        }

        val globalMax = peaks.maxOrNull() ?: 0f
        val amplitudes = if (globalMax <= 0f) {
            List(barCount) { MIN_BAR }
        } else {
            peaks.map { (it / globalMax).coerceIn(MIN_BAR, 1f) }
        }

        val durationMs = (totalFrames.toLong() * 1000 / sampleRate).toInt()
        return Waveform(amplitudes = amplitudes, durationMs = durationMs)
    }

    // --- low-level чтение little-endian ---

    private fun tagEquals(b: ByteArray, offset: Int, tag: String): Boolean {
        if (offset + tag.length > b.size) return false
        for (i in tag.indices) if (b[offset + i].toInt() != tag[i].code) return false
        return true
    }

    private fun readU16LE(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8)

    private fun readU32LE(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or
            ((b[i + 1].toInt() and 0xFF) shl 8) or
            ((b[i + 2].toInt() and 0xFF) shl 16) or
            ((b[i + 3].toInt() and 0xFF) shl 24)

    private fun readS16LE(b: ByteArray, i: Int): Int =
        readU16LE(b, i).toShort().toInt()

    private fun readS24LE(b: ByteArray, i: Int): Int {
        val v = (b[i].toInt() and 0xFF) or
            ((b[i + 1].toInt() and 0xFF) shl 8) or
            ((b[i + 2].toInt() and 0xFF) shl 16)
        // знаковое расширение из 24 в 32 бита
        return if (v and 0x800000 != 0) v or -0x1000000 else v
    }

    private fun readS32LE(b: ByteArray, i: Int): Int = readU32LE(b, i)
}