package io.carrotquest_sdk.android.lib.network.deserializers;

import android.util.Log;

import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse;
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthData;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;
import io.carrotquest_sdk.android.lib.wss.jwt.SaveJwtTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.jwt.SaveRefreshTokenUseCaseKt;

import com.google.gson.*;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class AuthDeserializer implements JsonDeserializer<AuthResponse> {
    public AuthDeserializer() {
    }

    @Override
    public AuthResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        AuthResponse response = new AuthResponse();
        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("AuthDeserializer. meta is null or dataJsonElement is null");
        }

        JsonElement metaJsonElement = json.getAsJsonObject().get(F.META);
        JsonElement dataJsonElement = json.getAsJsonObject().get(F.DATA);

        try {
            Meta meta = new Gson().fromJson(metaJsonElement, Meta.class);
            response.setMeta(meta);

            AuthData data = new AuthData();
            String authToken = "";
            if(dataJsonElement.getAsJsonObject().has(F.AUTH_TOKEN)) {
                if(dataJsonElement.getAsJsonObject().get(F.AUTH_TOKEN).isJsonObject()) {
                    JsonObject authTokenJO = dataJsonElement.getAsJsonObject().get(F.AUTH_TOKEN).getAsJsonObject();
                    if (authTokenJO != null && !authTokenJO.isJsonNull() && authTokenJO.has(F.ACCESS)) {
                        // Только парсим — сохраняет токены CarrotService.performAuth, когда ответ
                        // реально применён. Запись прямо во время парсинга подменяла глобальную
                        // пару токенов ещё до того, как вызывающий код увидел ответ.
                        authToken = authTokenJO.get(F.ACCESS).getAsString();

                        if(authTokenJO.has(F.REFRESH)) {
                            data.setRefreshToken(authTokenJO.get(F.REFRESH).getAsString());
                        }
                    }
                } else {
                    authToken = dataJsonElement.getAsJsonObject().get(F.AUTH_TOKEN).getAsString();
                }
            } else {
                throw new JsonParseException("AUTH_TOKEN is null");
            }

            if(!authToken.isEmpty()) {
                data.setAuthToken(authToken);
            }


            if(GsonUtil.jsonElementNotNull(dataJsonElement.getAsJsonObject(), F.USER)) {
                JsonObject joUser = dataJsonElement.getAsJsonObject().getAsJsonObject(F.USER);
                if (joUser != null) {
                    User user = new User();
                    if(GsonUtil.jsonElementNotNull(joUser, F.ID)) {
                        user.setId(joUser.get(F.ID).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joUser, F.AUTH_TOKEN)) {
                        user.setToken(joUser.get(F.AUTH_TOKEN).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joUser, F.IS_BANNED)) {
                        user.setBanned(joUser.get(F.IS_BANNED).getAsBoolean());
                    }

                    if(GsonUtil.jsonElementNotNull(joUser, F.HAS_CONVERSATIONS)) {
                        user.setHasConversations(joUser.get(F.HAS_CONVERSATIONS).getAsBoolean());
                    }

                    if (GsonUtil.jsonElementNotNull(joUser, F.CONVERSATIONS_UNREAD)) {
                        ArrayList<String> unreadConversationsArray = new ArrayList<>();
                        JsonArray unreadConversationsJsArray = joUser.get(F.CONVERSATIONS_UNREAD).getAsJsonArray();
                        if(!unreadConversationsJsArray.isJsonNull()) {
                            for(JsonElement element : unreadConversationsJsArray) {
                                unreadConversationsArray.add(element.getAsString());
                            }
                        }
                        user.setConversationsUnread(unreadConversationsArray);
                    } else {
                        user.setConversationsUnread(new ArrayList<>());
                    }
                    data.setUser(user);

                    // Флаги согласий пользователя — переносим в настройки после auth (см. performAuth),
                    // иначе плашка согласия показывается повторно на данных предыдущего пользователя.
                    if (GsonUtil.jsonElementNotNull(joUser, "data_processing_policy_is_allowed")) {
                        data.setDataProcessingPolicyIsAllowed(joUser.get("data_processing_policy_is_allowed").getAsBoolean());
                    }
                    if (GsonUtil.jsonElementNotNull(joUser, "email_storage_is_allowed")) {
                        data.setEmailStorageIsAllowed(joUser.get("email_storage_is_allowed").getAsBoolean());
                    }
                    if (GsonUtil.jsonElementNotNull(joUser, "phone_storage_is_allowed")) {
                        data.setPhoneStorageIsAllowed(joUser.get("phone_storage_is_allowed").getAsBoolean());
                    }
                }
            }

            if(GsonUtil.jsonElementNotNull(dataJsonElement.getAsJsonObject(), F.RESULT)) {
                JsonElement jsResult = dataJsonElement.getAsJsonObject().get(F.RESULT);
                if(jsResult.isJsonPrimitive()) {
                    data.setResult(jsResult.getAsString());
                }
            }

            response.setData(data);

            return response;
        }
        catch (JsonParseException e) {

            return new GsonBuilder().create().fromJson(json, AuthResponse.class);
        }
    }
}