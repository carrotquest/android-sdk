package io.carrotquest_sdk.android.presentation.mvp.button.presenter

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.TypedArray
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.text.Html
import android.text.TextUtils
import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.CarrotState
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.conversationsFlow
import io.carrotquest_sdk.android.domain.use_cases.conversations.currentConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.getLastConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.notPopup
import io.carrotquest_sdk.android.domain.use_cases.conversations.unread
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.closeLastMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getLastUnreadMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.openConversation
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettingsSuspend
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.button.model.FloatingButtonViewModel
import io.carrotquest_sdk.android.presentation.mvp.button.model.StateLastMessage
import io.carrotquest_sdk.android.presentation.mvp.button.view.FloatingButton
import io.carrotquest_sdk.android.presentation.mvp.button.view.LocationFloatingButton
import io.carrotquest_sdk.android.presentation.container.SdkContainerActivity
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class FloatingButtonPresenter : BasePresenter() {

    private val tag = "FloatingButtonPresenter"
    // Корутинная замена compositeDisposable (ветка remove_rx, фаза 7), на Main.
    private var presenterScope = sdkScope(SdkDispatchers.main)
    // Подписка на NetworkManager: collect живёт на скоупе менеджера (до deInit), поэтому отменяем
    // в onDestroy, иначе держит view (утечка). Раньше — Rx Disposable.
    private var networkCancellable: Cancellable? = null
    private val viewModel = FloatingButtonViewModel.getInstance()

    private var state: StateFabButton = StateFabButton.COLLAPSED
    private var isSetAttributes = false

    fun onStart() {
        getView()?.doGone()
        presenterScope.launch {
            // Внутренний поток состояния SDK (публичный Carrot.getStateFlow() убран из API).
            SdkStateManager.publicState
                .map { it is CarrotState.Ready }
                .distinctUntilChanged()
                .collect { isInit ->
                when (isInit) {
                    true -> {
                        initThis()

                        try {
                            // suspend getCurrentUser + loadConversations (последняя сама сохраняет в repo).
                            val user = getCurrentUser()
                            if (user != null) loadConversations(user.id)
                        } catch (t: Throwable) {
                            Log.e(tag, t)
                        }

                        getView()?.initView()
                        getView()?.show()
                    }
                    else -> {
                        getView()?.hide()
                    }
                }
            }
        }
    }

    fun onCreatedView() {
        subscribeOnLastUnreadMessage()
        presenterScope.launch {
            try {
                ConversationsRepository.getInstance().newConversationFlow.collect {
                    updateButtonView(ConversationsRepository.getInstance().getConversationsSync())
                }
            } catch (t: Throwable) {
                Log.e(tag, t)
            }
        }

        val ctx = getView()?.context ?: return
        // Отписку храним и отменяем в onDestroy — иначе collect живёт на скоупе менеджера до
        // deInit SDK и держит view (утечка). Перед повторной подпиской отменяем прежнюю.
        networkCancellable?.cancel()
        networkCancellable = NetworkManager.getInstance(ctx).addObserver { isConnect ->
            if (viewModel.isAutoHide()) {
                if (isConnect) {
                    getView()?.show()
                    if (viewModel.getLastMessage().state == StateLastMessage.HIDDEN) {
                        getView()?.showLastMessage()
                        viewModel.updateStateLastMessage(StateLastMessage.SHOW)
                    }
                } else {
                    getView()?.hide()
                    if (viewModel.getLastMessage().state == StateLastMessage.SHOW) {
                        getView()?.hideLastMessage()
                        viewModel.updateStateLastMessage(StateLastMessage.HIDDEN)
                    }
                }
            }
        }
    }

    fun onTapFloatingButton() {
        state = when (state) {
            StateFabButton.COLLAPSED -> {
                getView()?.updateTheme(getThemeUseCase(getView()?.context))

                expandButton()
                StateFabButton.EXPANDED
            }
            StateFabButton.EXPANDED -> {
                collapseButton()
                goToLastDialog()
                StateFabButton.COLLAPSED
            }
            StateFabButton.NOT_SOCIAL_NETWORKS -> {
                goToLastDialog()
                StateFabButton.NOT_SOCIAL_NETWORKS
            }
        }
    }

    fun onTapLastMessage() {
        presenterScope.launch {
            try {
                val message = getLastUnreadMessage()
                if (message != null) {
                    openConversation(message.conversation ?: "")
                }
            } catch (e: Throwable) {
            }
        }
    }

    private fun openSocialLink(baseUrlRes: Int, link: String?) {
        if (TextUtils.isEmpty(link)) return
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(getView()?.context?.getString(baseUrlRes) + link))
        getView()?.context?.startActivity(intent)
    }

    private fun onTapSocial(open: (SettingsEntity) -> Unit) {
        tapOnSocialNetworkButton()
        presenterScope.launch {
            try {
                val settings = getSettingsSuspend()
                if (settings != null) open(settings)
            } catch (e: Throwable) {
                Log.e(tag, e)
            }
        }
    }

    fun onTapFB() = onTapSocial { openSocialLink(R.string.facebook_base_url_str, it.textLinkFB) }

    fun onTapTelegram() = onTapSocial { openSocialLink(R.string.telegram_base_url_str, it.textLinkTelegram) }

    fun onTapViber() = onTapSocial {
        if (getView() != null) openSocialLink(R.string.viber_base_url_str, it.textLinkViber)
    }

    fun onTapVK() = onTapSocial { openSocialLink(R.string.vk_base_url_str, it.textLinkVK) }

    fun onTapInstagram() = onTapSocial { openSocialLink(R.string.instagram_base_url_str, it.textLinkInstagram) }

    fun onTapWhatsapp() = onTapSocial { openSocialLink(R.string.whatsapp_base_url_str, it.textLinkWhatsapp) }

    fun onTapEmptySpace() {
        if (state == StateFabButton.EXPANDED) {
            state = StateFabButton.COLLAPSED
            collapseButton()
        }
    }

    fun onTapCloseLastMessage() {
        presenterScope.launch {
            try {
                closeLastMessage(getLastUnreadMessage())
            } catch (e: Throwable) {
                // ниже всё равно закрываем — поведение как у оригинального doOnError
            }
            getView()?.hideLastMessage()
            viewModel.updateStateLastMessage(StateLastMessage.CLOSED)
        }
    }

    fun onCollapseEnd() {
        val ctx = getView()?.context ?: return
        if (viewModel.getLastMessage().state == StateLastMessage.HIDDEN
            && NetworkManager.getInstance(ctx).hasConnect) {
            getView()?.showLastMessage()
        }
    }

    fun onDestroy() {
        networkCancellable?.cancel()
        networkCancellable = null
        presenterScope.cancel()
        presenterScope = sdkScope(SdkDispatchers.main)

        super.detachView()
        state = StateFabButton.COLLAPSED
    }

    override fun getView(): FloatingButton? {
        return super.getView() as FloatingButton?
    }

    private fun initThis() {
        presenterScope.launch {
            try {
                val settings = getSettingsSuspend()
                if (settings != null) {
                    state = if (hasSocialNetwork(settings)) {
                        StateFabButton.COLLAPSED
                    } else {
                        StateFabButton.NOT_SOCIAL_NETWORKS
                    }
                    try {
                        getView()?.updateTheme(getThemeUseCase(getView()?.context))

                        val buttonBkg = ColorStateList.valueOf(Color.parseColor("#" + settings.originalAppColor))
                        getView()?.updateColor(buttonBkg)
                        getView()?.doVisible()
                    } catch (e: Exception) {
                        Log.e(tag, e)
                    }
                }
            } catch (error: Throwable) {
                Log.e(tag, error)
                getView()?.doGone()
            }
        }
    }

    private fun updateButtonView(conversations: ArrayList<DataConversation>) {
        presenterScope.launch {
            try {
                val unread = conversations.notPopup().unread()
                val size = unread.size
                if (size > 0) {
                    getView()?.showUnreadCounter()
                    try {
                        updateLastMessage(getLastUnreadMessage())
                    } catch (e: Throwable) {
                        Log.e(tag, e)
                    }
                } else {
                    getView()?.hideUnreadCounter()
                    getView()?.hideLastMessage()
                    viewModel.updateStateLastMessage(StateLastMessage.UNKNOWN)
                    viewModel.updateAdminIconLastMessage("")
                    viewModel.updateTextLastMessage("")
                }
                getView()?.updateUnreadCount(size.toString())
            } catch (e: Throwable) {
                Log.e(tag, e)
            }
        }
    }

    private fun subscribeOnLastUnreadMessage() {
        presenterScope.launch {
            try {
                conversationsFlow().collect {
                    updateButtonView(ArrayList(it))
                }
            } catch (t: Throwable) {
                Log.e(tag, t)
            }
        }
    }

    private fun updateLastMessage(lastUnreadMessage: MessageData?) {
        if (lastUnreadMessage != null) {
            var updatedText: String = when(lastUnreadMessage.type) {
                ResponseFields.ARTICLE -> lastUnreadMessage.bodyJson?.asJsonObject?.get(F.NAME)?.asString ?: ""
                ResponseFields.VOTE -> getView()?.context?.getString(R.string.plese_vote_operator) ?: ""
                else -> lastUnreadMessage.body ?: ""
            }

            val needShowAvatar = when(lastUnreadMessage.type) {
                ResponseFields.VOTE -> false
                else -> true
            }

            updatedText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(updatedText, Html.FROM_HTML_MODE_LEGACY).toString()
            } else {
                Html.fromHtml(updatedText).toString()
            }

            updatedText = updatedText.replace(160.toChar(), 32.toChar()).replace(65532.toChar(), 32.toChar()).trim()
            updatedText = EmojiParser.parseToUnicode(updatedText)
            if (TextUtils.isEmpty(updatedText)) {
                updatedText = "..."
            }

            getView()?.updateTextLastMessage(updatedText)
            viewModel.updateTextLastMessage(updatedText)

            val admin = lastUnreadMessage.messageFrom
            viewModel.updateAdminIconLastMessage(admin?.avatar ?: "")
            if (admin?.avatar != null) {
                getView()?.updateLastAdminIcon(admin.avatar!!)
            }

            if (viewModel.getLastMessage().state != StateLastMessage.HIDDEN) {
                if(needShowAvatar) {
                    getView()?.showLastMessage()
                } else {
                    getView()?.showLastMessageWithoutAvatar()
                }
                viewModel.updateStateLastMessage(StateLastMessage.SHOW)
            }

        } else {
            getView()?.hideLastMessage()
            viewModel.updateStateLastMessage(StateLastMessage.UNKNOWN)
        }
    }

    private fun expandButton() {
        getView()?.expand()
        presenterScope.launch {
            try {
                val settings = getSettingsSuspend()
                run {
                                if (settings != null) {
                                    if (settings.isShowFB) {
                                        getView()?.showFbButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showFbLabelButton()
                                        }
                                    }
                                    if (settings.isShowVK) {
                                        getView()?.showVkButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showVkLabelButton()
                                        }
                                    }
                                    if (settings.isShowTelegram) {
                                        getView()?.showTelegramButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showTelegramLabelButton()
                                        }
                                    }
                                    if (settings.isShowViber) {
                                        getView()?.showViberButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showViberLabelButton()
                                        }
                                    }
                                    if (settings.isShowInstagram) {
                                        getView()?.showInstagramButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showInstagramLabelButton()
                                        }
                                    }
                                    if (settings.isShowWhatsapp) {
                                        getView()?.showWhatsappButton()
                                        if (viewModel.getFlagShowSocialLabels()) {
                                            getView()?.showWhatsappLabelButton()
                                        }
                                    }

                                }
                                if (viewModel.getLastMessage().state == StateLastMessage.SHOW) {
                                    viewModel.updateStateLastMessage(StateLastMessage.HIDDEN)
                                }
                                if (viewModel.getFlagShowSocialLabels()) {
                                    getView()?.showOpenChatLabel()
                                }
                            }
            } catch (e: Throwable) {
                Log.e(tag, e)
            }
        }
    }

    private fun collapseButton() {
        hideSocialNetworks()
        getView()?.collapse()
    }

    private fun hideSocialNetworks() {
        getView()?.hideFbButton()
        getView()?.hideFbLabelButton()

        getView()?.hideVkButton()
        getView()?.hideVkLabelButton()

        getView()?.hideTelegramButton()
        getView()?.hideTelegramLabelButton()

        getView()?.hideViberButton()
        getView()?.hideViberLabelButton()

        getView()?.hideInstagramButton()
        getView()?.hideInstagramLabelButton()

        getView()?.hideWhatsappButton()
        getView()?.hideWhatsappLabelButton()

        getView()?.hideOpenChatLabel()
    }

    private fun goToLastDialog() {
        presenterScope.launch {
            try {
                val conversationId = getLastConversation()?.id ?: ""
                if (conversationId != "") {
                    openConversationById(conversationId)
                } else {
                    try {
                        val conversations = currentConversations()
                        if (conversations.isNotEmpty()) {
                            var savedConvId = false
                            for (conv in conversations) {
                                if (conv.type != ConversationType.BLOCK_POPUP_SMALL.stringValue
                                    && conv.type != ConversationType.BLOCK_POPUP_BIG.stringValue
                                ) {
                                    openConversationById(conv.id)
                                    savedConvId = true
                                    break
                                }
                            }
                            if (!savedConvId) {
                                openConversationById("")
                            }
                        } else {
                            openConversationById("")
                        }
                    } catch (t: Throwable) {
                        Log.e(tag, t)
                    }
                }
            } catch (e: Throwable) {
                Log.e(tag, e)
            }
        }
    }

    private fun openConversationById(conversationId: String) {
        presenterScope.launch {
            try { openConversation(conversationId) } catch (_: Throwable) {}
        }
        openConversation(conversationId)
    }

    private fun openConversation(conversationId: String) {
        val intent = Intent(getView()?.context, SdkContainerActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        intent.putExtra(SdkContainerActivity.CONVERSATION_ID_ARG, conversationId)
        getView()?.context?.startActivity(intent)
    }

    private fun tapOnSocialNetworkButton() {
        collapseButton()
        state = StateFabButton.COLLAPSED
    }

    private fun hasSocialNetwork(settingsEntity: SettingsEntity?): Boolean {
        if (settingsEntity == null) {
            return false
        }
        return settingsEntity.isShowFB
                || settingsEntity.isShowTelegram
                || settingsEntity.isShowVK
                || settingsEntity.isShowViber
                || settingsEntity.isShowInstagram
                || settingsEntity.isShowWhatsapp
    }

    @SuppressLint("Recycle")
    fun onSetAttributes(typedArray: TypedArray) {
        if (!isSetAttributes) {
            isSetAttributes = true

            var locationFloatingButton = LocationFloatingButton.BOTTOM_RIGHT
            var isShowSocialLabels = true
            var iconFloatingButtonOnExpandState = getView()?.resources?.getDrawable(R.drawable.ic_cq_message)
            var marginFAB = GraphicUtils.dpToPx(getView()?.context, 16.0f).toFloat()
            var autoHide = false

            val attrsCount = typedArray.indexCount
            if (attrsCount > 0) {
                for (i in 0 until attrsCount) {
                    val attr = typedArray.getIndex(i)

                    if (attr == R.styleable.FloatingButton_cq_location_fab) {
                        val locationId = typedArray.getInt(attr, 0)
                        locationFloatingButton = LocationFloatingButton.fromId(locationId)
                    } else if (attr == R.styleable.FloatingButton_cq_margin_fab) {
                        marginFAB = typedArray.getDimension(attr, marginFAB)
                    } else if (attr == R.styleable.FloatingButton_cq_icon_fab) {
                        iconFloatingButtonOnExpandState = typedArray.getDrawable(attr)
                    } else if (attr == R.styleable.FloatingButton_cq_visibility_background) {
                        val visibilityBack = typedArray.getBoolean(attr, true)
                        if (!visibilityBack) {
                            getView()?.updateMainBackgroundAlpha(0.0f)
                        }
                    } else if (attr == R.styleable.FloatingButton_cq_auto_hide_fab) {
                        autoHide = typedArray.getBoolean(attr, false)
                    } else if (attr == R.styleable.FloatingButton_cq_show_social_labels) {
                        isShowSocialLabels = typedArray.getBoolean(attr, true)
                    }
                }
            }

            viewModel.updateAutoHide(autoHide)
            viewModel.updateFlagShowSocialLabels(isShowSocialLabels)
            getView()?.updateIconOnFloatingButton(iconFloatingButtonOnExpandState)
            getView()?.setLocationFloatingButton(locationFloatingButton)
            getView()?.setMarginFloatingButton(marginFAB)
        }
    }

    fun onHideButton() {
        if (viewModel.getLastMessage().state == StateLastMessage.SHOW) {
            getView()?.hideLastMessage()
            viewModel.getLastMessage().state = StateLastMessage.HIDDEN
        }
    }

    fun onShowButton() {
        if (viewModel.getLastMessage().state == StateLastMessage.HIDDEN) {
            getView()?.showLastMessage()
            viewModel.getLastMessage().state = StateLastMessage.SHOW
        }
    }

    internal enum class StateFabButton {
        COLLAPSED,
        EXPANDED,
        NOT_SOCIAL_NETWORKS
    }
}