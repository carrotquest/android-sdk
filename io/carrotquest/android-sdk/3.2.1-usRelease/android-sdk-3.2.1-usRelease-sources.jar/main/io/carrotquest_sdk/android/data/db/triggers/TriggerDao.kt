package io.carrotquest_sdk.android.data.db.triggers

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TriggerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(triggers: List<TriggerDbEntity>)

    @Query("SELECT * FROM triggerdbentity")
    fun getAll(): Flow<List<TriggerDbEntity>>

    @Query("DELETE FROM triggerdbentity")
    fun deleteAll()
}