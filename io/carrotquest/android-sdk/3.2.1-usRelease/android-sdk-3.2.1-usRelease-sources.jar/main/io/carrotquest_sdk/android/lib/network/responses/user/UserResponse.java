package io.carrotquest_sdk.android.lib.network.responses.user;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;
import io.carrotquest_sdk.android.lib.network.responses.base.IBaseResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;

@Keep
public class UserResponse implements IBaseResponse {

    @SerializedName(F.META)
    private Meta meta;
    @SerializedName(F.DATA)
    private UserData data;

    @Override
    public UserData getData() {
        return data;
    }

    @Override
    public Meta getMeta() {
        return meta;
    }

    @Override
    public void setData(Data data) {
        if(data instanceof UserData) {
            this.data = (UserData) data;
        }
    }

    @Override
    public void setMeta(Meta meta) {
    this.meta = meta;
    }
}
