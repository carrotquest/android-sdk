package io.carrotquest_sdk.android.core.connection

import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.data.network.wss_responses.RtsMessageFactory
import io.carrotquest_sdk.android.domain.use_cases.rts.getRtsHost
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.wss.Channel
import io.carrotquest_sdk.android.lib.wss.ChannelEnum
import io.carrotquest_sdk.android.lib.wss.IWssService
import io.carrotquest_sdk.android.lib.wss.WssMessageListener
import io.carrotquest_sdk.android.lib.wss.jwt.JwtWssService

internal object WssManager {

    private const val TAG = "WssManager"
    private var wssService: IWssService? = null

    fun start(appId: String, userId: String) {
        stop()
        val context = CarrotLib.getLibComponents().context
        val host = getRtsHost(context)
        wssService = JwtWssService(context, host)

        val params = mutableListOf(userId)
        val channels = mutableListOf(
            Channel(ChannelEnum.ping),
            Channel(ChannelEnum.conversation_typing, params),
            Channel(ChannelEnum.conversation, params),
            Channel(ChannelEnum.message_conversation_started, params),
            Channel(ChannelEnum.conversation_read, params),
            Channel(ChannelEnum.conversation_reply, params),
            Channel(ChannelEnum.run_script, params),
            Channel(ChannelEnum.user_ban, params),
            Channel(ChannelEnum.users_removed, params),
            Channel(ChannelEnum.app_online_changed),
            Channel(ChannelEnum.conversation_reply_changed, params),
            Channel(ChannelEnum.chat_bot_conversation_finished, params),
            Channel(ChannelEnum.conversation_parts_batch, params)
        )

        val listener = WssMessageListener { response ->
            // Конкретное сообщение может сломать процессинг (malformed JSON, NPE внутри
            // .process()). Глотаем на уровне пакета — подписка продолжает работать,
            // остальные WSS-события обрабатываются штатно.
            try {
                RtsMessageFactory.createResponse(response)?.process()
            } catch (t: Throwable) {
                SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.REALTIME, TAG, "WSS message processing failed, skipping", t)
            }
        }

        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.REALTIME, TAG, "RTS: starting subscription (appId=$appId, channels=${channels.size})")
        wssService!!.stopSocket(appId)
        wssService!!.startSocket(appId, channels, listener)
    }

    fun stop() {
        if (wssService != null) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.REALTIME, TAG, "RTS: stopping")
        }
        wssService?.deInit()
        wssService = null
    }
}
