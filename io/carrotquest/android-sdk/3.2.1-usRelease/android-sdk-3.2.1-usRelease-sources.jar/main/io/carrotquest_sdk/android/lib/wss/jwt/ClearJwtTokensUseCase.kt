package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.repositories.IUserRepository
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

private const val TAG = "TokenFlow"

/**
 * Полностью сбрасывает persisted JWT-креды, чтобы следующий /connect начал свежую сессию.
 *
 * Важно: чистим не только новые JWT-ключи, но и легаси "CarrotToken". Легаси-ключ переживал
 * прежние частичные очистки токенов (ConnectionManager чистил только jwt/refresh) и мог
 * "воскрешать" мёртвый токен через refresh-fallback в RetrofitModule.paramAdds, а также через
 * UserRepository.loadUser(). Из-за этого протухшая авторизация залипала до переустановки —
 * после сброса достаточно перезапуска приложения.
 */
fun clearJwtTokens(context: Context = CarrotLib.getLibComponents().getContext()) {
    SdkLogger.log(
        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
        "clearJwtTokens: wiping access+refresh+CarrotToken. Before: ${tokenStateSummary()}",
    )
    SharedPreferencesLib.saveString(context, jwtTokenKey, "")
    SharedPreferencesLib.saveString(context, refreshTokenKey, "")
    SharedPreferencesLib.clearPreference(context, jwtTokenUpdateTimeStampKey)
    SharedPreferencesLib.clearPreference(context, refreshTokenUpdateTimeStampKey)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN)
}

/**
 * Полный сброс кред для пересоздания сессии: [clearJwtTokens] + обнуление `user.token`.
 *
 * [clearJwtTokens] НАМЕРЕННО не трогает `user.token` (он подставляется как `auth_token` обычных
 * запросов в RetrofitModule.paramAdds). Поэтому каждый, кто хочет «полностью сбросить авторизацию»,
 * обязан дополнительно обнулить `user.token`, иначе следующий /connect/запрос уйдёт со старым
 * auth_token. Раньше этот двухшаговый идиом был скопирован в 4 местах и норовил разъехаться —
 * собрано здесь в одну точку.
 */
fun clearAllCreds(
    userRepository: IUserRepository,
    context: Context = CarrotLib.getLibComponents().getContext(),
) {
    clearJwtTokens(context)
    userRepository.getUser()?.let { user ->
        user.token = ""
        userRepository.saveUser(user)
    }
}
