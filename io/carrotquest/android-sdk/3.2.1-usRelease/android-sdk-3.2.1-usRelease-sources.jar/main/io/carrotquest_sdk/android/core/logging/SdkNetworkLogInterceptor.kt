package io.carrotquest_sdk.android.core.logging

import okhttp3.Headers
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

// Секретные query-параметры и заголовки — маскируются, если includeSensitive выключен.
private val SENSITIVE_QUERY = setOf("auth_token", "carrotquest_auth_token", "api_key", "access_token", "user_auth_key")
private val SENSITIVE_HEADERS = setOf("authorization", "cookie", "set-cookie", "proxy-authorization")

/**
 * Структурный лог сетевых запросов через [SdkLogger] (категория NETWORK). Ставится ПЕРВЫМ в цепочке
 * application-интерсепторов, поэтому видит запрос до того, как SDK подставит auth_token глубже —
 * токен в URL обычно не попадает. На всякий случай секретные query-параметры всё равно маскируются.
 *
 * Уровни: успешный ответ (2xx/3xx) — DEBUG (сводка метод/URL/код/время/размеры); HTTP-ошибка
 * (4xx/5xx) и обрыв соединения — WARN (поэтому видны в персистентном буфере/снапшоте даже при
 * выключенном output); VERBOSE — плюс заголовки (секретные маскируются). Тело не логируется.
 */
internal class SdkNetworkLogInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val startNs = System.nanoTime()

        val response: Response = try {
            chain.proceed(request)
        } catch (e: IOException) {
            val ms = (System.nanoTime() - startNs) / 1_000_000
            val url = redactUrlForLog(request.url, SdkLogger.isIncludeSensitive())
            if (chain.call().isCanceled()) {
                // Штатная отмена вызова (call.cancel() из-за отмены корутины: суперседнутый запрос,
                // смена экрана, deInit/re-init). OkHttp сообщает о ней через IOException("Canceled").
                // Это НЕ сетевой сбой — не шумим WARN-ом со стектрейсом в персистентный буфер
                // диагностики, пишем DEBUG (виден только при поднятом уровне логов).
                SdkLogger.log(
                    SdkLogLevel.DEBUG, SdkLogCategory.NETWORK, TAG,
                    "${request.method} $url canceled (${ms}ms)",
                )
            } else {
                // Реальный обрыв/таймаут соединения — WARN (попадает в персистентный буфер диагностики).
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG,
                    "${request.method} $url | failed (${ms}ms): ${e.message}",
                    throwable = e,
                    fields = mapOf("method" to request.method, "url" to url, "error" to (e.message ?: "")),
                )
            }
            throw e
        }

        val ms = (System.nanoTime() - startNs) / 1_000_000
        // HTTP 4xx/5xx → WARN (виден в буфере/снапшоте даже при выключенном output); иначе DEBUG.
        val level = if (response.code in 400..599) SdkLogLevel.WARN else SdkLogLevel.DEBUG
        // Строим строку только если она куда-то пойдёт: WARN всегда (captured в буфер),
        // DEBUG — лишь когда output включён. Успешный запрос при выключенных логах = нулевой оверхед.
        if (level == SdkLogLevel.WARN || SdkLogger.isEnabled(SdkLogLevel.DEBUG)) {
            val url = redactUrlForLog(request.url, SdkLogger.isIncludeSensitive())
            val fields = LinkedHashMap<String, String>()
            fields["method"] = request.method
            fields["url"] = url
            fields["status"] = response.code.toString()
            fields["durationMs"] = ms.toString()
            request.body?.contentLength()?.takeIf { it >= 0 }?.let { fields["reqBytes"] = it.toString() }
            response.body?.contentLength()?.takeIf { it >= 0 }?.let { fields["respBytes"] = it.toString() }
            if (SdkLogger.isEnabled(SdkLogLevel.VERBOSE)) {
                fields["reqHeaders"] = redactHeadersForLog(request.headers, SdkLogger.isIncludeSensitive())
                fields["respHeaders"] = redactHeadersForLog(response.headers, SdkLogger.isIncludeSensitive())
            }
            SdkLogger.log(
                level, SdkLogCategory.NETWORK, TAG,
                "${request.method} $url -> ${response.code} (${ms}ms)",
                fields = fields,
            )
        }
        return response
    }

    private companion object {
        const val TAG = "Network"
    }
}

/** URL для лога: при выключенном [includeSensitive] значения секретных query-параметров маскируются. */
internal fun redactUrlForLog(url: HttpUrl, includeSensitive: Boolean): String {
    if (includeSensitive) return url.toString()
    val names = url.queryParameterNames
    if (names.none { it.lowercase() in SENSITIVE_QUERY }) return url.toString()
    val builder = url.newBuilder().query(null)
    for (name in names) {
        val sensitive = name.lowercase() in SENSITIVE_QUERY
        for (value in url.queryParameterValues(name)) {
            builder.addQueryParameter(name, if (sensitive) Redactor.token(value, false) else value)
        }
    }
    return builder.build().toString()
}

/** Заголовки для лога: при выключенном [includeSensitive] значения секретных заголовков маскируются. */
internal fun redactHeadersForLog(headers: Headers, includeSensitive: Boolean): String = buildString {
    for (i in 0 until headers.size) {
        val name = headers.name(i)
        val value = headers.value(i)
        val masked = !includeSensitive && name.lowercase() in SENSITIVE_HEADERS
        if (isNotEmpty()) append("; ")
        append(name).append(": ").append(if (masked) Redactor.token(value, false) else value)
    }
}
