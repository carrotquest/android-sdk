package io.carrotquest_sdk.android.data.network.wss_responses

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import kotlinx.coroutines.launch

class AppOnlineChanged : IRtsMessage {
    private val tag = "AppOnlineChanged"

    @SerializedName(F.STATUS)
    val statusOperators = "online"

    override fun process() {
        // Раньше: getSettings().take(1).subscribe{} (Rx) — теперь корутина + awaitSettings (remove_rx).
        // RtsProcessing.scope (отменяется в deInit), а не одноразовый sdkScope: orphan-корутина
        // дописывала статус операторов старой сессии в синглтон настроек после logout.
        RtsProcessing.scope.launch {
            try {
                // Ждём первые настройки; сам апдейт — атомарный RMW под локом репозитория, иначе
                // конкурентная запись (consent-флаги из performAuth) строилась бы на том же
                // снапшоте и одна из двух терялась.
                SettingsRepository.getInstance().awaitSettings()
                // Только copy: перечисление полей вручную молча теряло те, что не были указаны
                // (originalAppColor, messengerPattern, showLinkKbAtWelcomeMessage,
                // enableNewConversationButton) — потерянный originalAppColor валил диалог по `!!`
                // в офлайн-ветке loadSettings.
                SettingsRepository.getInstance().updateSettings { settings ->
                    settings.copy(
                        statusOperators = when (statusOperators) {
                            StatusOperators.ONLINE.value -> StatusOperators.ONLINE
                            StatusOperators.OFFLINE.value -> StatusOperators.OFFLINE
                            else -> StatusOperators.UNKNOWN
                        },
                    )
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.e(tag, e.toString())
            }
        }
    }
}
