package io.carrotquest_sdk.android.data.settings

import android.content.Context
import com.google.gson.Gson
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils

internal object SettingsManager {

    // Ключи в SharedPreferences для визуального fallback'а при cold start через push.
    // SettingsRepository в памяти, и пока не завершился connect, новый процесс приложения
    // не знает цвет аппа клиента — видим серый default. Кэшим минимум, нужный для шапки.
    const val CACHED_ORIGINAL_APP_COLOR = "cq_cached_original_app_color"
    const val CACHED_APP_COLOR = "cq_cached_app_color"
    const val CACHED_MESSENGER_PATTERN = "cq_cached_messenger_pattern"
    const val CACHED_ENABLE_NEW_CONVERSATION_BUTTON = "cq_cached_enable_new_conversation_button"
    const val CACHED_ENABLE_AUDIO_MESSAGES = "cq_cached_enable_audio_messages"

    // Кэш шапки (список диалогов и шапка диалога): имя аппа, статус операторов, приветствие,
    // аватары админов. При cold start через push настройки в памяти пусты до /connect —
    // без кэша шапка рисовалась совсем пустой (см. buildHeaderFallbackEntity).
    const val CACHED_APP_NAME = "cq_cached_app_name"
    const val CACHED_STATUS_OPERATORS = "cq_cached_status_operators"
    const val CACHED_ONLINE_MESSAGE = "cq_cached_online_message"
    const val CACHED_OFFLINE_MESSAGE = "cq_cached_offline_message"
    const val CACHED_SHOW_OFFLINE_MESSAGE = "cq_cached_show_offline_message"
    const val CACHED_ADMIN_AVATARS = "cq_cached_admin_avatars"
    const val CACHED_SHOW_POWERED_BY = "cq_cached_show_powered_by"

    fun applyFromConnectResponse(response: ConnectResponse, context: Context) {
        applyTheme(response)
        val entity = buildSettingsEntity(response, context)
        SettingsRepository.getInstance().saveSettings(entity)
        cacheSettingsFallback(context, entity)
    }

    // internal (не private) — прямой roundtrip-тест кэша шапки без сборки ConnectResponse.
    internal fun cacheSettingsFallback(context: Context, entity: SettingsEntity) {
        SharedPreferencesLib.saveString(context, CACHED_ORIGINAL_APP_COLOR, entity.originalAppColor ?: "")
        SharedPreferencesLib.saveString(context, CACHED_APP_COLOR, entity.appColor ?: "")
        SharedPreferencesLib.saveString(context, CACHED_MESSENGER_PATTERN, entity.messengerPattern ?: "")
        cacheFlag(context, CACHED_ENABLE_NEW_CONVERSATION_BUTTON, entity.enableNewConversationButton)
        cacheFlag(context, CACHED_ENABLE_AUDIO_MESSAGES, entity.enableAudioMessages)

        // Данные шапки. Аватары — только непустые url, максимум те же 3, что показывает шапка.
        SharedPreferencesLib.saveString(context, CACHED_APP_NAME, entity.appName ?: "")
        SharedPreferencesLib.saveString(context, CACHED_STATUS_OPERATORS, entity.statusOperators.name)
        SharedPreferencesLib.saveString(context, CACHED_ONLINE_MESSAGE, entity.onlineMessage ?: "")
        SharedPreferencesLib.saveString(context, CACHED_OFFLINE_MESSAGE, entity.offlineMessage ?: "")
        cacheFlag(context, CACHED_SHOW_OFFLINE_MESSAGE, entity.showOfflineMessage)
        cacheFlag(context, CACHED_SHOW_POWERED_BY, entity.showPoweredBy)
        val avatars = entity.admins.mapNotNull { it.avatar?.takeIf { url -> url.isNotEmpty() } }.take(3)
        SharedPreferencesLib.saveString(context, CACHED_ADMIN_AVATARS, Gson().toJson(avatars))
    }

    /**
     * Минимальный [SettingsEntity] из кэша прошлых connect'ов — для шапки при cold start через
     * push (настройки в памяти появятся только после /connect). null — кэша ещё нет (первый
     * запуск). Заполнены ТОЛЬКО поля шапки (toHeaderData); остальные — дефолты, использовать
     * такой entity вместо настоящих настроек нельзя.
     */
    fun buildHeaderFallbackEntity(context: Context): SettingsEntity? {
        val appName = SharedPreferencesLib.getString(context, CACHED_APP_NAME) ?: ""
        val avatarsJson = SharedPreferencesLib.getString(context, CACHED_ADMIN_AVATARS) ?: ""
        if (appName.isEmpty() && avatarsJson.isEmpty()) return null

        val avatars: List<String> = runCatching {
            Gson().fromJson(avatarsJson, Array<String>::class.java)?.toList()
        }.getOrNull() ?: emptyList()
        val status = runCatching {
            StatusOperators.valueOf(
                SharedPreferencesLib.getString(context, CACHED_STATUS_OPERATORS) ?: ""
            )
        }.getOrDefault(StatusOperators.UNKNOWN)

        return SettingsEntity(
            userId = "",
            sourceData = "",
            appName = appName,
            appId = null,
            admins = ArrayList(avatars.map { url -> Admin().apply { avatar = url } }),
            theme = null,
            locale = "",
            statusOperators = status,
            onlineMessage = SharedPreferencesLib.getString(context, CACHED_ONLINE_MESSAGE) ?: "",
            offlineMessage = SharedPreferencesLib.getString(context, CACHED_OFFLINE_MESSAGE) ?: "",
            showOfflineMessage = cachedFlagOrTrue(context, CACHED_SHOW_OFFLINE_MESSAGE),
            // showPoweredBy дефолтит в false: cachedFlagOrTrue не подходит (default true).
            showPoweredBy = SharedPreferencesLib.getString(context, CACHED_SHOW_POWERED_BY) == true.toString(),
        )
    }

    // ── Кэш boolean-флагов настроек с дефолтом true ──────────────────────────────
    // Конвенция хранения — СТРОКОЙ ("true"/"false"), обе стороны только здесь:
    // SharedPreferencesLib.getBoolean не умеет default и вернул бы false при отсутствии ключа —
    // то есть включил бы новое поведение всем, у кого кэша ещё нет. Не переводить существующие
    // ключи на saveBoolean/getBoolean: чтение строкового значения через getBoolean уронит каст,
    // а закэшированный false тихо потеряется при апгрейде.

    /** Записать флаг настроек в кэш (парный читатель — [cachedFlagOrTrue]). */
    private fun cacheFlag(context: Context, key: String, value: Boolean) {
        SharedPreferencesLib.saveString(context, key, value.toString())
    }

    /**
     * Прочитать флаг из кэша: false ТОЛЬКО при явно закэшированном "false"; отсутствие ключа
     * (кэша ещё нет) и "" (catch-all getString) означают дефолт true — прежнее поведение.
     */
    fun cachedFlagOrTrue(context: Context, key: String): Boolean =
        SharedPreferencesLib.getString(context, key) != false.toString()

    private fun applyTheme(response: ConnectResponse) {
        if (CarrotSDK.getTheme() == ThemeSdk.FROM_WEB) {
            val rawTheme = response.data?.app?.settings?.theme
            CarrotSDK.setTheme(if ("dark" == rawTheme) ThemeSdk.DARK else ThemeSdk.LIGHT)
        }
    }

    private fun buildSettingsEntity(response: ConnectResponse, context: Context): SettingsEntity {
        val app = response.data.app
        val settings = app.settings
        val user = response.data.user
        val rawColor = settings.appColor ?: ""
        val correctedColor = AppColorUtils.getCorrectAccentColor(context, rawColor)
        val admins = ArrayList<Admin>(app.admins)
        val appName = settings?.messengerName ?: app.name

        return SettingsEntity(
            userId = user.id,
            isShowVK = settings.isShowVK,
            textLinkVK = settings.textLinkVK,
            isShowViber = settings.isShowViber,
            textLinkViber = settings.textLinkViber,
            isShowFB = settings.isShowFB,
            textLinkFB = settings.textLinkFB,
            isShowTelegram = settings.isShowTelegram,
            textLinkTelegram = settings.textLinkTelegram,
            isShowInstagram = settings.isShowInstagram,
            textLinkInstagram = settings.textLinkInstagram,
            isShowWhatsapp = settings.isShowWhatsapp,
            textLinkWhatsapp = settings.textLinkWhatsapp,
            appColor = correctedColor,
            originalAppColor = rawColor,
            welcomeMessage = settings.welcomeMessage,
            messengerAvatar = settings.messengerAvatar,
            showPoweredBy = settings.isShowPoweredBy,
            sourceData = response.sourceData ?: "",
            appName = appName,
            appId = app.id,
            showLinkKbAtWelcomeMessage = settings.isShowKbLinkInWelcomeMessage,
            statusOperators = if ("online" == app.statusOperators) StatusOperators.ONLINE else StatusOperators.OFFLINE,
            onlineMessage = settings.onlineMessage,
            offlineMessage = settings.offlineMessage,
            showOfflineMessage = settings.isShowOfflineMessage,
            admins = admins,
            theme = settings.theme,
            locale = settings.locale ?: "",
            messengerPattern = settings.messengerPattern,
            enableNewConversationButton = settings.isEnableNewConversationButton,
            enableAudioMessages = settings.isEnableAudioMessages
        )
    }
}
