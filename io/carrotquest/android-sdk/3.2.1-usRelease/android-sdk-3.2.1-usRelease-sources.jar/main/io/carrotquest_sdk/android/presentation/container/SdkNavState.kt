package io.carrotquest_sdk.android.presentation.container

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Stable
sealed class SdkNavState {
    /** Начальное состояние: данные ещё грузятся, неизвестно — список или диалог. */
    @Immutable
    data object Determining : SdkNavState()
    @Immutable
    data object ConversationList : SdkNavState()
    @Immutable
    data class Dialog(
        val conversationId: String,
        val isNew: Boolean = false,
    ) : SdkNavState()
}
