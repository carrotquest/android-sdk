package io.carrotquest_sdk.android.core.util.files.download_files;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

public interface DownloadService {
    // Call<ResponseBody> (дефолтный адаптер Retrofit) вместо Observable — убран
    // RxJava2CallAdapterFactory (ветка remove_rx). Качаем блокирующим execute() на IO-потоке.
    @Streaming
    @GET
    Call<ResponseBody> download(@Url String url);
}
