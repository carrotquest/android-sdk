package io.carrotquest_sdk.android.presentation.mvp.notifications

import android.content.Intent
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.SendingMessageToBroadcastReceiver
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage
import kotlinx.coroutines.launch

/**
 * Переведён с Java + RxJava2 на Kotlin + корутины (ветка remove_rx, фаза 2), т.к.
 * [SendingMessageToBroadcastReceiverDao.getById] стал `suspend`, а Java не умеет его вызывать.
 */
class NotificationsAllHelper private constructor() {

    private var db: CarrotSdkDB? = null

    /**
     * Принимает идентификатор входящего сообщения, запоминает его и отправляет событие
     * в BroadcastReceiver — но только если уведомление об этом сообщении ещё не отправлялось.
     */
    fun pushMessage(message: IncomingMessage) {
        val messageId = message.messageId
        sdkScope(SdkDispatchers.io).launch {
            try {
                // Раньше Single getById -> onError(EmptyResultSetException) трактовался как
                // "ещё не отправляли". Теперь suspend + nullable: null == записи нет == не отправляли.
                val alreadySent = db?.sendingMessageToBroadcastReceiverDao()?.getById(messageId) != null
                if (!alreadySent) {
                    sendToBroadcastReceiver(message)
                }
            } catch (e: Throwable) {
                Log.e(TAG, e)
            }
        }
    }

    /** Запоминает, что это сообщение уже отправили и второй раз отправлять его не надо. */
    private fun saveMessage(messageId: String) {
        db?.sendingMessageToBroadcastReceiverDao()?.insert(SendingMessageToBroadcastReceiver(messageId))
    }

    /** Отправляет событие в BroadcastReceiver. */
    private fun sendToBroadcastReceiver(message: IncomingMessage) {
        saveMessage(message.messageId)
        val intent = Intent(NotificationsConstants.CQ_SDK_NEW_MESSAGE_ACTION)
        intent.putExtra(NotificationsConstants.CQ_SDK_NEW_MESSAGE_ARG, message)
        CarrotInternal.getLibComponent().contextSdk.sendBroadcast(intent)
    }

    companion object {
        private const val TAG = "NotificationsAllHelper"

        @Volatile
        private var instance: NotificationsAllHelper? = null

        @JvmStatic
        fun getInstance(): NotificationsAllHelper {
            if (instance == null) {
                instance = NotificationsAllHelper().apply {
                    db = CarrotInternal.getLibComponent().sdkDataBase
                }
            }
            return instance!!
        }
    }
}
