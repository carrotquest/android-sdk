package io.carrotquest_sdk.android.domain.use_cases.agreements

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.data.repositories.SettingsRepository

fun updateAppSettings(key: String, value: Boolean) = updateAppUserFlags(mapOf(key to value))

/**
 * Обновляет несколько флагов в data.user кэшированных настроек за один разбор/пересборку/эмит
 * (в отличие от многократного [updateAppSettings]). Пустая карта — no-op. Нужен после смены
 * пользователя (auth): переносим *_is_allowed из ответа app_auth в sourceData, иначе плашка
 * согласия строится на флагах предыдущего пользователя.
 */
fun updateAppUserFlags(flags: Map<String, Boolean>) {
    if (flags.isEmpty()) return
    // updateSettings (атомарный RMW), а не getSettings()+saveSettings: конкурентная запись
    // (например, statusOperators из RTS app_online_changed сразу после auth-склейки) строилась
    // бы на том же снапшоте и одна из двух молча терялась.
    SettingsRepository.getInstance().updateSettings { settings ->
        val jsonObject = JsonParser.parseString(settings.sourceData) as JsonObject
        val userJsonObject = jsonObject.get("user") as? JsonObject
            ?: return@updateSettings settings
        flags.forEach { (key, value) -> userJsonObject.addProperty(key, value) }
        jsonObject.add("user", userJsonObject)

        // Только copy: перечисление полей вручную молча теряло те, что не были указаны
        // (originalAppColor, messengerPattern, showLinkKbAtWelcomeMessage,
        // enableNewConversationButton) — потерянный originalAppColor валил диалог по `!!`
        // в офлайн-ветке loadSettings.
        settings.copy(sourceData = jsonObject.toString())
    }
}