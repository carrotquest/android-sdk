package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.data.repositories.triggers.TriggersRepository
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerComparison
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerEntity
import kotlinx.coroutines.flow.first

class GetTriggersUseCase {
    // Возвращает текущий список триггеров один раз (раньше Flowable, который потребитель
    // дёргал как one-shot; непрерывная подписка плодила бы лишние sendTrigger при изменениях БД).
    suspend fun call(): List<TriggerEntity> {
        return TriggersRepository.getInstance().getTriggers().first()
            .filter { t -> t.kind == 7 }
            .map { t ->
                TriggerEntity(
                    id = t.id,
                    kind = t.kind,
                    url = t.url,
                    comparison = when (t.comparison.lowercase()) {
                        "eq" -> TriggerComparison.Eq
                        "contains" -> TriggerComparison.Contains
                        "neq" -> TriggerComparison.Neq
                        "not_contains" -> TriggerComparison.NotContains
                        else -> TriggerComparison.Uncnown
                    }
                )
            }
    }
}
