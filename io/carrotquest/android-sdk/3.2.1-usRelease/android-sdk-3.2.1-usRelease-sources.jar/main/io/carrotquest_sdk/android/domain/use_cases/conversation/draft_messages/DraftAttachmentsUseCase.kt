package io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

/**
 * Драфт вложений диалога — зеркало текстового драфта, но хранит JSON-массив УЖЕ загруженных
 * вложений (формат attachments_cached: {type,id,filename,mime_type,size,url}). Файлы загружаются
 * на сервер сразу при выборе, поэтому драфт переживает закрытие диалога без переотправки: при
 * повторном открытии чипы восстанавливаются в состоянии UPLOADED (превью — из серверного url).
 */
fun saveDraftAttachmentsUseCase(json: String, conversationId: String) {
    val context = CarrotLib.getLibComponents().context
    SharedPreferencesLib.saveString(context, DRAFT_ATTACHMENTS_KEY + conversationId, json)
}

fun getDraftAttachmentsUseCase(conversationId: String): String? {
    val context = CarrotLib.getLibComponents().context
    return SharedPreferencesLib.getString(context, DRAFT_ATTACHMENTS_KEY + conversationId).ifEmpty { null }
}

fun clearDraftAttachmentsUseCase(conversationId: String) {
    val context = CarrotLib.getLibComponents().context
    SharedPreferencesLib.saveString(context, DRAFT_ATTACHMENTS_KEY + conversationId, "")
}
