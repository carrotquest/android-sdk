package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import android.webkit.URLUtil
import com.google.gson.Gson
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import org.json.JSONObject
import java.util.Locale

// createMessage/saveMessage/saveMessageWithAttachment/removeWelcomeMessage — в CreateMessageSuspend.kt.
// createWelcomeMessage переведён в suspend (ветка remove_rx) — Observable-ext убрана.
suspend fun createWelcomeMessage(settings: SettingsEntity): MessageData {
    val createdTS = (System.currentTimeMillis() / 1000).toString()
    val avatar = if (URLUtil.isValidUrl(settings.messengerAvatar)) {
        settings.messengerAvatar!!
    } else {
        BuildConfig.BASE_FILES_URL + "avatars/" + settings.messengerAvatar!!
    }
    val message = MessageData()
    message.id = createdTS

    message.body = settings.welcomeMessage
    message.conversation = ""
    message.created = createdTS
    message.sentVia = ResponseFields.SDK_ANDROID
    message.direction = ResponseFields.ADMIN_2_USER
    message.isFirst = true
    message.messageFrom = Admin()
    message.messageFrom.id = ""
    message.messageFrom.avatar = avatar
    message.messageFrom.type = "default_admin"
    message.messageFrom.name = settings.appName

    message.type = ResponseFields.REPLY_ADMIN
    message.status = MessageStatus.NORMAL.name.lowercase(Locale.getDefault())
    message.hasKBLink = settings.showLinkKbAtWelcomeMessage

    message.sourceJsonData = JSONObject(Gson().toJson(message))

    MessagesRepository.getInstance().setData(MessagesResponse())
    if (MessagesRepository.getInstance().getWelcomeMessage() == null) {
        MessagesRepository.getInstance().saveWelcomeMessage(message)
    }
    return message
}
