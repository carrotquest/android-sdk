package io.carrotquest_sdk.android.data.network.wss_responses

import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import kotlinx.coroutines.cancelChildren

/**
 * Общий скоуп асинхронной обработки RTS-сообщений (IRtsMessage.process).
 *
 * Раньше каждый process() создавал одноразовый sdkScope, который никто не хранил и не отменял:
 * logout (deInit) посреди обработки не останавливал корутину, и она дописывала данные СТАРОГО
 * пользователя (настройки, диалоги, попапы) в процесс-wide синглтоны уже после teardown — поверх
 * состояния новой сессии.
 *
 * Отменяется в CarrotService.deInit (cancelWork) — рядом с deInit репозиториев. НЕ отменяется
 * в WssManager.stop(): stop дёргается и при каждом пересоздании сессии/реконнекте, а сообщения,
 * пришедшие перед обрывом, должны дообработаться (иначе терялись бы до следующей загрузки истории).
 */
internal object RtsProcessing {

    val scope = sdkScope(SdkDispatchers.io)

    /** Отмена всей текущей обработки; сам скоуп остаётся рабочим для следующей сессии. */
    fun cancelWork() {
        scope.coroutineContext.cancelChildren()
    }
}
