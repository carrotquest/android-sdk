package io.carrotquest_sdk.android.core.constants;

public class SharedPreferenceKeys {
    public static String CARROT_PREF_NAME = "CarrotPref";

    public static String CARROT_TOKEN = "CarrotToken";
    public static String CARROT_USER_ID = "CarrotUserId";
    // Признак «SDK деинициализирован пользователем» (Carrot.deInit). Persist — переживает
    // убийство процесса. Ставится в deInit, снимается при следующем setup. Пуш-энтрипоинт
    // (SdkFirebaseMessagingService) дропает уведомления, пока флаг стоит, чтобы после logout
    // не показывать пуши предыдущему юзеру.
    public static String SDK_DEINITIALIZED = "CarrotSdkDeinitialized";

    // Незавершённая отписка push-токена от юзера на бэкенде (Carrot.deInit). Сохраняем ДО очистки
    // кред, чтобы (а) отправить запрос аутентифицированным токеном старого юзера и (б) повторить
    // на следующем старте, если запрос не дошёл (таймаут/офлайн/kill процесса). Очищается при успехе.
    public static String PENDING_UNSUB_USER_ID = "CarrotPendingUnsubUserId";
    public static String PENDING_UNSUB_DEVICE_ID = "CarrotPendingUnsubDeviceId";
    public static String PENDING_UNSUB_TOKEN = "CarrotPendingUnsubToken";
    public static String CARROT_USER_UNREAD_CONVERSATIONS = "CarrotUserUnreadConversations";
    public static String CARROT_USER_BANNED = "CarrotUserBanned";

    public static String CARROT_IS_SHOW_VK = "CarrotIsShowVK";
    public static String CARROT_TEXT_LINK_VK = "CarrotTextLinkVK";

    public static String CARROT_IS_SHOW_VIBER = "CarrotIsShowViber";
    public static String CARROT_TEXT_LINK_VIBER = "CarrotTextLinkViber";

    public static String CARROT_IS_SHOW_FB = "CarrotIsShowFB";
    public static String CARROT_TEXT_LINK_FB = "CarrotTextLinkFB";

    public static String CARROT_IS_SHOW_TELEGRAM = "CarrotIsShowTelegram";
    public static String CARROT_TEXT_LINK_TELEGRAM = "CarrotTextLinkTelegram";

    public static String APP_NAME = "AppName";

    public static String CHAT_COLOR = "ChatColor";

    public static String WELCOME_MESSAGE = "welcomeMessage";
    public static String AVATAR = "avatar";

    public static String COUNT_DIALOGS_WITH_UNREAD_MESSAGES = "CountDialogsWithUnreadMessages";

    public static String CARROT_USER_BAN_WITH_RIGHT_ON_LAST_PART_VALUE = "CARROT_USER_BAN_WITH_RIGHT_ON_LAST_PART_VALUE";


    public static String HIDE_LAST_MESSAGE = "HIDE_LAST_MESSAGE";

    //UTM-метки
    public static String UTM_SOURCE = "utm_source";
    public static String UTM_MEDIUM = "utm_medium";
    public static String UTM_CAMPAIGN = "utm_campaign";
    public static String UTM_TERM = "utm_term";
    public static String UTM_CONTENT = "utm_content";


    public static String SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED = "sdk_push_notifications_unsubscribed";
    public static String SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED = "sdk_push_campaigns_unsubscribed_key";

    public static String AUTHED_USER_ID_KEY = "authed_user_id_key"; // legacy: не используется, old combined "authId:userId"
    public static String AUTHED_AUTH_ID_KEY = "authed_auth_id_key";
    public static String AUTHED_SDK_USER_ID_KEY = "authed_sdk_user_id_key";
    public static String CONNECTED_USER_ID_KEY = "connected_user_id_key";
}
