package io.carrotquest_sdk.android.core.init

import io.carrotquest_sdk.android.Callback

import android.content.Context
import android.content.IntentFilter
import android.os.Build
import android.text.TextUtils
import androidx.core.content.ContextCompat
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.connection.ConnectionManager
import io.carrotquest_sdk.android.core.connection.WssManager
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.utm.UtmUtil
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.data.settings.SettingsManager
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.findLastUnreadPopup
import io.carrotquest_sdk.android.domain.use_cases.popup.saveNewPopUp
import io.carrotquest_sdk.android.domain.use_cases.rts.saveRtsHost
import io.carrotquest_sdk.android.domain.use_cases.triggers.LoadTriggersUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.loadUserProps
import io.carrotquest_sdk.android.domain.use_cases.user.saveConnectedUserIdUseCase
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.utils.isFreedom
import io.carrotquest_sdk.android.lib.wss.jwt.saveJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.saveRefreshToken
import io.carrotquest_sdk.android.lib.utils.saveDashlyTokenFlag
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushTapReceiver
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.ResponseBody
import retrofit2.HttpException
import java.io.IOException
import java.util.concurrent.TimeoutException

internal object InitCoordinator {

    private const val TAG = "InitCoordinator"
    private const val INIT_TIMEOUT_SECONDS = 30L
    private const val MAX_INIT_RETRIES = 2
    private const val INITIAL_RETRY_DELAY_MS = 1_000L

    /**
     * Транзиентными считаем ошибки сети, timeout и 5xx/408 от сервера.
     * Всё остальное (4xx, IllegalArgumentException и т.д.) — ретраить бесполезно.
     */
    private fun isTransientError(e: Throwable): Boolean = when (e) {
        is IOException -> true
        is TimeoutException -> true
        is HttpException -> e.code() == 408 || e.code() in 500..599
        else -> false
    }

    /**
     * Скоуп основного init/connect-потока (корутины). Отменяется в [abort].
     */
    private val initScope = sdkScope(SdkDispatchers.io)

    /**
     * Зарегистрированный PushTapReceiver. Храним, чтобы снять регистрацию в [abort] (на deInit)
     * и перед повторной регистрацией — иначе при logout→login ресиверы накапливаются
     * (IntentReceiverLeaked). Регистрируем на applicationContext, чтобы не привязывать к Activity.
     */
    private var pushTapReceiver: PushTapReceiver? = null

    /**
     * Отменяет все активные init-задачи (корутинный connect-поток + fire-and-forget Rx-подписки).
     * Вызывать при deInit, чтобы задачи не продолжили выполняться на фоне уже "мёртвого" SDK.
     */
    fun abort() {
        initScope.coroutineContext.cancelChildren()
        unregisterPushTapReceiver()
    }

    fun connect(
        appId: String,
        apiKey: String,
        carrotLib: CarrotLib,
        userRepository: UserRepository,
        startSession: Boolean,
        callback: Callback<Boolean>?,
        onPushInit: Runnable,
        onRefreshTokenService: Runnable
    ) {
        if (!SdkStateManager.onInitStarted()) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.LIFECYCLE, TAG, "connect: SDK already initializing/ready — skipping duplicate init")
            callback?.onResponse(true)
            return
        }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.LIFECYCLE, TAG, "connect: init started, appId=$appId, startSession=$startSession")

        val referrer = try {
            UtmUtil.getReferrer(CarrotLib.getLibComponents().context)
        } catch (e: Exception) {
            Log.e(TAG, e)
            ""
        }

        // TODO FREEDOM удалить потом
        io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib.saveString(
            CarrotInternal.getLibComponent().contextSdk,
            "X_APP_ID_KEY",
            appId
        )

        val sdkVersion = CarrotSDK.getVersion() ?: ""
        val context = CarrotInternal.getLibComponent().contextSdk

        initScope.launch {
            try {
                // connect + timeout + retry (транзиентные ошибки) с exponential backoff.
                val response = connectWithRetry(
                    apiKey, appId, sdkVersion, referrer, startSession, context, carrotLib, userRepository
                )

                // Раньше .filter: пропускаем, если приложение не заблокировано ИЛИ статус не 200.
                // Если отфильтровано (app заблокирован при статусе 200) — init прерываем (был onComplete).
                val passesFilter =
                    (response.data != null && response.data.app != null && !response.data.app.isBlocked) ||
                            (response.meta.status != 200)
                if (!passesFilter) {
                    SdkStateManager.onInitAborted()
                    return@launch
                }

                // Side-effects + завершение init — на главном потоке (раньше observeOn(mainThread)).
                withContext(SdkDispatchers.main) {
                    applyConnectSideEffects(appId, response)

                    // Раньше — DisposableObserver.onNext: гард isInit только на этой части.
                    if (SdkStateManager.isInit()) return@withContext
                    SdkLogger.log(
                        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                        "connect: SUCCESS, connectedUserId=${response.data.user.id}, gotAccessToken=${!response.data.user.token.isNullOrEmpty()}",
                    )
                    try {
                        userRepository.saveUser(response.data.user)
                    } catch (e: Exception) {
                        Log.d("saveUserTag", "error: $e")
                    }
                    onPushInit.run()
                    initComplete(appId, response, userRepository, needWssConnect = true, onRefreshTokenService)
                    try {
                        callback?.onResponse(TextUtils.isEmpty(response.meta.error))
                    } catch (e: Exception) {
                        Log.e(TAG, e)
                    }
                }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                initError(e)
                // Колбэк наружу — строго на главном потоке: хост в onFailure обычно трогает UI
                // (Toast) и может перезапустить init. На IO это роняло хост и не доводило re-init
                // (тот же класс бага, что чинёный teardown-on-IO).
                withContext(SdkDispatchers.main) {
                    callback?.onFailure(e)
                }
            }
        }

        initBroadcast(CarrotLib.getLibComponents().context)
    }

    /**
     * Вызывает [ConnectionManager.connect] с таймаутом [INIT_TIMEOUT_SECONDS] и ретраем
     * транзиентных ошибок (до [MAX_INIT_RETRIES], exponential backoff). Раньше — timeout()+retryWhen().
     */
    private suspend fun connectWithRetry(
        apiKey: String,
        appId: String,
        sdkVersion: String,
        referrer: String,
        startSession: Boolean,
        context: Context,
        carrotLib: CarrotLib,
        userRepository: UserRepository
    ): ConnectResponse {
        var attempt = 0
        while (true) {
            val result = runCatching {
                withTimeoutOrNull(INIT_TIMEOUT_SECONDS * 1000) {
                    ConnectionManager.connect(
                        apiKey, appId, sdkVersion, referrer, startSession, context, carrotLib, userRepository
                    )
                }
            }
            val response = result.getOrNull()
            if (result.isSuccess && response != null) return response

            // null от withTimeoutOrNull = таймаут (транзиентный); иначе — реальная ошибка.
            val err = result.exceptionOrNull() ?: TimeoutException("init timeout after ${INIT_TIMEOUT_SECONDS}s")
            if (err is CancellationException) throw err
            attempt++
            if (attempt > MAX_INIT_RETRIES || !isTransientError(err)) throw err
            val delayMs = INITIAL_RETRY_DELAY_MS shl (attempt - 1)
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.LIFECYCLE, TAG, "init retry #$attempt after ${delayMs}ms, cause=$err")
            delay(delayMs)
        }
    }

    /**
     * Side-effects успешного connect (раньше — doOnNext): настройки, connected-user-id, RTS-host,
     * popups (fire-and-forget Rx), сохранение юзера, utm, triggers (fire-and-forget Rx).
     */
    private fun applyConnectSideEffects(appId: String, response: ConnectResponse) {
        val ctx = CarrotInternal.getLibComponent().contextSdk

        SettingsManager.applyFromConnectResponse(response, ctx)

        // Токены сохраняем здесь — в точке, где ответ ПРИНЯТ. Раньше это делал ConnectDeserializer
        // прямо во время парсинга: пара токенов подменялась даже для ответа, который потом
        // отбрасывался (таймаут/ретрай, заблокированное приложение), — и глобальный токен
        // расходился с сохранённой личностью.
        response.data.authToken?.takeIf { it.isNotEmpty() }?.let { access ->
            saveJwtToken(access, ctx)
            response.data.refreshToken?.takeIf { it.isNotEmpty() }?.let { saveRefreshToken(it, ctx) }
        }

        val user = response.data.user
        saveConnectedUserIdUseCase(user.id, ctx)

        val userEntity = UserEntity(
            user.id, user.token, user.hasConversations,
            user.isBanned, user.conversationsUnread
        )

        val hosts = response.data.realtimeServices.hosts
        if (hosts.isNotEmpty()) {
            for ((_, rtsHost) in hosts) {
                if (rtsHost.isNotEmpty()) {
                    saveRtsHost(ctx, rtsHost)
                    break
                }
            }
        }

        downloadPopUps(userEntity)

        io.carrotquest_sdk.android.data.repositories.UserRepository
            .getInstance().saveUser(userEntity)
        UtmUtil.sendSavedUtm(CarrotLib.getLibComponents().context)

        // TODO FREEDOM удалить потом
        if (isFreedom(appId)) {
            saveDashlyTokenFlag()
        }

        loadTriggers()
    }

    private fun loadTriggers() {
        initScope.launch {
            try {
                LoadTriggersUseCase().call()
            } catch (t: Throwable) {
                Log.e(TAG, t.toString())
            }
        }
    }

    private fun initBroadcast(context: Context) {
        // Снимаем прежний ресивер (если init вызывается повторно без deInit) — иначе утечка.
        unregisterPushTapReceiver()

        val appContext = context.applicationContext
        val receiver = PushTapReceiver()
        val filter = IntentFilter("carrotquest.sdk.tap.push")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            ContextCompat.registerReceiver(appContext, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        }
        pushTapReceiver = receiver
    }

    private fun unregisterPushTapReceiver() {
        val receiver = pushTapReceiver ?: return
        try {
            CarrotLib.getLibComponents().context.applicationContext.unregisterReceiver(receiver)
        } catch (e: Exception) {
            // ресивер мог быть не зарегистрирован — игнорируем
        }
        pushTapReceiver = null
    }

    // fire-and-forget на initScope (раньше — Disposable под CompositeDisposable). findLastUnreadPopup
    // и saveNewPopUp уже suspend.
    private fun downloadPopUps(userEntity: UserEntity) {
        initScope.launch {
            try {
                val popUpsList = findLastUnreadPopup(userEntity) ?: emptyList()
                // Раньше эмиссия списка задерживалась на 2с перед сохранением попапов.
                delay(2000)
                for (p in popUpsList) {
                    try {
                        saveNewPopUp(p)
                    } catch (t: Throwable) {
                        Log.e(TAG, t.toString())
                    }
                }
            } catch (t: Throwable) {
                Log.e(TAG, t.toString())
            }
        }
    }

    private fun initComplete(
        appId: String,
        connectResponse: ConnectResponse,
        userRepository: UserRepository,
        needWssConnect: Boolean,
        onRefreshTokenService: Runnable
    ) {
        ConnectionManager.reset()
        userRepository.saveUser(connectResponse.data.user)
        SdkStateManager.onReady()

        onRefreshTokenService.run()
        if (needWssConnect) {
            WssManager.start(appId, connectResponse.data.user.id)
        }

        initScope.launch {
            try {
                loadUserProps(connectResponse.data.user.id)
            } catch (t: Throwable) {
                Log.e(TAG, t.toString())
            }
        }
    }

    private fun initError(e: Throwable) {
        SdkStateManager.onFailed(e)
        Log.e(TAG, e)
        if (e is HttpException) {
            val responseBody: ResponseBody? = e.response()?.errorBody()
            try {
                if (responseBody != null) {
                    try {
                        Log.e(TAG, responseBody.string())
                    } catch (ioException: IOException) {
                        Log.e(TAG, responseBody.toString())
                    }
                }
            } catch (e1: Exception) {
                Log.e(TAG, e1)
            }
        }
    }
}
