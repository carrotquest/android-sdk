package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import java.util.Date

fun isActualRefreshToken(context: Context = CarrotLib.getLibComponents().getContext()): Boolean {
    val refreshToken = getRefreshToken()

    val result: Boolean
    val reason: String
    //Если refresh-токен не найден, то он не актуальный
    if (refreshToken.isNullOrEmpty()) {
        result = false; reason = "refresh_empty"
    } else {
        val updateTokenTimeStamp = getLastUpdateRefreshToken()
        //Если не найден таймштамп сохранения токена, то токен не актуальный
        if (updateTokenTimeStamp <= 0) {
            result = false; reason = "no_refresh_timestamp"
        } else {
            //Токен актуальный, если разница между текущим временем и временем обновления меньше 30 дней
            val ageMs = Date().time - updateTokenTimeStamp
            result = ageMs < refreshTokenLiveTime
            reason = if (result) "valid" else "refresh_expired_by_age"
        }
    }

    // DEBUG — см. комментарий в isActualJwtToken.
    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.AUTH, "TokenFlow") {
        "isActualRefreshToken=$result (reason=$reason), refresh=${maskToken(refreshToken)}"
    }
    return result
}