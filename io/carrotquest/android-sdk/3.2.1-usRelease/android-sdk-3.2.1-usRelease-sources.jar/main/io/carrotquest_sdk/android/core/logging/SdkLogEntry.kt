package io.carrotquest_sdk.android.core.logging

/**
 * A single log record delivered to a [SdkLogSink].
 *
 * [message] is the ready-to-read human string; [fields] are structured key/value pairs (url,
 * status, durationMs, userId (masked), …) for machine processing/filtering.
 */
data class SdkLogEntry(
    val timestampMs: Long,
    val level: SdkLogLevel,
    val category: SdkLogCategory,
    val tag: String,
    val message: String,
    val fields: Map<String, String> = emptyMap(),
    val throwable: Throwable? = null,
)
