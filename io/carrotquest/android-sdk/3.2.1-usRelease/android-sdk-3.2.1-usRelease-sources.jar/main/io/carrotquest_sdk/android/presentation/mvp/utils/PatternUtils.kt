package io.carrotquest_sdk.android.presentation.mvp.utils

import io.carrotquest_sdk.android.BuildConfig

/**
 * Формирует URL для PNG-паттерна подложки мессенджера.
 *
 * @param patternName имя паттерна из settings (например, "pat-3")
 * @param isDark      текущая тема
 * @return полный URL вида: {CDN_BASE_URL}/img/themes/{theme}/patterns/{patternName}.png
 */
fun getPatternUrl(patternName: String, isDark: Boolean): String {
    val theme = if (isDark) "dark" else "default"
    return "${BuildConfig.CDN_BASE_URL}/img/themes/$theme/patterns/$patternName.png"
}
