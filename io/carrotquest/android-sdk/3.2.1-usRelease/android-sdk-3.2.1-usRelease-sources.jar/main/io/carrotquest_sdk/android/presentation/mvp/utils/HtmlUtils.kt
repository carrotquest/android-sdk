package io.carrotquest_sdk.android.presentation.mvp.utils

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.URLSpan
import android.text.style.UnderlineSpan
import android.text.util.Linkify
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.core.text.HtmlCompat

/**
 * Парсит строку как HTML и возвращает [AnnotatedString] с сохранёнными стилями
 * (жирный, курсив, подчёркнутый, зачёркнутый, цвет).
 * Безопасно вызывать на plain-text — без тегов возвращает строку как есть.
 */
/** Возвращает содержимое, если строка целиком обёрнута в один <p>...</p>, иначе null. */
private fun String.singleParagraphContent(): String? {
    val trimmed = trim()
    val open = "<p>"
    val close = "</p>"
    if (!trimmed.startsWith(open, ignoreCase = true)) return null
    if (!trimmed.endsWith(close, ignoreCase = true)) return null
    // Убеждаемся, что это ровно один <p> — нет других закрывающих </p> внутри
    val inner = trimmed.substring(open.length, trimmed.length - close.length)
    if (inner.contains("</p>", ignoreCase = true)) return null
    return inner
}

private val LIST_TAG_REGEX = Regex("""</?(ul|ol|li)\b[^>]*>""", RegexOption.IGNORE_CASE)

/**
 * Разворачивает HTML-списки в плоский текст с маркерами: `<ul>` → «• », `<ol>` → «1. », «2. »…
 * Вложенность отражается отступами. Элементы разделяются `<br>` (HtmlCompat сохранит переносы).
 * Внутренние inline-теги (`<b>`, `<i>`, `<a>`…) не трогаем — их по-прежнему обработает HtmlCompat.
 * Если списков нет — строка возвращается без изменений.
 */
internal fun String.expandHtmlLists(): String {
    if (!contains("<li", ignoreCase = true)) return this

    data class Frame(val ordered: Boolean, var index: Int)
    val stack = ArrayDeque<Frame>()
    val sb = StringBuilder()
    var last = 0
    // Перенос строки без дублей подряд (вложенные списки иначе дают пустые строки).
    fun appendBreak() { if (sb.isNotEmpty() && !sb.endsWith("<br>")) sb.append("<br>") }

    for (m in LIST_TAG_REGEX.findAll(this)) {
        sb.append(this, last, m.range.first)
        last = m.range.last + 1
        val tag = m.groupValues[1].lowercase()
        val closing = m.value.startsWith("</")
        when (tag) {
            "ul", "ol" -> {
                if (closing) {
                    if (stack.isNotEmpty()) stack.removeLast()
                } else {
                    appendBreak() // список — с новой строки, если до него есть контент
                    stack.addLast(Frame(ordered = tag == "ol", index = 0))
                }
            }
            "li" -> {
                if (!closing) {
                    val frame = stack.lastOrNull()
                    val indent = "&nbsp;&nbsp;".repeat((stack.size - 1).coerceAtLeast(0))
                    val marker = if (frame?.ordered == true) {
                        frame.index += 1
                        "${frame.index}. "
                    } else {
                        frame?.let { it.index += 1 }
                        "• "
                    }
                    sb.append(indent).append(marker)
                } else {
                    appendBreak()
                }
            }
        }
    }
    sb.append(this, last, this.length)
    return sb.toString()
}

// 7+ цифр (с опциональными +, пробелами, дефисами, скобками) или короткие экстренные номера.
// Linkify.PHONE_NUMBERS не используем — он не находит российские форматы без +7.
// Разделители — только горизонтальные ([ \t]); НЕ \s, иначе перенос строки склеивает два
// номера на соседних строках в один матч.
private val PHONE_REGEX = Regex("""(?<!\d)\+?\d[\d \t\-().]{5,}\d(?!\d)|(?<!\d)(?:112|911|101|102|103|104|105)(?!\d)""")

/**
 * Делает кликабельными контактные данные и URL в plain-тексте: email и web-ссылки
 * (через [Linkify]) + телефоны (через [PHONE_REGEX]). Уже размеченные ссылки
 * (например, HTML `<a href>` из [toAnnotatedHtml]) повторно не линкуются.
 *
 * @param onLinkClick если задан — клик по ссылке вызывает его (для аналитики/единого
 *   открытия через presenter), иначе используется поведение Compose по умолчанию.
 */
fun AnnotatedString.withContactLinks(
    accentColor: Color,
    onLinkClick: ((String) -> Unit)? = null,
): AnnotatedString {
    val textStr = text
    val linkStyle = TextLinkStyles(style = SpanStyle(color = accentColor))

    // Уже размеченные ссылки (HTML <a>) — их не трогаем, чтобы не было пересечений
    val existingLinks = getLinkAnnotations(0, textStr.length).map { it.start until it.end }

    data class Link(val url: String, val start: Int, val end: Int)
    val links = mutableListOf<Link>()

    fun overlaps(start: Int, end: Int): Boolean =
        existingLinks.any { it.first < end && it.last + 1 > start } ||
        links.any { it.start < end && it.end > start }

    // Email + web-ссылки
    val spannable = SpannableString(textStr)
    Linkify.addLinks(spannable, Linkify.EMAIL_ADDRESSES or Linkify.WEB_URLS)
    spannable.getSpans(0, spannable.length, URLSpan::class.java).forEach { span ->
        val start = spannable.getSpanStart(span)
        val end = spannable.getSpanEnd(span)
        if (start >= 0 && end > start && !overlaps(start, end)) {
            links += Link(span.url, start, end)
        }
    }

    // Телефоны — пропускаем диапазоны, уже занятые ссылками
    PHONE_REGEX.findAll(textStr).forEach { match ->
        val start = match.range.first
        val end = match.range.last + 1
        if (!overlaps(start, end)) {
            val digits = match.value.filter { it.isDigit() || it == '+' }
            links += Link("tel:$digits", start, end)
        }
    }

    if (links.isEmpty()) return this
    val listener = onLinkClick?.toLinkListener()
    return buildAnnotatedString {
        append(this@withContactLinks)
        links.forEach { addLink(LinkAnnotation.Url(it.url, linkStyle, listener), it.start, it.end) }
    }
}

/** Оборачивает колбэк открытия URL в [LinkInteractionListener]; null-колбэк → дефолтное поведение. */
private fun ((String) -> Unit).toLinkListener() = LinkInteractionListener { link ->
    (link as? LinkAnnotation.Url)?.url?.let { this(it) }
}

/**
 * @param linkColor если задан — HTML-ссылки (`<a href>`) стилизуются этим цветом и
 *   становятся кликабельными; если null — ссылки остаются как обычный текст.
 * @param onLinkClick колбэк клика по ссылке (для аналитики/единого открытия).
 */
fun String.toAnnotatedHtml(
    linkColor: Color? = null,
    onLinkClick: ((String) -> Unit)? = null,
): AnnotatedString {
    // Разворачиваем списки (<ul>/<ol>/<li>) в текст с маркерами — HtmlCompat сам нумерацию
    // <ol> не делает, а маркеры <ul> кладёт спанами, которые мы в текст не переносим.
    val expanded = expandHtmlLists()
    // Если весь текст обёрнут в один <p>...</p> — убираем тег без замены на переносы строк
    val input = expanded.singleParagraphContent() ?: expanded
    val spanned = HtmlCompat.fromHtml(input, HtmlCompat.FROM_HTML_MODE_COMPACT)
    val linkListener = onLinkClick?.toLinkListener()
    return buildAnnotatedString {
        append(spanned.toString().trimEnd())
        spanned.getSpans(0, spanned.length, Any::class.java).forEach { span ->
            val start = spanned.getSpanStart(span)
            val end = spanned.getSpanEnd(span).coerceAtMost(length)
            if (start < 0 || start >= end) return@forEach
            when (span) {
                is StyleSpan -> when (span.style) {
                    Typeface.BOLD ->
                        addStyle(SpanStyle(fontWeight = FontWeight.Bold), start, end)
                    Typeface.ITALIC ->
                        addStyle(SpanStyle(fontStyle = FontStyle.Italic), start, end)
                    Typeface.BOLD_ITALIC ->
                        addStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic), start, end)
                }
                is UnderlineSpan ->
                    addStyle(SpanStyle(textDecoration = TextDecoration.Underline), start, end)
                is StrikethroughSpan ->
                    addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough), start, end)
                is ForegroundColorSpan ->
                    addStyle(SpanStyle(color = Color(span.foregroundColor)), start, end)
                is URLSpan -> if (linkColor != null) {
                    val url = span.url ?: return@forEach
                    val styles = TextLinkStyles(
                        SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)
                    )
                    addLink(LinkAnnotation.Url(url, styles, linkListener), start, end)
                }
            }
        }
    }
}
