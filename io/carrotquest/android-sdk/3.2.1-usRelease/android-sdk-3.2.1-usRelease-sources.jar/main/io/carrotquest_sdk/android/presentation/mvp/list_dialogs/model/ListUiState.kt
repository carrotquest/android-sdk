package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Stable
sealed class ListUiState {
    @Immutable
    data object Loading : ListUiState()
    @Immutable
    data object Empty : ListUiState()
    @Immutable
    data class Content(
        val recentItems: List<ConversationListItem>,
        val historyItems: List<ConversationListItem>
    ) : ListUiState()
    @Immutable
    data class Error(val type: ErrorType) : ListUiState()
}

enum class ErrorType {
    NO_INTERNET,
    AIRPLANE_MODE,
    SOMETHING_WENT_WRONG
}
