package io.carrotquest_sdk.android.core.coroutines

import io.carrotquest_sdk.android.core.SdkGlobalHandlers
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

/**
 * Обработчик непойманных исключений для корутин SDK.
 *
 * Зачем: непойманное исключение из `launch` идёт в [CoroutineExceptionHandler] своего скоупа, а если
 * его нет — в uncaught-handler ПОТОКА, то есть в системный KillApplicationHandler → падает
 * приложение интегратора. `SupervisorJob()` от этого не спасает: он лишь не отменяет соседних детей.
 *
 * Почему именно так, а не через глобальный Thread.setDefaultUncaughtExceptionHandler
 * (см. [SdkGlobalHandlers]): элемент контекста действует ТОЛЬКО на скоупы, которые создал сам SDK,
 * поэтому он не зависит от обфускации (сравнивать имена пакетов в минифицированной сборке
 * бессмысленно) и физически не может проглотить краш хост-приложения.
 *
 * Ставить в каждый создаваемый SDK скоуп — проще всего через [sdkScope]. Для framework-скоупов,
 * контекст которых мы не создаём (`viewModelScope`), передавать элементом в сам launch:
 * `viewModelScope.launch(SdkCoroutineExceptionHandler) { ... }`.
 *
 * ВАЖНО: это сетка для фоновой работы, а не замена обработке ошибок по месту. Исключение, брошенное
 * в main-потоке посреди fragment-транзакции, глушить нельзя — FragmentManager останется в
 * неконсистентном состоянии; такие места закрываются гейтом на границе жизненного цикла.
 */
internal val SdkCoroutineExceptionHandler = CoroutineExceptionHandler { context, throwable ->
    val name = context[CoroutineName]?.name
    SdkGlobalHandlers.logSwallowed(if (name != null) "coroutine $name" else "coroutine", throwable)
}

/**
 * Скоуп для фоновой работы SDK: [SupervisorJob] + переданный диспетчер + [SdkCoroutineExceptionHandler].
 * Использовать вместо прямого конструктора [CoroutineScope], чтобы новый скоуп не оказался без сетки.
 */
internal fun sdkScope(dispatcher: CoroutineDispatcher): CoroutineScope =
    CoroutineScope(SupervisorJob() + dispatcher + SdkCoroutineExceptionHandler)
