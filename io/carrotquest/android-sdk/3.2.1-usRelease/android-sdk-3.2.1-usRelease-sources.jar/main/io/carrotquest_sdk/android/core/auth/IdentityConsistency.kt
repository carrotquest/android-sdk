package io.carrotquest_sdk.android.core.auth

import android.os.SystemClock
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.coroutines.sdkScope
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.lib.network.auth.JwtIdentityGuard
import io.carrotquest_sdk.android.lib.network.auth.currentRequestAuthToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlockingDetailed
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Продакшен-обвязка [IdentityRepairer]: сверяет текущую личность с владельцем токена запросов и
 * лечит рассинхрон. Точки вызова — барьер идентичности (заблокированный запрос), завершение auth и
 * готовность сессии; проверка дешёвая (декодирование claims), вызывать можно свободно.
 */
internal object IdentityConsistency {

    private const val TAG = "IdentityConsistency"

    // Отдельный скоуп: ремонт запускается из OkHttp-интерсептора, а блокирующий refresh нельзя
    // делать на его потоке (и на main). Отменяется в deInit вместе со сбросом счётчиков.
    private val scope = sdkScope(SdkDispatchers.io)

    // Лямбды — fail-open (пустая личность / null-владельцы = «проверить нечем»): repair() зовёт
    // mismatch() между ступенями без обёртки, и исключение из чтения репозитория (граф DI разобран)
    // или декодера JWT обрывало бы лестницу с уже сожжённым бюджетом попыток.
    private val repairer = IdentityRepairer(
        currentId = { runCatching { io.carrotquest_sdk.android.data.user.UserStateHolder.currentId() }.getOrDefault("") },
        tokenOwners = { runCatching { JwtIdentityGuard.tokenOwnerIds(currentRequestAuthToken()) }.getOrNull() },
        refreshAccess = {
            withContext(SdkDispatchers.io) { refreshJwtTokenBlockingDetailed(null) }
        },
        reAuthStoredCreds = { CarrotInternal.getService()?.reAuthForIdentityRepair() ?: false },
        rebuildSession = { CarrotInternal.getService()?.recoverSession() },
        elapsedMs = { SystemClock.elapsedRealtime() },
        log = { level, message -> SdkLogger.log(level, SdkLogCategory.AUTH, TAG, message) },
    )

    /** null — инвариант соблюдён либо проверить нечем. */
    fun mismatch(): IdentityMismatch? = runCatching { repairer.mismatch() }.getOrNull()

    /**
     * Проверить инвариант и, если он нарушен, полечить — асинхронно. Если всё согласовано, стоит
     * ровно одно декодирование JWT. Во время init/teardown не лечим: там личность и токены и так
     * переписываются, ремонт поверх них создал бы гонку.
     */
    fun checkAndRepairAsync(reason: String) {
        if (!SdkStateManager.isInit()) return
        if (mismatch() == null) return
        scope.launch { repairer.repair(reason) }
    }

    /** Сброс на deInit: отменяем ремонт в полёте, обнуляем кулдаун и счётчик попыток. */
    fun reset() {
        scope.coroutineContext.cancelChildren()
        repairer.reset()
    }
}
