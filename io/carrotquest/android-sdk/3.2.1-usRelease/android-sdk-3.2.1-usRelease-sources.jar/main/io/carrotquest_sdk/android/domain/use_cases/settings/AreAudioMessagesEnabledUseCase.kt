package io.carrotquest_sdk.android.domain.use_cases.settings

import android.content.Context
import io.carrotquest_sdk.android.data.settings.SettingsManager

/**
 * Настройка аппа messenger_enable_audio_messages.
 *
 * true (и значение по умолчанию) — запись голосовых доступна: в инпуте показываем микрофон.
 * false — апп выключил голосовые: кнопки микрофона нет. Прослушивание уже присланных голосовых
 * от настройки не зависит — оно доступно всегда.
 *
 * Источники по порядку: настройки в памяти → кэш SharedPreferences (настройки ещё не пришли:
 * cold start через push, обрыв сети) → true. Кэш пишет [SettingsManager] при каждом connect.
 */
fun areAudioMessagesEnabled(context: Context): Boolean {
    getSettings()?.let { return it.enableAudioMessages }
    return SettingsManager.cachedFlagOrTrue(context, SettingsManager.CACHED_ENABLE_AUDIO_MESSAGES)
}
