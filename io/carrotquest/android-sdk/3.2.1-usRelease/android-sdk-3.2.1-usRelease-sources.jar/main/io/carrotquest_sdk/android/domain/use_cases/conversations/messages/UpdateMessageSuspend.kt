package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.JsonObject
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import java.util.Locale

/**
 * Suspend-версии обновления статуса/беседы сообщения (strangler, ветка remove_rx).
 * Сосуществуют с Observable-ext в UpdateMessageUseCase.kt — разные сигнатуры, конфликта нет.
 * Тонкие делегаты к MessagesRepository (in-memory) — без сети.
 */

/** Проставляет статус сообщению и обновляет его в репозитории. */
suspend fun updateStatusMessage(message: MessageData?, status: String) {
    if (message != null) {
        message.status = status
        MessagesRepository.getInstance().updateMessage(message)
    }
}

/**
 * Привязывает сообщение к беседе (conversation = conversationId), проставляет в
 * sourceJsonData статус LOADED и обновляет сообщение в репозитории.
 */
suspend fun updateConversationMessage(conversationId: String, message: MessageData?) {
    if (message != null) {
        message.conversation = conversationId

        val sourceObject = message.sourceJsonData
        if (sourceObject != null) {
            if (sourceObject.has(F.STATUS)) {
                sourceObject.remove(F.STATUS)
            }
            sourceObject.put(F.STATUS, MessageStatus.LOADED.name.lowercase(Locale.getDefault()))
        }
        message.sourceJsonData = sourceObject

        MessagesRepository.getInstance().updateMessage(message)
    }
}

/** Привязывает сообщение к беседе и обновляет его в репозитории (без смены статуса). */
suspend fun updateMessage(conversationId: String, message: MessageData?) {
    if (message != null) {
        message.conversation = conversationId
        MessagesRepository.getInstance().updateMessage(message)
    }
}

/** Проставляет messageMetaData.loading и обновляет сообщение (по messageId). */
suspend fun updateAutoReplayLoading(messageId: String, value: Boolean) {
    val message = getMessage(messageId)
    if (message != null) {
        message.messageMetaData?.loading = value
        MessagesRepository.getInstance().updateMessage(message)
    }
}

/** Отправляет на сервер пометку replied (conversationParts). Возвращает успех (status == 200). */
suspend fun updateAutoReplay(messageId: String, replied: Boolean): Boolean {
    val bodyMetaDataObject = JsonObject()
    bodyMetaDataObject.addProperty("replied", replied)
    val res = CarrotInternal.getService().carrotLib.conversationPartsSuspend(messageId, bodyMetaDataObject)
    return res.status == 200
}

/** Локальное обновление сообщения в репозитории (без сети). */
suspend fun updateAutoReplayLocal(message: MessageData) {
    MessagesRepository.getInstance().updateMessage(message)
}
