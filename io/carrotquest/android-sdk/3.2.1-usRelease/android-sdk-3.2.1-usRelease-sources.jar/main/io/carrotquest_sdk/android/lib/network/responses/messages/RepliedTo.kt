package io.carrotquest_sdk.android.lib.network.responses.messages

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F

/**
 * Вложенная цитата сообщения (ключ `replied_to`) — снапшот процитированного оригинала,
 * который бэкенд кладёт внутрь цитирующего сообщения (CAR-75966).
 *
 * Это осознанно НЕ [MessageData], а урезанное подмножество полей: по контракту у вложенной
 * цитаты нет своего `replied_to` (вложенность исключена структурно), нет `conversation`,
 * `direction`, `meta_data`, `actions` и пр. Ключ `replied_to` в сообщении отсутствует целиком
 * (не null), если цитаты нет или оригинал физически удалён — тогда поле [MessageData.repliedTo]
 * остаётся null.
 */
@Keep
data class RepliedTo(
    @SerializedName(F.ID)
    @Expose
    val id: String,

    /** Тип оригинала: reply_user / reply_admin / article. */
    @SerializedName(F.TYPE)
    @Expose
    val type: String? = null,

    @SerializedName(F.CREATED)
    @Expose
    val created: String? = null,

    /** Тело оригинала; для article бэкенд кладёт сюда НАЗВАНИЕ статьи, не её id. */
    @SerializedName(F.BODY)
    @Expose
    val body: String? = null,

    /**
     * Автор оригинала. Для reply_user бэкенд отдаёт урезанный объект `{id, name}` без
     * аватара — все поля [Admin], кроме id/name, могут быть null.
     */
    @SerializedName(F.FROM)
    @Expose
    val from: Admin? = null,

    /** Вложения оригинала; ключ приходит только когда список не пуст. */
    @SerializedName(F.ATTACHMENTS)
    @Expose
    val attachments: ArrayList<Attachment> = ArrayList(),

    /** Мягкое удаление оригинала: плашку «Сообщение удалено» рисует клиент. */
    @SerializedName(F.REMOVED)
    @Expose
    val removed: Boolean = false,

    @SerializedName(F.EDITED)
    @Expose
    val edited: Boolean = false,

    /**
     * Частичная цитата (выделенный фрагмент оригинала). При рендере приоритетнее [body].
     * Заморожен на момент отправки; при edit/purge оригинала бэкенд молча стирает его в БД
     * без отдельного RTS-события по цитирующим сообщениям.
     */
    @SerializedName(F.PARTIAL_TEXT)
    @Expose
    val partialText: String? = null,
)
