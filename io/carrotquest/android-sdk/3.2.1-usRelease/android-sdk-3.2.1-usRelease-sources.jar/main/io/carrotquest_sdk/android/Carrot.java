package io.carrotquest_sdk.android;

import android.content.Context;

import io.carrotquest_sdk.android.core.main.CarrotSDK;

public class Carrot extends CarrotSDK {

    /** Brand-named alias of {@link io.carrotquest_sdk.android.Callback}. */
    public interface Callback<T> extends io.carrotquest_sdk.android.Callback<T> {
    }

    /**
     * Not meant to be instantiated — {@link Carrot} is a static facade, use its static methods
     * (e.g. {@code Carrot.setup(...)}) directly. The constructor stays private to prevent creating
     * useless, half-initialized instances.
     */
    private Carrot(Context context) {
        super(context);
    }
}