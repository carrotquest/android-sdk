package io.carrotquest_sdk.android.core.constants


enum class ConversationType(val stringValue: String) {
    CHAT ("popup_chat"),
    POPUP_BIG("popup_big"),
    POPUP_SMALL("popup_small"),
    BLOCK_POPUP_BIG("block_popup_big"),
    BLOCK_POPUP_SMALL("block_popup_small"),
    LEAD_BOT("lead_bot"),
    ROUTING_BOT("routing_bot")
}

private val POPUP_CONVERSATION_TYPES = setOf(
    ConversationType.POPUP_BIG.stringValue,
    ConversationType.POPUP_SMALL.stringValue,
    ConversationType.BLOCK_POPUP_BIG.stringValue,
    ConversationType.BLOCK_POPUP_SMALL.stringValue,
)

/**
 * Беседа-поп-ап (а не чат). Такие диалоги не отображаются как чат — их показываем оверлеем
 * и пропускаем при выборе «последнего диалога» (openChat). NB: CHAT.stringValue == "popup_chat"
 * — это ОБЫЧНЫЙ чат, не поп-ап.
 */
fun isPopUpConversationType(type: String?): Boolean = type != null && type in POPUP_CONVERSATION_TYPES