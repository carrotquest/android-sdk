package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.data.data_entities.popup.PopUpStatesModel
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.repositories.PopupRepository
import io.carrotquest_sdk.android.data.repositories.SettingsRepository

// suspend (ветка remove_rx) — Observable-ext убрана. Кэш картинок попапа — fire-and-forget
// внутри saveImages; сохранение попапа в БД (savePopUp) триггерит показ.
suspend fun saveNewPopUp(popUpMessage: PopUpMessage): PopUpMessage {
    val appId = SettingsRepository.getInstance().getSettingsObject()?.appId
    saveImages(popUpMessage, appId)

    PopupRepository.savePopUp(
        PopUpDbEntity(
            id = popUpMessage.id,
            state = PopUpStatesModel.PROCESS.name,
            bodyJson = popUpMessage.sourceJson,
            expirationTime = popUpMessage.expirationTime,
            backgroundColor = popUpMessage.backgroundColor
        )
    )
    return popUpMessage
}
