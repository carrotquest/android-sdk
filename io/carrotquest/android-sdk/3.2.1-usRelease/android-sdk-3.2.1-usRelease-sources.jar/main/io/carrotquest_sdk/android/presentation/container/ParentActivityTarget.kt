package io.carrotquest_sdk.android.presentation.container

/**
 * Куда вести пользователя при закрытии чата, открытого из пуша при закрытом приложении
 * (см. SdkContainerActivity.navigateToParentActivity / Carrot.setParentActivityClassName).
 */
internal sealed interface ParentActivityTarget {
    /** Указанная хостом Activity (Carrot.setParentActivityClassName). */
    data class Named(val className: String) : ParentActivityTarget

    /** Имя не задано — запускаем launcher-Activity приложения. */
    data object AppLauncher : ParentActivityTarget
}

/**
 * Чистый выбор цели по имени parent-activity: непустое имя → [ParentActivityTarget.Named],
 * иначе → [ParentActivityTarget.AppLauncher]. Покрыт ParentActivityTargetTest.
 */
internal fun parentActivityTarget(parentClassName: String?): ParentActivityTarget =
    if (!parentClassName.isNullOrBlank()) ParentActivityTarget.Named(parentClassName)
    else ParentActivityTarget.AppLauncher
