package io.carrotquest_sdk.android.core.util;

import io.carrotquest_sdk.android.core.logging.SdkLogger;

/**
 * Легаси-фасад логирования. Делегирует в {@link SdkLogger}; весь вывод гейтится уровнем
 * (по умолчанию NONE — ничего не пишется). Оставлен ради существующих call-site'ов.
 */
public class Log {
    public static void i(String tag, String msg) {
        SdkLogger.i(tag, msg);
    }

    public static void e(String tag, String msg) {
        SdkLogger.e(tag, msg);
    }

    public static void e(String tag, Exception e) {
        SdkLogger.e(tag, e.toString(), e);
    }

    public static void e(String tag, Throwable t) {
        SdkLogger.e(tag, t.toString(), t);
    }

    public static void d(String tag, String msg) {
        SdkLogger.d(tag, msg);
    }

    public static void v(String tag, String msg) {
        SdkLogger.v(tag, msg);
    }
}
