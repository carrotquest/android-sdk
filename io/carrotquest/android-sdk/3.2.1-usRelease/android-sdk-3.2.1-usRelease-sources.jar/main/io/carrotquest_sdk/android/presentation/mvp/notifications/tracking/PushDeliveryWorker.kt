package io.carrotquest_sdk.android.presentation.mvp.notifications.tracking

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository


class PushDeliveryWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        Log.d("PushDeliveryWorker", "doWork")
        val conversationId = inputData.getString("CONVERSATION_ID") ?: return Result.failure()

        Log.d("PushDeliveryWorker", "conversationId: $conversationId")
        return try {
            val context = CarrotInternal.getLibComponent().contextSdk

            CarrotInternal.setupWithoutConnect(context)
            // plain Worker (синхронный doWork) — блокирующе ждём suspend-вызов.
            val response = kotlinx.coroutines.runBlocking {
                CarrotInternal.getService().carrotLib.markReadSuspend(conversationId)
            }

            Log.d("PushDeliveryWorker", "response.status: ${response.status}")
            if(response.status != 200) {
                Result.retry()
            } else {
                ConversationsRepository.getInstance().removeUnreadConversation(conversationId)
                PushStorage.removePushId(applicationContext, conversationId)

                Result.success()
            }
        } catch (e: Exception) {
            Log.d("PushDeliveryWorker", "Exception: $e")
            Log.e("PushDeliveryWorker", e)
            // 403 — скоупов на этот диалог нет и не появится (типовой случай: пуш пришёл прежнему
            // юзеру после logout, markread чужого диалога). Ретрай лишь повторял бы 403 на каждом
            // взводе WorkManager. Прочие ошибки (сеть, 5xx) — ретраим как раньше.
            if (e is retrofit2.HttpException && e.code() == 403) {
                PushStorage.removePushId(applicationContext, conversationId)
                Result.failure()
            } else {
                Result.retry()
            }
        }
    }
}