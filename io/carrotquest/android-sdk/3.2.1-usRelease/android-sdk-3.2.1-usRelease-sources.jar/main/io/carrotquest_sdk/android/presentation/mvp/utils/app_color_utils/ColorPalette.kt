package io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils

import io.carrotquest_sdk.android.core.main.ThemeSdk

/**
 * Структура данных для хранения "системы цветов" для чата.
 *
 */
data class ColorPalette(val originalAccentColor: String,
                        val contrastAccentColor: String,
                        val theme: ThemeSdk
)
