package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.core.auth.IdentityConsistency
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.network.F
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Последний рубеж перед отправкой: не выпускает запрос, у которого user_id в пути не совпадает с
 * владельцем auth_token (см. [JwtIdentityGuard]).
 *
 * Стоит в цепочке ПОСЛЕДНИМ — после paramAdds (который прикладывает auth_token) и после
 * [TokenRefreshInterceptor] (чтобы проверялись и ретраи с обновлённым токеном).
 *
 * Почему блокируем, а не «чиним на лету». Такой запрос гарантированно получает
 * `403 PermissionDeniedError`, а 403 у нас запускает сброс кред и token-less пересоздание сессии —
 * то есть НОВОГО анонимного юзера. Именно так одна проигранная гонка превращалась в поток ошибок и
 * россыпь анонимов на бэкенде. Дешевле потерять одну операцию (её инициатор повторит её на
 * следующем init/тике), чем уронить идентичность всей сессии.
 *
 * Подменять user_id в пути на владельца токена тоже нельзя: если владелец — устаревший аноним,
 * запрос «успешно» запишет данные не тому юзеру, и мы получим молчаливую порчу вместо явной ошибки.
 */
internal class IdentityGuardInterceptor : Interceptor {

    private companion object {
        const val TAG = "IdentityGuard"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val token = request.url.queryParameter(F.AUTH_TOKEN)
        val path = request.url.encodedPath

        if (!JwtIdentityGuard.isMismatch(token, path)) return chain.proceed(request)

        val owners = JwtIdentityGuard.tokenOwnerIds(token)
        val requested = JwtIdentityGuard.requestUserId(path)
        SdkLogger.log(
            SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
            "BLOCKED $path: request addresses user_id=$requested, but auth_token belongs to $owners. " +
                "Sending it would return 403 and reset the session to a new anonymous user.",
        )
        // Блокировка — не конец: 403 (единственный триггер пересоздания сессии) теперь не придёт,
        // поэтому сам барьер обязан позвать ремонт, иначе рассинхрон вечен (был прод-инцидент:
        // «нет соединения» при живой сети до переустановки приложения). Асинхронно — на потоке
        // OkHttp блокирующий refresh делать нельзя; ремонт сам себя гейтит кулдауном и лимитом.
        IdentityConsistency.checkAndRepairAsync("blocked $path")
        throw IdentityMismatchException("Carrot SDK: request user_id does not match the auth_token owner")
    }
}
