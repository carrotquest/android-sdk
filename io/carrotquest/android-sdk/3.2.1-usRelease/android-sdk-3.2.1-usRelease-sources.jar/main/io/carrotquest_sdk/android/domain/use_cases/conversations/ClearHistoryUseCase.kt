package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.core.util.Log

// Синхронная очистка истории диалогов (ветка remove_rx) — Observable-ext убрана.
fun clearHistory() {
    ConversationsRepository.getInstance().clearConversations()
    Log.d("clearHistory", "clear History dialogs")
}
