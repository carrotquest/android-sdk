package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.repositories.IUserRepository
import io.carrotquest_sdk.android.lib.wss.jwt.clearJwtTokens
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlocking
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Зависимости [refreshToken]/[clearTokens]/[onSessionExpired] вынесены в конструктор для
 * тестируемости (по умолчанию делегируют в реальные top-level функции). Production-код и Java
 * (`RetrofitModule`) используют конструктор с одним аргументом через @JvmOverloads.
 */
internal class TokenRefreshInterceptor @JvmOverloads constructor(
    private val userRepository: IUserRepository,
    private val refreshToken: (String?) -> String? = { failed -> refreshJwtTokenBlocking(failed) },
    private val clearTokens: () -> Unit = { clearJwtTokens() },
    private val onSessionExpired: () -> Unit = { SdkStateManager.notifySessionExpired() }
) : Interceptor {

    private companion object {
        const val TAG = "TokenRefreshInterceptor"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())
        val url = chain.request().url.toString()

        if (url.contains("refresh")) return response
        if (response.code != 401 && response.code != 403) return response

        // Логируем причину отказа: сервер обычно кладёт её в тело ответа. encodedPath — без query,
        // чтобы не светить auth_token в логах. Тело здесь можно безопасно прочитать: ниже мы в любом
        // случае не возвращаем оригинальный response (всегда retry/re-proceed нового запроса).
        val code = response.code
        val errorBody = try {
            response.body?.string().orEmpty()
        } catch (e: Exception) {
            ""
        }
        Log.e(TAG, "auth-protected request got HTTP $code on ${chain.request().url.encodedPath}; body=$errorBody")

        response.close()

        val oldToken = chain.request().url.queryParameter(F.AUTH_TOKEN)
        // Для 401: передаём упавший токен — если JWT_TOKEN_KEY уже обновлён другим потоком,
        //          refreshJwtTokenBlocking вернёт его сразу (оптимизация для конкурентных 401).
        // Для 403: передаём null — форсируем реальный /refresh запрос.
        //          Причина: JWT_TOKEN_KEY (connect-jwt) может отличаться от user.token (auth-jwt),
        //          и оптимизация `current != failedToken` вернула бы connect-jwt без рефреша,
        //          что тоже просрочено и дало бы повторный 403.
        val failedToken = if (response.code == 403) null else oldToken
        Log.i(TAG, "attempting token refresh after HTTP $code (forced=${response.code == 403})")
        val newToken = try {
            refreshToken(failedToken)
        } catch (e: java.io.IOException) {
            // Сетевая ошибка во время refresh — повторяем оригинальный запрос как есть,
            // он тоже упадёт с IOException, и caller получит сетевую ошибку. Токены не трогаем.
            Log.e(TAG, "refresh network error, retrying original request as-is (tokens NOT touched): $e")
            return chain.proceed(chain.request())
        }
        if (newToken == null) {
            // Refresh провален сервером (не сеть — IOException обработан выше) → refresh-токен мёртв.
            // Чистим ВСЕ persisted креды (вкл. легаси CarrotToken), чтобы следующий /connect стартовал
            // свежую сессию и протухшая авторизация не залипала до переустановки — теперь достаточно
            // перезапуска приложения. Сигналим клиенту, что сессия истекла, и возвращаем ответ как есть
            // (без бесконечных retry).
            Log.e(TAG, "refresh REJECTED by server → both tokens dead, clearing creds (next /connect will go anonymous)")
            clearTokens()
            onSessionExpired()
            return chain.proceed(chain.request())
        }

        Log.i(TAG, "refresh SUCCESS → retrying original request with new access (no new lead)")
        userRepository.getUser()?.let { user ->
            user.token = newToken
            userRepository.saveUser(user)
        }

        val newUrl = chain.request().url.newBuilder()
            .setQueryParameter(F.AUTH_TOKEN, newToken)
            .build()
        return chain.proceed(chain.request().newBuilder().url(newUrl).build())
    }
}
