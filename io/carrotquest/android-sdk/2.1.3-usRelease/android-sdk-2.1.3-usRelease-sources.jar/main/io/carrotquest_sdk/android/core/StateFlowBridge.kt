package io.carrotquest_sdk.android.core

import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.subjects.BehaviorSubject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val TAG = "StateFlowBridge"

private val bridgeScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

private fun attachInitSubject(subject: BehaviorSubject<Boolean>) {
    bridgeScope.launch {
        SdkStateManager.publicState.collect { state ->
            try {
                subject.onNext(state is CarrotState.Ready)
            } catch (t: Throwable) {
                Log.e(TAG, "attachInitSubject.onNext failed: $t")
            }
        }
    }
}

@Volatile
private var initSubject: BehaviorSubject<Boolean>? = null

/**
 * Внутренний Rx-мост init-состояния (true == SDK Ready). Раньше отдавался наружу через
 * публичный `Carrot.getInitObservable()`, который убрали из API — состояние SDK не должно
 * занимать клиента. Оставлен только для внутренних Rx-потребителей (например,
 * FloatingButtonPresenter), которые ждут готовности SDK.
 */
internal fun internalInitObservable(): BehaviorSubject<Boolean> {
    var subject = initSubject
    if (subject == null) {
        subject = BehaviorSubject.createDefault(SdkStateManager.isInit())
        attachInitSubject(subject)
        initSubject = subject
    }
    return subject
}
