package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

/**
 * Полностью сбрасывает persisted JWT-креды, чтобы следующий /connect начал свежую сессию.
 *
 * Важно: чистим не только новые JWT-ключи, но и легаси "CarrotToken". Легаси-ключ переживал
 * прежние частичные очистки токенов (ConnectionManager чистил только jwt/refresh) и мог
 * "воскрешать" мёртвый токен через refresh-fallback в RetrofitModule.paramAdds, а также через
 * UserRepository.loadUser(). Из-за этого протухшая авторизация залипала до переустановки —
 * после сброса достаточно перезапуска приложения.
 */
fun clearJwtTokens(context: Context = CarrotLib.getLibComponents().context) {
    Log.i("TokenFlow", "clearJwtTokens: wiping access+refresh+CarrotToken. Before: ${tokenStateSummary()}")
    SharedPreferencesLib.saveString(context, jwtTokenKey, "")
    SharedPreferencesLib.saveString(context, refreshTokenKey, "")
    SharedPreferencesLib.clearPreference(context, jwtTokenUpdateTimeStampKey)
    SharedPreferencesLib.clearPreference(context, refreshTokenUpdateTimeStampKey)
    SharedPreferencesLib.clearPreference(context, SharedPreferenceKeys.CARROT_TOKEN)
}