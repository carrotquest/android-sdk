package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject

private const val TAG = "JWT"

/**
 * Асинхронный refresh JWT-токена. При успехе (status 200) — сохраняет новые access+refresh
 * в SharedPrefs и эмитит новый access в переданный subject.
 *
 * ВАЖНО: subject чаще всего shared (например, [JwtTokenRefreshService.updateJwtTokenObservable]).
 * Мы НЕ вызываем onError на subject при сбое — это терминирует shared поток для всех
 * подписчиков. Вместо этого сетевые и HTTP-ошибки логируются, а subject просто не эмитит —
 * следующий вызов refresh (таймер / повторная попытка) попробует снова.
 *
 * Для путей, которым нужен явный error path (HTTP interceptor, [ConnectionManager]) используй
 * [refreshJwtTokenBlocking] — он возвращает `String?` и не трогает shared subject.
 */
fun refreshJwtToken(updateJwtTokenSubject: BehaviorSubject<String>) {
    val carrotApi = CarrotLib.getLibComponents().carrotApi
    val needUpdateRefreshToken = !isActualRefreshToken()
    Log.i(TAG, "refreshJwtToken(async): requesting /refresh (updateRefreshToken=$needUpdateRefreshToken). State: ${tokenStateSummary()}")

    try {
        carrotApi.refresh(needUpdateRefreshToken)
            .subscribeOn(Schedulers.io())
            .take(1)
            .subscribe(
                { response ->
                    if (response.meta.status == 200) {
                        val token = response.data.access
                        saveJwtToken(token)
                        saveRefreshToken(response.data.refresh)
                        updateJwtTokenSubject.onNext(token)
                        Log.i(TAG, "refreshJwtToken(async): SUCCESS, new access=${maskToken(token)}")
                    } else {
                        // Не-200 ответ: истёкший refresh, 4xx/5xx от сервера и т.д.
                        // Оставляем реальные код и сообщение — не фальшивые "999".
                        Log.e(TAG, "refresh non-200: status=${response.meta.status}, error=${response.meta.error}")
                        // 4xx — серверный отказ (протухший refresh-токен и т.п.), не сетевой сбой.
                        // Уведомляем SDK: клиент должен вызвать deInit() + setup().
                        if (response.meta.status in 400..499) {
                            SdkStateManager.notifySessionExpired()
                        }
                    }
                },
                { e ->
                    // Сетевая ошибка (IOException), TimeoutException и т.д. Сохраняем оригинал.
                    Log.e(TAG, e)
                }
            )
    } catch (e: Exception) {
        Log.e(TAG, e)
    }
}
