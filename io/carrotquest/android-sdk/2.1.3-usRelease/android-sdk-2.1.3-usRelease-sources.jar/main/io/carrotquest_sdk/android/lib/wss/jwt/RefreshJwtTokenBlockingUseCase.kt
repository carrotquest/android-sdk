package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib

// Shared lock — serializes all callers (timer + HTTP 401 interceptor).
internal val refreshLock = Any()

/**
 * Синхронно обновляет JWT-токен. Безопасно при конкурентных вызовах:
 * если пока мы ждали lock другой поток уже обновил токен — возвращаем готовый.
 *
 * @param failedToken токен, с которым запрос получил 401 (null для timer-based refresh)
 */
internal fun refreshJwtTokenBlocking(failedToken: String? = null): String? {
    synchronized(refreshLock) {
        val current = getJwtToken()
        if (!failedToken.isNullOrEmpty() && current.isNotEmpty() && current != failedToken) {
            Log.i("TokenFlow", "refreshBlocking: token already refreshed by another thread, reusing access=${maskToken(current)}")
            return current
        }
        val updateRefresh = !isActualRefreshToken()
        Log.i("TokenFlow", "refreshBlocking: requesting /refresh (updateRefreshToken=$updateRefresh). State: ${tokenStateSummary()}")
        return try {
            val carrotApi = CarrotLib.getLibComponents().carrotApi
            val response = carrotApi.refresh(updateRefresh)
                .take(1)
                .blockingFirst()
            if (response.meta.status == 200) {
                saveJwtToken(response.data.access)
                saveRefreshToken(response.data.refresh)
                Log.i("TokenFlow", "refreshBlocking: SUCCESS, new access=${maskToken(response.data.access)} (refresh token still alive)")
                response.data.access
            } else {
                // Не-200: refresh-токен отвергнут сервером → оба токена мертвы → caller уйдёт в анонима.
                Log.e("TokenFlow", "refreshBlocking: REJECTED status=${response.meta.status} error=${response.meta.error} → refresh token dead, will fall back to anonymous")
                null
            }
        } catch (e: java.io.IOException) {
            // Сетевая ошибка — пробрасываем, чтобы caller мог отличить её от серверного отказа.
            // Токены при этом не трогаем: они могут быть валидны, просто сеть недоступна.
            Log.e("TokenFlow", "refreshBlocking: NETWORK error (tokens NOT touched): $e")
            throw e
        } catch (e: Exception) {
            // RxJava blockingFirst оборачивает checked IOException в RuntimeException — разворачиваем,
            // иначе сетевой сбой выглядел бы как «refresh мёртв» и приводил бы к сбросу токенов/анониму.
            val cause = e.cause
            if (cause is java.io.IOException) {
                Log.e("TokenFlow", "refreshBlocking: NETWORK error (unwrapped, tokens NOT touched): $cause")
                throw cause
            }
            Log.e("TokenFlow", "refreshBlocking: error $e")
            null
        }
    }
}
