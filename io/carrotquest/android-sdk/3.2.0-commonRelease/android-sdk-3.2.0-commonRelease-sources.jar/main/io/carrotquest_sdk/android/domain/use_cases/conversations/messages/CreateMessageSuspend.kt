package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.Gson
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.RepliedTo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

/**
 * Suspend-версии создания/сохранения исходящих сообщений (strangler, ветка remove_rx).
 * Сосуществуют с Observable-ext в CreateMessageUseCase.kt — разные сигнатуры (нет
 * Observable-receiver), конфликта нет.
 *
 * Чистая логика построения сообщения и защита от перекоса часов вынесены в
 * internal-функции [clampOutgoingCreated]/[buildOutgoingTextMessage]/
 * [buildOutgoingAttachmentMessage] — без обращения к синглтонам, покрыты юнит-тестами.
 */

/**
 * Время (created, в секундах) для нового исходящего сообщения с защитой от перекоса
 * системных часов устройства: берём максимум из времени устройства и (последнее
 * сообщение в диалоге + 1 c), чтобы сообщение не встало раньше существующих
 * (чат сортируется по created). Гранулярность created — секунды.
 */
internal fun outgoingCreatedSeconds(deviceSeconds: Long, lastMessageCreatedSeconds: Long): Long =
    max(deviceSeconds, lastMessageCreatedSeconds + 1)

/**
 * То же, что [outgoingCreatedSeconds], но дополнительно клампит к lastUpdate беседы
 * (приходит строкой, бывает null/невалидным — тогда 0). Применяется для текстовых
 * сообщений (у вложений клампа к lastUpdate нет — см. оригинал).
 */
internal fun clampOutgoingCreated(
    deviceSeconds: Long,
    lastMessageCreatedSeconds: Long,
    conversationLastUpdate: String?
): Long {
    val lastUpdateLong = conversationLastUpdate?.toLongOrNull() ?: 0L
    return max(outgoingCreatedSeconds(deviceSeconds, lastMessageCreatedSeconds), lastUpdateLong)
}

/**
 * Текст оригинала для цитаты. У статьи из базы знаний body — это ID статьи, а название лежит
 * в bodyJson.name; бэкенд в replied_to.body тоже отдаёт название — локальные превью (чип
 * инпута, optimistic-снапшот) должны совпадать с серверными.
 */
fun MessageData.quotableBodyText(): String? {
    if (type != ResponseFields.ARTICLE) return body
    return runCatching {
        bodyJson?.takeIf { it.isJsonObject }?.asJsonObject
            ?.get("name")?.takeIf { !it.isJsonNull }?.asString
    }.getOrNull()?.takeIf { it.isNotBlank() } ?: body
}

/**
 * Локальный снапшот цитаты из уже загруженного оригинала — чтобы optimistic-бабл выглядел
 * идентично серверному эху (бэкенд в ответ на replied_to=id вернёт такой же объект).
 * null, если у оригинала нет серверного id (цитировать optimistic-сообщение нельзя — 400).
 */
fun MessageData.toRepliedToSnapshot(): RepliedTo? {
    val originalId = id ?: return null
    return RepliedTo(
        id = originalId,
        type = type,
        created = created,
        // Как в серверном replied_to: для article — название статьи, не её id.
        body = quotableBodyText(),
        from = messageFrom,
        attachments = attachments ?: ArrayList(),
        // removed у MessageData — строка-таймстамп; непустая = оригинал мягко удалён.
        removed = !removed.isNullOrEmpty() && !removed.equals("false", ignoreCase = true),
        edited = false,
        partialText = null,
    )
}

/** Чистое построение исходящего текстового сообщения. Без синглтонов и сети. */
internal fun buildOutgoingTextMessage(
    text: String,
    conversationId: String,
    createdSeconds: Long,
    isFirst: Boolean,
    status: MessageStatus,
    repliedTo: RepliedTo? = null
): MessageData {
    val createdTS = createdSeconds.toString()
    val message = MessageData()
    message.id = createdTS
    message.body = text.replace("\n", "<br/>")
    message.conversation = conversationId
    message.created = createdTS
    message.sentVia = ResponseFields.SDK_ANDROID
    message.direction = ResponseFields.USER_2_ADMIN
    message.isFirst = isFirst
    message.randomId = createdTS
    message.type = ResponseFields.REPLY_USER
    message.status =
        if (status != MessageStatus.NORMAL) status.name.lowercase(Locale.getDefault()) else ""
    // Ставим ДО сборки sourceJsonData, чтобы replied_to попал и в сырой JSON (Gson сериализует
    // RepliedTo по @SerializedName — та же схема, что у серверного ответа).
    message.repliedTo = repliedTo
    message.sourceJsonData = JSONObject(Gson().toJson(message))
    return message
}

/** Чистое построение исходящего сообщения с вложением. Без синглтонов и сети. */
internal fun buildOutgoingAttachmentMessage(
    attachment: Attachment,
    conversationId: String,
    createdSeconds: Long,
    isFirst: Boolean,
    status: MessageStatus,
    conversation: DataConversation?,
    repliedTo: RepliedTo? = null
): MessageData {
    val createdTS = createdSeconds.toString()

    val messageFrom = Admin()
    messageFrom.id = when (conversation) {
        null -> conversationId
        else -> conversation.id
    }
    messageFrom.avatar = when (conversation) {
        null -> ""
        else -> conversation.partLast?.messageFrom?.avatar
    }
    messageFrom.type = when (conversation) {
        null -> ""
        else -> conversation.partLast?.messageFrom?.type
    }
    messageFrom.name = when (conversation) {
        null -> ""
        else -> conversation.partLast?.messageFrom?.name
    }

    val attachments = ArrayList<Attachment>()
    attachment.status = "loaded"
    attachments.add(attachment)

    val message = MessageData()
    message.id = createdTS
    message.body = ""
    message.conversation = conversationId
    message.created = createdTS
    message.randomId = createdTS
    message.sentVia = ResponseFields.SDK_ANDROID
    message.direction = ResponseFields.USER_2_ADMIN
    message.isFirst = isFirst
    message.type = ResponseFields.REPLY_USER
    message.status =
        if (status != MessageStatus.NORMAL) status.name.lowercase(Locale.getDefault()) else ""
    message.attachments = attachments
    message.messageFrom = messageFrom
    // ДО сборки sourceJsonData — см. buildOutgoingTextMessage.
    message.repliedTo = repliedTo
    message.sourceJsonData = JSONObject(Gson().toJson(message))
    return message
}

/** Обновляет беседу новым последним сообщением (partLast/partsCount). */
private fun applyOutgoingToConversation(conversationId: String, message: MessageData, conversation: DataConversation) {
    conversation.message = message
    conversation.partLast = message
    conversation.partsCount = conversation.partsCount + 1
    ConversationsRepository.getInstance().updateConversation(conversationId, conversation)
}

suspend fun createMessage(
    text: String,
    conversationId: String,
    isFirst: Boolean,
    status: MessageStatus,
    repliedTo: RepliedTo? = null
): MessageData = withContext(Dispatchers.IO) {
    val conversation = getConversationSuspend(conversationId)
    val createdSeconds = clampOutgoingCreated(
        System.currentTimeMillis() / 1000,
        MessagesRepository.getInstance().getLastMessageCreatedSeconds(),
        conversation?.lastUpdate
    )
    val message = buildOutgoingTextMessage(text, conversationId, createdSeconds, isFirst, status, repliedTo)
    if (conversation != null) {
        applyOutgoingToConversation(conversationId, message, conversation)
    }
    message
}

/** Создаёт LOADING-сообщение и сразу кладёт его в репозиторий (как Observable-ext createMessage(text, id)). */
suspend fun createMessage(text: String, conversationId: String, repliedTo: RepliedTo? = null): MessageData {
    val message = createMessage(text, conversationId, isFirst = false, status = MessageStatus.LOADING, repliedTo = repliedTo)
    MessagesRepository.getInstance().addMessage(message)
    return message
}

suspend fun createMessage(
    attachment: Attachment,
    conversationId: String,
    isFirst: Boolean,
    status: MessageStatus,
    repliedTo: RepliedTo? = null
): MessageData = withContext(Dispatchers.IO) {
    val conversation = getConversationSuspend(conversationId)
    // У вложений клампа к lastUpdate беседы нет (см. оригинальный Observable-ext).
    val createdSeconds = outgoingCreatedSeconds(
        System.currentTimeMillis() / 1000,
        MessagesRepository.getInstance().getLastMessageCreatedSeconds()
    )
    val message = buildOutgoingAttachmentMessage(attachment, conversationId, createdSeconds, isFirst, status, conversation, repliedTo)
    if (conversation != null) {
        applyOutgoingToConversation(conversationId, message, conversation)
    }
    message
}

suspend fun saveMessage(message: MessageData): MessageData {
    MessagesRepository.getInstance().addMessage(message)
    return message
}

suspend fun removeWelcomeMessage(): String {
    val message = MessagesRepository.getInstance().getWelcomeMessage() ?: return ""
    val messageId = message.id ?: ""
    MessagesRepository.getInstance().removeMessage(message)
    MessagesRepository.getInstance().saveWelcomeMessage(null)
    return messageId
}
