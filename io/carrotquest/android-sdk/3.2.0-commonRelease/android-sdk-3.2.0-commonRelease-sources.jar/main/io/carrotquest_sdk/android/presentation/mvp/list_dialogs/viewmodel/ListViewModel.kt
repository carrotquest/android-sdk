package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.coroutines.SdkCoroutineExceptionHandler
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadMoreConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.reloadConversation
import io.carrotquest_sdk.android.domain.use_cases.settings.getLastSettings
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationUiItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ErrorType
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListHeaderData
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListUiState
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.PreviewIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

class ListViewModel(application: Application) : AndroidViewModel(application) {

    private companion object {
        const val TAG = "ListViewModel"
        // Сетевой таймаут на загрузку списка/пагинацию. После — Error state, чтобы
        // спиннер не висел при тихих обрывах сети, сломанном HTTP/2-канале или
        // прокси, которые держат соединение, ничего не отдавая.
        const val NETWORK_TIMEOUT_MS = 15_000L
    }

    // Порог "недавний диалог": если последняя реплика не старше этого времени,
    // диалог попадает в секцию "Недавние".
    private val recentThresholdMs: Long = TimeUnit.HOURS.toMillis(1)

    // Последний загруженный список — нужен для перестройки стейта при toggle группы
    private var cachedConversations: List<ConversationUiItem> = emptyList()

    // ID операторов чьи группы раскрыты в данный момент
    private val expandedGroupIds = mutableSetOf<String>()

    fun toggleGroup(operatorId: String) {
        if (expandedGroupIds.contains(operatorId)) expandedGroupIds.remove(operatorId)
        else expandedGroupIds.add(operatorId)
        if (cachedConversations.isNotEmpty()) {
            _uiState.value = buildContent(cachedConversations)
        }
    }

    private val _uiState = MutableStateFlow<ListUiState>(ListUiState.Loading)
    val uiState: StateFlow<ListUiState> = _uiState.asStateFlow()

    private val _headerData = MutableStateFlow(ListHeaderData())
    val headerData: StateFlow<ListHeaderData> = _headerData.asStateFlow()

    private var isPagination = false
    var startedFromNotification = false

    // Подписка на NetworkManager: живёт всё время жизни VM, снимается в onCleared().
    private var networkObserverCancellable: Cancellable? = null

    init {
        loadHeaderData()
        subscribeToLiveUpdates()
        observeNetworkState()
        loadData()
    }

    private fun loadHeaderData() {
        getLastSettings()?.let { _headerData.value = it.toHeaderData() }
    }

    fun loadData() {
        ConversationsRepository.getInstance().saveOpenedConversation("")

        // Live-проверка системного состояния сети (НЕ асинхронный кэш hasConnect, см.
        // комментарий ниже): офлайн-открытие списка и Retry без сети получают мгновенную
        // точную ошибку вместо 15-секундного таймаута или SOMETHING_WENT_WRONG из catch.
        if (!networkManager().isNetworkAvailable()) {
            _uiState.value = ListUiState.Error(offlineErrorType())
            return
        }

        _uiState.value = ListUiState.Loading

        // Не делаем синхронный гейт по NetworkManager.hasConnect: этот флаг —
        // асинхронно прогреваемый кэш (true только после успешного фонового пинга),
        // и сразу после смены сети (например, включения VPN) он может несколько секунд
        // оставаться false при реально работающем интернете. Пускаем запрос — реальную
        // ошибку сети поймает withTimeoutOrNull / catch ниже.
        viewModelScope.launch(Dispatchers.IO + SdkCoroutineExceptionHandler) {
            try {
                val user = getCurrentUser() ?: run {
                    _uiState.value = ListUiState.Error(ErrorType.SOMETHING_WENT_WRONG)
                    return@launch
                }
                val finished = withTimeoutOrNull(NETWORK_TIMEOUT_MS) {
                    loadConversations(user.id)
                    true
                }
                if (finished == null) {
                    _uiState.value = ListUiState.Error(ErrorType.NO_INTERNET)
                    return@launch
                }
                withContext(Dispatchers.Main) {
                    showConversationsFromRepo()
                }
            } catch (e: Exception) {
                Log.e(TAG, e)
                // Если запрос упал из-за пропавшей по ходу загрузки сети — показываем
                // сетевую ошибку, а не generic (observer мог ещё не успеть сработать).
                _uiState.value = ListUiState.Error(
                    if (!networkManager().isNetworkAvailable()) offlineErrorType()
                    else ErrorType.SOMETHING_WENT_WRONG
                )
            }
        }
    }

    // ── Network state ────────────────────────────────────────────────────────

    // Полноэкранная ошибка сети должна показываться всегда, а не только при упавшем
    // loadData: наблюдаем за NetworkManager и перекрываем любой стейт (включая
    // Content/Empty) при потере сети; при восстановлении перезагружаем список,
    // если висела ошибка. Observer НЕ реплеит текущее состояние при подписке
    // (SharedFlow с replay = 0), поэтому стартовый офлайн ловится синхронной
    // проверкой в loadData()/refreshNetworkState().
    private fun observeNetworkState() {
        networkObserverCancellable = networkManager().addObserver { isConnected ->
            if (!isConnected) {
                _uiState.value = ListUiState.Error(offlineErrorType())
            } else if (_uiState.value is ListUiState.Error) {
                loadData()
            }
        }
    }

    /**
     * Синхронная live-сверка стейта с фактическим состоянием сети. Контейнер зовёт её
     * в onResume: после Doze connectivity-broadcast может не прийти вовсе, а
     * revalidate()-ping даёт результат с задержкой в секунды — здесь же ошибка
     * (или восстановление из неё) отражается мгновенно.
     */
    fun refreshNetworkState() {
        if (!networkManager().isNetworkAvailable()) {
            _uiState.value = ListUiState.Error(offlineErrorType())
        } else if (_uiState.value is ListUiState.Error) {
            loadData()
        }
    }

    private fun networkManager(): NetworkManager =
        NetworkManager.getInstance(getApplication<Application>())

    private fun offlineErrorType(): ErrorType =
        if (NetworkManager.isAirplaneModeOn()) ErrorType.AIRPLANE_MODE else ErrorType.NO_INTERNET

    override fun onCleared() {
        networkObserverCancellable?.cancel()
        networkObserverCancellable = null
        super.onCleared()
    }

    private fun showConversationsFromRepo() {
        val conversations = ConversationsRepository.getInstance().conversationsFlow.value
            .filter { it.id != null && it.type != null }
        _uiState.value = if (conversations.isEmpty()) ListUiState.Empty
                         else buildContent(conversations.toSortedUiItems())
    }

    private fun subscribeToLiveUpdates() {
        // Единственный источник live-обновлений — changeSignal, НЕ conversationsFlow.
        // conversationsFlow — StateFlow, дедуплицирующий равные по содержимому списки: часть
        // RTS-обработчиков (ConversationReplyChangedMessage при удалении/редактировании последнего
        // сообщения) мутирует объект DataConversation in-place, поэтому ArrayList(...) содержит те
        // же references → ArrayList.equals == true → StateFlow глотает эмиссию (раньше тут была
        // вторая, дедуплицирующая подписка на conversationsFlow.drop(1) — она ничего не добавляла
        // и была миной). changeSignal срабатывает на КАЖДОЕ изменение (emitConversationsChanged
        // всегда шлёт и value, и сигнал), поэтому ловит in-place-мутации. Начальный показ —
        // loadData()/showConversationsFromRepo().
        viewModelScope.launch(SdkCoroutineExceptionHandler) {
            ConversationsRepository.getInstance().changeSignal.collect {
                val state = _uiState.value
                if (state is ListUiState.Loading) return@collect
                // Пока показываем сетевую ошибку — не даём залётному сигналу репозитория
                // перерисовать список поверх неё: из офлайн-ошибки выводит только
                // loadData() (observer сети / Retry / refreshNetworkState).
                if (state is ListUiState.Error && state.type != ErrorType.SOMETHING_WENT_WRONG) return@collect
                val conversations = ConversationsRepository.getInstance().conversationsFlow.value
                    .filter { it.id != null && it.type != null }
                _uiState.value = if (conversations.isEmpty()) ListUiState.Empty
                                 else buildContent(conversations.toSortedUiItems())
            }
        }


        // Удаление сообщения → перезагрузить диалог если в нём ещё есть сообщения
        viewModelScope.launch(Dispatchers.IO + SdkCoroutineExceptionHandler) {
            MessagesRepository.getInstance().removedMessageFlow.collect { message ->
                message ?: return@collect
                val conversation = ConversationsRepository.getInstance()
                    .getConversationById(message.conversation) ?: return@collect
                if ((conversation.partsCount ?: 0) > 1) {
                    reloadConversation(message.conversation)
                }
            }
        }
    }

    fun onPagination() {
        if (isPagination) return
        isPagination = true
        viewModelScope.launch(Dispatchers.IO + SdkCoroutineExceptionHandler) {
            try {
                val user = getCurrentUser() ?: return@launch
                withTimeoutOrNull(NETWORK_TIMEOUT_MS) {
                    loadMoreConversations(user.id, ConversationsRepository.getInstance().getCurrentAfter())
                }
            } catch (e: Exception) {
                Log.e(TAG, e)
            } finally {
                // finally гарантирует сброс флага и при таймауте, и при отмене корутины.
                isPagination = false
            }
        }
    }

    // Корутины viewModelScope отменяются автоматически; вручную в onCleared()
    // снимается только observer NetworkManager (он живёт в скоупе менеджера).

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun List<DataConversation>.toSortedUiItems() =
        sortedByDescending { it.lastUpdate?.toLongOrNull() ?: 0L }
            .map { it.toUiItem() }

    // ── Mappers ──────────────────────────────────────────────────────────────

    private fun SettingsEntity.toHeaderData(): ListHeaderData {
        val msg = when (statusOperators) {
            // offline-текст показываем только если он включён в настройках виджета
            StatusOperators.OFFLINE -> if (showOfflineMessage) offlineMessage ?: "" else ""
            else -> onlineMessage ?: ""
        }
        val isOnline = when (statusOperators) {
            StatusOperators.ONLINE -> true
            StatusOperators.OFFLINE -> false
            else -> null
        }

        return ListHeaderData(
            appName = appName ?: "",
            statusMessage = msg,
            isOnline = isOnline,
            adminAvatarUrls = (admins.filter { !it.avatar.isNullOrEmpty() }.shuffled() +
                               admins.filter { it.avatar.isNullOrEmpty() }.shuffled())
                .take(3)
                .map { it.avatar ?: "" },
            showPoweredBy = showPoweredBy
        )
    }

    private fun DataConversation.toUiItem(): ConversationUiItem {
        val lastMsg = partLast
        lastMsg.conversationType = type
        val ctx = getApplication<Application>()

        val (previewText, icon) = buildPreview(lastMsg, ctx)

        val namePrefix = if (previewText.isNotEmpty()
            && lastMsg?.removed.isNullOrEmpty()
            && lastMsg?.direction == ResponseFields.ADMIN_2_USER
            && lastMsg.sentVia == "message_manual"
            && !(type ?: "").contains("block_popup")
        ) {
            lastMsg.messageFrom?.name?.takeIf { it.isNotEmpty() }
        } else {
            null
        }

        val lastReplyTimestamp = (partLast?.created ?: lastUpdate)
            ?.toLongOrNull()?.times(1000L) ?: 0L
        val isRecent = System.currentTimeMillis() - lastReplyTimestamp <= recentThresholdMs

        // Fallback для диалогов без оператора (новый без ответа, триггер, системный):
        // берём имя приложения из шапки — так же, как делает DialogHeader.
        val displayAdmin = getDisplayAdmin()
        val fallbackName = _headerData.value.appName.takeIf { it.isNotEmpty() }
        val displayAdminName = displayAdmin?.name?.takeIf { it.isNotEmpty() } ?: fallbackName

        return ConversationUiItem(
            id = id ?: "",
            lastMessageText = previewText,
            lastMessagePrefix = namePrefix,
            lastMessageIcon = icon,
            lastMessageTime = lastUpdate?.toFormattedTime() ?: "",
            unreadCount = unreadPartsCount ?: 0,
            adminName = displayAdminName,
            adminAvatarUrl = displayAdmin?.avatar,
            lastAdminId = displayAdmin?.id,
            isClosed = closed ?: false,
            isRecent = isRecent,
            isLastMessageDeleted = !lastMsg?.removed.isNullOrEmpty(),
        )
    }

    private fun DataConversation.getDisplayAdmin() =
        if (lastSender?.type == "message_sender") lastSender else lastAdmin

    private fun buildContent(conversations: List<ConversationUiItem>): ListUiState.Content {
        cachedConversations = conversations
        return ConversationListBuilder.build(conversations, expandedGroupIds) as ListUiState.Content
    }

    private fun buildPreview(
        msg: io.carrotquest_sdk.android.lib.network.responses.messages.MessageData?,
        ctx: android.content.Context
    ): Pair<String, PreviewIcon> = MessagePreviewBuilder.build(
        msg,
        MessagePreviewBuilder.Strings(
            file        = ctx.getString(R.string.file_str),
            image       = ctx.getString(R.string.image_str),
            images      = ctx.getString(R.string.images_str),
            files       = ctx.getString(R.string.files_str),
            deleted     = ctx.getString(R.string.list_message_deleted),
            popup       = ctx.getString(R.string.list_message_popup),
            vote        = ctx.getString(R.string.list_message_vote),
            botButtons  = ctx.getString(R.string.list_message_bot_buttons),
            botAnswerField = ctx.getString(R.string.list_message_bot_answer_field),
            botCalendly = ctx.getString(R.string.list_message_bot_calendly),
        )
    )

    private fun String.toFormattedTime(): String {
        return try {
            val timestamp = this.toLong() * 1000
            val now = System.currentTimeMillis()
            val diffMs = now - timestamp
            val ctx = getApplication<Application>()

            when {
                diffMs < 60_000L -> ctx.getString(R.string.list_time_just_now)
                diffMs < 30 * 60_000L -> {
                    val mins = (diffMs / 60_000L).toInt()
                    ctx.getString(R.string.list_time_minutes_ago, mins)
                }
                else -> {
                    val date = java.util.Calendar.getInstance().also { it.timeInMillis = timestamp }
                    val todayCal = java.util.Calendar.getInstance()

                    val isToday = date.get(java.util.Calendar.YEAR) == todayCal.get(java.util.Calendar.YEAR) &&
                            date.get(java.util.Calendar.DAY_OF_YEAR) == todayCal.get(java.util.Calendar.DAY_OF_YEAR)
                    val isSameYear = date.get(java.util.Calendar.YEAR) == todayCal.get(java.util.Calendar.YEAR)

                    when {
                        isToday -> android.text.format.DateFormat.getTimeFormat(ctx).format(date.time)
                        isSameYear -> {
                            val pattern = android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "MMMd")
                            SimpleDateFormat(pattern, Locale.getDefault()).format(date.time)
                        }
                        else -> {
                            val pattern = android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "yMMMd")
                            SimpleDateFormat(pattern, Locale.getDefault()).format(date.time)
                        }
                    }
                }
            }
        } catch (_: Exception) {
            ""
        }
    }
}
