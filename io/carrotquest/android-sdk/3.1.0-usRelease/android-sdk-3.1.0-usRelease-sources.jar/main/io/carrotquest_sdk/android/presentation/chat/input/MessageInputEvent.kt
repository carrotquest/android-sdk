package io.carrotquest_sdk.android.presentation.chat.input

import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentKind

/**
 * События инпута: UI → [MessageInputViewModel] → DialogPresenter (UDF, как ChatEvent).
 *
 * Сторона отправки side-effect'ов — в DialogFragment.handleInputEvent: VM применяет
 * оптимистичное состояние, презентер делает реальное действие (сеть/БД).
 */
sealed class MessageInputEvent {
    data class TextChanged(val text: String) : MessageInputEvent()
    data object SendTapped : MessageInputEvent()
    data object AttachTapped : MessageInputEvent()
    data object PhonePrefixTapped : MessageInputEvent()

    /**
     * Удалить/отменить вложение по [clientId]. Один кейс для обоих: тап по крестику загруженного
     * чипа и тап по индикатору загрузки (отмена). Презентер отменит Job, если загрузка ещё идёт,
     * и уберёт чип из VM.
     */
    data class RemoveAttachment(val clientId: String) : MessageInputEvent()

    // ── Согласие на обработку перс. данных (над баром в режиме BOT_INPUT) ────────
    /** Переключение чекбокса согласия данного вида (чистое UI-состояние, обрабатывает VM). */
    data class ConsentToggled(val kind: ConsentKind) : MessageInputEvent()
    /** Тап по ссылке на документ в блоке согласия — открытие через презентер (onGoToLink). */
    data class ConsentLinkTapped(val url: String) : MessageInputEvent()

    // ── Голосовые сообщения (Ф2) ────────────────────────────────────────────────
    // Реальные side-effect'ы (пермишен, AudioRecord, плеер превью, upload+send) делает
    // DialogFragment/презентер; VM держит только отображаемое voiceState.
    /** Тап по mic: запросить RECORD_AUDIO и начать запись. */
    data object StartVoiceRecording : MessageInputEvent()
    /** Тап по стоп: остановить запись и перейти к превью. */
    data object StopVoiceRecording : MessageInputEvent()
    /** Отмена во время записи: остановить и выбросить файл (вернуться в Idle). */
    data object CancelVoiceRecording : MessageInputEvent()
    /** Превью: play/pause прослушивания записанного. */
    data object PlayPreviewToggle : MessageInputEvent()
    /** Превью: удалить запись (вернуться в Idle). */
    data object DeleteVoicePreview : MessageInputEvent()
    /** Превью: отправить голосовое отдельным сообщением. */
    data object SendVoice : MessageInputEvent()
}