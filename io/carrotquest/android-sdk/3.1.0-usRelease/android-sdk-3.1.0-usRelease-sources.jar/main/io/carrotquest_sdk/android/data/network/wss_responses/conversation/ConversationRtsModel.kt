package io.carrotquest_sdk.android.data.network.wss_responses.conversation

import androidx.annotation.Keep
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.recipientTypeIsRight
import io.carrotquest_sdk.android.data.network.PopUpDeserializer
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.popup.saveNewPopUp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Порт ConversationRtsModel.java → Kotlin (ветка remove_rx). Gson-модель RTS-сообщения о беседе.
 * Rx убран: getSettings().subscribe → корутина (awaitSettings); saveNewPopUp — suspend.
 * @field:SerializedName — чтобы Gson мапил JSON на backing-поля (как @SerializedName в Java).
 */
@Keep
class ConversationRtsModel {

    @field:SerializedName(ResponseFields.ID)
    var id: String? = null

    @field:SerializedName(ResponseFields.CREATED)
    var created: String? = null

    @field:SerializedName(ResponseFields.LAST_ADMIN)
    var lastAdmin: Admin? = null

    @field:SerializedName(ResponseFields.LAST_UPDATE)
    var lastUpdate: String? = null

    @field:SerializedName(ResponseFields.PART_LAST)
    var partLast: MessageData? = null

    @field:SerializedName(ResponseFields.PARTS_COUNT)
    var partsCount: Int? = null

    @field:SerializedName(ResponseFields.REPLY_TYPE)
    var replyType: String? = null

    @field:SerializedName(ResponseFields.TYPE)
    var type: String? = null

    @field:SerializedName(ResponseFields.UNREAD_PARTS_COUNT)
    var unreadPartsCount: Int? = null

    @field:SerializedName(F.EXPIRATION_TIME)
    var expirationTime: Long? = null

    @field:SerializedName(F.RECIPIENT_TYPE)
    var recipientType: String? = null

    // random_id обязателен для подмены псевдо-id (routing_*) на реальный серверный id:
    // DialogPresenter ждёт newConversationFlow с матчем по randomId. Без этого поля
    // конверсация из started-канала добавлялась с randomId=null, и если этот канал
    // обгонял conversation_parts_batch, матч не случался никогда (reply уходил на
    // routing_* → 404).
    @field:SerializedName(ResponseFields.RANDOM_ID)
    var randomId: String? = null

    @JvmField
    var sourceConversation: JsonObject? = null

    fun process(parts: ArrayList<MessageData>) {
        // Трассировка нового диалога (канал message_conversation_started): тип/recipient/части
        // и решение об добавлении каждой части. Метаданные без тела — release-safe.
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, "ConversationRtsModel") {
            "started conv: id=$id type=$type recipient=$recipientType parts=${parts.size} " +
                "isChat=${isChat()} isPopup=${isPopupSdk()} isBot=${isBot()}"
        }
        MessagesRepository.getInstance().addMessages(parts, false)
        for (m in parts) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, "ConversationRtsModel") {
                "started conv part: id=${m.id} dir=${m.direction} sentVia=${m.sentVia} " +
                    "bodyJsonNull=${m.bodyJson == null} actions=${m.actions?.size ?: 0} " +
                    "willAddWss=${!isPopupSdk() && m.actions.isNullOrEmpty()}"
            }
            if (!isPopupSdk() && m.actions.isNullOrEmpty()) {
                MessagesRepository.getInstance().addWssMessage(m)
            }
        }

        // Раньше: SettingsRepository.getSettings().take(1).subscribe{ ... } — теперь корутина.
        CoroutineScope(SdkDispatchers.io).launch {
            try {
                val settingsEntity = SettingsRepository.getInstance().awaitSettings()
                when {
                    isChat() -> onNewChatConversation(settingsEntity)
                    isPopupSdk() -> onNewPopup()
                    isBot() -> onAnswerBot()
                }
            } catch (t: Throwable) {
                Log.e("ConversationRtsModel", "Error: $t")
            }
        }
    }

    fun updateConversationSource(jsonElement: JsonElement) {
        if (jsonElement.isJsonObject) {
            val jsonObject = jsonElement.asJsonObject
            sourceConversation = if (jsonObject.has(F.CONVERSATION)) {
                jsonObject.get(F.CONVERSATION).asJsonObject
            } else {
                jsonElement.asJsonObject
            }
        }
    }

    private fun onNewChatConversation(settingsEntity: SettingsEntity) {
        val showKb = settingsEntity.showLinkKbAtWelcomeMessage
        val conversationEntity = convertToConversationEntity(this, showKb)
        conversationEntity.setSourceJsonData(sourceConversation)
        ConversationsRepository.getInstance().addConversation(conversationEntity)

        if (conversationEntity.partLast != null) {
            MessagesRepository.getInstance().addMessage(conversationEntity.partLast)
        }
    }

    private suspend fun onNewPopup() {
        val popUpMessage = convertToPopupEntity(this)
        if (popUpMessage != null) {
            saveNewPopUp(popUpMessage)

            val conversationEntity = convertToConversationEntity(this, false)
            ConversationsRepository.getInstance().addConversation(conversationEntity)
        }
    }

    private fun onAnswerBot() {
        val conversationEntity = convertToConversationEntity(this, false)
        ConversationsRepository.getInstance().addConversation(conversationEntity)
    }

    private fun convertToPopupEntity(sourceModel: ConversationRtsModel): PopUpMessage? {
        val messageData = sourceModel.partLast ?: return null
        val jsonBody = messageData.bodyJson?.asJsonObject ?: return null

        jsonBody.addProperty("id", sourceModel.id)
        jsonBody.addProperty("part_last_id", messageData.id)
        jsonBody.addProperty("expiration_time", sourceModel.expirationTime)

        val gson = GsonBuilder()
            .registerTypeAdapter(PopUpMessage::class.java, PopUpDeserializer())
            .create()

        return gson.fromJson(jsonBody, PopUpMessage::class.java)
    }

    // Подстраховка на случай, если Gson-маппинг не увидел random_id (иной уровень вложенности
    // фрейма): читаем напрямую из сохранённого JSON объекта conversation.
    private fun randomIdFromSource(): String? =
        sourceConversation
            ?.takeIf { it.has(ResponseFields.RANDOM_ID) && !it.get(ResponseFields.RANDOM_ID).isJsonNull }
            ?.get(ResponseFields.RANDOM_ID)?.asString

    private fun isChat(): Boolean =
        ConversationType.CHAT.stringValue == type && recipientType?.recipientTypeIsRight() == true

    private fun isPopupSdk(): Boolean =
        ConversationType.BLOCK_POPUP_SMALL.stringValue == type && recipientType?.recipientTypeIsRight() == true

    private fun isBot(): Boolean =
        (ConversationType.ROUTING_BOT.stringValue == type || ConversationType.LEAD_BOT.stringValue == type) &&
                recipientType?.recipientTypeIsRight() == true

    // getRecipientType() генерируется автоматически из свойства recipientType (доступно из Java).

    private fun convertToConversationEntity(sourceModel: ConversationRtsModel, showKb: Boolean): DataConversation {
        val model = DataConversation()

        sourceModel.partLast?.expirationTime = expirationTime

        model.setId(sourceModel.id)
        model.setCreated(sourceModel.created)
        model.setRead(false)
        model.setClicked(true)
        model.setUnsubscribed(false)
        model.setClosed(false)
        model.setMessage(null)
        model.setType(sourceModel.type)
        model.setReplyType(sourceModel.replyType)
        model.setPartLast(sourceModel.partLast)
        model.setPartsCount(sourceModel.partsCount)
        model.setAssignee(null)
        model.setUnreadPartsCount(sourceModel.unreadPartsCount)
        model.setLastAdmin(sourceModel.lastAdmin)
        model.setLastUpdate(sourceModel.lastUpdate)
        model.setTags(null)
        model.setRecipientType(sourceModel.recipientType)
        model.setRandomId(sourceModel.randomId ?: randomIdFromSource())
        model.setSourceJsonData(sourceConversation)

        return model
    }
}
