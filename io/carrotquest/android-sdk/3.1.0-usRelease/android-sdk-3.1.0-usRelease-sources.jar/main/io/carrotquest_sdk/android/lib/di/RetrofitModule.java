package io.carrotquest_sdk.android.lib.di;

import android.content.Context;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.core.logging.SdkNetworkLogInterceptor;
import io.carrotquest_sdk.android.domain.use_cases.user.GetUserAgentUseCaseKt;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.auth.TokenRefreshInterceptor;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import com.google.gson.Gson;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.lib.utils.FreedomUtilsKt;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.lib.wss.jwt.GetJwtTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.jwt.GetRefreshTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.core.ConstantsKt;
import okhttp3.*;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import javax.inject.Singleton;

import java.util.UUID;
import java.util.concurrent.TimeUnit;


@Module(includes = {ContextModule.class})
public class RetrofitModule {

    private final Gson gson;

    private final Context context;
    private final IUserRepository userRepository;
    private final boolean isUseEuServers;

    public RetrofitModule(Context context, IUserRepository userRepository, boolean isUseEuServers) {
        this.context = context;
        gson = new GsonModule(context).provideGson();
        this.userRepository = userRepository;
        this.isUseEuServers = isUseEuServers;
    }

    @Provides
    @Singleton
    public Retrofit provideRetrofit(Retrofit.Builder builder) {
        Interceptor paramAdds = chain -> {
            Request request = chain.request();

            // Снапшот auth-полей ОДИН раз в начале. User мутабелен и разделяется между потоками:
            // deInit()/logout на другом потоке обнуляет token/id по ходу этого метода, и повторное
            // чтение user.getToken() посреди intercept давало NPE на .isEmpty() (краш процесса на
            // OkHttp Dispatcher при логауте с фоновым трафиком). Читаем снапшот и приводим null к "".
            User user = userRepository.getUser();
            String userToken = (user == null || user.getToken() == null) ? "" : user.getToken();
            String userId = (user == null) ? null : user.getId();
            String nonce = UUID.randomUUID().toString().replace("-", "");

            HttpUrl.Builder urlBuilder = request.url().newBuilder()
                    .addQueryParameter(F.NONCE, nonce)
                    .addQueryParameter(F.USER_AGENT, "android_sdk")
                    .addQueryParameter(F.ID_AS_STRING, "1");




            //TODO FREEDOM удалить потом
            String appId = SharedPreferencesLib.getString(context, "X_APP_ID_KEY");
            if(request.url().toString().contains("refresh")) {
                // /auth/jwt/refresh ВСЕГДА аутентифицируем refresh-токеном из prefs (fallback —
                // легаси CarrotToken), НЕЗАВИСИМО от user.token. Раньше при пустом user.token
                // срабатывала мёртвая ветка contains("isRefresh") (реальный url её не содержит) —
                // /refresh уходил вообще без кредов → гарантированный 401 → интерсептор ложно
                // считал refresh-токен мёртвым и стирал все креды (шторм 401 после реконнекта).
                String refreshToken = GetRefreshTokenUseCaseKt.getRefreshToken(context);
                if(refreshToken == null || refreshToken.isEmpty()) {
                    refreshToken = SharedPreferencesLib.getString(context, "CarrotToken");
                }
                if(refreshToken != null && !refreshToken.isEmpty()) {
                    urlBuilder.addQueryParameter(F.AUTH_TOKEN, refreshToken);
                }
            } else if(userToken.isEmpty()) {
                // user.token пуст (напр., /connect ответил без auth_token), но JWT-пара может быть
                // живой — прикладываем access из prefs вместо запроса совсем без кредов.
                String access = GetJwtTokenUseCaseKt.getJwtToken();
                if(!access.isEmpty()) {
                    urlBuilder.addQueryParameter(F.AUTH_TOKEN, access);
                }
            } else {
                if (request.url().toString().contains("connect")
                        && !FreedomUtilsKt.hasSavedDashlyTokenFlag()
                        && FreedomUtilsKt.isDashly()
                        && appId.equals(FreedomUtilsKt.FREEDOM_AP_ID)) {
                    urlBuilder.addQueryParameter("carrotquest_auth_token", userToken);
                } else {
                    urlBuilder.addQueryParameter(F.AUTH_TOKEN, userToken);
                }
            }

            //if("GET".equals(request.method()) ) {
            if(userId != null) {
                urlBuilder.addQueryParameter(F.REQUEST_USER_ID, userId);
            }
            if(appId != null && !appId.isEmpty()) {
                urlBuilder.addQueryParameter(F.REQUEST_APP_ID, appId);
            }
            //}

            HttpUrl newUrl = urlBuilder.build();
            Request.Builder newRequestBuilder = request.newBuilder()
                    .url(newUrl);

            String userAgent = GetUserAgentUseCaseKt.getUserAgent();
            newRequestBuilder.header("User-Agent", userAgent);

            request = newRequestBuilder.build();
            return chain.proceed(request);
        };

        OkHttpClient client = new OkHttpClient.Builder()
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(new SdkNetworkLogInterceptor())
                .addInterceptor(paramAdds)
                .addInterceptor(new TokenRefreshInterceptor(userRepository))
                .build();


        String baseUrl = BuildConfig.BASE_API_URL;
        if (isUseEuServers) {
            baseUrl = ConstantsKt.EU_BASE_URL;
        }
        return builder
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    @Provides
    @Singleton
    public Retrofit.Builder provideRetrofitBuilder() {
        return new Retrofit.Builder()
                .addConverterFactory(ScalarsConverterFactory.create());
    }
}
