package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import com.google.gson.Gson
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.buildAttachmentsCachedJson
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.util.Locale

// Скоуп fire-and-forget переотправки ошибочных сообщений (раньше Observable.subscribe на Schedulers.io).
private val errorMessagesScope = CoroutineScope(SdkDispatchers.io + SupervisorJob())

private const val TAG = "FailSendingMessage"

/**
 * Переотправка упавших сообщений (reconnect / reload диалога / тап «Повторить»).
 *
 * Маршруты по данным персиста:
 *  - attachmentsCached есть (вложения уже на сервере) → reply сразу с этим JSON;
 *  - вложение с ЛОКАЛЬНЫМ путём на диске (голос/легаси-аттач) → повторная загрузка через
 *    POST /attachments (сохраняя type — голос остаётся голосом) → reply с attachments_cached.
 *    Легаси-эндпоинт replyfile не используется: он терял type и body;
 *  - нечего слать (пустой body без вложений — «пустышки» старых версий) → запись удаляется,
 *    пустой reply на бэк не уходит.
 *
 * Запись БД удаляется ТОЛЬКО при подтверждённом успехе (LOADED), по исходному id
 * (sendMessage при успехе мутирует message.id на серверный). Серверная ошибка сохраняет
 * запись для следующей попытки — вместе с attach-метой (onError внутри sendMessage
 * пересохраняет запись без неё).
 */
fun sendErrorMessages(messages: List<MessageData>) {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    messages.forEach { message ->
        // Ключ записи в БД: фиксируем ДО отправки — при успехе sendMessage перезапишет
        // message.id серверным, и clearErrorMessage по нему не нашёл бы строку.
        val failId = message.id
        message.sourceJsonData = JSONObject(Gson().toJson(message))
        addMessageToConversation(message)

        db.failSendingMessageDao().updateProcessStatus(failId, 1)

        errorMessagesScope.launch {
            try {
                val attachmentsCached = getErrorMessageAttachmentsCached(failId)
                val localAttachment = message.attachments?.firstOrNull()
                val localFile = localAttachment?.url
                    ?.takeIf { !it.startsWith("http") }
                    ?.let { File(it) }
                    ?.takeIf { it.exists() }

                val result: MessageData = when {
                    attachmentsCached != null -> sendMessage(message, attachmentsCached)

                    localFile != null -> {
                        val uploaded = CarrotInternal.getService().carrotLib.uploadAttachmentSuspend(localFile)
                        // Тип из персиста главнее серверного (сервер отвечает file для WAV,
                        // контракт голосового требует type=voice — как в основном пути отправки).
                        localAttachment.type?.let { uploaded.type = it }
                        sendMessage(message, buildAttachmentsCachedJson(listOf(uploaded)))
                    }

                    message.body.isNullOrEmpty() -> {
                        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.DATABASE, TAG) {
                            "resend skipped, nothing to send: id=$failId conv=${message.conversation} " +
                                "(no body, no attachments) — record dropped"
                        }
                        clearErrorMessage(messageId = failId)
                        MessagesRepository.getInstance().removeMessage(failId)
                        return@launch
                    }

                    else -> sendMessage(message)
                }

                val sentOk = result.status == MessageStatus.LOADED.name.lowercase(Locale.getDefault())
                if (sentOk) {
                    clearErrorMessage(messageId = failId)
                    updateMessagesAtConversation(message.conversation)
                } else {
                    // Серверная ошибка (meta.error): onError внутри sendMessage пересохранил запись
                    // без attach-меты — восстанавливаем её, иначе следующий ретрай потеряет вложение.
                    saveErrorMessage(message, attachPath = localFile?.absolutePath, attachmentsCached = attachmentsCached)
                    db.failSendingMessageDao().updateProcessStatus(failId, 0)
                }
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.DATABASE, TAG) {
                    "resend failed, kept for retry: id=$failId $e"
                }
                db.failSendingMessageDao().updateProcessStatus(failId, 0)
            }
        }
    }
}

private fun addMessageToConversation(message: MessageData) {
    // Ресенд на reconnect идёт по ВСЕМ диалогам (getAllErrorMessages), а MessagesRepository —
    // синглтон открытого диалога: без фильтра упавшие сообщения чужих диалогов появлялись
    // в текущем чате.
    val openedId = ConversationsRepository.getInstance().getOpenedConversationId()
    if (openedId.isEmpty() || message.conversation == openedId) {
        MessagesRepository.getInstance().addMessage(message)
    }
}

private fun updateMessagesAtConversation(conversationId: String) {
    errorMessagesScope.launch {
        try {
            val response = CarrotLib.getLibComponents().carrotApi.getMessages(conversationId)
            val list = ArrayList<MessageData>()
            list.addAll(response.data)
            MessagesRepository.getInstance().addMessages(list)
        } catch (e: Throwable) {
            // мягкий фолбэк — обновление списка не критично
        }
    }
}
