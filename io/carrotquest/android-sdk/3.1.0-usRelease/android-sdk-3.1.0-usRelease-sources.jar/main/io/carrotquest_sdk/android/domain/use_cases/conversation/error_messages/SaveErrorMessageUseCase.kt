package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.FailSendingMessage

/**
 * Персистит упавшее сообщение для последующего ресенда (reconnect / reload / тап «Повторить»).
 *
 * @param attachPath   ЛОКАЛЬНЫЙ путь файла вложения (голос/легаси-аттач) — при ресенде файл
 *                     будет заново загружен с диска.
 * @param attachmentsCached готовый JSON form-поля attachments_cached (вложения уже на сервере) —
 *                     при ресенде уходит в reply как есть, без повторной загрузки.
 *
 * Сообщение из MessagesRepository НЕ удаляется: WARNING-бабл остаётся в чате (для голоса — с
 * плеером) и по нему работает тап-ретрай. Раньше удалялось — бабл исчезал сразу, а после
 * перезахода восстанавливался пустым (см. mapMessage).
 */
fun saveErrorMessage(message: MessageData, attachPath: String? = null, attachmentsCached: String? = null) {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    val failMessage = FailSendingMessage(message.id)
    failMessage.conversationId = message.conversation
    failMessage.body = message.body
    // У исходящих user-сообщений messageFrom == null by design (см. NewMessageUseCase) —
    // разыменование без ?. роняло сохранение целиком: упавшее сообщение не попадало
    // в FailSendingMessage и ретрай был невозможен.
    failMessage.messageFrom = message.messageFrom?.id
    failMessage.created = message.created
    failMessage.attachPath = attachPath
    val bodyJson = message.bodyJson
    if(bodyJson != null) {
        failMessage.bodyJson = bodyJson.toString()
    }
    failMessage.direction = message.direction
    failMessage.first = message.isFirst
    failMessage.randomId = message.randomId
    failMessage.read = message.read
    failMessage.replyType = message.replyType
    failMessage.sentVia = message.sentVia
    failMessage.status = message.status
    failMessage.type = message.type

    // Метаданные вложения — чтобы восстановленное сообщение рендерилось как оригинал
    // (голос плеером, файл с именем), а ресенд знал type/mime при повторной загрузке.
    val firstAttachment = message.attachments?.firstOrNull()
    if (firstAttachment != null) {
        failMessage.attachType = firstAttachment.type
        failMessage.attachMimeType = firstAttachment.mimeType
        failMessage.attachFilename = firstAttachment.filename
        failMessage.attachSize = firstAttachment.size
    }
    failMessage.attachmentsCached = attachmentsCached

    failMessage.inSendingProcess = false

    db.failSendingMessageDao().insert(failMessage)

    SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.DATABASE, "FailSendingMessage") {
        "saved for resend: id=${message.id} conv=${message.conversation} " +
            "attachPath=${attachPath != null} attachType=${firstAttachment?.type} " +
            "attachmentsCached=${attachmentsCached != null} bodyEmpty=${message.body.isNullOrEmpty()}"
    }
}
