package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import com.google.gson.JsonParser
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.FailSendingMessage

fun getAllErrorMessages(): List<MessageData> {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    return db.failSendingMessageDao().all.map { message ->
        return@map mapMessage(message)
    }
}

fun getErrorMessages(conversationId: String): List<MessageData> {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    return db.failSendingMessageDao().getAllByConversationId(conversationId).map { message ->
        return@map mapMessage(message)
    }.toList()
}

private fun mapMessage(message: FailSendingMessage): MessageData {
    val failMessage = MessageData()

    failMessage.id = message.id
    failMessage.conversation = message.conversationId
    failMessage.body = message.body
    // Симметрично saveErrorMessage: у user-сообщений messageFrom нет — восстановленное
    // сообщение тоже должно иметь null, а не Admin с пустым id.
    failMessage.messageFrom = message.messageFrom?.let { fromId -> Admin().apply { id = fromId } }
    failMessage.created = message.created

    // Восстанавливаем вложение с метаданными (v27): без type/mimeType голосовое рендерилось
    // безымянной файловой карточкой, а не плеером. attachPath — локальный путь на диске.
    if (message.attachPath != null) {
        val attachments = ArrayList<Attachment>()
        val attachment = Attachment()
        attachment.url = message.attachPath
        attachment.type = message.attachType
        attachment.mimeType = message.attachMimeType
        attachment.filename = message.attachFilename
        attachment.size = message.attachSize ?: 0L
        attachments.add(attachment)
        failMessage.attachments = attachments
    }

    // bodyJson восстанавливаем из ПЕРСИСТА (раньше читался из только что созданного
    // MessageData — всегда null, поле терялось при любом восстановлении).
    val storedBodyJson = message.bodyJson
    if (storedBodyJson != null) {
        failMessage.bodyJson = runCatching { JsonParser.parseString(storedBodyJson) }.getOrNull()
    }
    failMessage.direction = message.direction
    failMessage.isFirst = message.first
    failMessage.randomId = message.randomId
    failMessage.read = message.read
    failMessage.replyType = message.replyType
    failMessage.sentVia = message.sentVia
    failMessage.status = message.status
    failMessage.type = message.type

    return failMessage
}

/** attachments_cached, сохранённый вместе с упавшим сообщением (вложения уже на сервере). */
fun getErrorMessageAttachmentsCached(messageId: String): String? =
    SdkApp.getInstance().database.failSendingMessageDao().getAttachmentsCached(messageId)
