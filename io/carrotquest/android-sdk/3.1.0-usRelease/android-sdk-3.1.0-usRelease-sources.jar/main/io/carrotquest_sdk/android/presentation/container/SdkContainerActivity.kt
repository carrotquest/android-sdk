package io.carrotquest_sdk.android.presentation.container

import io.carrotquest_sdk.android.Callback

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import android.content.Context
import android.view.inputmethod.InputMethodManager
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.presentation.mvp.base.BaseSdkActivity
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListHeaderData
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view.ListContentScreen
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel.ListViewModel
import io.carrotquest_sdk.android.presentation.ui.LoadingContent
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.mvp.utils.isTablet
import androidx.lifecycle.lifecycleScope
import io.carrotquest_sdk.android.core.constants.isPopUpConversationType
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListUiState
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SdkContainerActivity : BaseSdkActivity() {

    companion object {
        const val APP_COLOR = "APP_COLOR"
        const val STARTED_FROM_NOTIFICATION = "started_from_notification"
        const val CONVERSATION_ID_ARG = "CONVERSATION_ID_ARG"
    }

    private val containerViewModel: SdkContainerViewModel by viewModels()
    private val listViewModel: ListViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            requestedOrientation = if (isTablet(this)) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        } catch (e: Exception) {
            Log.d("SetOrientation", "$e")
        }

        val currentTheme = getThemeUseCase(this)
        when (currentTheme) {
            ThemeSdk.DARK -> setTheme(R.style.DarkCqSdkTheme)
            else -> setTheme(R.style.LightCqSdkTheme)
        }

        super.onCreate(savedInstanceState)

        // Cold start через PendingIntent уведомления: процесс хоста только что поднят,
        // Carrot.setup() ещё не вызывался (хост обычно делает это в MainActivity, которую
        // Android не запускает при тапе на push). Без этого блока активити крутит спиннер
        // навсегда: service==null, репозитории пусты. Восстанавливаем apiKey из prefs
        // (он туда сохраняется при каждом setup) и инициализируем сами.
        // Если apiKey нет — закрываемся, нечего показывать.
        var awaitingInit = false
        if (!Carrot.isInit()) {
            val savedApiKey = SharedPreferencesLib.getString(this, "api_key")
            if (savedApiKey.isNullOrEmpty()) {
                Log.e("SdkContainerActivity", "Cold start without saved apiKey, finishing")
                finish()
                return
            }
            try {
                awaitingInit = true
                Carrot.setup(this, savedApiKey, object : Callback<Boolean> {
                    override fun onResponse(result: Boolean?) {
                        Log.d("SdkContainerActivity", "Auto-init after cold start: success")
                        // Навигация выполняется ниже через awaitInitAndNavigate(); этот
                        // callback нужен только для логов/диагностики.
                    }

                    override fun onFailure(t: Throwable?) {
                        Log.e("SdkContainerActivity", "Auto-init after cold start failed: $t")
                    }
                })
            } catch (t: Throwable) {
                Log.e("SdkContainerActivity", "Carrot.setup threw: $t")
                finish()
                return
            }
        }

        enableEdgeToEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                containerViewModel.onBack()
            }
        })

        // Иконки статус-бара: светлые на тёмном фоне, тёмные на светлом.
        // Используем начальный accentColor из ViewModel (уже вычислен в buildUiState).
        val accentArgb = (containerViewModel.uiState.value.accentColor.value.toLong() and 0xFFFFFFFFL).toInt()
        val luminance = androidx.core.graphics.ColorUtils.calculateLuminance(accentArgb)
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            .isAppearanceLightStatusBars = luminance > 0.5

        listViewModel.startedFromNotification =
            intent.getBooleanExtra(STARTED_FROM_NOTIFICATION, false)

        // Если auto-init был запущен — сначала ждём его завершения. Иначе DialogFragment
        // создастся раньше connect'а, при пустых репозиториях getConversation/loadMessages
        // запустятся параллельными подписками без дедупа → лавина HTTP /conversations и
        // NPE в Rx-цепочках. Пока ждём — рендерится Determining state (спиннер).
        val pushConversationId = intent.getStringExtra(CONVERSATION_ID_ARG)
        if (awaitingInit) {
            lifecycleScope.launch {
                // SdkStateManager.publicState переходит в Ready после успешного connect'а.
                io.carrotquest_sdk.android.core.SdkStateManager.publicState
                    .first { it is io.carrotquest_sdk.android.core.CarrotState.Ready
                            || it is io.carrotquest_sdk.android.core.CarrotState.Failed }

                // Connect возвращает только user+settings, ConversationsRepository остаётся
                // пустым до первого запроса. Если открыть DialogFragment в этот момент,
                // presenter параллельно дёрнет loadConversations несколько раз
                // (getConversation → fallback на полный список). Пред-грузим список здесь,
                // чтобы при последующем navigateToDialog диалог был в кэше.
                try {
                    val user = io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser()
                    if (user != null) {
                        io.carrotquest_sdk.android.domain.use_cases.conversations
                            .loadConversations(user.id)
                    }
                } catch (e: Throwable) {
                    Log.e("SdkContainerActivity", "preload conversations failed: $e")
                }

                proceedAfterInit(pushConversationId)
            }
        } else {
            proceedAfterInit(pushConversationId)
        }

        setupContent()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val pushConversationId = intent?.getStringExtra(CONVERSATION_ID_ARG)
        if (!pushConversationId.isNullOrEmpty()) {
            containerViewModel.navigateToDialog(pushConversationId)
        }
    }

    override fun onResume() {
        super.onResume()
        // Перезапустить ping-цикл NetworkManager на случай, если за ночь в Doze
        // фоновый retry исчерпал MAX_RETRY_ATTEMPTS и hasInternet застрял в false:
        // CONNECTIVITY_CHANGE при выходе из Doze может не прийти (сеть формально
        // не менялась), и список/диалоги начнут ложно показывать "нет интернета".
        // DialogPresenter.onResume делает то же самое — здесь дублируем для случая,
        // когда пользователь стоит на экране списка без открытого диалога.
        io.carrotquest_sdk.android.lib.managers.network.NetworkManager
            .getInstance(this).revalidate()
        // Синхронная live-сверка списка с состоянием сети: revalidate() выше даёт
        // результат через ping с задержкой в секунды, а observer NetworkManager не
        // реплеит текущее состояние — без этого вызова возврат на список в офлайне
        // (или обратно в онлайне) отразился бы с опозданием.
        listViewModel.refreshNetworkState()
    }

    /**
     * Навигация по cold-start сценарию: открыть диалог из push, либо последний диалог
     * из кэша / списка. Выделено в отдельный метод, чтобы вызывать как сразу (если SDK
     * уже инициализирован), так и после ожидания auto-init.
     */
    private fun proceedAfterInit(pushConversationId: String?) {
        if (!pushConversationId.isNullOrEmpty()) {
            containerViewModel.navigateToDialog(pushConversationId)
        } else {
            // Синхронно проверяем кэш: если данные уже есть в репозитории,
            // навигируем ДО первого рендера — никакой анимации вообще.
            // Поп-ап-беседы пропускаем: их нельзя показать как чат (тело пустое) — берём
            // последний ОБЫЧНЫЙ диалог.
            val cachedId = lastDisplayableConversationId()
            if (cachedId != null) {
                containerViewModel.navigateToDialog(cachedId)
            } else {
                // Кэша нет — показываем спиннер (Determining), ждём загрузки,
                // затем открываем последний диалог или новый пустой. После загрузки список
                // уже наполнил репозиторий — берём последний не-поп-ап диалог тем же способом.
                lifecycleScope.launch {
                    listViewModel.uiState.first { it !is ListUiState.Loading }
                    val id = lastDisplayableConversationId()
                    containerViewModel.navigateToDialog(id ?: "", isNew = id == null)
                }
            }
        }
    }

    /**
     * Последний диалог, который можно открыть как чат: самый свежий по lastUpdate, ИСКЛЮЧАЯ
     * поп-ап-беседы (их нельзя показать в теле диалога — было бы пусто, баг #11). null — нет
     * подходящих диалогов (откроем новый пустой).
     */
    private fun lastDisplayableConversationId(): String? =
        ConversationsRepository.getInstance().conversationsFlow.value
            .filter { it.id != null && it.type != null && !isPopUpConversationType(it.type) }
            .maxByOrNull { it.lastUpdate?.toLongOrNull() ?: 0L }
            ?.id

    /**
     * Закрытие контейнера. Если чат был открыт из пуша при закрытом приложении
     * (STARTED_FROM_NOTIFICATION), уводим пользователя в хост-приложение (parent-activity, заданную
     * через Carrot.setParentActivityClassName, или launcher), а не на домашний экран. Иначе —
     * обычный finish(). Восстановление механики goToParentActivity() из удалённой DialogActivity.
     */
    private fun closeContainer() {
        if (intent.getBooleanExtra(STARTED_FROM_NOTIFICATION, false)) {
            navigateToParentActivity()
        }
        finish()
    }

    private fun navigateToParentActivity() {
        runCatching {
            val i = when (val target = parentActivityTarget(CarrotSDK.getParentActivityClassName())) {
                is ParentActivityTarget.Named ->
                    Intent(this, Class.forName(target.className)).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                ParentActivityTarget.AppLauncher ->
                    packageManager.getLaunchIntentForPackage(packageName)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
            }
            i?.let { startActivity(it) }
        }.onFailure { Log.e("SdkContainerActivity", "navigateToParentActivity failed: $it") }
    }

    private fun setupContent() {
        val themeAtRender = getThemeUseCase(this)
        setContent {
            val uiState by containerViewModel.uiState.collectAsState()
            SdkContainerScreen(
                containerViewModel = containerViewModel,
                listViewModel = listViewModel,
                theme = themeAtRender,
                accentColor = uiState.accentColor,
                patternUrl = uiState.patternUrl,
                fragmentManager = supportFragmentManager,
                onClose = { closeContainer() }
            )
        }
    }

}

// ── Корневой экран контейнера ─────────────────────────────────────────────────


@Composable
private fun SdkContainerScreen(
    containerViewModel: SdkContainerViewModel,
    listViewModel: ListViewModel,
    theme: ThemeSdk,
    accentColor: Color,
    patternUrl: String?,
    fragmentManager: FragmentManager,
    onClose: () -> Unit
) {
    val navState by containerViewModel.navState.collectAsState()
    val headerData by listViewModel.headerData.collectAsState()
    val unreadCount by containerViewModel.unreadConversationsCount.collectAsState()
    val operatorInfo by containerViewModel.operatorInfo.collectAsState()
    val isDark = theme == ThemeSdk.DARK

    val pageBg = SdkColors.pageBackground(isDark)

    val view = LocalView.current
    val hideKeyboard = {
        (view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(view.windowToken, 0)
    }

    // Скрываем клавиатуру при открытии активити
    LaunchedEffect(Unit) {
        hideKeyboard()
        containerViewModel.closeEvent.collectLatest { onClose() }
    }

    // Скрываем клавиатуру при переходе к списку диалогов
    LaunchedEffect(navState) {
        if (navState is SdkNavState.ConversationList) hideKeyboard()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(accentColor)
    ) {
        // PNG-паттерн с прозрачным фоном поверх цветной подложки (тайлинг)
        if (patternUrl != null) {
            TiledPatternImage(
                url = patternUrl,
                accentColor = accentColor,
                modifier = Modifier.fillMaxSize()
            )
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // Шапка — всегда видна, меняет содержимое в зависимости от navState
            SdkSharedHeader(
                navState = navState,
                headerData = headerData,
                accentColor = accentColor,
                unreadCount = unreadCount,
                operatorInfo = operatorInfo,
                onBack = { containerViewModel.navigateToList() },
                onClose = { containerViewModel.close() }
            )



            // Контентная область — теперь анимация включает в себя саму "карточку"
            AnimatedContent(
                targetState = navState,
                transitionSpec = {
                    // Веб-подобный fade-through: уходящий контент сначала ПОЛНОСТЬЮ гаснет (200мс),
                    // открывая accent-подложку (как в вебе), затем после паузы 80мс проявляется новый
                    // (fadeIn с delayMillis = 280). Без слайда и без пружинного ресайза контейнера
                    // (SizeTransform(clip = false)) — поэтому нет ни «проезда вниз», ни баунса.
                    ContentTransform(
                        targetContentEnter = fadeIn(tween(200, delayMillis = 280)),
                        initialContentExit = fadeOut(tween(200)),
                        sizeTransform = SizeTransform(clip = false),
                    )
                },
                label = "ContentAnimation",
                modifier = Modifier.fillMaxSize()
            ) { state ->
                // Белая "карточка" теперь анимируется целиком
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(pageBg)
                        .navigationBarsPadding()
                        .imePadding()
                ) {
                    when (state) {
                        is SdkNavState.Determining -> LoadingContent(accentColor)
                        is SdkNavState.ConversationList -> ListContentScreen(
                            viewModel = listViewModel,
                            theme = theme,
                            accentColor = accentColor,
                            onConversationClick = { id ->
                                containerViewModel.onConversationClicked(id)
                            },
                            onNewConversationClick = {
                                containerViewModel.navigateToDialog("", isNew = true)
                            }
                        )
                        is SdkNavState.Dialog -> DialogScreen(
                            conversationId = state.conversationId,
                            fragmentManager = fragmentManager,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}

// ── Общая шапка ───────────────────────────────────────────────────────────────

@Composable
private fun SdkSharedHeader(
    navState: SdkNavState,
    headerData: ListHeaderData,
    accentColor: Color,
    unreadCount: Int,
    operatorInfo: OperatorInfo?,
    onBack: () -> Unit,
    onClose: () -> Unit
) {
    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val onAccent = remember(accentColor) { SdkColors.onAccent(accentColor) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = statusBarPadding)
    ) {
        // Анимированный контент шапки (только прозрачность, без движения)
        AnimatedContent(
            targetState = navState,
            // Тот же fade-through, что и у контента: содержимое шапки гаснет, открывая подложку,
            // и проявляется новое после паузы (✕ остаётся статичной).
            transitionSpec = { fadeIn(tween(200, delayMillis = 280)) togetherWith fadeOut(tween(200)) },
            label = "HeaderAnimation"
        ) { state ->
            if (state is SdkNavState.Dialog) {
                DialogHeader(
                    appName = headerData.appName,
                    operatorName = operatorInfo?.name,
                    isOnline = headerData.isOnline,
                    unreadCount = unreadCount,
                    onAccent = onAccent,
                    onBack = onBack
                )
            } else {
                ListHeader(headerData = headerData, accentColor = accentColor, onAccent = onAccent)
            }
        }

        // Кнопка ✕ — статичная
        SdkHeaderButton(
            onClick = onClose,
            onAccent = onAccent,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 10.dp, end = 16.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_cq_close_green_24dp),
                contentDescription = null,
                tint = onAccent,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

// ── Универсальная кнопка шапки (rounded square, полупрозрачный фон) ───────────

@Composable
private fun SdkHeaderButton(
    onClick: () -> Unit,
    onAccent: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(onAccent.copy(alpha = 0.25f))
            .clickable(role = Role.Button) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

// ── Шапка в режиме списка ─────────────────────────────────────────────────────

@Composable
private fun ListHeader(headerData: ListHeaderData, accentColor: Color, onAccent: Color) {
    // Отступ справа = 16 (отступ кнопки) + 36 (размер кнопки) + 8 = 60dp
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, start = 20.dp, end = 20.dp, bottom = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (headerData.adminAvatarUrls.isNotEmpty()) {
            StackedAvatars(urls = headerData.adminAvatarUrls, accentColor)
            Spacer(modifier = Modifier.height(12.dp))
        }
        if (headerData.appName.isNotEmpty()) {
            Text(
                text = headerData.appName,
                color = onAccent,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (headerData.statusMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = headerData.statusMessage,
                color = onAccent.copy(alpha = 0.85f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ── Шапка в режиме диалога ────────────────────────────────────────────────────

@Composable
private fun DialogHeader(
    appName: String,
    operatorName: String?,
    isOnline: Boolean?,
    unreadCount: Int,
    onAccent: Color,
    onBack: () -> Unit
) {
    val displayName = operatorName?.takeIf { it.isNotEmpty() } ?: appName
    val statusLabel = when (isOnline) {
        true -> stringResource(R.string.list_status_online)
        false -> stringResource(R.string.list_status_offline)
        null -> ""
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            // Мин. высота: пока настройки не загрузились, имя/статус пусты и центральная Column
            // схлопывается в 0 → нижняя граница шапки прилипала к кнопке ✕ (top 10 + 36). Держим
            // высоту (≈ высота заполненной шапки), чтобы под кнопкой оставался воздух.
            .defaultMinSize(minHeight = 60.dp)
            .padding(top = 10.dp, start = 16.dp, end = 16.dp, bottom = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        // Имя + статус — по центру, отступы под кнопки по бокам
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (displayName.isNotEmpty()) {
                Text(
                    text = displayName,
                    color = onAccent,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (statusLabel.isNotEmpty()) {
                Text(
                    text = statusLabel,
                    color = onAccent.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }

        // Кнопка ≡ (назад к списку) с баблом непрочитанных диалогов
        Box(modifier = Modifier.align(Alignment.CenterStart)) {
            SdkHeaderButton(onClick = onBack, onAccent = onAccent) {
                Icon(
                    painter = painterResource(R.drawable.ic_cq_burger),
                    contentDescription = null,
                    tint = onAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
            if (unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 4.dp, y = (-4).dp)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(SdkColors.unreadBadge),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (unreadCount > 99) "99+" else unreadCount.toString(),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// ── Стек аватаров ─────────────────────────────────────────────────────────────

@Composable
private fun StackedAvatars(urls: List<String>, accentColor: Color) {
    val avatarSize = 44.dp
    val step = 28.dp
    val totalWidth = avatarSize + step * (urls.size - 1).coerceAtLeast(0)

    Box(
        modifier = Modifier
            .width(totalWidth)
            .height(avatarSize)
    ) {
        urls.forEachIndexed { index, url ->
            val placeholder = painterResource(R.drawable.ic_grey_circle_placrholder)
            AsyncImage(
                model = url,
                contentDescription = null,
                modifier = Modifier
                    .size(avatarSize)
                    .offset(x = step * index)
                    .zIndex((urls.size - index).toFloat())
                    .clip(CircleShape)
                    .background(accentColor)
                    .border(2.dp, accentColor, CircleShape),
                placeholder = placeholder,
                error = placeholder,
                fallback = placeholder
            )
        }
    }
}
