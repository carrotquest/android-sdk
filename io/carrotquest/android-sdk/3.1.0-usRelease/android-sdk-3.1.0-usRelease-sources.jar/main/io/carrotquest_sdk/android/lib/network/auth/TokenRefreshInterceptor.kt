package io.carrotquest_sdk.android.lib.network.auth

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.repositories.IUserRepository
import io.carrotquest_sdk.android.lib.wss.jwt.clearAllCreds
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlocking
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Зависимости [refreshToken]/[clearTokens]/[onSessionExpired] вынесены в конструктор для
 * тестируемости (по умолчанию делегируют в реальные top-level функции). Production-код и Java
 * (`RetrofitModule`) используют конструктор с одним аргументом через @JvmOverloads.
 */
internal class TokenRefreshInterceptor @JvmOverloads constructor(
    private val userRepository: IUserRepository,
    private val refreshToken: (String?) -> String? = { failed -> refreshJwtTokenBlocking(failed) },
    // «Полный» сброс кред: jwt/refresh + user.token (=auth_token), чтобы следующий запрос/connect
    // ушёл token-less. См. clearAllCreds — раньше user.token чистился отдельной строкой на сайтах.
    private val clearTokens: () -> Unit = { clearAllCreds(userRepository) },
    private val onSessionExpired: () -> Unit = { SdkStateManager.notifySessionExpired() },
    // Refresh-кред, которым paramAdds аутентифицирует POST /refresh (prefs + fallback CarrotToken).
    // Лямбда — для тестируемости.
    private val storedRefreshCred: () -> String? = {
        io.carrotquest_sdk.android.lib.wss.jwt.getRefreshToken()
            ?: io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib.getString(
                io.carrotquest_sdk.android.lib.CarrotLib.getLibComponents().context, "CarrotToken"
            ).takeIf { !it.isNullOrEmpty() }
    },
) : Interceptor {

    private companion object {
        const val TAG = "TokenRefreshInterceptor"
        // Запросы teardown (logout: pushes_unsubscribe) помечаются этим заголовком. На их 401/403
        // интерсептор НЕ эскалирует в session-recovery/clearTokens — иначе провал отписки посреди
        // deInit запускал шторм recovery↔connect (см. баг «logout broken anon 401»). Авто-рефреш
        // при живом refresh при этом остаётся — чтобы отписка всё же прошла и устройство отвязалось.
        const val HEADER_NO_SESSION_RECOVERY = "X-CQ-No-Session-Recovery"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())
        val url = chain.request().url.toString()

        if (url.contains("refresh")) return response
        if (response.code != 401 && response.code != 403) return response

        val noSessionRecovery = chain.request().header(HEADER_NO_SESSION_RECOVERY) != null

        // Логируем причину отказа: сервер обычно кладёт её в тело ответа. encodedPath — без query,
        // чтобы не светить auth_token в логах. Тело здесь можно безопасно прочитать: ниже мы в любом
        // случае не возвращаем оригинальный response (всегда retry/re-proceed нового запроса).
        val code = response.code
        val errorBody = try {
            response.body?.string().orEmpty()
        } catch (e: Exception) {
            ""
        }
        SdkLogger.log(
            SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
            "auth-protected request got HTTP $code on ${chain.request().url.encodedPath}; body=$errorBody",
        )

        response.close()

        // 403 absent_scopes / PermissionDeniedError: токен валиден по подписи и времени, но НЕ
        // содержит нужных scopes. /refresh бесполезен — он выдаёт новый access с теми же scopes
        // (refresh-токен жив, вернёт 200) → повторный 403 на каждом запросе всю сессию. Поэтому
        // НЕ рефрешим, а чистим креды + обнуляем auth_token и сигналим recovery (token-less
        // пересоздание сессии через /connect). Лечит залипание без выгрузки приложения.
        val permissionDenied = code == 403 &&
            (errorBody.contains("absent_scopes") || errorBody.contains("PermissionDeniedError"))
        if (permissionDenied) {
            if (noSessionRecovery) {
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "403 absent_scopes on teardown request — NOT clearing creds / NOT recovering",
                )
                return chain.proceed(chain.request())
            }
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "403 absent_scopes — refresh won't fix scopes; clearing creds and triggering session recovery",
            )
            clearTokens() // = clearAllCreds: jwt/refresh + user.token
            onSessionExpired()
            return chain.proceed(chain.request())
        }

        // Token-less состояние: рефрешить НЕЧЕМ (нет ни refresh-токена, ни легаси CarrotToken) —
        // POST /refresh ушёл бы без кредов и гарантированно получил 401, который ниже ложно
        // трактовался бы как «refresh-токен отвергнут» → clearTokens → шторм wipe'ов. Сигналим
        // recovery (он сам владеет очисткой и делает token-less /connect) и выходим.
        val refreshCredSnapshot = storedRefreshCred()
        if (refreshCredSnapshot.isNullOrEmpty()) {
            if (noSessionRecovery) {
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "HTTP $code on teardown request in token-less state — NOT recovering",
                )
                return chain.proceed(chain.request())
            }
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "HTTP $code in token-less state — nothing to refresh, triggering session recovery",
            )
            onSessionExpired()
            return chain.proceed(chain.request())
        }

        val oldToken = chain.request().url.queryParameter(F.AUTH_TOKEN)
        // Для 401: передаём упавший токен — если JWT_TOKEN_KEY уже обновлён другим потоком,
        //          refreshJwtTokenBlocking вернёт его сразу (оптимизация для конкурентных 401).
        // Для 403: передаём null — форсируем реальный /refresh запрос.
        //          Причина: JWT_TOKEN_KEY (connect-jwt) может отличаться от user.token (auth-jwt),
        //          и оптимизация `current != failedToken` вернула бы connect-jwt без рефреша,
        //          что тоже просрочено и дало бы повторный 403.
        val failedToken = if (response.code == 403) null else oldToken
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "attempting token refresh after HTTP $code (forced=${response.code == 403})",
        )
        val newToken = try {
            refreshToken(failedToken)
        } catch (e: java.io.IOException) {
            // Сетевая ошибка во время refresh — повторяем оригинальный запрос как есть,
            // он тоже упадёт с IOException, и caller получит сетевую ошибку. Токены не трогаем.
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "refresh network error, retrying original request as-is (tokens NOT touched): $e",
            )
            return chain.proceed(chain.request())
        }
        if (newToken == null) {
            // Refresh провален сервером (не сеть — IOException обработан выше) → refresh-токен мёртв.
            if (noSessionRecovery) {
                // Teardown (отписка): рефрешить нечем, но сессию НЕ трогаем и recovery НЕ зовём —
                // это завершение сессии, а не рабочий запрос.
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "refresh REJECTED on teardown request — NOT clearing creds / NOT recovering",
                )
                return chain.proceed(chain.request())
            }
            // Snapshot-guard: чистим креды ТОЛЬКО если они не менялись с начала нашей попытки.
            // Иначе стрэглер-401 (чей refresh стартовал до успешного recovery) затирал СВЕЖУЮ
            // пару, которую recovery только что получил от token-less /connect, — и перезапускал
            // шторм. Сигналим о протухшей сессии в любом случае.
            if (storedRefreshCred() == refreshCredSnapshot) {
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refresh REJECTED by server → both tokens dead, clearing creds (next /connect will go anonymous)",
                )
                clearTokens()
            } else {
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                    "refresh REJECTED, but creds changed during attempt (recovery won the race) — NOT clearing",
                )
            }
            onSessionExpired()
            return chain.proceed(chain.request())
        }

        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "refresh SUCCESS → retrying original request with new access (no new lead)",
        )
        userRepository.getUser()?.let { user ->
            user.token = newToken
            userRepository.saveUser(user)
        }

        val newUrl = chain.request().url.newBuilder()
            .setQueryParameter(F.AUTH_TOKEN, newToken)
            .build()
        return chain.proceed(chain.request().newBuilder().url(newUrl).build())
    }
}
