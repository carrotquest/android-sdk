package io.carrotquest_sdk.android.presentation.chat.input

import androidx.lifecycle.ViewModel
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState
import io.carrotquest_sdk.android.presentation.chat.ContactInputType
import io.carrotquest_sdk.android.presentation.chat.computeSendEnabled
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

// Сколько последних пиков амплитуды держим для живой волны записи (скользящее окно).
private const val MAX_LIVE_AMPLITUDES = 64

/**
 * Состояние нижнего бара ввода (UDF, как [io.carrotquest_sdk.android.presentation.chat.ChatViewModel]).
 *
 * Источники изменений:
 *  - [onEvent] — оптимистичные UI-события (ввод текста);
 *  - сеттеры (setVisible/setHint/setSendEnabled/showPhonePrefix и т.п.) — IDialogView-бридж
 *    из DialogPresenter (видимость, hint, тип поля, разрешение отправки, префикс телефона).
 *
 * Реальные side-effect'ы (сеть/БД/typing/draft/отправка) делает презентер; VM держит только
 * отображаемое состояние и не знает о домене.
 */
class MessageInputViewModel : ViewModel() {

    private val _state = MutableStateFlow(MessageInputState())
    val state: StateFlow<MessageInputState> = _state.asStateFlow()

    // Префикс телефона приходит тремя независимыми сигналами презентера (видимость + флаг + код),
    // которые могут прийти в любом порядке. Удерживаем их отдельно и собираем PhonePrefixUi,
    // чтобы флаг/код пережили toggle видимости и не было видимого-но-пустого третьего состояния.
    private var phonePrefixVisible = false
    private var phoneFlag = ""
    private var phoneCode = ""

    // Последний гейт отправки от презентера (enableSendButton/disableSendButton ≈ «текст валиден»).
    // Храним, чтобы пересчитывать sendEnabled и при изменении вложений, а не только по вызову презентера.
    private var sendAllowedGate = false

    // ── UI events ──────────────────────────────────────────────────────────────
    fun onEvent(event: MessageInputEvent) {
        when (event) {
            is MessageInputEvent.TextChanged -> _state.update { it.copy(text = event.text) }
            // Чекбокс согласия — чистое UI-состояние: переключаем строку и пересчитываем гейт отправки.
            is MessageInputEvent.ConsentToggled -> {
                _state.update { it.copy(consent = it.consent?.toggled(event.kind)) }
                recomputeSendEnabled()
            }
            // Остальные события — чистые side-effect'ы; их выполняет DialogFragment через презентер
            // (отправка/picker/выбор страны/отмена-удаление вложения), итог вернётся сюда сеттерами.
            // Все прочие — чистые side-effect'ы (отправка/picker/страна/удаление вложения, а также
            // голосовые: пермишен/AudioRecord/плеер/upload). Их делает DialogFragment через презентер;
            // итоговое voiceState возвращается сюда сеттерами ниже.
            MessageInputEvent.SendTapped,
            MessageInputEvent.AttachTapped,
            MessageInputEvent.PhonePrefixTapped,
            is MessageInputEvent.ConsentLinkTapped,
            is MessageInputEvent.RemoveAttachment,
            MessageInputEvent.StartVoiceRecording,
            MessageInputEvent.StopVoiceRecording,
            MessageInputEvent.CancelVoiceRecording,
            MessageInputEvent.PlayPreviewToggle,
            MessageInputEvent.DeleteVoicePreview,
            MessageInputEvent.SendVoice -> Unit
        }
    }

    // ── Bridge: видимость / доступность ──────────────────────────────────────────
    fun setVisible(visible: Boolean) = _state.update { it.copy(visible = visible) }
    fun setEnabled(enabled: Boolean) = _state.update { it.copy(enabled = enabled) }

    /** Программная установка текста: загрузка draft в showInput и сброс в clearInput. */
    fun setText(text: String) = _state.update { it.copy(text = text) }

    fun setHint(hint: String?) = _state.update { it.copy(hint = hint) }
    fun setMaxLength(maxLength: Int?) = _state.update { it.copy(maxLength = maxLength) }
    fun setInputType(type: ContactInputType) = _state.update { it.copy(inputType = type) }

    fun setAttachVisible(visible: Boolean) = _state.update { it.copy(attachVisible = visible) }
    fun setSendVisible(visible: Boolean) = _state.update { it.copy(sendVisible = visible) }

    /** Блок согласия для режима BOT_INPUT (null — убрать). Пересчитываем гейт отправки. */
    fun setConsent(consent: ConsentUiState?) {
        _state.update { it.copy(consent = consent) }
        recomputeSendEnabled()
    }

    /**
     * allowed — гейт презентера (enableSendButton / disableSendButton ≈ «текст валиден»). Запоминаем
     * и пересчитываем итог через [recomputeSendEnabled] (учитывает и вложения).
     */
    fun setSendEnabled(allowed: Boolean) {
        sendAllowedGate = allowed
        recomputeSendEnabled()
    }

    // ── Вложения (upload-on-select): операции из DialogFragment/презентера ───────
    fun addAttachment(attachment: PendingAttachment) {
        _state.update { it.copy(attachments = it.attachments + attachment) }
        recomputeSendEnabled()
    }

    fun updateAttachmentState(clientId: String, uploadState: AttachmentUploadState) {
        _state.update { s ->
            s.copy(attachments = s.attachments.map {
                if (it.clientId == clientId) it.withUploadState(uploadState) else it
            })
        }
        recomputeSendEnabled()
    }

    fun removeAttachment(clientId: String) {
        _state.update { s -> s.copy(attachments = s.attachments.filterNot { it.clientId == clientId }) }
        recomputeSendEnabled()
    }

    fun clearAttachments() {
        _state.update { it.copy(attachments = emptyList()) }
        recomputeSendEnabled()
    }

    /**
     * Итоговая доступность отправки: ничего не грузится И (валидный текст ИЛИ есть вложения).
     * Без вложений формула сводится к computeSendEnabled(text,type,gate) — текстовый путь не меняется.
     * Отправка с одними вложениями (пустой текст) разрешена; пока хоть одно UPLOADING — заблокирована
     * (нельзя слать ссылку, которой ещё нет).
     */
    private fun recomputeSendEnabled() = _state.update { s ->
        val anyUploading = s.attachments.any { it.uploadState == AttachmentUploadState.UPLOADING }
        val hasAttachments = s.attachments.isNotEmpty()
        val textOk = computeSendEnabled(s.text, s.inputType, sendAllowedGate)
        // Согласие гейтит отправку: пока обязательные чекбоксы не отмечены — нельзя (неявные — не блокируют).
        s.copy(sendEnabled = !anyUploading && s.consentOk && (textOk || hasAttachments))
    }

    // ── Голосовые (Ф2): переходы voiceState из DialogFragment/презентера ─────────
    /** Запись началась (пермишен выдан, AudioRecord стартовал). */
    fun startVoiceRecording() = _state.update { it.copy(voiceState = VoiceState.Recording()) }

    /** Новый пик амплитуды от рекордера — добавляем в живую волну (ограниченное окно). */
    fun addVoiceAmplitude(amplitude: Float) = _state.update { s ->
        val cur = s.voiceState
        if (cur !is VoiceState.Recording) s
        else s.copy(
            voiceState = cur.copy(
                amplitudes = (cur.amplitudes + amplitude).takeLast(MAX_LIVE_AMPLITUDES)
            )
        )
    }

    /** Обновить отображаемое время записи (секунды). */
    fun setVoiceElapsed(elapsedSec: Int) = _state.update { s ->
        val cur = s.voiceState
        if (cur is VoiceState.Recording) s.copy(voiceState = cur.copy(elapsedSec = elapsedSec)) else s
    }

    /** Запись остановлена → превью записанного файла. */
    fun showVoicePreview(filePath: String, durationSec: Int, waveform: List<Float>) =
        _state.update { it.copy(voiceState = VoiceState.Preview(filePath, durationSec, waveform)) }

    /** Превью: play/stop. */
    fun setVoicePreviewPlaying(isPlaying: Boolean) = _state.update { s ->
        val cur = s.voiceState
        if (cur is VoiceState.Preview) s.copy(voiceState = cur.copy(isPlaying = isPlaying)) else s
    }

    /** Превью: прогресс воспроизведения [0..1] для анимации волны. */
    fun setVoicePreviewProgress(progress: Float) = _state.update { s ->
        val cur = s.voiceState
        if (cur is VoiceState.Preview) s.copy(voiceState = cur.copy(progress = progress.coerceIn(0f, 1f))) else s
    }

    /** Сброс в обычный бар (отмена записи / удаление превью / после отправки). */
    fun clearVoice() = _state.update { it.copy(voiceState = VoiceState.Idle) }

    // ── Bridge: префикс телефона ────────────────────────────────────────────────
    fun showPhonePrefix() { phonePrefixVisible = true; recomputePhonePrefix() }
    fun hidePhonePrefix() { phonePrefixVisible = false; recomputePhonePrefix() }
    fun setPhoneRegionFlag(flag: String) { phoneFlag = flag; recomputePhonePrefix() }
    fun setPhoneRegionPrefix(code: String) { phoneCode = code; recomputePhonePrefix() }

    private fun recomputePhonePrefix() = _state.update {
        it.copy(phonePrefix = if (phonePrefixVisible) PhonePrefixUi(phoneFlag, phoneCode) else null)
    }
}
