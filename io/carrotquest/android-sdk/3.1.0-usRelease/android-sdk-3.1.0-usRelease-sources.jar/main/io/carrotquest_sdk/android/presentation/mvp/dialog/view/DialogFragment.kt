package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.Manifest
import android.content.Context
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.lifecycle.lifecycleScope
import io.carrotquest_sdk.android.core.audio.VoiceRecorder
import io.carrotquest_sdk.android.presentation.chat.WaveformExtractor
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftMessageUseCase
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.chat.ChatEvent
import io.carrotquest_sdk.android.presentation.chat.ChatScreen
import io.carrotquest_sdk.android.presentation.chat.ChatScreenState
import io.carrotquest_sdk.android.presentation.chat.ChatViewModel
import io.carrotquest_sdk.android.presentation.chat.ContactInputType
import io.carrotquest_sdk.android.presentation.chat.ErrorKind
import io.carrotquest_sdk.android.presentation.chat.isPositiveVote
import io.carrotquest_sdk.android.presentation.chat.input.AttachmentUploadState
import io.carrotquest_sdk.android.presentation.chat.input.PendingAttachment
import io.carrotquest_sdk.android.presentation.chat.input.MessageInput
import io.carrotquest_sdk.android.presentation.chat.input.MessageInputEvent
import io.carrotquest_sdk.android.presentation.chat.input.MessageInputViewModel
import io.carrotquest_sdk.android.presentation.chat.input.VoiceState
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.presentation.mvp.dialog.presenter.DialogPresenter
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper

class DialogFragment : Fragment(), IDialogView {

    companion object {
        private const val TAG = "DialogFragment"
        private const val ARG_CONVERSATION_ID = "conversation_id"
        // Число палочек волны для превью голосового (из WaveformExtractor).
        private const val VOICE_PREVIEW_BARS = 40

        fun newInstance(conversationId: String) = DialogFragment().apply {
            arguments = bundleOf(ARG_CONVERSATION_ID to conversationId)
        }
    }

    private val presenter = DialogPresenter()
    private val chatViewModel: ChatViewModel by viewModels()
    private val inputViewModel: MessageInputViewModel by viewModels()

    // Мульти-выбор файлов/картинок (мультиаттачи). Пустой список = отмена пикера.
    private val documentPick = registerForActivityResult(OpenMultipleDocuments()) { uris ->
        if (!uris.isNullOrEmpty()) presenter.onFilesPicked(uris)
    }

    // Запрос storage-разрешений для file picker (pre-T); раньше RxPermission, теперь AndroidX.
    private val storagePermissionLauncher = registerForActivityResult(RequestMultiplePermissions()) { results ->
        if (results.values.any { it }) {
            documentPick.launch(FilePickerHelper.mAllowMimeTypes)
        }
    }

    private val selectRegionLauncher = registerForActivityResult(
        io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries.SelectCountryContract()
    ) { country ->
        if (country != null) presenter.onCountrySelected(country)
    }

    // ── Голосовые (Ф2) ──────────────────────────────────────────────────────────
    private var voiceRecorder: VoiceRecorder? = null
    private var voiceAmplitudeJob: Job? = null
    private var voiceTimerJob: Job? = null
    private var voicePreviewProgressJob: Job? = null
    private var voicePlayer: MediaPlayer? = null

    // Запрос RECORD_AUDIO по тапу на mic: при выдаче — стартуем запись.
    private val recordAudioPermissionLauncher = registerForActivityResult(RequestPermission()) { granted ->
        if (granted) startVoiceRecordingInternal()
        else Toast.makeText(requireContext(), R.string.cq_voice_permission_required, Toast.LENGTH_LONG).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Тело чата и поле ввода — единое Compose-дерево (Column). Отдельный View-bottom_bar и
        // RootContainerForKeyboard убраны: клавиатуру (imePadding) обеспечивает контейнер
        // SdkContainerScreen, поэтому отдельный layout больше не нужен.
        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val conversationId = arguments?.getString(ARG_CONVERSATION_ID) ?: ""
        chatViewModel.setConversationId(conversationId)

        try {
            presenter.attachView(this)
            presenter.onCreate()
        } catch (e: Exception) {
            Log.e(TAG, "$e")
        }

        val isDark = getThemeUseCase(requireContext()) == ThemeSdk.DARK
        // Единый акцент — из SdkContainerViewModel (тот же, что в ChatScreen и шапке).
        val accentColor = (activity as? io.carrotquest_sdk.android.presentation.container.SdkContainerActivity)
            ?.let {
                val vm = androidx.lifecycle.ViewModelProvider(it)[io.carrotquest_sdk.android.presentation.container.SdkContainerViewModel::class.java]
                vm.uiState.value.accentColor
            } ?: Color(0xFF5C6BC0)

        // Плашка «Powered by» внизу тела чата — по настройке аппа.
        val settings = io.carrotquest_sdk.android.data.repositories.SettingsRepository.getInstance().getSettingsObject()
        val showPoweredBy = settings?.showPoweredBy == true
        val appName = settings?.appName ?: ""

        (view as ComposeView).setContent {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SdkColors.pageBackground(isDark))
            ) {
                ChatScreen(
                    viewModel = chatViewModel,
                    accentColor = accentColor,
                    isDark = isDark,
                    showPoweredBy = showPoweredBy,
                    appName = appName,
                    onEvent = { event -> handleChatEvent(event) },
                    modifier = Modifier.weight(1f),
                )
                // Инпут показываем только когда тело чата реально показано (Content). В полноэкранных
                // состояниях — ошибка (нет сети/авиарежим/generic) И загрузка (спиннер, в т.ч. после
                // Retry) — отправка невозможна, поэтому поле прячем целиком. Бизнес-видимость
                // (inputViewModel.visible: боты/allow_user_replies) не трогаем — вернётся сама.
                val chatState by chatViewModel.state.collectAsState()
                if (chatState is ChatScreenState.Content) {
                    val inputState by inputViewModel.state.collectAsState()
                    MessageInput(
                        state = inputState,
                        accentColor = accentColor,
                        isDark = isDark,
                        onEvent = { event -> handleInputEvent(event) },
                    )
                }
            }
        }

        presenter.onChangeConversationId(conversationId)
        presenter.onCreateWebView(conversationId)

        // Запускаем логику диалога напрямую — без ожидания загрузки WebView
        when {
            conversationId == "last_conversation" -> presenter.onOpenLastDialog()
            conversationId.isNotEmpty() -> presenter.onOpenDialog()
            else -> presenter.onOpenNewDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun onStop() {
        // Сворачивание/звонок во время записи: не пишем в фоне — фиксируем запись в превью
        // (или idle, если устройство дало сбой). Воспроизведение превью тоже останавливаем.
        if (inputViewModel.state.value.voiceState is VoiceState.Recording) {
            stopRecordingToPreview()
        }
        if (voicePlayer != null) {
            stopVoicePlayer()
            inputViewModel.setVoicePreviewProgress(0f)
            inputViewModel.setVoicePreviewPlaying(false)
        }
        super.onStop()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Освобождаем рекордер/плеер голоса (amplitude-job отменится с viewLifecycleScope сам).
        voiceRecorder?.cancel(); voiceRecorder = null
        stopVoicePlayer()
        presenter.onDestroy()
    }

    // ── Event routing ───────────────────────────────────────────────────────

    private fun handleChatEvent(event: ChatEvent) {
        chatViewModel.onEvent(event)
        when (event) {
            is ChatEvent.BotOptionSelected -> presenter.onSelectBotBrunch(
                messageId = event.messageId,
                branchId = event.option.id,
                branchLinkId = event.option.branchId ?: "",
                answerBody = event.option.text,
                href = event.option.link ?: "",
                context = requireContext(),
            )
            // Позитивную оценку отправляем сразу — комментарий не нужен. Низкие оценки НЕ отправляем
            // по тапу: сначала показываем поле комментария (ChatViewModel.onEvent → setVotePending),
            // реальная отправка — в CommentVoteSent. Иначе оценка уходила бы без комментария и сервер
            // помечал сообщение как Rated, пока локальный оверрайд ещё Pending — карточка мигала и
            // откатывалась к выбору эмодзи (баг оценки оператора). Порог — isPositiveVote (не магия «5»).
            is ChatEvent.VoteSelected -> if (isPositiveVote(event.score)) presenter.sendVote(event.messageId, event.score)
            is ChatEvent.CommentVoteSent -> presenter.sendCommentVote(event.messageId, event.score, event.comment)
            is ChatEvent.ContactFormSubmitted -> {
                val type = when (event.inputType) {
                    ContactInputType.EMAIL -> "email"
                    ContactInputType.PHONE -> "phone"
                    ContactInputType.NAME  -> "name"
                    ContactInputType.TEXT  -> "text"
                }
                presenter.setContactDetails(event.messageId, type, event.value)
            }
            is ChatEvent.Retry -> presenter.retry()
            is ChatEvent.LoadOlderMessages -> presenter.paginationMessages()
            is ChatEvent.MessageTapped -> presenter.onTapMessage(requireContext(), event.messageId)
            is ChatEvent.LinkTapped -> presenter.onGoToLink(event.url, requireContext())
            else -> {}
        }
    }

    // UI инпута → оптимистичное состояние (VM) + реальный side-effect (presenter), как handleChatEvent.
    private fun handleInputEvent(event: MessageInputEvent) {
        inputViewModel.onEvent(event)
        when (event) {
            is MessageInputEvent.TextChanged -> presenter.onInputText(event.text)
            MessageInputEvent.SendTapped -> presenter.onTapSendMessage(inputViewModel.state.value.text)
            MessageInputEvent.AttachTapped -> presenter.onOpenPicker(getScreenHeight() * 2 / 3)
            MessageInputEvent.PhonePrefixTapped -> selectRegionLauncher.launch("")
            // Отмена/удаление вложения: отменяем фоновую загрузку (презентер) и убираем чип (VM).
            is MessageInputEvent.RemoveAttachment -> {
                presenter.onRemoveAttachment(event.clientId)
                inputViewModel.removeAttachment(event.clientId)
            }
            // Чекбокс согласия — уже применён inputViewModel.onEvent выше, side-effect нет.
            is MessageInputEvent.ConsentToggled -> {}
            // Ссылка на документ в блоке согласия — открываем через презентер (как ссылки в теле чата).
            is MessageInputEvent.ConsentLinkTapped -> presenter.onGoToLink(event.url, requireContext())
            // Голосовые (Ф2.4): пермишен + VoiceRecorder + плеер превью + upload/send.
            MessageInputEvent.StartVoiceRecording -> onStartVoiceRecording()
            MessageInputEvent.StopVoiceRecording -> stopRecordingToPreview()
            MessageInputEvent.CancelVoiceRecording -> cancelVoiceRecording()
            MessageInputEvent.PlayPreviewToggle -> togglePreviewPlayback()
            MessageInputEvent.DeleteVoicePreview -> deleteVoicePreview()
            MessageInputEvent.SendVoice -> sendVoice()
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    // ── Голосовые: связка рекордера/плеера/отправки (Ф2.4) ──────────────────────

    private fun onStartVoiceRecording() {
        val granted = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startVoiceRecordingInternal()
        else recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoiceRecordingInternal() {
        val recorder = VoiceRecorder()
        // filesDir, не cacheDir: путь к WAV персистится в FailSendingMessage для ресенда после
        // сбоя сети — кэш ОС может вычистить раньше. Успешная отправка удаляет файл (onSendVoice).
        val voiceDir = File(requireContext().filesDir, "cq_voice").apply { mkdirs() }
        val file = File(voiceDir, "cq_voice_${System.currentTimeMillis()}.wav")
        if (!recorder.start(file)) {
            Toast.makeText(requireContext(), R.string.cq_lib_something_wrong, Toast.LENGTH_SHORT).show()
            return
        }
        voiceRecorder = recorder
        inputViewModel.startVoiceRecording()
        voiceAmplitudeJob = viewLifecycleOwner.lifecycleScope.launch {
            recorder.amplitude.collect { inputViewModel.addVoiceAmplitude(it) }
        }
        // Таймер записи в реальном времени (раз в секунду) + детект авто-стопа.
        voiceTimerJob = viewLifecycleOwner.lifecycleScope.launch {
            var sec = 0
            while (true) {
                kotlinx.coroutines.delay(1_000)
                // Рекордер мог остановиться сам (лимит длительности или сбой устройства) —
                // фиксируем запись в превью (recorder.stop() вернёт Success/Failed).
                if (voiceRecorder?.isRecording == false) {
                    stopRecordingToPreview()
                    break
                }
                sec++
                inputViewModel.setVoiceElapsed(sec)
            }
        }
    }

    private fun stopRecordingToPreview() {
        voiceAmplitudeJob?.cancel(); voiceAmplitudeJob = null
        voiceTimerJob?.cancel(); voiceTimerJob = null
        val recorder = voiceRecorder ?: return
        voiceRecorder = null
        when (val result = recorder.stop()) {
            is VoiceRecorder.RecordResult.Success -> {
                val durationSec = (result.durationMs / 1000L).toInt()
                val wave = WaveformExtractor.fromSource(result.file.absolutePath, VOICE_PREVIEW_BARS)
                    ?.amplitudes ?: emptyList()
                inputViewModel.showVoicePreview(result.file.absolutePath, durationSec, wave)
            }
            // TooShort/Failed — файл уже удалён рекордером, возвращаемся в обычный бар.
            else -> inputViewModel.clearVoice()
        }
    }

    private fun cancelVoiceRecording() {
        voiceAmplitudeJob?.cancel(); voiceAmplitudeJob = null
        voiceTimerJob?.cancel(); voiceTimerJob = null
        voiceRecorder?.cancel(); voiceRecorder = null
        stopVoicePlayer()
        inputViewModel.clearVoice()
    }

    private fun togglePreviewPlayback() {
        val state = inputViewModel.state.value.voiceState as? VoiceState.Preview ?: return
        val player = voicePlayer
        when {
            player != null && player.isPlaying -> {
                // Стоп: останавливаем воспроизведение и перематываем в начало (повторный тап — с нуля).
                player.pause()
                player.seekTo(0)
                stopVoiceProgressTick()
                inputViewModel.setVoicePreviewProgress(0f)
                inputViewModel.setVoicePreviewPlaying(false)
            }
            player != null -> {
                player.start()
                inputViewModel.setVoicePreviewPlaying(true)
                startVoiceProgressTick()
            }
            else -> try {
                val mp = MediaPlayer()
                mp.setDataSource(state.filePath)
                mp.setOnCompletionListener {
                    it.seekTo(0)
                    stopVoiceProgressTick()
                    inputViewModel.setVoicePreviewProgress(0f)
                    inputViewModel.setVoicePreviewPlaying(false)
                }
                mp.prepare()
                mp.start()
                voicePlayer = mp
                inputViewModel.setVoicePreviewPlaying(true)
                startVoiceProgressTick()
            } catch (t: Throwable) {
                Log.e(TAG, "voice preview playback failed: $t")
                stopVoicePlayer()
                inputViewModel.setVoicePreviewPlaying(false)
            }
        }
    }

    // Тик прогресса воспроизведения превью (для анимации волны, как в баббле).
    private fun startVoiceProgressTick() {
        voicePreviewProgressJob?.cancel()
        voicePreviewProgressJob = viewLifecycleOwner.lifecycleScope.launch {
            while (true) {
                val fraction = voicePlayer?.let { mp ->
                    val dur = mp.duration
                    if (dur > 0) mp.currentPosition.toFloat() / dur else null
                } ?: break
                inputViewModel.setVoicePreviewProgress(fraction)
                kotlinx.coroutines.delay(60)
            }
        }
    }

    private fun stopVoiceProgressTick() {
        voicePreviewProgressJob?.cancel()
        voicePreviewProgressJob = null
    }

    private fun deleteVoicePreview() {
        val state = inputViewModel.state.value.voiceState as? VoiceState.Preview
        stopVoicePlayer()
        state?.let { File(it.filePath).delete() }
        inputViewModel.clearVoice()
    }

    private fun sendVoice() {
        // Тап по отправке во время записи — сначала останавливаем (получаем файл), потом шлём.
        val preview: VoiceState.Preview? = when (val current = inputViewModel.state.value.voiceState) {
            is VoiceState.Preview -> current
            is VoiceState.Recording -> {
                voiceAmplitudeJob?.cancel(); voiceAmplitudeJob = null
        voiceTimerJob?.cancel(); voiceTimerJob = null
                val recorder = voiceRecorder; voiceRecorder = null
                val res = recorder?.stop()
                if (res is VoiceRecorder.RecordResult.Success) {
                    VoiceState.Preview(res.file.absolutePath, (res.durationMs / 1000L).toInt())
                } else null
            }
            VoiceState.Idle -> null
        }
        stopVoicePlayer()
        inputViewModel.clearVoice()
        if (preview != null) {
            presenter.onSendVoice(File(preview.filePath), preview.durationSec)
        }
    }

    private fun stopVoicePlayer() {
        stopVoiceProgressTick()
        voicePlayer?.let {
            try { it.stop() } catch (_: Throwable) {}
            it.release()
        }
        voicePlayer = null
    }

    private fun defaultHint(): String = getString(R.string.input_message_hint_text)

    // Тип клавиатуры презентера (InputType) → семантический тип поля. Презентерный keyboardTypeFor
    // возвращает ровно эти три варианта; всё прочее (mainInputType) — обычный текст.
    private fun keyboardTypeToContactType(keyboardType: Int): ContactInputType = when (keyboardType) {
        InputType.TYPE_CLASS_PHONE -> ContactInputType.PHONE
        InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> ContactInputType.EMAIL
        else -> ContactInputType.TEXT
    }

    private fun getScreenHeight(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            requireActivity().windowManager.currentWindowMetrics.bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val size = Point()
            @Suppress("DEPRECATION")
            requireActivity().windowManager.defaultDisplay.getSize(size)
            size.y
        }
    }

    override fun hideLoadError() {
        // Переходим в Loading только из Error — это семантика "скрыть оверлей ошибки".
        // Network observer вызывает hideLoadError() при каждом revalidate-пинге, и если
        // Content уже показан, сбрасывать его в Loading нельзя: setReady() после этого
        // не вызывается, и диалог зависает в вечной загрузке.
        if (chatViewModel.state.value is ChatScreenState.Error) {
            chatViewModel.setLoading()
        }
    }

    override fun hideLoading() {
        chatViewModel.setReady()
    }

    override fun showLoadingOlderMessages() {
        chatViewModel.setLoadingOlderMessages(true)
    }

    override fun hideLoadingOlderMessages() {
        val canLoadMore = MessagesRepository.getInstance().getCurrentAfter().isNotEmpty()
        chatViewModel.setLoadingOlderMessages(false, canLoadMore)
    }

    // ── IDialogView: Errors ───────────────────────────────────────────────────

    override fun showErrorNoInternet() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.NO_INTERNET)
        }
    }

    override fun showErrorAirplaneMode() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.AIRPLANE_MODE)
        }
    }

    override fun showErrorSomething() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.GENERIC)
        }
    }

    override fun showErrorFileNotFound() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showErrorSendMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showDataSavedMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_your_data_is_saved),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    // ── IDialogView: Input (делегирование в MessageInputViewModel) ──────────────

    override fun enableInput() {
        inputViewModel.setEnabled(true)
        inputViewModel.setSendEnabled(true)
    }

    override fun disableInput() {
        inputViewModel.setEnabled(false)
        inputViewModel.setSendEnabled(false)
    }

    override fun hideInput() {
        inputViewModel.setVisible(false)
    }

    override fun showInput(conversationId: String) {
        val draft = getDraftMessageUseCase(conversationId) ?: ""
        inputViewModel.setText(draft)
        inputViewModel.setVisible(true)
        // Согласие относится только к текущему BOT_INPUT-запросу: при показе бара сбрасываем,
        // а ветка property_field (applyBotPropertyFieldInput) выставит его заново после showInput.
        inputViewModel.setConsent(null)
        // Восстановленный непустой draft делает кнопку отправки активной (раньше это происходило
        // через TextWatcher при setText; программный setText в Compose событие ввода не порождает).
        inputViewModel.setSendEnabled(draft.isNotEmpty())
        // Драфт вложений: восстанавливаем ранее выбранные (уже загруженные) файлы как чипы.
        presenter.restoreAttachmentDraft(conversationId)
    }

    override fun clearInput() {
        inputViewModel.setText("")
    }

    override fun setInputMod(mod: InputMod) {
        // Управляет ТОЛЬКО видимостью прикрепления. Хинтом во всех ветках уже рулит updateHint(...),
        // поэтому setInputMod его не трогает. Раньше ветка BOT_INPUT ставила hint="" и затирала
        // вычисленный botAnswerHint (пример номера / «Введите email») — поле бот-ввода всегда было
        // с пустым плейсхолдером. Теперь плейсхолдер бот-ввода виден.
        when (mod) {
            InputMod.NORMAL, InputMod.ALLOW_USER_REPLIES -> inputViewModel.setAttachVisible(true)
            InputMod.BOT_INPUT -> inputViewModel.setAttachVisible(false)
        }
    }

    override fun updateHint(hint: String?) {
        inputViewModel.setHint(hint ?: defaultHint())
    }

    override fun updateMaxLengthInput(maxLength: Int?) {
        inputViewModel.setMaxLength(maxLength)
    }

    override fun showSendButton() {
        inputViewModel.setSendVisible(true)
    }

    override fun hideSendButton() {
        inputViewModel.setSendVisible(false)
    }

    override fun enableSendButton() {
        inputViewModel.setSendVisible(true)
        inputViewModel.setSendEnabled(true)
    }

    override fun disableSendButton() {
        inputViewModel.setSendVisible(true)
        inputViewModel.setSendEnabled(false)
    }

    override fun showAttachFileButton() {
        inputViewModel.setAttachVisible(true)
    }

    override fun hideAttachFileButton() {
        inputViewModel.setAttachVisible(false)
    }

    override fun showPhonePrefix() {
        inputViewModel.showPhonePrefix()
    }

    override fun hidePhonePrefix() {
        inputViewModel.hidePhonePrefix()
    }

    override fun updatePhoneRegionFlag(flag: String) {
        inputViewModel.setPhoneRegionFlag(flag)
    }

    override fun updatePhoneRegionPrefix(prefix: String) {
        inputViewModel.setPhoneRegionPrefix(prefix)
    }

    override fun setKeyboardType(keyboardType: Int) {
        inputViewModel.setInputType(keyboardTypeToContactType(keyboardType))
    }

    override fun setConsent(consent: io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState?) {
        inputViewModel.setConsent(consent)
    }

    override fun updateAppColor(color: Int) {
        // No-op: акцент кнопки отправки берётся из SdkContainerViewModel и передаётся в MessageInput
        // напрямую (как в ChatScreen). Презентерный цвет из настроек намеренно игнорируется.
    }

    // ── IDialogView: File ─────────────────────────────────────────────────────

    override fun openFilePicker() {
        requireActivity().runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                documentPick.launch(FilePickerHelper.mAllowMimeTypes)
            } else {
                val act = requireActivity()
                val readGranted = ContextCompat.checkSelfPermission(
                    act, Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                val writeGranted = ContextCompat.checkSelfPermission(
                    act, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (!readGranted || !writeGranted) {
                    storagePermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        )
                    )
                } else {
                    documentPick.launch(FilePickerHelper.mAllowMimeTypes)
                }
            }
        }
    }

    // ── IDialogView: мультиаттачи (делегирование в MessageInputViewModel) ────────
    override fun addPendingAttachment(attachment: PendingAttachment) {
        inputViewModel.addAttachment(attachment)
    }

    override fun updatePendingAttachmentState(clientId: String, state: AttachmentUploadState) {
        inputViewModel.updateAttachmentState(clientId, state)
    }

    override fun removePendingAttachment(clientId: String) {
        inputViewModel.removeAttachment(clientId)
    }

    override fun clearPendingAttachments() {
        inputViewModel.clearAttachments()
    }

    override fun getCurrentContext(): Context? = context ?: activity

    override fun getSupportFragmentManager(): androidx.fragment.app.FragmentManager? =
        if (isAdded) parentFragmentManager else null
}
