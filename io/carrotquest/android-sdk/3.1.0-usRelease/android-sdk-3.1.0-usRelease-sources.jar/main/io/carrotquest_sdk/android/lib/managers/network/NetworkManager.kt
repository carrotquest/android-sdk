package io.carrotquest_sdk.android.lib.managers.network

import android.annotation.SuppressLint
import android.content.Context
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.lib.managers.IStateManager
import io.carrotquest_sdk.android.lib.managers.StateObserver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class NetworkManager private constructor() : IStateManager {

    @SuppressLint("StaticFieldLeak")
    private lateinit var context: Context

    // PublishSubject<Boolean> → SharedFlow без replay: подписчик получает только
    // последующие изменения состояния (как было с PublishSubject). Текущее
    // состояние доступно синхронно через hasConnect.
    private val connectFlow = MutableSharedFlow<Boolean>(
        replay = 0,
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    // Скоуп менеджера: ping-цикл + рассылка состояния подписчикам. Отменяется в deInit().
    private val scope = CoroutineScope(SupervisorJob() + SdkDispatchers.io)

    private var networkStateReceiver: NetworkStateReceiver? = null

    // Активная джоба ping-цикла. Отменяем прежнюю при новом onConnect() — иначе
    // receiver плодит параллельные ping-loop'ы (как раньше dispose() прежней подписки).
    private var pingJob: Job? = null

    @Volatile
    private var hasInternet = false

    private var retryTime = 10 // SEC
    private var currentTry = 0

    /** Текущее (прогретое ping'ом) состояние интернета. Для Java — getHasConnect(). */
    val hasConnect: Boolean get() = hasInternet

    /**
     * Принудительно перезапускает ping-цикл проверки интернета. Нужен для случаев,
     * когда приложение долго пробыло в background/Doze: фоновый retry-цикл
     * исчерпал MAX_RETRY_ATTEMPTS, выставил hasInternet = false и больше не
     * запускается до следующего CONNECTIVITY_CHANGE broadcast'а — а его при выходе
     * из Doze может не прийти, если сеть формально не менялась. Активити чата
     * вызывает revalidate() в onResume, чтобы оживить флаг.
     */
    fun revalidate() = onConnect()

    fun onConnect() {
        // Сбрасываем retry-счётчик и backoff — начинаем новый цикл по событию от
        // BroadcastReceiver. Предыдущую джобу обязательно отменяем, иначе два
        // (а то и больше) retry-loop'а работают параллельно.
        currentTry = 0
        retryTime = 10
        pingJob?.cancel()
        pingJob = scope.launch {
            var attempts = 0
            while (isActive) {
                val result: Boolean = try {
                    ping()
                } catch (e: Exception) {
                    // Соединение установить не удалось — retry с backoff (как старый retryWhen).
                    attempts++
                    if (attempts > MAX_RETRY_ATTEMPTS) {
                        // Лимит исчерпан (как onComplete в старом retryWhen): не спамим
                        // сеть, ждём следующий connectivity event от receiver'а.
                        hasInternet = false
                        connectFlow.emit(false)
                        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.CONNECTIVITY, TAG, "network unavailable (retry exhausted): ${e.message}")
                        return@launch
                    }
                    delay(retryTime * 1000L)
                    continue
                }
                // ping вернул значение без исключения → одно событие, цикл завершаем
                // (старый Observable.create(emitter -> emitter.onNext(ping())) делал
                // один onNext без resubscribe; retryWhen срабатывал только на ошибку).
                hasInternet = result
                connectFlow.emit(result)
                SdkLogger.log(
                    SdkLogLevel.INFO, SdkLogCategory.CONNECTIVITY, TAG,
                    if (result) "network available" else "network unavailable",
                    fields = mapOf("online" to result.toString()),
                )
                return@launch
            }
        }
    }

    fun offConnect() {
        hasInternet = false
        scope.launch { connectFlow.emit(false) }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.CONNECTIVITY, TAG, "network off (disconnected)")
    }

    override fun addObserver(observer: StateObserver): Cancellable {
        // observeOn(mainThread): коллектим на Main, чтобы UI-обработчики были на главном потоке.
        // Job живёт до deInit() (scope.cancel()) ИЛИ до Cancellable.cancel() от подписчика.
        val job = scope.launch(SdkDispatchers.main) {
            connectFlow.collect { observer.onChanged(it) }
        }
        return Cancellable { job.cancel() }
    }

    override fun deInit() {
        networkStateReceiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (e: Exception) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.CONNECTIVITY, TAG, "unregisterReceiver failed", throwable = e)
            }
        }
        scope.cancel()
        instance = null
    }

    /**
     * Проверяет доступность интернета через [URLS_FOR_PING].
     * Считаем, что интернет есть, если хотя бы один URL ответил.
     *
     * @return true если хоть один URL ответил; false если все URL'ы ответили не-200.
     * @throws Exception если ни один URL не удалось открыть (триггерит retry в onConnect).
     */
    private fun ping(): Boolean {
        currentTry++

        var anyAttemptThrew = false
        for (urlStr in URLS_FOR_PING) {
            try {
                if (pingHost(urlStr)) {
                    currentTry = 0
                    retryTime = 10
                    hasInternet = true
                    return true
                }
                // pingHost вернул false (не-200) — пробуем следующий URL.
            } catch (e: Exception) {
                anyAttemptThrew = true
            }
        }

        // Увеличиваем интервал между попытками соединения.
        if (retryTime < MAX_RETRY_DELAY && currentTry % 10 == 0) {
            retryTime += 10
        }

        if (anyAttemptThrew) {
            throw Exception("network not available")
        }

        return false
    }

    /**
     * Делает до MAX_PING_COUNT-1 попыток открыть [urlStr].
     *
     * @return true если сервер вернул любой HTTP-ответ — это уже доказывает, что
     *         DNS работает и до хоста есть сетевой маршрут (принимаем не только 200,
     *         но и редиректы/ошибки).
     * @throws Exception если все попытки упали с IOException.
     */
    private fun pingHost(urlStr: String): Boolean {
        var lastException: Exception? = null
        var attempt = 1
        while (attempt < MAX_PING_COUNT) {
            attempt++
            try {
                val url = URL(urlStr)
                val urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.setRequestProperty("Connection", "close")
                urlConnection.connectTimeout = PING_TIME_OUT
                urlConnection.connect()
                return urlConnection.responseCode > 0
            } catch (e: Exception) {
                lastException = e
            }
        }
        throw lastException ?: Exception("ping failed")
    }

    /**
     * Синхронно проверяет, есть ли у устройства активное сетевое подключение с
     * capability INTERNET. В отличие от [hasConnect] это не прогретый асинхронным
     * ping'ом кэш, а живое состояние из системы — корректно отражает выключение
     * сети, авиарежим, выход из Doze.
     */
    fun isNetworkAvailable(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val active = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(active)
                caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (e: Exception) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.CONNECTIVITY, TAG, "isNetworkAvailable check failed", throwable = e)
            false
        }
    }

    val connectionType: String
        @Suppress("DEPRECATION")
        get() {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return ""
            val info = cm.activeNetworkInfo ?: return ""
            return when (info.type) {
                ConnectivityManager.TYPE_WIFI -> "WIFI"
                ConnectivityManager.TYPE_MOBILE -> "MOBILE"
                ConnectivityManager.TYPE_VPN -> "VPN"
                else -> "OTHER"
            }
        }

    companion object {
        private const val TAG = "NetworkManager"
        private const val CONNECTIVITY_ACTION = "android.net.conn.CONNECTIVITY_CHANGE"

        // Пингуем оба адреса: если хотя бы один отвечает — считаем, что интернет есть.
        // Так не выпадаем в "no internet" из-за того, что один из хостов заблокирован.
        private val URLS_FOR_PING = arrayOf("https://www.google.com/", "https://ya.ru/")
        private const val MAX_PING_COUNT = 5
        private const val PING_TIME_OUT = 2000 // MS
        private const val MAX_RETRY_DELAY = 600 // SEC

        // Лимит на retry-цикл: после него ждём следующий connectivity event. С backoff
        // до 10 минут это ≈ час попыток, дальше жечь батарею и трафик бессмысленно.
        private const val MAX_RETRY_ATTEMPTS = 30

        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: NetworkManager? = null

        @JvmStatic
        fun getInstance(context: Context): NetworkManager {
            instance?.let { return it }
            val nm = NetworkManager()
            // applicationContext: ресивер живёт до deInit() SDK, а не до конкретной Activity.
            // Регистрация на Activity-контексте приводила к IntentReceiverLeaked при её destroy.
            val appContext = context.applicationContext
            nm.context = appContext
            nm.networkStateReceiver = NetworkStateReceiver()
            val filter = IntentFilter().apply { addAction(CONNECTIVITY_ACTION) }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.registerReceiver(nm.networkStateReceiver, filter, Context.RECEIVER_EXPORTED)
                } else {
                    appContext.registerReceiver(nm.networkStateReceiver, filter)
                }
            } catch (e: Exception) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.CONNECTIVITY, TAG, "hasConnect check failed", throwable = e)
            }
            instance = nm
            // Синхронно прогреваем флаг живым системным состоянием ДО того, как отработает
            // асинхронный ping в onConnect(). Иначе hasConnect до первого ответа ping'а слепо
            // возвращает false и провоцирует ложный INTERNET_DISAPPEARED (см. changeStateSockets).
            nm.hasInternet = nm.isNetworkAvailable()
            // Первичная проверка связи. Дальше ping-loop'ы запускаются только через
            // onConnect() из BroadcastReceiver'а.
            nm.onConnect()
            return nm
        }

        @JvmStatic
        fun isAirplaneModeOn(): Boolean {
            val ctx = instance?.context ?: return false
            return Settings.System.getInt(
                ctx.contentResolver, Settings.System.AIRPLANE_MODE_ON, 0
            ) != 0
        }
    }
}
