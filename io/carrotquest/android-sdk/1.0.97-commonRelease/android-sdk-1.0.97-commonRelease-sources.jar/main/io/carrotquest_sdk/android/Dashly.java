package io.carrotquest_sdk.android;

import android.content.Context;

import io.carrotquest_sdk.android.core.main.CarrotSDK;

public class Dashly extends CarrotSDK {
    public interface Callback<T> extends CarrotSDK.Callback<T> {
        void onResponse(T result);
        void onFailure(Throwable t);
    }

    public Dashly(Context context) {
        super(context);
    }
}
