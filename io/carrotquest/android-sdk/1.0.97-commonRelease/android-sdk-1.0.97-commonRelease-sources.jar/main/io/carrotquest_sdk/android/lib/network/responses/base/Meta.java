package io.carrotquest_sdk.android.lib.network.responses.base;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

@Keep
public class Meta {
    @SerializedName("status")
    private int status;

    @SerializedName("error")
    private String error;

    @SerializedName("error_message")
    private String errorMessage;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
