package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.data.repositories.PopupRepository
import io.reactivex.Observable

fun <T> Observable<T>.expirationSubscribe(): Observable<String> {
    return Observable.defer {
        flatMap {
            PopupRepository.expirationObservable()
        }
    }
}