package io.carrotquest_sdk.android.presentation.mvp.button.model

class FloatingButtonViewModel {
    companion object {
        private var instance: FloatingButtonViewModel? = null
        fun getInstance(): FloatingButtonViewModel {
            if (instance == null) {
                instance = FloatingButtonViewModel()
            }
            return instance!!
        }
    }

    private val lastMessage: LastMessage = LastMessage("", "", StateLastMessage.UNKNOWN)

    private var isShowSocialLabels = true

    private var autoHide = false

    fun getLastMessage(): LastMessage {
        return lastMessage
    }

    fun updateTextLastMessage(text: String) {
        lastMessage.text = text
    }

    fun updateAdminIconLastMessage(adminIcon: String) {
        lastMessage.adminIcon = adminIcon
    }

    fun updateStateLastMessage(state: StateLastMessage) {
        lastMessage.state = state
    }

    fun updateFlagShowSocialLabels(showSocialLabels: Boolean) {
        this.isShowSocialLabels = showSocialLabels
    }

    fun getFlagShowSocialLabels() = isShowSocialLabels

    fun isAutoHide() = autoHide
    fun updateAutoHide(autoHide: Boolean) {
        this.autoHide = autoHide
    }
}