package io.carrotquest_sdk.android.presentation.mvp.button.view

enum class LocationFloatingButton private constructor(var id: Int) {
    TOP_LEFT(0),
    TOP_RIGHT(1),
    BOTTOM_LEFT(2),
    BOTTOM_RIGHT(3);


    companion object {

        fun fromId(id: Int): LocationFloatingButton {
            for (locationFAB in values()) {
                if (locationFAB.id == id) {
                    return locationFAB
                }
            }
            throw IllegalArgumentException()
        }
    }
}