package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.presenter

import android.content.Context
import android.content.Intent
import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.LongSerializationPolicy
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.js_interface.IJsListPresenter
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.getLastOpenedConversationId
import io.carrotquest_sdk.android.domain.use_cases.conversations.getNotPopupConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onAddMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onRemoveMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.onCreateConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.openConversation
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view.ListActivity
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.Locale
import java.util.concurrent.TimeUnit

class ListPresentation : BasePresenter(), IJsListPresenter {
    private var compositeDisposable = CompositeDisposable()
    private companion object {
        const val TAG = "ListPresentation"
    }
    private var isPagination = false
    private var startedFromNotification = false



    override fun onSelectConversation(context: Context, conversationId: String) {
        val intent = Intent(context, DialogActivity::class.java)
        intent.putExtra(DialogActivity.CONVERSATION_ID_ARG, conversationId)
        intent.putExtra(DialogActivity.STARTED_FROM_NOT_ARG, startedFromNotification)
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        context.startActivity(intent)

        getView()?.closeActivity()
    }

    override fun paginationConversations() {
        if(!isPagination) {
            isPagination = true
            compositeDisposable.add(
                    Observable.just(true)
                            .getCurrentUser()
                            .loadConversations(ConversationsRepository.getInstance().getCurrentAfter())
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .take(1)
                            .subscribe({
                                Log.d(TAG, "Pagination conversations. Size = ${it.size}")
                                isPagination = false
                            }, { t ->
                                Log.e(TAG, t)
                                isPagination = false
                            })
            )
        }
    }

    override fun domUpdated() {

    }

    override fun getView(): ListActivity? {
        return super.getView() as ListActivity
    }

    fun onChangeErrorStateWebView(isError: Boolean) {

    }

    fun setIsStartedFromNotification(startedFromNotification: Boolean) {
        this.startedFromNotification = startedFromNotification
    }

    fun webViewIsReady() {
        val hasInternet = NetworkManager.getInstance(getView()).hasConnect
        ConversationsRepository.getInstance().saveOpenedConversation("")
        if(hasInternet) {
            //инициализация
            compositeDisposable.add(Observable.just(true)
                .getConversations()
                .getNotPopupConversations()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())

                .doOnError { t ->
                    Log.e(TAG, t)
                }
                .take(1)
                .subscribe({ conversations ->
                    if (conversations.size > 0) {
                        getView()?.hideError()
                        compositeDisposable.add(
                            Observable.just(true)
                                .getSettings()
                                .take(1)
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribeOn(Schedulers.io())
                                .map { x -> x }
                                .doOnError {
                                    Log.e(TAG, it)
                                }
                                .subscribe { settings ->
                                    val jsonObject = JsonObject()
                                    val jsonParser = JsonParser()

                                    val conversationsJs = JsonArray()
                                    val joConnect =
                                        prepareJsonSettings(jsonParser.parse(settings.sourceData) as JsonObject)
                                    val providerName = when (BuildConfig.FLAVOR) {
                                        "common" -> "Carrot quest"
                                        "us" -> "Dashly"
                                        else -> ""
                                    }
                                    if (providerName.isNotEmpty()) {
                                        joConnect.addProperty("provider_name", providerName)
                                    }

                                    jsonObject.add("appSettings", joConnect)

                                    for (model in conversations) {
                                        if (model.sourceJsonData != null) {
                                            conversationsJs.add(model.sourceJsonData)
                                        }
                                    }

                                    jsonObject.add(
                                        ResponseFields.UNSTRUCTURED_CONVERSATION_LIST,
                                        conversationsJs
                                    )

                                    val js =
                                        "javascript:window.webView.initConversationList(${jsonObject.toString()})"

                                    compositeDisposable.add(
                                        Observable
                                            .just(true)
                                            .delay(1, TimeUnit.SECONDS)
                                            .subscribeOn(Schedulers.io())
                                            .take(1)
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .subscribe {
                                                getView()?.initList(js)

                                            }
                                    )

                                    // Берем небольшую паузу, чтобы веб-сьюха успела прогрузиться
                                    // и скрываем индикатор загрузки
                                    compositeDisposable.add(
                                        Observable
                                            .just(true)
                                            .delay(2, TimeUnit.SECONDS)
                                            .subscribeOn(Schedulers.io())
                                            .take(1)
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .subscribe {
                                                getView()?.hideLoading()
                                            }
                                    )
                                })
                    } else {
                        getView()?.showEmptyList()
                    }
                }, { t ->
                    Log.e(TAG, t)
                    getView()?.showErrorSomething()
                })
            )
        } else {
            getView()?.showErrorNoInternet()
        }


        //Когда пришло новое сообщение
        compositeDisposable.add(
            Observable.just(true)
                .onAddMessages()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ messages ->
                    for (message in messages) {
                        val conversationId = message.conversation
                        compositeDisposable.add(
                            Observable.just(true)
                                .getConversation(conversationId)
                                .take(1)
                                .filter { x -> x.value != null }
                                .map { x -> x.value!! }
                                .subscribe({ conversation ->
                                    val js =
                                        "javascript:window.webView.updateConversationObject(${conversation.sourceJsonData.toString()})"
                                    getView()?.updateDialog(js)

                                    conversation.lastAdmin = message.messageFrom
                                    ConversationsRepository.getInstance()
                                        .updateConversation(conversationId, conversation)

                                }, { t ->
                                    Log.e(TAG, t)
                                })
                        )

                    }
                }, { t ->
                    Log.e(TAG, t)
                })
        )

        //Когда обновилось сообщение
        compositeDisposable.add(
            Observable.just(true)
                .getConversations()
                .getNotPopupConversations()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ conversations ->
                    for (conversation in conversations) {
                        /*val jsonArray = prepareJsonUpdateConversation(conversation.partLast, conversation)
                                val js = "javascript:window.webView.updateConversation(\"${conversation.id}\", $jsonArray)"
                                getView()?.updateDialog(js)*/

                        val js =
                            "javascript:window.webView.updateConversationObject(${conversation.sourceJsonData.toString()})"
                        getView()?.updateDialog(js)
                    }
                }, { t ->
                    Log.e(TAG, t)
                })
        )


        compositeDisposable.add(
            Observable.just(true)
                .onRemoveMessage()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .filter { true }
                .map { x -> x }
                .subscribe({ message ->
                    compositeDisposable.add(
                        Observable.just(true)
                            .getConversation(message.conversation)
                            .take(1)
                            .subscribe({ opt ->
                                if (opt?.value != null) {
                                    val conversation = opt.value
                                    val partsCount = conversation.partsCount
                                    if (partsCount <= 1) {
                                        val conversationId = message.conversation
                                        val js =
                                            "javascript:window.webView.removeConversation(\"$conversationId\")"
                                        getView()?.deleteDialog(js)
                                    } else {
                                        compositeDisposable.add(
                                            Observable.just(message.conversation)
                                                .loadConversation()
                                                .take(1)
                                                .subscribe({

                                                }, { t ->
                                                    Log.e(TAG, t)
                                                })
                                        )
                                    }
                                }

                            }, { t ->
                                Log.e(TAG, t)
                            })
                    )
                }, { t ->
                    Log.e(TAG, t)
                })
        )

        //Когда создается новый диалог
        compositeDisposable.add(
            Observable.just(true)
                .onCreateConversation()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ conversation ->
                    val conversationsJson = prepareJsonAddConversation(conversation)
                    val js = "javascript:window.webView.addConversations(${conversationsJson})"
                    getView()?.addDialog(js)
                }, { t ->
                    Log.e(TAG, t)
                })
        )
    }

    fun onBack() {
        compositeDisposable.add(Observable.just(true)
                .getLastOpenedConversationId()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext { conversation ->
                    compositeDisposable.add(
                            Observable.just(true)
                                    .openConversation(conversation)
                                    .subscribe()
                    )

                    val conversationId = conversation ?: ""
                    openConversation(conversationId)

                }
                .doOnError {t->
                    Log.e(TAG, t)
                }
                .subscribe()
        )
    }

    fun onDestroy() {
        super.detachView()
        compositeDisposable.dispose()
    }

    fun onStartCreateConversation() {
        val intent = Intent(getView(), DialogActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        //intent.putExtra(DialogActivity.CONVERSATION_ID_ARG, "NEW")
        getView()?.startActivity(intent)
    }

    private fun openConversation(conversationId: String) {
        val intent = Intent(getView(), DialogActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        intent.putExtra(DialogActivity.STARTED_FROM_NOT_ARG, startedFromNotification)
        intent.putExtra(DialogActivity.CONVERSATION_ID_ARG, conversationId)
        getView()?.startActivity(intent)
    }

    private fun prepareJsonUpdateConversation(message: MessageData, conversation: DataConversation): JsonArray {
        val partCountNewValue = conversation.partsCount //+ 1
        val bodyPartLastNewValue = message.body
        val bodyJsonPartLastNewValue = message.bodyJson.toString()
        val partLastType = message.type
        var unreadPartsCount = conversation.unreadPartsCount
        /*if (message.direction == ResponseFields.ADMIN_2_USER) {
            unreadPartsCount += 1
        }*/
        val partLastIsDeleted = message.removed

        val jsonArray = JsonArray()
        val partsCountObject = JsonObject()
        partsCountObject.addProperty(ResponseFields.PARTS_COUNT, partCountNewValue)
        jsonArray.add(partsCountObject)

        val unreadPartsCountObject = JsonObject()
        unreadPartsCountObject.addProperty(ResponseFields.UNREAD_PARTS_COUNT, unreadPartsCount)
        jsonArray.add(unreadPartsCountObject)

        val lastUpdateCountObject = JsonObject()
        lastUpdateCountObject.addProperty(ResponseFields.LAST_UPDATE, message.created)
        jsonArray.add(lastUpdateCountObject)

        val partLastObject = JsonObject()
        val bodyObject = JsonObject()
        bodyObject.addProperty(ResponseFields.BODY, bodyPartLastNewValue)

        val bodyJsonObject = JsonObject()
        bodyJsonObject.addProperty(ResponseFields.BODY_JSON, bodyJsonPartLastNewValue)

        val partLastArray = JsonArray()

        val typeObject = JsonObject()
        typeObject.addProperty(ResponseFields.TYPE, partLastType)

        val isDeletedObject = JsonObject()
        isDeletedObject.addProperty(F.REMOVED, partLastIsDeleted)

        partLastArray.add(bodyObject)
        partLastArray.add(bodyJsonObject)
        partLastArray.add(typeObject)
        partLastArray.add(isDeletedObject)
        partLastObject.add(ResponseFields.PART_LAST, partLastArray)
        jsonArray.add(partLastObject)

        val messageFrom = message.messageFrom
        if (messageFrom?.type != null && ResponseFields.ADMIN == messageFrom.type?.lowercase(Locale.getDefault())) {
            val lastAdminObject = JsonObject()
            val lastAdminArray = JsonArray()

            val adminAvatarObject = JsonObject()
            adminAvatarObject.addProperty(ResponseFields.AVATAR, messageFrom.avatar)
            lastAdminArray.add(adminAvatarObject)

            val adminNameObject = JsonObject()
            adminNameObject.addProperty(ResponseFields.NAME, messageFrom.name)
            lastAdminArray.add(adminNameObject)

            lastAdminObject.add(ResponseFields.LAST_ADMIN, lastAdminArray)
            jsonArray.add(lastAdminObject)
        }

        return jsonArray
    }

    private fun prepareJsonAddConversation(conversation: DataConversation): JsonArray {
        val jsonArray = JsonArray()

        val gsonBuilder = GsonBuilder()
        gsonBuilder.setLongSerializationPolicy(LongSerializationPolicy.STRING)
        val gson = gsonBuilder.create()

        val jsonParser = JsonParser()
        //val conversationViewEntity: ConversationViewEntity = convertModelToView(conversation)
        val jo = jsonParser.parse(gson.toJson(conversation)) as JsonObject
        jsonArray.add(jo)

        return jsonArray
    }

    private fun prepareJsonSettings(joSettings: JsonObject): JsonObject {
        if (joSettings.has("app")) {
            val app = joSettings.getAsJsonObject("app")
            if (app.has("settings")) {
                val settings = app.getAsJsonObject("settings")
                if (settings.has("locale")) {
                    settings.remove("locale")
                }
                var currentLang = Locale.getDefault().language
                if(currentLang != "en" && currentLang != "ru") {
                    currentLang = "en"
                }
                settings.addProperty("locale", currentLang)

                if(settings.has("messenger_theme")) {
                    settings.remove("messenger_theme")
                }
                val theme = getThemeUseCase(getView())
                val themeStr = if( theme == SimpleTheme.DARK) "dark" else "light"
                settings.addProperty("messenger_theme", themeStr)

                app.remove("settings")
                app.add("settings", settings)
            }
            joSettings.remove("app")
            joSettings.add("app", app)
        }

        if(joSettings.has("knowledge_base_domain")) {
            var kbDomain = joSettings.get("knowledge_base_domain").asString
            if(kbDomain != null && !kbDomain.contains("http://") && !kbDomain.contains("https://")) {
                kbDomain = "//$kbDomain"
            }
            joSettings.remove("knowledge_base_domain")
            joSettings.addProperty("knowledge_base_domain", kbDomain)
        }


        return joSettings
    }
}