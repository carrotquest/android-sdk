package io.carrotquest_sdk.android.lib.utils.files

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.carrotquest_sdk.android.lib.utils.loging.Log
import java.io.*

fun readFile(fileName: String, context: Context) : String? {
    try {
        val i = context.assets.open(fileName)
        return inputStreamToString(i)
    }
    catch (ioEx: IOException) {
        Log.e("readFile", ioEx.toString())
    }
    return null
}

fun saveBitmapImageToGallery(bitmap: Bitmap, contentResolver: ContentResolver, callback: SaveImageCallback) {
    try {
        MediaStore.Images.Media.insertImage(contentResolver, bitmap, "", "")
                ?: throw Exception()

        callback.done()
    } catch (e: Exception) {
        callback.fail()
    }
}

private fun inputStreamToString(inputStream: InputStream): String {
    val builder = StringBuilder()
    val reader = InputStreamReader(inputStream, "UTF-8")
    reader.readLines().forEach {
        builder.append(it)
    }
    return builder.toString()
}

interface SaveImageCallback {
    fun done()
    fun fail()

}