package io.carrotquest_sdk.android.core.util.files.download_files;

public interface DownloadProgressListener {
    void update(long bytesRead, boolean done);
}
