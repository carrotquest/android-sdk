package io.carrotquest_sdk.android.lib.network.responses.start_conversation;

import androidx.annotation.Keep;

import io.carrotquest_sdk.android.lib.network.responses.base.Data;
import io.carrotquest_sdk.android.lib.network.responses.base.IBaseResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
@Keep
public class StartConversationResponse implements IBaseResponse {
    private DataStartConversation data;
    private Meta meta;

    @Override
    public DataStartConversation getData() {
        return data;
    }

    @Override
    public Meta getMeta() {
        return meta;
    }

    @Override
    public void setData(Data data) {
        this.data = (DataStartConversation)data;
    }

    @Override
    public void setMeta(Meta meta) {
        this.meta = meta;
    }
}
