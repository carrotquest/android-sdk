package io.carrotquest_sdk.android.lib.utils.mock_responses

import okhttp3.mockwebserver.RecordedRequest


fun isFirebaseToken(request: RecordedRequest?) : Boolean {
    if(request?.path == null) {
        return false
    }
    return request.path?.contains("djangousers")!! && request.path?.contains("firebase_token")!!
}

fun isGetAppsList(request: RecordedRequest?) : Boolean {
    if(request?.path == null) {
        return false
    }

    return request.path?.contains("djangousers")!! && !request.path?.contains("firebase_token")!! && request.method == "GET"
}

fun isChangeAlert(request: RecordedRequest?) : Boolean {
    if(request?.path == null) {
        return false
    }

    return request.path?.contains("djangousers")!! && !request.path?.contains("firebase_token")!! && request.method == "PATCH"
}

fun isGetDialogsList(request: RecordedRequest?) : Boolean {
    if(request?.path == null) {
        return false
    }
    return request.path?.contains("/conversations")!! && request.method == "GET"
}


fun isCheckVersion(request: RecordedRequest?) : Boolean {
    if(request?.path == null) {
        return false
    }
    return request.path?.contains("/utils/clientsupport")!! && request.method == "GET"
}