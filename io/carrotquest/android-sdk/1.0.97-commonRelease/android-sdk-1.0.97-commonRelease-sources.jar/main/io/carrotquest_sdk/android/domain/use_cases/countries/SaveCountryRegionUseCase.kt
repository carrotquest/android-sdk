package io.carrotquest_sdk.android.domain.use_cases.countries

import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.main.CarrotInternal


class SaveCountryRegionUseCase {
    fun call(region: String) {
        val context = CarrotInternal.getLibComponent().contextSdk
        SharedPreferencesLib.saveString(context, SAVED_REGION, region)
    }
}