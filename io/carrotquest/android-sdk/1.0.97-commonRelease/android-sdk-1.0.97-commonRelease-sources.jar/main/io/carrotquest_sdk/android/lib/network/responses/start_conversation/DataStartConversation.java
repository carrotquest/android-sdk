package io.carrotquest_sdk.android.lib.network.responses.start_conversation;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;
@Keep
public class DataStartConversation extends Data {
    @SerializedName(F.ID)
    @Expose
    private String conversationId;

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }
}
