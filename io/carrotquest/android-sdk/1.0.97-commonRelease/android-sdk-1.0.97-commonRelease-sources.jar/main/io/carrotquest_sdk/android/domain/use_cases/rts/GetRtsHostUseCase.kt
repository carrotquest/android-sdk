package io.carrotquest_sdk.android.domain.use_cases.rts

import android.content.Context
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib


fun getRtsHost(context: Context): String {
    var savedHost = SharedPreferencesLib.getString(context, hostRtsKey)
    if(savedHost == null || savedHost.isEmpty()) {
        return BuildConfig.WSS_URL
    }

    if(!savedHost.startsWith("ws")) {
        savedHost = "wss://$savedHost"
    }

    if(!savedHost.endsWith("/")) {
        savedHost = "$savedHost/"
    }

    if(!savedHost.contains("websocket")) {
        savedHost = "${savedHost}websocket/"
    }

    return savedHost
}