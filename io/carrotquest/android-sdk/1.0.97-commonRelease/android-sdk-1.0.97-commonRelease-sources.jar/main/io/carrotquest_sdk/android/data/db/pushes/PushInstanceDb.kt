package io.carrotquest_sdk.android.data.db.pushes

import androidx.room.Room
import android.content.Context
import io.carrotquest_sdk.android.data.db.PushDB

class PushInstanceDb {

    private val context: Context? = null

    companion object {
        private var db: PushDB? = null
        private var context: Context? = null

        fun getDb(context: Context) : PushDB{
            if (this.context == null) {
                this.context = context
            }
            if (this.db == null) {
                db = Room.databaseBuilder(context, PushDB::class.java, "carrot_pushes_sdk.db")
                        .allowMainThreadQueries().fallbackToDestructiveMigration().build()
            }

            return db!!
        }
    }
}