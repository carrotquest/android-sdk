package io.carrotquest_sdk.android.core.constants


enum class ConversationType(val stringValue: String) {
    CHAT ("popup_chat"),
    POPUP_BIG("popup_big"),
    POPUP_SMALL("popup_small"),
    BLOCK_POPUP_BIG("block_popup_big"),
    BLOCK_POPUP_SMALL("block_popup_small"),
    LEAD_BOT("lead_bot"),
    ROUTING_BOT("routing_bot")
}