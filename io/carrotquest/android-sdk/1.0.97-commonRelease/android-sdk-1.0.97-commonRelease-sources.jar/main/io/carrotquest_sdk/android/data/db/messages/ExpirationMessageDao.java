package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import io.reactivex.Single;

@Dao
public interface ExpirationMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ExpirationMessage message);

//    @Query("SELECT * FROM expirationmessage WHERE id = :identifier")
//    Single<ExpirationMessage> getById(String identifier);

    @Query("SELECT * FROM expirationmessage")
    List<ExpirationMessage> getAll();

    @Query("DELETE FROM expirationmessage WHERE id = :idxxx")
    void remove(String idxxx);
}