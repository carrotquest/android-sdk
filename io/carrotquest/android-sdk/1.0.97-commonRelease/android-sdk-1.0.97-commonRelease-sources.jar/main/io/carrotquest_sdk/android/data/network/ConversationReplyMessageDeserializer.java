package io.carrotquest_sdk.android.data.network;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.db.files.SavedFile;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationReplyMessage;

public class ConversationReplyMessageDeserializer implements JsonDeserializer<ConversationReplyMessage> {
    private static final String TAG = "ConversationReplyMessageDeserializer";

    @Override
    public ConversationReplyMessage deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        MessageData messageData = ConvertUtilsKt.convertJsonToMessageData(json);
        ConversationReplyMessage response = new ConversationReplyMessage(messageData);
        if (GsonUtil.jsonElementNotNull(json, ResponseFields.CONVERSATION_CLOSED)) {
            response.conversationClosed = json.getAsJsonObject().get(ResponseFields.CONVERSATION_CLOSED).getAsBoolean();
        }

        if(response.getAttachments() != null && !response.getAttachments().isEmpty()) {
            ArrayList<Attachment> tempList = new ArrayList<>();
            for(Attachment attachment : response.getAttachments()) {
                if(attachment.getStatus() == null) {
                    SavedFile savedFile = CarrotInternal.getLibComponent().getSdkDataBase().savedFileDao().getByURL(attachment.getUrl());
                    //if (savedFile != null) {
                        attachment.setStatus("loaded");
                    //}
                }
                tempList.add(attachment);
            }
            response.setAttachments(tempList);
        }

        return response;
    }

}
