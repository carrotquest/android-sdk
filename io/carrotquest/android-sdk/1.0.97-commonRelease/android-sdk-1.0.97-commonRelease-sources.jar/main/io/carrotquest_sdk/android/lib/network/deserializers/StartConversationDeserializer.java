package io.carrotquest_sdk.android.lib.network.deserializers;

import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.DataStartConversation;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

import com.google.gson.*;

import java.lang.reflect.Type;

public class StartConversationDeserializer implements JsonDeserializer<StartConversationResponse> {

    public StartConversationDeserializer() {
    }

    @Override
    public StartConversationResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("StartConversationDeserializer. meta is null or dataJsonElement is null");
        }

        JsonObject meta = json.getAsJsonObject().getAsJsonObject(F.META);
        JsonObject data = json.getAsJsonObject().getAsJsonObject(F.DATA);

        StartConversationResponse response = new StartConversationResponse();
        if (data != null) {
            response.setData(new Gson().fromJson(data, DataStartConversation.class));
        }
        if (meta != null) {
            response.setMeta(new Gson().fromJson(meta, Meta.class));
        }

        return response;
    }
}