package io.carrotquest_sdk.android.presentation.mvp.dialog.model

enum class StateAppBar {
    COLLAPSED,
    EXPANDED
}