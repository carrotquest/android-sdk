package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
@Keep
public class MetaMessages extends Meta {
    @SerializedName(F.NEXT_ARTER)
    @Expose
    private String nextAfter;

    public String getNextAfter() {
        return nextAfter;
    }

    public void setNextAfter(String nextAfter) {
        this.nextAfter = nextAfter;
    }
}