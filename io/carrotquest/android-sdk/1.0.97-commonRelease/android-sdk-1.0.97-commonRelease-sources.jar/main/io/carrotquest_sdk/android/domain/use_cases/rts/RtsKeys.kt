package io.carrotquest_sdk.android.domain.use_cases.rts

const val hostRtsKey = "HOST_RTS_KEY"
