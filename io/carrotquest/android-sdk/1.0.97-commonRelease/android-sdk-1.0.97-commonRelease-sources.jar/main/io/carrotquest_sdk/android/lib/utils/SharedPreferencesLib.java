package io.carrotquest_sdk.android.lib.utils;

import android.content.Context;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class SharedPreferencesLib {
    public static final String NAME_SHARED_PREFERENCES = "io.carrotquest.utils";

    public SharedPreferencesLib() {
    }

    public static void saveBoolean(Context context, String key, boolean value) {
        android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static void saveString(Context context, String key, String value) {
        android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
        editor.putString(key, value);
        editor.apply();
    }

    public static void saveInt(Context context, String key, int value) {
        android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
        editor.putInt(key, value);
        editor.apply();
    }

    public static void saveLong(Context context, String key, long value) {
        android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
        editor.putLong(key, value);
        editor.apply();
    }

    private static android.content.SharedPreferences.Editor getSharedEditor(Context context, String key) {
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        android.content.SharedPreferences.Editor editor = sharedPreferences.edit();
        if(sharedPreferences.contains(key)) {
            editor.remove(key);
        }

        return editor;
    }

    public static String getString(Context context, String key) {
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        return sharedPreferences.getString(key, "");
    }

    public static boolean getBoolean(Context context, String key) {
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        return sharedPreferences.getBoolean(key, false);
    }

    public static long getLong(Context context, String key) {
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        return sharedPreferences.getLong(key, 0);
    }

    public static int getInt(Context context, String key) {
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        return sharedPreferences.getInt(key, 0);
    }

    public static void saveStringSet(Context context, String key, Set<String> value) {
        android.content.SharedPreferences.Editor editor = getSharedEditor(context, key);
        editor.putStringSet(key, value);
        editor.apply();
    }
    public static Set<String> getStringSet(Context context, String key) {
        android.content.SharedPreferences sharedPreferences = context.getSharedPreferences(NAME_SHARED_PREFERENCES, 0);
        return sharedPreferences.getStringSet(key,new HashSet<>());
    }

    public static ArrayList<String> getPreferenceArray(Context context, String key) {
        android.content.SharedPreferences prefs = context.getSharedPreferences(NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE);
        Set<String> unreadConversations = prefs.getStringSet(key, null);
        if(unreadConversations == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(Objects.requireNonNull(unreadConversations));
    }

    public static void clearPreference(Context context, String key) {
        android.content.SharedPreferences prefs = context.getSharedPreferences(NAME_SHARED_PREFERENCES, Context.MODE_PRIVATE);
        prefs.edit().remove(key).apply();
    }
}
