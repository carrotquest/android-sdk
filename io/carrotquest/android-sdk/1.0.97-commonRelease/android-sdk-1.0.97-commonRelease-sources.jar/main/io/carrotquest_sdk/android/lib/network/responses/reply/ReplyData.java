package io.carrotquest_sdk.android.lib.network.responses.reply;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;
@Keep
public class ReplyData extends Data {
    @SerializedName(F.ID)
    @Expose
    private String id;

    @SerializedName(F.ID_ASSIGN_PART)
    @Expose
    private String idAssignedPart;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdAssignedPart() {
        return idAssignedPart;
    }

    public void setIdAssignedPart(String idAssignedPart) {
        this.idAssignedPart = idAssignedPart;
    }
}
