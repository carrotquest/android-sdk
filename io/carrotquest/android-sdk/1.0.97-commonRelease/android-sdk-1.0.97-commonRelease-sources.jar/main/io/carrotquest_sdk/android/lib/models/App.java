package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class App {
    @SerializedName(F.ID)
    private String id;
    @SerializedName(F.SETTINGS)
    private Settings settings;
    @SerializedName(F.NAME)
    private String name;

    @SerializedName(F.STATUS_OPERATORS)
    private String statusOperators;

    @SerializedName(F.ACTIVE)
    private boolean isActive;
    @SerializedName(F.ADMINS)
    private List<Admin> admins;

    @SerializedName(F.BLOCKED)
    private boolean isBlocked;



    public Settings getSettings() {
        return settings;
    }

    public void setSettings(Settings settings) {
        this.settings = settings;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public List<Admin> getAdmins() {
        return admins;
    }

    public void setAdmins(List<Admin> admins) {
        this.admins = admins;
    }

    public String getStatusOperators() {
        return statusOperators;
    }

    public void setStatusOperators(String statusOperators) {
        this.statusOperators = statusOperators;
    }

    public void setBlocked(boolean blocked) {
        isBlocked = blocked;
    }

    public boolean isBlocked() {
        return isBlocked;
    }
}
