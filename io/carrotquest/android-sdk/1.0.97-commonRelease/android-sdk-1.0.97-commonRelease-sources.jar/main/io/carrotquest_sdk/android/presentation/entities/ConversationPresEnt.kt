package io.carrotquest_sdk.android.presentation.entities

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.presentation.constans.PE

data class ConversationPresEnt(
        @SerializedName(PE.ID)
        val id: String,
        @SerializedName(PE.CREATED)
        val created: String,
        @SerializedName(PE.READ)
        val read: Boolean?,
        @SerializedName(PE.CLIKCKED)
        val clicked: Boolean?,
        @SerializedName(PE.UNSUBSCRIBED)
        val unsubscribed: Boolean?,
        @SerializedName(PE.CLOSED)
        val closed: Boolean?,
        @SerializedName(PE.MESSAGE)
        val message: Any?,
        @SerializedName(PE.TYPE)
        val type: String?,
        @SerializedName(PE.REPLY_TYPE)
        val replyType: String,
        @SerializedName(PE.PART_LAST)
        val partLast: MessageData,
        @SerializedName(PE.PARTS_COUNT)
        val partsCount: Int,
        @SerializedName(PE.ASSIGNEE)
        val assignee: Any?,
        @SerializedName(PE.UNREAD_PARTS_COUNT)
        val unreadPartsCount: Int,
        @SerializedName(PE.LAST_ADMIN)
        val lastAdmin: Admin?,
        @SerializedName(PE.LAST_UPDATE)
        val lastUpdate: String?,
        @SerializedName(PE.TAGS)
        val tags: List<Any>?
)