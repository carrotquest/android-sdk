package io.carrotquest_sdk.android.domain.entities.popup

enum class TypeBlockPopUp {
    TEXT,
    IMAGE,
    VIDEO,
    BUTTON,
    INPUT
}