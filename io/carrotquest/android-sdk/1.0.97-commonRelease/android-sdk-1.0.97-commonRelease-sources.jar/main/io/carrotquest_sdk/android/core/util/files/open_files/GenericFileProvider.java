package io.carrotquest_sdk.android.core.util.files.open_files;


import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
