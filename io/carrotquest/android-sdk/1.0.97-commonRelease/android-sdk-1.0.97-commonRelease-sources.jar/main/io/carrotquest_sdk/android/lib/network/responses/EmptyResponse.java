package io.carrotquest_sdk.android.lib.network.responses;

public class EmptyResponse {

}
