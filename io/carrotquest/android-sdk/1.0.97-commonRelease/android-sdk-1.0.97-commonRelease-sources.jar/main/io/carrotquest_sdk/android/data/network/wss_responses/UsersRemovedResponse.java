package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

import javax.inject.Inject;

import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;

public class UsersRemovedResponse implements IRtsMessage {
    @Inject
    UserRepository userRepository;

    @SerializedName("ids")
    @Expose
    private ArrayList<String> ids = null;

    public ArrayList<String> getIds() {
        return ids;
    }

    public void setIds(ArrayList<String> ids) {
        this.ids = ids;
    }


    @Override
    public void process() {
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        userRepository.removeUsers(ids);

    }
}
