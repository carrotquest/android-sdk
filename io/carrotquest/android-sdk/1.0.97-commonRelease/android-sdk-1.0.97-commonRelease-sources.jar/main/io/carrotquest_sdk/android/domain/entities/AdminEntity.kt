package io.carrotquest_sdk.android.domain.entities

data class AdminEntity(
        val id: String,
        val name: String?,
        val avatar: String?,
        val type: String?
)