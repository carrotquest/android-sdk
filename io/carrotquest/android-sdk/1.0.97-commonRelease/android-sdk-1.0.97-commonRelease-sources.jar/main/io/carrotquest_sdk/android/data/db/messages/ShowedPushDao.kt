package io.carrotquest_sdk.android.data.db.messages

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ShowedPushDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(message: ShowedPush)

    @Query("SELECT * FROM showedpush WHERE id = :idxxx")
    fun getById(idxxx: String): ShowedPush?

//    @Query("SELECT * FROM showedpush")
//    fun getAll(): List<ShowedPush>?
}