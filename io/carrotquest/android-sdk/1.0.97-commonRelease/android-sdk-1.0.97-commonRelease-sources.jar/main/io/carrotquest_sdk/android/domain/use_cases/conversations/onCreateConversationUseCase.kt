package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.reactivex.Observable

fun <T> Observable<T>.onCreateConversation() : Observable<DataConversation> {
    return Observable.defer {
        return@defer this.flatMap {
            ConversationsRepository.getInstance().getAddedConversation()
        }
    }
}