package io.carrotquest_sdk.android.lib.core

const val EU_BASE_URL = "https://api-eu.carrotquest.io/v1/"
const val EU_BASE_RTS_URL = "ws://realtime-services-eu.carrotquest.io/websocket/"