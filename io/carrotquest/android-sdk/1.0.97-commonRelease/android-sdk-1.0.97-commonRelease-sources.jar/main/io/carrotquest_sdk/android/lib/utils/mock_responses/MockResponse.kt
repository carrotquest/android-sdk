package io.carrotquest_sdk.android.lib.utils.mock_responses

import android.content.Context
import io.carrotquest_sdk.android.lib.utils.files.readFile
import okhttp3.mockwebserver.RecordedRequest

fun getStringJsonFromFile(request: RecordedRequest?, context: Context): String? {
    when {
        isFirebaseToken(request) -> {
            return readFile("network_files/djangousers_firebase_token_success.json", context)
        }
        isGetAppsList(request) -> {
            return readFile("network_files/apps_list.json", context)
        }
        isChangeAlert(request) -> {
            return readFile("network_files/change_alert.json", context)
        }
        isGetDialogsList(request) -> {
            return readFile("network_files/dialogs_list.json", context)
        }
        isCheckVersion(request) -> {
            return readFile("network_files/check_version.json", context)
        }
        else -> return null
    }
}