package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
@Keep
public class ReplyFileResponse {
    @SerializedName(F.META)
    private Meta meta;
    @SerializedName(F.DATA)
    private ReplyFileData data;

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public ReplyFileData getData() {
        return data;
    }

    public void setData(ReplyFileData data) {
        this.data = data;
    }
}
