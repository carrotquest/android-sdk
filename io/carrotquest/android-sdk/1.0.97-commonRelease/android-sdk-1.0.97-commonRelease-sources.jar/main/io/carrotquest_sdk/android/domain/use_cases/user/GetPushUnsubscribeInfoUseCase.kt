package io.carrotquest_sdk.android.domain.use_cases.user

import android.content.Context
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys

fun isPushNotificationsUnsubscribed(context: Context): Boolean {
    return SharedPreferencesLib.getBoolean(context, SharedPreferenceKeys.SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED)
}

fun isPushCampaignsUnsubscribed(context: Context): Boolean {
    return SharedPreferencesLib.getBoolean(context, SharedPreferenceKeys.SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED)
}