package io.carrotquest_sdk.android.presentation.mvp.popup.view

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.webkit.WebView
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

class PopUpWebView: CarrotWebView {
    private val loadingObserver = object : Observer<Boolean> {
        override fun onComplete() {

        }

        override fun onSubscribe(d: Disposable) {

        }

        override fun onNext(isLoading: Boolean) {
            if(isLoading) {
                hideLoading()
                hideLoadError()
            }
        }

        override fun onError(e: Throwable) {

        }

    }

    constructor(context: Context?): super(context)
    constructor(context: Context?, attrs: AttributeSet?): super(context, attrs)

    init {
        super.addLoadingObserver(loadingObserver)
        super.hideLoading()
        super.webView.isVerticalScrollBarEnabled = false
        super.webView.isVerticalFadingEdgeEnabled = false
        super.webView.setOnScrollChangeListener { _: WebView?, _: Int, _: Int, _: Int, _: Int ->
            run {

                Log.d("", "")
            }
        }
        super.webView.isScrollContainer = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            super.webView.requestFocus()
        }
    }

    override fun onOverScrolled(scrollX: Int, scrollY: Int, clampedX: Boolean, clampedY: Boolean) {
        super.onOverScrolled(scrollX, scrollY, clampedX, clampedY)
        Log.d("", "")
    }

}