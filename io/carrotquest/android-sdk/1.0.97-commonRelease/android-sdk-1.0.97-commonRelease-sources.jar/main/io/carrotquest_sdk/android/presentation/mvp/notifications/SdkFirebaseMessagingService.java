package io.carrotquest_sdk.android.presentation.mvp.notifications;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.di.SdkLibComponent;

public class SdkFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "SDk Firebase Cloud Messaging Service";

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        SdkLibComponent libComponent = CarrotInternal.getLibComponent();
        if (libComponent != null) {
            libComponent.getNotificationHelper().postNotification(remoteMessage.getData());
        }
    }
}
