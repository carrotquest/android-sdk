package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.Observable

fun <T> Observable<T>.clearHistory() : Observable<Boolean> {
    val tag = "Observable.getConversations()"
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(true)
                    .doOnNext {
                        ConversationsRepository.getInstance().clearConversations()
                        Log.d(tag, "clear History dialogs")
                    }

        }
    }
}