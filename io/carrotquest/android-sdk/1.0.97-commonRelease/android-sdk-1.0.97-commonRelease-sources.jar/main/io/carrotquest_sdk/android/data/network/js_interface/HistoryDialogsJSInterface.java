package io.carrotquest_sdk.android.data.network.js_interface;

import android.content.Context;
import android.webkit.JavascriptInterface;

import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView;

public class HistoryDialogsJSInterface extends BaseJsInterface implements JSInterface {

    private Context context;
    private IJsListPresenter presenter;

    public HistoryDialogsJSInterface(Context context, IJsListPresenter presenter, CarrotWebView webView) {
        super(webView);
        this.context = context;
        this.presenter = presenter;
    }

    /**
     * Када выбрали определенный диалог
     * @param conversationId Идентификатор этого определенного диалога
     */
    @JavascriptInterface
    public void selectConversation(final String conversationId) {
        if(presenter != null) {
            presenter.onSelectConversation(context, String.valueOf(conversationId));
            super.methodComplete("selectConversation");
        }
    }

    /**
     * Говорит о том, что надо загружать новые данные
     */
    @JavascriptInterface
    public void endList() {
        if(presenter != null) {
            presenter.paginationConversations();
            super.methodComplete("endList");
        }
    }

    /**
     * Говорит о том, что страница успешно полностью загрузилась
     */
    @JavascriptInterface
    public void iframeOnload() {
        if(presenter != null) {
            presenter.domUpdated();
            super.methodComplete("iframeOnload");
        }
    }
}
