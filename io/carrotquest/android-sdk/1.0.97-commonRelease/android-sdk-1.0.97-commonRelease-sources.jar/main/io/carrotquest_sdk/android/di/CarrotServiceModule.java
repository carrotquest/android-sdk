package io.carrotquest_sdk.android.di;

import android.content.Context;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.service.CarrotService;

import javax.inject.Singleton;

@Module(includes = ContextSdkModule.class)
public class CarrotServiceModule {
    private Context context;
    private String appId;
    private boolean isUseEuServers = false;
    public CarrotServiceModule(Context context, String appId, boolean useEuServers) {
        this.appId = appId;
        this.context = context;
        this.isUseEuServers = useEuServers;
    }

    @Provides
    @Singleton
    public CarrotService provideCarrotService() {
        return new CarrotService(context, appId, isUseEuServers);
    }
}
