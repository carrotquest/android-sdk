package io.carrotquest_sdk.android.presentation.mvp.calendly.view

import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView

interface ICalendlyView: IBaseView {
    fun initWebView()
    fun close()
    fun showError()
    fun showWidget(eventData: String)
    fun hideLoader()
}