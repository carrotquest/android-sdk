package io.carrotquest_sdk.android.core.constants;

public enum MessageStatus {
    LOADED,
    LOADING ,
    WARNING,
    NORMAL
}
