package io.carrotquest_sdk.android.lib.di;

import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.wss.WssService;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

@Module(includes = {ContextModule.class, RepositoryModule.class})
public class WssServiceModule {

    private boolean isUseEuServers = false;

    public WssServiceModule(boolean useEuServers) {
        this.isUseEuServers = useEuServers;
    }

    @Singleton
    @Provides
    public WssService provideWssService() {
        try {
            return new WssService(CarrotLib.getLibComponents().getContext(), isUseEuServers);
        }
        catch (Exception e) {
            return null;
        }
    }
}
