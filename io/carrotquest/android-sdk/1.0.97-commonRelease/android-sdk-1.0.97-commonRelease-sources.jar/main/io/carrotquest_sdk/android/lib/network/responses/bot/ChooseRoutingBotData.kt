package io.carrotquest_sdk.android.lib.network.responses.bot

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Data

@Keep
class ChooseRoutingBotData: Data() {
    @SerializedName(F.FOUND)
    var found: Boolean? = null

    @SerializedName(F.CHAT_BOT)
    var bot: ChatBotData? = null

    @SerializedName(F.MESSAGE_SENDER)
    var sender: Admin? = null
}