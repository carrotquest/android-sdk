package io.carrotquest_sdk.android.lib.wss;

import com.neovisionaries.ws.client.WebSocket;
import com.neovisionaries.ws.client.WebSocketException;
import com.neovisionaries.ws.client.WebSocketFactory;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.lib.utils.loging.Log;
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk;
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType;
import io.carrotquest_sdk.android.lib.wss.response.WssResponse;
import io.carrotquest_sdk.android.lib.wss.utils.CloseReason;
import io.carrotquest_sdk.android.lib.wss.utils.RtsUtilsKt;
import io.carrotquest_sdk.android.lib.wss.utils.SocketListener;
import io.carrotquest_sdk.android.lib.core.ConstantsKt;
import io.reactivex.Observer;

public class ClientWebSocket {

    private final String TAG = "ClientWebSocket";
    private final String appId;
    private final String authToken;
    private final List<Channel> channels;

    private WebSocket webSocket;
    private boolean isConnected = false;
    private final SocketListener socketListener;
    private boolean isUseEuServers = false;

    ClientWebSocket(String authToken, String appId, List<Channel> channels, List<Observer<WssResponse>> observers, boolean isUseEuServers) {
        this.authToken = authToken;
        this.appId = appId;
        this.channels = channels;

        this.isUseEuServers = isUseEuServers;

        socketListener = new SocketListener(appId);
        socketListener.setObservers(observers);
    }

    public void connect() {
        Log.Companion.d(TAG, "connect");
        new Thread(() -> {
            if (webSocket != null) {
                reconnect();
            } else {
                String strUrl = "";
                String baseUrl = BuildConfig.WSS_URL;
                if(this.isUseEuServers) {
                    baseUrl = ConstantsKt.EU_BASE_RTS_URL;
                }
                try {
                    strUrl = RtsUtilsKt.getRtsConnectUrl(baseUrl, appId, new ArrayList<>(channels), authToken);
                }catch (Exception e) {
                    Log.Companion.e(TAG, "connect error: " + e);
                }

                try {
                    WebSocketFactory factory = new WebSocketFactory();
                    webSocket = factory.createSocket(new URI(strUrl));
                    webSocket.addListener(socketListener);
                    webSocket.connect();
                    isConnected = true;

                    LogToElk.getInstance().write(appId, "Rts connect", MessageToElkType.RTS_CONNECT, new HashMap<>());
                } catch (WebSocketException e) {
                    isConnected = false;
                    Log.Companion.e(TAG, "WebSocketException: " + e.toString());

                    HashMap<String, Object> params = new HashMap<>();
                    params.put("web_socket_exception", e.toString());
                    LogToElk.getInstance().write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params);
                } catch (IOException e) {
                    isConnected = false;
                    Log.Companion.e(TAG, "IOException: " + e.toString());

                    HashMap<String, Object> params = new HashMap<>();
                    params.put("io_exception", e.toString());
                    LogToElk.getInstance().write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params);
                } catch (URISyntaxException e) {
                    isConnected = false;
                    Log.Companion.e(TAG, "URISyntaxException: " + e.toString());

                    HashMap<String, Object> params = new HashMap<>();
                    params.put("uri_syntax_exception", e.toString());
                    LogToElk.getInstance().write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params);
                } catch (Exception e) {
                    isConnected = false;
                    Log.Companion.e(TAG, "Just exception: " + e.toString());

                    HashMap<String, Object> params = new HashMap<>();
                    params.put("exception", e.toString());
                    LogToElk.getInstance().write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params);
                }
            }
        }).start();
    }

    private void reconnect() {
        close(CloseReason.RECONNECT);
        connect();
    }

    void close(CloseReason reason) {
        if (webSocket != null) {
            webSocket.disconnect();
            webSocket = null;

            if(reason != CloseReason.NONE) {
                HashMap<String, Object> params = new HashMap<>();
                params.put("reason", reason.name().toLowerCase());
                LogToElk.getInstance().write(appId, "Rts disconnect", MessageToElkType.RTS_DISCONNECT, params);
            }
        }
        isConnected = false;
    }

    boolean isConnected() {
        return isConnected;
    }

    String getAppId() {
        return appId;
    }
}