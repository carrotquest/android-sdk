package io.carrotquest_sdk.android.data.repositories.triggers

import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.db.triggers.TriggerDbEntity
import io.reactivex.Flowable
import io.reactivex.Observable

class TriggersRepository {

    companion object {
        private var instance: TriggersRepository? = null
        fun getInstance(): TriggersRepository {
            if (instance == null) {
                instance = TriggersRepository()
            }
            return instance!!
        }
    }

    fun loadTriggers(): Observable<Boolean> {
        return CarrotInternal.getService().carrotLib.triggers
            .onErrorReturn {
                val response = TriggersResponse()
                val meta = Meta()
                meta.status = 600
                meta.error = it.toString()
                response.setMeta(meta)

                return@onErrorReturn response
            }
            .flatMap { response ->
            if (response.getMeta()?.status == 200) {
                val data = response.getData()
                if (data != null) {
                    val trDao = CarrotInternal.getLibComponent().sdkDataBase.triggerDao()
                    trDao.deleteAll()

                    val dbList = data
                        .filter { t -> t.getKind() == 7 }
                        .map { t ->
                            return@map try {
                                TriggerDbEntity(
                                    id = t.getId() ?: "",
                                    kind = t.getKind() ?: -1,
                                    url = t.getUrl() ?: "",
                                    comparison = t.getComparison() ?: "",
                                )
                            } catch(e: Throwable) {
                                TriggerDbEntity(id = "", kind = 0, url = "", comparison = "" )
                            }
                        }

                    trDao.insert(dbList)
                }
            }

            return@flatMap Observable.just(response.getMeta()?.status == 200)
        }
    }

    fun getTriggers(): Flowable<List<TriggerDbEntity>> {
        return CarrotInternal.getLibComponent().sdkDataBase.triggerDao().getAll()
    }
}