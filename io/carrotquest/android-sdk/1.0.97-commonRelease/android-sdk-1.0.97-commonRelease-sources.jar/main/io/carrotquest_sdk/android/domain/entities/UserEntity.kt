package io.carrotquest_sdk.android.domain.entities

data class UserEntity(
        val id: String,
        val token: String,
        val hasConversations: Boolean = false,
        val isBanned: Boolean = false,
        val conversationsUnread: List<String> = ArrayList()
)