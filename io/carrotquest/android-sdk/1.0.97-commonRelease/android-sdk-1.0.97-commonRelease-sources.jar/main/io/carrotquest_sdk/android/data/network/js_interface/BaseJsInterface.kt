package io.carrotquest_sdk.android.data.network.js_interface

import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView

open class BaseJsInterface(private val webView: CarrotWebView) {
    fun methodComplete(methodName: String) {
        webView.executeJsInWebView("javascript:window.webView.methodComplete({method : \"$methodName\"})")
    }
}