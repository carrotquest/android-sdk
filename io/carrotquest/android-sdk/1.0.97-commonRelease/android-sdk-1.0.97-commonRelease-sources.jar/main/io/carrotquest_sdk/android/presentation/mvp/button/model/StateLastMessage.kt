package io.carrotquest_sdk.android.presentation.mvp.button.model

enum class StateLastMessage {
    HIDDEN,
    SHOW,
    CLOSED,
    UNKNOWN
}