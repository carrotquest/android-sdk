package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun getLastUpdateJwtTokenTime(): Long {
    val context = CarrotLib.getLibComponents().context
    return  SharedPreferencesLib.getLong(context, jwtTokenUpdateTimeStampKey)
}

fun getLastUpdateRefreshToken(): Long {
    val context = CarrotLib.getLibComponents().context
    return  SharedPreferencesLib.getLong(context, refreshTokenUpdateTimeStampKey)
}