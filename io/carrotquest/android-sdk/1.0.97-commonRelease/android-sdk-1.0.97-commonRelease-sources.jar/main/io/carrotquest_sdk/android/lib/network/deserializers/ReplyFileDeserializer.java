package io.carrotquest_sdk.android.lib.network.deserializers;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileData;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

import com.google.gson.*;

import java.lang.reflect.Type;

public class ReplyFileDeserializer  implements JsonDeserializer<ReplyFileResponse> {
    public ReplyFileDeserializer(){
    }

    @Override
    public ReplyFileResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ReplyFileResponse response = new ReplyFileResponse();


        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("ReplyFileDeserializer. meta is null or dataJsonElement is null");
        }

        JsonElement metaJsonElement = json.getAsJsonObject().get(F.META);
        JsonElement dataJsonElement = json.getAsJsonObject().get(F.DATA);

        if (metaJsonElement == null || dataJsonElement == null) {
            throw new JsonParseException("metaJsonElement == null or dataJsonElement == null");
        }

        try {
            Meta meta = new Gson().fromJson(metaJsonElement, Meta.class);
            response.setMeta(meta);

            ReplyFileData data = new ReplyFileData();
            if(GsonUtil.jsonElementNotNull(dataJsonElement.getAsJsonObject(), F.ID)) {
                data.setId(dataJsonElement.getAsJsonObject().get(F.ID).getAsString());
            }
            else {
                throw new JsonParseException("ID is null");
            }

            if(GsonUtil.jsonElementNotNull(dataJsonElement.getAsJsonObject(), F.ATTACHMENT)) {
                JsonObject joAttachment = dataJsonElement.getAsJsonObject().getAsJsonObject(F.ATTACHMENT);
                if (joAttachment != null) {
                    Attachment attachment = new Attachment();
                    if(GsonUtil.jsonElementNotNull(joAttachment, F.ID)) {
                        attachment.setId(joAttachment.get(F.ID).getAsString());
                    }
                    else {
                        throw new JsonParseException("Attachment ID is null");
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.TYPE)) {
                        attachment.setType(joAttachment.get(F.TYPE).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.FILENAME)) {
                        attachment.setFilename(joAttachment.get(F.FILENAME).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.CREATED)) {
                        attachment.setCreated(joAttachment.get(F.CREATED).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.MIME_TYPE)) {
                        attachment.setMimeType(joAttachment.get(F.MIME_TYPE).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.SIZE)) {
                        attachment.setSize(joAttachment.get(F.SIZE).getAsLong());
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.URL)) {
                        attachment.setUrl(joAttachment.get(F.URL).getAsString());
                    }

                    if(GsonUtil.jsonElementNotNull(joAttachment, F.STATUS)) {
                        attachment.setStatus(joAttachment.get(F.STATUS).getAsString());
                    }

                    data.setAttachment(attachment);
                }
            }



            response.setData(data);


            return response;
        }
        catch (JsonParseException je) {
            return new GsonBuilder().create().fromJson(json, ReplyFileResponse.class);
        }
    }
}
