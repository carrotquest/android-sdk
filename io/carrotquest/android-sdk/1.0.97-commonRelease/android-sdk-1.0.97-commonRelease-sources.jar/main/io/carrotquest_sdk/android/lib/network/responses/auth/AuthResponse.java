package io.carrotquest_sdk.android.lib.network.responses.auth;

import androidx.annotation.Keep;

import io.carrotquest_sdk.android.lib.network.responses.base.Data;
import io.carrotquest_sdk.android.lib.network.responses.base.IBaseResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
@Keep
public class AuthResponse implements IBaseResponse {

    private AuthData data;
    private Meta meta;

    @Override
    public AuthData getData() {
        return data;
    }

    @Override
    public Meta getMeta() {
        return meta;
    }

    @Override
    public void setData(Data data) {
        this.data = (AuthData)data;
    }

    @Override
    public void setMeta(Meta meta) {
        this.meta = meta;
    }
}
