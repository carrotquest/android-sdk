package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
@Keep
public class MessageMetaData {
    @SerializedName(F.VOTE)
    @Expose
    private Integer vote;

    @SerializedName(F.COMMENT)
    @Expose
    private String comment;

    @SerializedName(F.LOADING)
    @Expose
    private Boolean loading;

    @SerializedName(F.REPLIED)
    @Expose
    private Boolean replied;

    @SerializedName(F.CLOSED)
    @Expose
    private Boolean closed;

    @SerializedName(F.DURATION)
    @Expose
    private Integer duration;

    @SerializedName("answer_body")
    @Expose
    private String answerBody;
    @Expose
    @SerializedName("answer_action_id")
    private String answerActionId;
    @Expose
    @SerializedName("answer_time")
    private Long answerTime;

    public Integer getVote() {
        return vote;
    }

    public void setVote(Integer vote) {
        this.vote = vote;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getLoading() {
        return loading;
    }

    public void setLoading(Boolean loading) {
        this.loading = loading;
    }

    public Boolean getReplied() {
        return replied;
    }

    public void setReplied(Boolean replied) {
        this.replied = replied;
    }

    public Boolean getClosed() {
        return closed;
    }

    public void setClosed(Boolean closed) {
        this.closed = closed;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getAnswerBody() {
        return answerBody;
    }

    public void setAnswerBody(String answerBody) {
        this.answerBody = answerBody;
    }

    public String getAnswerActionId() {
        return answerActionId;
    }

    public void setAnswerActionId(String answerActionId) {
        this.answerActionId = answerActionId;
    }

    public Long getAnswerTime() {
        return answerTime;
    }

    public void setAnswerTime(Long answerTime) {
        this.answerTime = answerTime;
    }
}
