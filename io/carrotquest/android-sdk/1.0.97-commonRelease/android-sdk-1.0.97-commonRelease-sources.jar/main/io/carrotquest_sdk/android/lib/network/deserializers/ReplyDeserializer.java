package io.carrotquest_sdk.android.lib.network.deserializers;

import android.util.Log;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyData;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

import com.google.gson.*;

import java.lang.reflect.Type;

public class ReplyDeserializer implements JsonDeserializer<ReplyResponse> {

    private static final String TAG = "ReplyDeserializer";

    public ReplyDeserializer() {
    }

    @Override
    public ReplyResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ReplyResponse replyResponse = new ReplyResponse();

        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("ReplyDeserializer. meta is null or dataJsonElement is null");
        }

        JsonElement metaJsonElement = json.getAsJsonObject().get(F.META);
        JsonElement dataJsonElement = json.getAsJsonObject().get(F.DATA);

        if (metaJsonElement == null || dataJsonElement == null) {
            throw new JsonParseException("metaJsonElement == null or dataJsonElement == null");
        }

        try {
            Meta meta = new Gson().fromJson(metaJsonElement, Meta.class);
            ReplyData data = new ReplyData();
            if(dataJsonElement.getAsJsonObject().has(F.ID)) {
                data.setId(dataJsonElement.getAsJsonObject().get(F.ID).getAsString());
            }
            else {
                throw new JsonParseException("ID is null");
            }
            if(dataJsonElement.getAsJsonObject().has(F.ID_ASSIGN_PART)) {
                data.setIdAssignedPart(dataJsonElement.getAsJsonObject().get(F.ID_ASSIGN_PART).getAsString());
            }

            replyResponse.setMeta(meta);
            replyResponse.setData(data);

        } catch (Exception e) {
            Log.e(TAG, e.toString());

            replyResponse = new Gson().fromJson(json, ReplyResponse.class);
        }

        return replyResponse;
    }
}
