package io.carrotquest_sdk.android.domain.use_cases.bot

import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.reactivex.Observable

fun <T> Observable<T>.chooseRoutingBot(conversationId: String) : Observable<ChooseRoutingBotData?> {
    return Observable.defer {
        val cId = if(conversationId == "last_conversation") {
            ""
        } else {
            conversationId
        }
        return@defer this.flatMap {
            CarrotInternal.getService().carrotLib
                .chooseRoutingBot(cId).map { x ->
                    return@map x.data
                }.take(1)
        }.onErrorReturn {
            return@onErrorReturn ChooseRoutingBotData()
        }
    }
}

fun Observable<String>.getBotIdFromJson() : Observable<String?> {
    return Observable.defer {
        return@defer this.flatMap { sourceStr ->
            try {
                val chooseRoutingBotData: ChooseRoutingBotData? =
                    Gson().fromJson(sourceStr, ChooseRoutingBotData::class.java)
                return@flatMap Observable.just(chooseRoutingBotData?.bot?.id)
            } catch (e: Exception) {
                return@flatMap Observable.just(null)
            }
        }
    }
}