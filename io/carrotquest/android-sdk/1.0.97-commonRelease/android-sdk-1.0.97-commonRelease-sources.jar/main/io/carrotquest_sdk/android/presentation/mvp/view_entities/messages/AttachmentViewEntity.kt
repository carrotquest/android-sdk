package io.carrotquest_sdk.android.presentation.mvp.view_entities.messages

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F

data class AttachmentViewEntity (
        @SerializedName(F.TYPE)
        var type: String,
        @SerializedName(F.ID)
        var id: String,
        @SerializedName(F.FILENAME)
        var filename: String,
        @SerializedName(F.MIME_TYPE)
        var mimeType: String,
        @SerializedName(F.SIZE)
        var size: Long = 0,
        @SerializedName(F.URL)
        var url: String?,
        @SerializedName(F.CREATED)
        var created: String,
        @SerializedName(F.STATUS)
        var status: String?
)