package io.carrotquest_sdk.android.data.db.triggers

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import io.reactivex.Flowable

@Dao
interface TriggerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(triggers: List<TriggerDbEntity>)

    @Query("SELECT * FROM triggerdbentity")
    fun getAll(): Flowable<List<TriggerDbEntity>>

    @Query("DELETE FROM triggerdbentity")
    fun deleteAll()
}