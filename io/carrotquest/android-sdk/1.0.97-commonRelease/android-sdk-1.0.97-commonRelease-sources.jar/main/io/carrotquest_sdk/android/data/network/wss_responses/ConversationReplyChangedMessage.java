package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.repositories.MessagesRepository;

public class ConversationReplyChangedMessage extends MessageData implements IRtsMessage {

    public ConversationReplyChangedMessage(MessageData messageData) {
        this.setId(messageData.getId());
        this.setBody(messageData.getBody());
        this.setActions(messageData.getActions());
        this.setRandomId(messageData.getRandomId());
        this.setReplyType(messageData.getReplyType());
        this.setSentVia(messageData.getSentVia());
        this.setType(messageData.getType());
        this.setRead(messageData.getRead());
        this.setDirection(messageData.getDirection());
        this.setBodyJson(messageData.getBodyJson());
        this.setConversation(messageData.getConversation());
        this.setCreated(messageData.getCreated());
        this.setMessageMetaData(messageData.getMessageMetaData());
        this.setMessageFrom(messageData.getMessageFrom());
        this.setAttachments(messageData.getAttachments());
        this.setExpiraionTime(messageData.getExpiraionTime());
        this.setFirst(messageData.isFirst());
        this.setSourceJsonData(messageData.getSourceJsonData());
        this.setStatus(messageData.getStatus());
        this.setRemoved(messageData.getRemoved());
    }

    @Override
    public void process() {
        MessagesRepository.Companion.getInstance().updateMessage(this);
        DataConversation conversation = ConversationsRepository.Companion.getInstance().getConversationById(this.getConversation());
        if (conversation != null) {
            if (conversation.getPartLast().getId().equals(this.getId())) {
                conversation.setPartLast(this);
                JsonObject sourceConversation = conversation.getSourceJsonData();
                if(sourceConversation != null) {
                    sourceConversation.remove(F.PART_LAST);
                    String jsonPartLastString = this.getSourceJsonData().toString();
                    JsonObject jsonPartLast = new JsonParser().parse(jsonPartLastString).getAsJsonObject();
                    sourceConversation.add(F.PART_LAST, jsonPartLast);
                    conversation.setSourceJsonData(sourceConversation);
                }

                String conversationId = conversation.getId();
                if(conversationId != null) {
                    ConversationsRepository.Companion.getInstance().updateConversation(conversationId, conversation);
                }
            }
        }
    }
}