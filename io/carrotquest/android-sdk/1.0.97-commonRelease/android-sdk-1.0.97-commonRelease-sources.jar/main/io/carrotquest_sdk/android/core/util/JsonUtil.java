package io.carrotquest_sdk.android.core.util;

import java.util.Map;

public class JsonUtil {

    public static String createJsonParams(Map<String, String> params) {
        StringBuilder strParams = new StringBuilder();
        strParams.append("[{");
        int paramsSize = params.entrySet().size();
        int counter = 1;
        for (Map.Entry<String, String> pair : params.entrySet()) {
            strParams.append("\"");
            strParams.append(pair.getKey());
            strParams.append("\"");
            strParams.append(":");
            if (!pair.getKey().equals("created")) {
                strParams.append("\"");
            }
            strParams.append(pair.getValue());
            if (!pair.getKey().equals("created")) {
                strParams.append("\"");
            }

            if(counter < paramsSize) {
                strParams.append(", ");
            }
            counter++;
        }

        strParams.append("}]");

        return strParams.toString();
    }

    public static String createJsonParamsWithBool(Map<String, Boolean> params) {
        StringBuilder strParams = new StringBuilder();
        strParams.append("[{");
        int paramsSize = params.entrySet().size();
        int counter = 1;

        for (Map.Entry<String, Boolean> pair : params.entrySet()) {
            strParams.append("\"");
            strParams.append(pair.getKey());
            strParams.append("\"");
            strParams.append(":");
            strParams.append(pair.getValue());

            if(counter < paramsSize) {
                strParams.append(", ");
            }
            counter++;
        }

        strParams.append("}]");

        return strParams.toString();
    }

}
