package io.carrotquest_sdk.android.presentation.mvp.dialog.view;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.util.AttributeSet;
import android.util.Pair;

import io.reactivex.Observable;
import io.reactivex.Observer;

public class RootContainerForKeyboard extends ConstraintLayout {
    private Observer<Pair<Integer, Integer>> sizeObserver;

    public void setSizeObserver(Observer<Pair<Integer, Integer>> sizeObserver) {
        this.sizeObserver = sizeObserver;
    }

    public RootContainerForKeyboard(Context context) {
        super(context);
    }

    public RootContainerForKeyboard(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RootContainerForKeyboard(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w, h, oldW, oldH);
        if(sizeObserver != null) {
            Observable.just(new Pair<>(oldH, h)).subscribe(sizeObserver);
        }
    }
}
