package io.carrotquest_sdk.android.lib.models;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

public class UserPropertySerializer implements JsonSerializer<UserProperty> {
    @Override
    public JsonElement serialize(UserProperty src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject result = new JsonObject();
        return result;
    }
}
