package io.carrotquest_sdk.android.domain.entities

data class RoutingBotEntity(
    val needStartRoutingBot: Boolean,
    val sender: AdminEntity?,
    val startBrunchAsMessage: MessageEntity?
)