package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.reactivex.Observable

fun <T> Observable<T>.removeMessage(message: MessageData) : Observable<String> {
    return Observable.defer {
        this.flatMap {
            MessagesRepository.getInstance().removeMessage(message.id)
            Observable.just(message.id)
        }
    }
}