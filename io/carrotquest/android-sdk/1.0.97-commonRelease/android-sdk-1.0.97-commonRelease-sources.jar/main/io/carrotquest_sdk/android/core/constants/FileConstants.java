package io.carrotquest_sdk.android.core.constants;

public class FileConstants {
    public static final String DIRECTORY = "carrot_sdk";
}
