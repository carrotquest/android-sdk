package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.FailSendingMessage

fun getAllErrorMessages(): List<MessageData> {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    return db.failSendingMessageDao().all.map { message ->
        return@map mapMessage(message)
    }
}

fun getErrorMessages(conversationId: String): List<MessageData> {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    return db.failSendingMessageDao().getAllByConversationId(conversationId).map { message ->
        return@map mapMessage(message)
    }.toList()
}

private fun mapMessage(message: FailSendingMessage): MessageData {
    val failMessage = MessageData()

    failMessage.id = message.id
    failMessage.conversation = message.conversationId
    failMessage.body = message.body
    val from = Admin()
    from.id = message.messageFrom
    failMessage.messageFrom = from
    failMessage.created = message.created

    if (message.attachPath != null) {
        val attachments = ArrayList<Attachment>()
        val attachment = Attachment()
        attachment.url = message.attachPath
        attachments.add(attachment)
        failMessage.attachments = attachments
    }

    val bodyJson = failMessage.bodyJson
    if(bodyJson != null) {
        failMessage.bodyJson = Gson().toJsonTree(bodyJson)
    }
    failMessage.direction = message.direction
    failMessage.isFirst = message.first
    failMessage.randomId = message.randomId
    failMessage.read = message.read
    failMessage.replyType = message.replyType
    failMessage.sentVia = message.sentVia
    failMessage.status = message.status
    failMessage.type = message.type

    return failMessage;
}