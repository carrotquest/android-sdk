package io.carrotquest_sdk.android.di;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper;

@Module
public class NotificationHelperModule {
    @Provides
    @Singleton
    public PushNotificationHelper provideNotificationHelper() {
        return PushNotificationHelper.getInstance();
    }
}
