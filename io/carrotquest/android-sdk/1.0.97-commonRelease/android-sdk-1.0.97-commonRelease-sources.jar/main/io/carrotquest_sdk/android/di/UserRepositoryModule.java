package io.carrotquest_sdk.android.di;

import android.content.Context;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;

import javax.inject.Singleton;

@Module(includes = ContextSdkModule.class)
public class UserRepositoryModule {
    @Provides
    @Singleton
    UserRepository getUserRepository(Context context){return new UserRepository(context);}
}
