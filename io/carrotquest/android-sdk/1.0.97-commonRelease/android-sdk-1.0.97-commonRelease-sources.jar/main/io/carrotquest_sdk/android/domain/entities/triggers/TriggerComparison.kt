package io.carrotquest_sdk.android.domain.entities.triggers

enum class TriggerComparison {
    Eq,
    Contains,
    Neq,
    NotContains,
    Uncnown,
}