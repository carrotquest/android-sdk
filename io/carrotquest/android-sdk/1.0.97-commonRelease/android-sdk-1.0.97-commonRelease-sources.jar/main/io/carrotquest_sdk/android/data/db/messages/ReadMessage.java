package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;


@Entity
public class ReadMessage {
    @NonNull
    @PrimaryKey
    public String id;

    public ReadMessage(@NonNull String id) {
        this.id = id;
    }
}
