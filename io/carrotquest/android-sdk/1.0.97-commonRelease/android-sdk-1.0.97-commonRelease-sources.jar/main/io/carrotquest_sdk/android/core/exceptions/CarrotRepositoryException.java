package io.carrotquest_sdk.android.core.exceptions;

public class CarrotRepositoryException extends CarrotException {
    public CarrotRepositoryException(String message) {
        super(message);
    }
}
