package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import io.reactivex.Single;

@Dao
public interface  ClosedMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ClosedMessage message);

    @Query("SELECT * FROM closedmessage WHERE id = :identifier")
    Single<ClosedMessage> getById(String identifier);

    @Query("SELECT * FROM closedmessage")
    List<ClosedMessage> getAll();

    @Query("DELETE FROM closedmessage WHERE id NOT IN (SELECT id from closedmessage ORDER BY id DESC LIMIT 20)")
    void clear();

}
