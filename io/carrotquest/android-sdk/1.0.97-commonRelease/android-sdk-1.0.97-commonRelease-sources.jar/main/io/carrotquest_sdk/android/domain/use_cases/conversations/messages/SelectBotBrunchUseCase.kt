package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.reactivex.Observable
import org.json.JSONObject

fun <T> Observable<T>.selectBotBrunch(messageId: String, actionId: String, actionBody: String) : Observable<Boolean> {
    return Observable.defer {
        return@defer this.flatMap {
            val metaDataJson = JSONObject()
            metaDataJson.put("answer_action_id", actionId)
            metaDataJson.put("answer_body", actionBody)

            CarrotInternal.getService().carrotLib.setMetaData(messageId, metaDataJson.toString())
                    .map { x -> x.status == 200 }
                    .doOnError {
                        Log.Companion.e("", it)
                    }
        }
    }
}