package io.carrotquest_sdk.android.models;

import com.google.gson.annotations.SerializedName;

public class UserProperty {
    private static final String TAG = "UserProperty";
    public enum Operation {
        @SerializedName("update_or_create") UPDATE_OR_CREATE,
        @SerializedName("set_once")SET_ONCE,
        @SerializedName("add")ADD,
        @SerializedName("delete")DELETE,
        @SerializedName("append")APPEND,
        @SerializedName("union")UNION,
        @SerializedName("exclude")EXCLUDE
    }
    @SerializedName("op")
    public String operation;
    private String key;
    private String value;

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public UserProperty(String key, String value) {
        this(Operation.UPDATE_OR_CREATE, key, value);
    }

    public UserProperty(Operation operation, String key, String value) {
        switch (operation) {
            case ADD:
                this.operation = "add";
                break;
            case UNION:
                this.operation = "union";
                break;
            case APPEND:
                this.operation = "append";
                break;
            case UPDATE_OR_CREATE:
                this.operation = "update_or_create";
                break;
            case DELETE:
                this.operation = "delete";
                break;
            case EXCLUDE:
                this.operation = "exclude";
                break;
            case SET_ONCE:
                this.operation = "set_once";
                break;
        }

        this.key = key;
        this.value = value;
    }
}
