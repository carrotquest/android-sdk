package io.carrotquest_sdk.android.lib.network.responses.triggers

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
@Keep
class TriggersResponse {
    @SerializedName(F.DATA)
    @Expose
    private var data: List<Trigger>? = null

    @SerializedName(F.META)
    @Expose
    private var meta: Meta? = null

    fun getData(): List<Trigger>? {
        return data
    }

    fun getMeta(): Meta? {
        return meta
    }

    fun setData(data: List<Trigger>) {
        //if (data is TriggersData) {
            this.data = data
        //}
    }

    fun setMeta(meta: Meta?) {
        this.meta = meta
    }
}