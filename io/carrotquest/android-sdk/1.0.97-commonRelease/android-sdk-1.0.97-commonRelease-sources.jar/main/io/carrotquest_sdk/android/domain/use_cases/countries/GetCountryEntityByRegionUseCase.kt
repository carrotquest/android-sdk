package io.carrotquest_sdk.android.domain.use_cases.countries

import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import java.util.Locale

fun getCountryEntityByRegion(region: String, phoneNumberUtil: PhoneNumberUtil): CountryEntity {
    val locale = Locale("", region)
    val countryName = locale.displayCountry
    val regionCode = phoneNumberUtil.getCountryCodeForRegion(region.uppercase())

    return CountryEntity(
        name = countryName,
        flag = getEmoji(region),
        region = region,
        regionCode = regionCode,
    )
}