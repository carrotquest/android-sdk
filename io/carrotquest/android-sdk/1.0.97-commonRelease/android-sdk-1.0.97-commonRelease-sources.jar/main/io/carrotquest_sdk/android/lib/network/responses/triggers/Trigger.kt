package io.carrotquest_sdk.android.lib.network.responses.triggers

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Data
@Keep
class Trigger: Data() {
    @SerializedName(F.ID)
    @Expose
    private var id: String? = null

    @SerializedName(F.KIND)
    @Expose
    private var kind: Int? = null


    private var url: String? = null
    private var comparison: String? = null

    fun getId(): String? {
        return this.id
    }

    fun setId(id: String) {
        this.id = id
    }

    fun getKind(): Int? {
        return this.kind
    }

    fun setKind(kind: Int) {
        this.kind = kind
    }


    fun getUrl(): String? {
        return this.url
    }

    fun setUrl(url: String) {
        this.url = url
    }

    fun getComparison(): String? {
        return this.comparison
    }

    fun setComparison(comparison: String) {
        this.comparison = comparison
    }

}