package io.carrotquest_sdk.android.core.util;

import android.content.Context;
import android.content.pm.PackageManager;

public class ExternalAppsUtil {
    /**
     * Возвращает флаг доступности прирложения на устройстве
     * @param appName Название приложения
     * @return Доступность
     */
    public static boolean isAppAvailable(Context context, String appName)
    {
        PackageManager pm = context.getPackageManager();
        try
        {
            pm.getPackageInfo(appName, PackageManager.GET_ACTIVITIES);
            return true;
        }
        catch (PackageManager.NameNotFoundException e)
        {
            return false;
        }
    }
}
