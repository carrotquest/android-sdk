package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.result.contract.ActivityResultContract
import androidx.appcompat.app.AppCompatActivity
import io.carrotquest_sdk.android.presentation.entities.CountryEntity

class SelectCountryContract: ActivityResultContract<String, CountryEntity?>() {
    override fun createIntent(context: Context, input: String): Intent {
        return Intent(context, CountriesBottomSheetSdkActivity::class.java)
    }

    override fun parseResult(resultCode: Int, intent: Intent?): CountryEntity? {
        val selectedCountry = when {
            resultCode != AppCompatActivity.RESULT_OK -> null
            else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getSerializableExtra("SELECTED_COUNTRY", CountryEntity::class.java)
            } else {
                intent?.getSerializableExtra("SELECTED_COUNTRY") as CountryEntity
            }
        }

        return selectedCountry
    }
}