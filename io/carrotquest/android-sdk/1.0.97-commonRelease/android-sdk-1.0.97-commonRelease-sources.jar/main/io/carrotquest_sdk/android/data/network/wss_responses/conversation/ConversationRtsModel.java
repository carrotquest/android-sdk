package io.carrotquest_sdk.android.data.network.wss_responses.conversation;

import androidx.annotation.Keep;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.core.constants.ConversationType;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.core.util.ConversationUtilsKt;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.network.PopUpDeserializer;
import io.carrotquest_sdk.android.data.network.wss_responses.IRtsMessage;
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.repositories.MessagesRepository;
import io.carrotquest_sdk.android.domain.entities.SettingsEntity;
import io.carrotquest_sdk.android.domain.use_cases.popup.IncomingPopUpUseCaseKt;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;

@Keep
public class ConversationRtsModel {

    @SerializedName(ResponseFields.ID)
    public String id;


    @SerializedName(ResponseFields.CREATED)
    @Expose
    public String created;
    @SerializedName(ResponseFields.LAST_ADMIN)
    @Expose
    public Admin lastAdmin;
    @SerializedName(ResponseFields.LAST_UPDATE)
    @Expose
    public String lastUpdate;
    @SerializedName(ResponseFields.PART_LAST)
    @Expose
    public MessageData partLast;
    @SerializedName(ResponseFields.PARTS_COUNT)
    @Expose
    public Integer partsCount;
    @SerializedName(ResponseFields.REPLY_TYPE)
    @Expose
    public String replyType;
    @SerializedName(ResponseFields.TYPE)
    @Expose
    public String type;
    @SerializedName(ResponseFields.UNREAD_PARTS_COUNT)
    @Expose
    public Integer unreadPartsCount;
    @SerializedName(F.EXPIRATION_TIME)
    @Expose
    public Long expirationTime;
    @SerializedName(F.RECIPIENT_TYPE)
    private String recipientType;

    public JsonObject sourceConversation;


    public void process(ArrayList<MessageData> parts) {
        MessagesRepository.Companion.getInstance().addMessages(parts, false);
        for(MessageData m : parts){
            if(!isPopupSdk() && (m.getActions() == null || m.getActions().isEmpty())) {
                MessagesRepository.Companion.getInstance().addWssMessage(m);
            }
        }

        Disposable d = io.carrotquest_sdk.android.data.repositories.SettingsRepository
                .Companion
                .getInstance()
                .getSettings()
                .take(1)
                .doOnError(t -> {
                    Log.e("ConversationRtsModel", "Error: " + t );
                })
                .subscribe(settingsEntity -> {
                    if (isChat()) {
                        onNewChatConversation(settingsEntity);
                    } else if (isPopupSdk()) {
                        onNewPopup();
                    } else if(isBot()) {
                        onAnswerBot();
                    }
                });
    }

    public void updateConversationSource(JsonElement jsonElement) {
        if(jsonElement.isJsonObject()) {
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            if(jsonObject.has(F.CONVERSATION)) {
                this.sourceConversation = jsonObject.get(F.CONVERSATION).getAsJsonObject();
            } else {
                this.sourceConversation = jsonElement.getAsJsonObject();
            }
        }
    }

    private void onNewChatConversation(SettingsEntity settingsEntity) {
        boolean showKb = settingsEntity.getShowLinkKbAtWelcomeMessage();
        DataConversation conversationEntity = convertToConversationEntity(this, showKb);
        conversationEntity.setSourceJsonData(sourceConversation);
        ConversationsRepository.Companion.getInstance().addConversation(conversationEntity);

        if (conversationEntity.getPartLast() != null) {
            MessagesRepository.Companion.getInstance().addMessage(conversationEntity.getPartLast());
        }
    }

    private void onNewPopup() {
        PopUpMessage popUpMessage = convertToPopupEntity(this);
        if (popUpMessage != null) {
            IncomingPopUpUseCaseKt
                    .saveNewPopUp(Observable.just(popUpMessage))
                    .subscribe();

            DataConversation conversationEntity = convertToConversationEntity(this, false);
            ConversationsRepository.Companion.getInstance().addConversation(conversationEntity);
        }
    }

    private void onAnswerBot() {
        DataConversation conversationEntity = convertToConversationEntity(this, false);
        ConversationsRepository.Companion.getInstance().addConversation(conversationEntity);

    }

    private PopUpMessage convertToPopupEntity(ConversationRtsModel sourceModel) {
        MessageData messageData = sourceModel.partLast;
        if (messageData != null) {
            JsonObject jsonBody = messageData.getBodyJson().getAsJsonObject();
            if (jsonBody != null) {
                jsonBody.addProperty("id", sourceModel.id);
                jsonBody.addProperty("expiration_time", sourceModel.expirationTime);
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(PopUpMessage.class, new PopUpDeserializer())
                        .create();

                PopUpMessage popUp = gson.fromJson(jsonBody, PopUpMessage.class);

                return popUp;
            }
        }

        return null;
    }

    private boolean isChat() {
        return ConversationType.CHAT.getStringValue().equals(type) && recipientType != null && ConversationUtilsKt.recipientTypeIsRight(recipientType);
    }

    private boolean isPopupSdk() {
        return ConversationType.BLOCK_POPUP_SMALL.getStringValue().equals(type) && recipientType != null && ConversationUtilsKt.recipientTypeIsRight(recipientType);
    }

    private boolean isBot() {
        return (ConversationType.ROUTING_BOT.getStringValue().equals(type) || ConversationType.LEAD_BOT.getStringValue().equals(type)) && recipientType != null && ConversationUtilsKt.recipientTypeIsRight(recipientType);
    }

    public String getRecipientType() {
        return recipientType;
    }

    private DataConversation convertToConversationEntity(ConversationRtsModel sourceModel, boolean showKb) {
        DataConversation model = new DataConversation();

        sourceModel.partLast.setExpiraionTime(this.expirationTime);

        model.setId(sourceModel.id);
        model.setCreated(sourceModel.created);
        model.setRead(false);
        model.setId(sourceModel.id);
        model.setClicked(true);
        model.setUnsubscribed(false);
        model.setClosed(false);
        model.setMessage(null);
        model.setId(sourceModel.id);
        model.setType(sourceModel.type);
        model.setReplyType(sourceModel.replyType);
        model.setPartLast(sourceModel.partLast);
        model.setPartsCount(sourceModel.partsCount);
        model.setAssignee(null);
        model.setUnreadPartsCount(sourceModel.unreadPartsCount);
        model.setLastAdmin(sourceModel.lastAdmin);
        model.setLastUpdate(sourceModel.lastUpdate);
        model.setTags(null);
        model.setRecipientType(sourceModel.recipientType);
        model.setSourceJsonData(this.sourceConversation);

        return model;
    }
}