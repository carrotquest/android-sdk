package io.carrotquest_sdk.android.core.constants;

public class Flags {
    public static final String NEW_CONVERSATION_ID_ARG = "NEW_CONVERSATION_ID_ARG";
}
