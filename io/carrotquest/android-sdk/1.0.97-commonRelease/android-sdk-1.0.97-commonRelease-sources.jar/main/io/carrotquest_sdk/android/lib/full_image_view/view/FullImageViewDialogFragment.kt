package io.carrotquest_sdk.android.lib.full_image_view.view

import android.Manifest
import android.animation.Animator
import android.animation.ValueAnimator
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.DialogFragment
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.github.chrisbanes.photoview.PhotoView
import com.google.android.material.snackbar.Snackbar
import com.vanniktech.rxpermission.Permission
import com.vanniktech.rxpermission.RealRxPermission
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback
import io.carrotquest_sdk.android.lib.view.full_image_view.presenter.FullImageViewPresenter
import java.io.File

class FullImageViewDialogFragment : DialogFragment() {
    private var presenter: FullImageViewPresenter? = null
    private var isHideControls = false
    private var loadProgressBar: ProgressBar? = null
    private var backImageButton: ImageButton? = null
    private var errorContainer: LinearLayout? = null
    private var fullImageView: PhotoView? = null
    private var controlsTopContainer: ConstraintLayout? = null
    private var controlsBottomContainer: ConstraintLayout? = null
    private var mainContainer: ConstraintLayout? = null
    private var shareImageButton: ImageButton? = null
    private var saveImageButton: ImageButton? = null

    private var contentUri: Uri? = null

    companion object {
        private const val URL_IMAGE = "url_image_for_full_view"
        private const val FILE_PATH = "file_path_for_full_view"
        private const val BITMAP = "bitmap_for_full_view"

        fun newInstance(url: String): FullImageViewDialogFragment {
            val fragment = FullImageViewDialogFragment()
            fragment.setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            val args = Bundle()
            args.putString(URL_IMAGE, url)
            fragment.arguments = args

            return fragment
        }

        fun newInstance(file: File): FullImageViewDialogFragment {
            val fragment = FullImageViewDialogFragment()
            fragment.setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            val args = Bundle()
            args.putString(FILE_PATH, file.path)
            fragment.arguments = args

            return fragment
        }

        fun newInstance(bitmap: Bitmap): FullImageViewDialogFragment {
            val fragment = FullImageViewDialogFragment()
            fragment.setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            val args = Bundle()
            args.putParcelable(BITMAP, bitmap)
            fragment.arguments = args

            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.full_image_view_layout, null)
        init(v)
        return v
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setWindowAnimations(R.style.DialogAnimationFade)
    }

    private fun init(view: View) {
        presenter = FullImageViewPresenter()
        presenter!!.attachView(this)

        loadProgressBar = view.findViewById(R.id.load_image_pb)
        errorContainer = view.findViewById(R.id.error_container)
        fullImageView = view.findViewById(R.id.full_image_view)
        controlsTopContainer = view.findViewById(R.id.controls_top_container)
        controlsBottomContainer = view.findViewById(R.id.controls_bottom_container)
        mainContainer = view.findViewById(R.id.full_image_main_container)

        backImageButton = view.findViewById(R.id.back_image_button)
        backImageButton?.setOnClickListener { _ -> dismiss() }

        shareImageButton = view.findViewById(R.id.share_image_button)
        shareImageButton?.setOnClickListener {
            run {
                if (contentUri != null) {
                    presenter?.onTapShareImage(requireContext())
                }
            }
        }

        saveImageButton = view.findViewById(R.id.save_image_button)
        saveImageButton?.setOnClickListener { _ ->
            run {
                if (contentUri != null && activity != null) {
                    val rxPermission = RealRxPermission.getInstance(context)
                    rxPermission.request(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .subscribe { _: Permission? ->
                            presenter?.onTapSaveImage(requireActivity().contentResolver, object :
                                SaveImageCallback {
                                override fun done() {
                                    showSaveSuccess()
                                }

                                override fun fail() {
                                    showSaveError()
                                }
                            })
                        }
                }
            }
        }

        val args = arguments
        if (args != null) {
            if (args.getString(URL_IMAGE) != null) {
                val strUrl = args.getString(URL_IMAGE) ?: ""
                presenter?.onStart(strUrl)
            } else if (args.getString(FILE_PATH) != null) {
                val filePath = args.getString(FILE_PATH) ?: ""
                val file = File(filePath)
                presenter?.onStart(file)
            } else if(args.getParcelable<Bitmap>(BITMAP) != null) {
                val bitmap = args.getParcelable<Bitmap>(BITMAP)
                presenter?.onStart(bitmap)
            }
        } else {
            showError()
        }
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)

        if (presenter != null) {
            presenter?.detachView()
            presenter = null
        }
    }

    fun showImage(imageUrl: String) {
        fullImageView?.setOnPhotoTapListener { _, _, _ -> presenter!!.onImageTap(isHideControls) }
        errorContainer?.visibility = View.GONE

        Glide.with(this)
            .load(Uri.parse(imageUrl))
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    loadProgressBar?.visibility = View.GONE
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    loadProgressBar?.visibility = View.GONE

                    if (resource != null && context != null) {
                        presenter?.onLoadResource(resource, context!!)
                    }

                    return false
                }

            })
            .into(fullImageView!!)
    }

    fun showImage(file: File) {
        fullImageView?.setOnPhotoTapListener { _, _, _ -> presenter!!.onImageTap(isHideControls) }
        errorContainer?.visibility = View.GONE

        Glide.with(this)
            .load(file)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    loadProgressBar?.visibility = View.GONE
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    loadProgressBar?.visibility = View.GONE

                    if (resource != null && context != null) {
                        presenter?.onLoadResource(resource, context!!)
                    }
                    
                    return false
                }

            })
            .into(fullImageView!!)
    }

    fun showImage(bitmap: Bitmap) {
        fullImageView?.setOnPhotoTapListener { _, _, _ -> presenter!!.onImageTap(isHideControls) }
        errorContainer?.visibility = View.GONE

        Glide.with(this)
                .load(bitmap)
                .listener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Drawable>?,
                            isFirstResource: Boolean
                    ): Boolean {
                        loadProgressBar?.visibility = View.GONE
                        return false
                    }

                    override fun onResourceReady(
                            resource: Drawable?,
                            model: Any?,
                            target: Target<Drawable>?,
                            dataSource: DataSource?,
                            isFirstResource: Boolean
                    ): Boolean {
                        loadProgressBar?.visibility = View.GONE

                        if (resource != null && context != null) {
                            presenter?.onLoadResource(resource, context!!)
                        }

                        return false
                    }

                })
                .into(fullImageView!!)
    }

    fun showError() {
        errorContainer?.visibility = View.VISIBLE
    }

    fun showControls() {
        val animator = ValueAnimator.ofFloat(0.0f, 1.0f)
        animator.duration = 400
        animator.addUpdateListener { animation ->
            run {
                controlsTopContainer?.alpha = animation.animatedValue as Float
                controlsBottomContainer?.alpha = animation.animatedValue as Float
            }
        }
        animator.addListener(object : Animator.AnimatorListener {
            override fun onAnimationRepeat(animation: Animator) {

            }

            override fun onAnimationEnd(animation: Animator) {

            }

            override fun onAnimationCancel(animation: Animator) {

            }

            override fun onAnimationStart(animation: Animator) {
                controlsTopContainer?.alpha = 0.0f
                controlsTopContainer?.visibility = View.VISIBLE
                controlsBottomContainer?.alpha = 0.0f
                controlsBottomContainer?.visibility = View.VISIBLE

                isHideControls = false
            }
        })
        animator.start()
    }

    fun hideControls() {
        val animator = ValueAnimator.ofFloat(1.0f, 0.0f)
        animator.duration = 200
        animator.addUpdateListener { animation ->
            run {
                controlsTopContainer?.alpha = animation.animatedValue as Float
                controlsBottomContainer?.alpha = animation.animatedValue as Float
            }
        }
        animator.addListener(object : Animator.AnimatorListener {
            override fun onAnimationRepeat(animation: Animator) {

            }

            override fun onAnimationEnd(animation: Animator) {
                controlsTopContainer?.visibility = View.GONE
                controlsBottomContainer?.visibility = View.GONE
            }

            override fun onAnimationCancel(animation: Animator) {

            }

            override fun onAnimationStart(animation: Animator) {
                isHideControls = true
            }
        })
        animator.start()
    }

    fun openShareInterface(shareIntent: Intent) {
        startActivity(
            Intent.createChooser(
                shareIntent,
                getString(R.string.cq_lib_share_intent_title)
            )
        )
    }

    fun updateContentUri(contentUri: Uri) {
        this.contentUri = contentUri
        enabledBottomContainer()
    }

    private fun enabledBottomContainer() {
        saveImageButton?.isClickable = true
        shareImageButton?.isClickable = true
    }

    private fun showSaveError() {
        if(this.view != null) {
            Snackbar.make(this.requireView(), getString(R.string.cq_lib_something_wrong), Snackbar.LENGTH_LONG).show()
        }
    }

    private fun showSaveSuccess() {
        if(this.view != null) {
            Snackbar.make(this.requireView(), getString(R.string.cq_lib_save_success), Snackbar.LENGTH_LONG).show()
        }
    }
}