package io.carrotquest_sdk.android.domain.use_cases.settings

import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.reactivex.Observable

fun <T> Observable<T>.changeStatusOperators(status: StatusOperators) : Observable<T> {
    return Observable.defer {
        return@defer this.flatMap {
            SettingsRepository.getInstance().getSettings()
                    .take(1)
                    .doOnNext {settings->
                        if(settings != null) {
                            val updatedSettings = SettingsEntity(
                                    userId = settings.userId,
                                    isShowVK = settings.isShowVK,
                                    textLinkVK = settings.textLinkVK,
                                    isShowViber = settings.isShowViber,
                                    textLinkViber = settings.textLinkViber,
                                    isShowFB = settings.isShowFB,
                                    textLinkFB = settings.textLinkFB,
                                    isShowTelegram = settings.isShowTelegram,
                                    textLinkTelegram = settings.textLinkTelegram,
                                isShowInstagram = settings.isShowInstagram,
                                textLinkInstagram = settings.textLinkInstagram,
                                isShowWhatsapp = settings.isShowWhatsapp,
                                textLinkWhatsapp = settings.textLinkWhatsapp,
                                appColor = settings.appColor,
                                welcomeMessage = settings.welcomeMessage,
                                messengerAvatar = settings.messengerAvatar,
                                showPoweredBy = settings.showPoweredBy,
                                sourceData = settings.sourceData,
                                appName = settings.appName,
                                appId = settings.appId,
                                statusOperators = status,
                                onlineMessage = settings.onlineMessage,
                                offlineMessage = settings.offlineMessage,
                                admins = settings.admins,
                                theme = settings.theme,
                                locale = settings.locale
                            )

                            SettingsRepository.getInstance().saveSettings(updatedSettings)
                        }
                    }
                    .subscribe()

            Observable.just(it)
        }
    }
}