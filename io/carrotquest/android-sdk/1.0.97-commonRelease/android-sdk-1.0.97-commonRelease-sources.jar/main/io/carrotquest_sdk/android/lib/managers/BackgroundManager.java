package io.carrotquest_sdk.android.lib.managers;

import android.util.Log;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;

public class BackgroundManager implements IStateManager {
    private BehaviorSubject<Boolean> changeStateBehavior;
    private ForegroundBackgroundListener foregroundBackgroundListener;
    private CompositeDisposable compositeDisposable;

    private boolean lastStateIsForeground = false;

    private static BackgroundManager instance;

    public static BackgroundManager getInstance() {
        if (instance == null) {
            instance = new BackgroundManager();
        }
        return instance;
    }

    private BackgroundManager() {
        compositeDisposable = new CompositeDisposable();
        changeStateBehavior = BehaviorSubject.create();
        foregroundBackgroundListener = new ForegroundBackgroundListener();

    }

    @Override
    public void addObserver(Consumer<Boolean> observer, Consumer<Throwable> errorConsumer, Action complete) {
        try {
            compositeDisposable.add(changeStateBehavior.subscribe(observer, errorConsumer, complete));
            ProcessLifecycleOwner.get().getLifecycle().addObserver(foregroundBackgroundListener);
        } catch (Exception e) {
            Log.e("", e.toString());
        }
    }

    @Override
    public void deInit() {
        ProcessLifecycleOwner.get().getLifecycle().removeObserver(foregroundBackgroundListener);
        changeStateBehavior.onComplete();
        compositeDisposable.dispose();
        instance = null;
    }

    public boolean lastStateIsForeground() {
        return lastStateIsForeground;
    }

    private class ForegroundBackgroundListener implements LifecycleObserver {

        @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
        void onResume() {
            lastStateIsForeground = true;
            changeStateBehavior.onNext(true);
        }

        @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        void onPause() {
            lastStateIsForeground = false;
            changeStateBehavior.onNext(false);
        }
    }
}
