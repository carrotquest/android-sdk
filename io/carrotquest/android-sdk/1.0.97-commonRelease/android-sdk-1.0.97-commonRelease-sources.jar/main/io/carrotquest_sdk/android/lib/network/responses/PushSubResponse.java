package io.carrotquest_sdk.android.lib.network.responses;

import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;

public class PushSubResponse extends NetworkResponse {
    public PushSubResponse(String error) {
        super(error);
    }
}
