package io.carrotquest_sdk.android.lib.network.responses.connect;

import androidx.annotation.Keep;

import io.carrotquest_sdk.android.lib.network.responses.base.Data;
import io.carrotquest_sdk.android.lib.network.responses.base.IBaseResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
@Keep
public class ConnectResponse implements IBaseResponse {
    private DataConnect data;
    private Meta meta;

    private String sourceData;



    @Override
    public DataConnect getData() {
        return data;
    }

    @Override
    public Meta getMeta() {
        return meta;
    }

    @Override
    public void setData(Data data) {
        this.data = (DataConnect) data;
    }

    @Override
    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public void setSourceData(String sourceData) {
        this.sourceData = sourceData;
    }

    public String getSourceData() {
        return sourceData;
    }
}
