package io.carrotquest_sdk.android.presentation.mvp.dialog.model


class DialogViewModel {
    companion object {
        private var instance: DialogViewModel? = null
        fun getInstance(): DialogViewModel {
            if (instance == null) {
                instance = DialogViewModel()
            }
            return instance!!
        }
    }

    private var currentConversationId: String = ""
    private var needStartRoutingBot = false
    private var botId: String = ""
    private var firstMessageTime: String? = null

    fun updateCurrentConversationId(id: String) {
        this.currentConversationId = id
    }

    fun getCurrentConversationId() = this.currentConversationId
    
    private var currentStateAppBar: StateAppBar = StateAppBar.EXPANDED
    
    fun updateCurrentStateAppBar(state: StateAppBar) {
        this.currentStateAppBar = state
    }
    
    fun getCurrentStateAppBar() = this.currentStateAppBar

    fun needStartRoutingBot() = this.needStartRoutingBot

    fun setNeedStartRoutingBot(needStartRoutingBot: Boolean) {
        println("start_routing_bot setNeedStartRoutingBot $needStartRoutingBot")
        this.needStartRoutingBot = needStartRoutingBot
    }

    fun setRoutingBotId(botId: String) {
        this.botId = botId
    }

    fun getRoutingBotId() = this.botId
}