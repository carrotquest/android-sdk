package io.carrotquest_sdk.android.lib.network.responses.refresh

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta

@Keep
data class RefreshResponse(
    @SerializedName(F.META)
    val meta: Meta,
    @SerializedName(F.DATA)
    val data: RefreshData
)