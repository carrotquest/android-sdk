package io.carrotquest_sdk.android.data.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import io.carrotquest_sdk.android.data.db.messages.ShowedPush;
import io.carrotquest_sdk.android.data.db.messages.ShowedPushDao;

@Database(
        entities = {
                ShowedPush.class
        },
        version = 2,
        exportSchema = false)
public abstract class PushDB extends RoomDatabase {
    public abstract ShowedPushDao showedPushDao();
}
