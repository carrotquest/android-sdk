package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.reactivex.Observable

fun <T> Observable<T>.onRemoveMessage() : Observable<MessageData?> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getRemovedMessage()
                    /*.doOnNext {
                        if (it.value != null) {
                            Observable.just(it.value.conversation)
                                    .loadConversation()
                                    .subscribe({ conversation ->
                                        if(conversation != null) {
                                            ConversationsRepository.getInstance().updateConversation(it.value.conversation, conversation)
                                        }
                                    }, { t ->
                                        Log.e("onRemoveMessage", t)
                                    })
                        }
                    }*/
                    .map { x ->
                        x.value
                    }
        }
    }
}