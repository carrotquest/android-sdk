package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ConversationReplyResponse {
    @SerializedName("id")
    public String id;
    @SerializedName("created")
    public Integer created;
    @SerializedName("conversation")
    public String conversation;
    @SerializedName("body")
    public String body;
    @SerializedName("body_json")
    public Object bodyJson;
    @SerializedName("direction")
    public String direction;
    @SerializedName("read")
    public Boolean read;
    @SerializedName("type")
    public String type;
    @SerializedName("sent_via")
    public String sentVia;
    /*@SerializedName("meta_data")
    private MetaData metaData;*/
    @SerializedName("reply_type")
    public String replyType;
    /*@SerializedName("from")
    private From from;*/
    @SerializedName("random_id")
    public Integer randomId;
    @SerializedName("conversation_closed")
    public Boolean conversationClosed;
    @SerializedName("conversation_tags")
    public List<Object> conversationTags = null;
    @SerializedName("conversation_admin_unread_count")
    public Integer conversationAdminUnreadCount;
    /*@SerializedName("assignee")
    private Assignee assignee;*/
    @SerializedName("channel")
    public Object channel;
}
