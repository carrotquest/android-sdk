package io.carrotquest_sdk.android.di;

import android.content.Context;

import javax.inject.Singleton;

import dagger.Component;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;
import io.carrotquest_sdk.android.data.service.CarrotService;
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper;
import io.carrotquest_sdk.android.ui.fab.FloatingButton;

@Singleton
@Component(modules = {ContextSdkModule.class,
        CarrotServiceModule.class,
        UserRepositoryModule.class,
        GsonModule.class,
        DataBaseModule.class,
        NotificationHelperModule.class})

public interface SdkLibComponent {
    Context getContextSdk();
    UserRepository getUserRepository();
    CarrotSdkDB getSdkDataBase();

    PushNotificationHelper getNotificationHelper();
    CarrotService getCarrotService();

    void inject(UserRepository userRepository);
    void inject(CarrotService carrotService);
    void inject(FloatingButton floatingButtonOld);
    void inject(PushNotificationHelper pushNotificationHelper);
    void inject(CarrotSdkDB database);
}
