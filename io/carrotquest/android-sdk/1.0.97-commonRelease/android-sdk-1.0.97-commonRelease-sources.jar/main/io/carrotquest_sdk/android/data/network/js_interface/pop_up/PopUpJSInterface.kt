package io.carrotquest_sdk.android.data.network.js_interface.pop_up

import android.content.Context
import android.webkit.JavascriptInterface
import io.carrotquest_sdk.android.data.network.js_interface.BaseJsInterface
import io.carrotquest_sdk.android.data.network.js_interface.JSInterface
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import java.net.URLDecoder

class PopUpJSInterface(val context: Context, val presenter: IJSPopUpPresenter, webView: CarrotWebView) : JSInterface, BaseJsInterface(webView) {
    private val tag = this.javaClass.name

    /**
     * Попап готов к показу
     */
    @JavascriptInterface
    fun popUpIsReady(width: Int, height: Int) {
        presenter.popUpIsReady(width, height)
        super.methodComplete("popUpIsReady")
    }


    /**
     * Нужно закрыть попап
     */
    @JavascriptInterface
    fun closePopUp() {
        presenter.close()
        super.methodComplete("closePopUp")
    }


    /**
     * Нужно перейти по ссылке
     */
    @JavascriptInterface
    fun openLink(url: String) {
        presenter.openLink(URLDecoder.decode(url, "UTF-8"))
        super.methodComplete("openLink")
    }


    /**
     * Нужно отправить событие
     */
    @JavascriptInterface
    fun trackEvent(eventName: String) {
        presenter.trackEvent(eventName)
        super.methodComplete("trackEvent")
    }

    /**
     * Утсанавливает свойство пользователя
     */
    @JavascriptInterface
    fun identify(props: String) {
        presenter.setUserProperty(props)
        super.methodComplete("identify")
    }

    /**
     * При установке фокуса в поле ввода возвращает отступ его от верха
     */
    @JavascriptInterface
    fun popUpInputTap(topOffset: Int) {
        presenter.setTopOffsetCurrentInputBar(topOffset)
        super.methodComplete("popUpInputTap")
    }
}