package io.carrotquest_sdk.android.lib.wss.utils

import com.google.gson.JsonParser
import com.neovisionaries.ws.client.WebSocket
import com.neovisionaries.ws.client.WebSocketAdapter
import com.neovisionaries.ws.client.WebSocketException
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.i
import io.carrotquest_sdk.android.lib.wss.response.WssResponse
import io.reactivex.Observer


private const val tag = "SocketListener"

class SocketListener(private val appId: String): WebSocketAdapter() {
    private val context = CarrotLib.getLibComponents().context
    private var observers: List<Observer<WssResponse>>? = null

    fun setObservers(observers: List<Observer<WssResponse>>?) {
        this.observers = observers
    }

    @Throws(Exception::class)
    override fun onConnected(websocket: WebSocket?, headers: Map<String?, List<String?>?>?) {
        super.onConnected(websocket, headers)
    }

    @Throws(Exception::class)
    override fun onTextMessage(websocket: WebSocket?, text: String?) {
        super.onTextMessage(websocket, text)

        val jsonParser = JsonParser()
        val jElement = jsonParser.parse(text)
        val response = WssResponse.fromJson(jElement)

        // Сохраение тэга и времени последнего полученного сообщения
        SharedPreferencesLib.saveString(context, shPrefTagKey + appId, response.tag)
        SharedPreferencesLib.saveString(context, shPrefTimeKey + appId, response.time)

        //Отправка сообщения наблюдателям
        if (observers != null) {
            for (o in observers!!) {
                o.onNext(response)
            }
        }
    }

    override fun onError(websocket: WebSocket?, cause: WebSocketException) {
        i(tag, "Error -->" + cause.message)
    }
}