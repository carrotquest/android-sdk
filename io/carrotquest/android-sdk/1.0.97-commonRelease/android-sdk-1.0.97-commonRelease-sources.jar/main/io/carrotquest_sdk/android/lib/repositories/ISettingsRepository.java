package io.carrotquest_sdk.android.lib.repositories;

import io.carrotquest_sdk.android.lib.models.Settings;
import io.reactivex.subjects.BehaviorSubject;

public interface ISettingsRepository {
    Settings getSettings();
    void saveSettings(Settings settings);
    BehaviorSubject getSaveSettingObservable();
}
