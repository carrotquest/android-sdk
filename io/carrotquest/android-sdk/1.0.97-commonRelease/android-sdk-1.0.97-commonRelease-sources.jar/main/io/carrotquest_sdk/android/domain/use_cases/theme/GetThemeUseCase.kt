package io.carrotquest_sdk.android.domain.use_cases.theme

import android.content.Context
import android.content.res.Configuration
import android.content.res.Configuration.UI_MODE_NIGHT_YES
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.reactivex.Observable
import java.lang.Exception

fun <T> Observable<T>.getTheme(context: Context?) : Observable<SimpleTheme> {
    val tag = "Observable.getTheme()"
    return Observable.defer {
        val theme: ThemeSdk? = CarrotSDK.getTheme()
        if (theme == null || theme == ThemeSdk.LIGHT) {
            return@defer Observable.just(SimpleTheme.DEFAULT)
        }

        if (theme == ThemeSdk.DARK) {
            return@defer Observable.just(SimpleTheme.DARK)
        }

        if (theme == ThemeSdk.FROM_WEB) {
           getSettings().map { settings ->
                if (settings.theme == "dark") {
                    return@map Observable.just(SimpleTheme.DARK)
                }
                return@map Observable.just(SimpleTheme.DEFAULT)
            }
        }

        if (theme == ThemeSdk.FROM_DEVICE) {
            try {
                if (context != null && context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == UI_MODE_NIGHT_YES) {
                    return@defer Observable.just(SimpleTheme.DARK)
                } else {
                    return@defer Observable.just(SimpleTheme.DEFAULT)
                }
            }catch (e: Exception ){
                Log.Companion.e("getThemeTag", e)
            }
        }

        Observable.just(SimpleTheme.DEFAULT)
    }
}

fun getThemeUseCase(context: Context?): SimpleTheme {
    val theme: ThemeSdk? = CarrotSDK.getTheme()
    if (theme == null || theme == ThemeSdk.LIGHT) {
        return SimpleTheme.DEFAULT
    }

    if (theme == ThemeSdk.DARK) {
        return SimpleTheme.DARK
    }

    if (theme == ThemeSdk.FROM_WEB) {
        val settings = SettingsRepository.getInstance().getSettingsObject()
        if (settings?.theme == "dark") {
            return SimpleTheme.DARK
        }
        return SimpleTheme.DEFAULT
    }


    if (theme == ThemeSdk.FROM_DEVICE) {
       // val appContext = SdkApp.getInstance().applicationContext
        //if (appContext.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == UI_MODE_NIGHT_YES) {
        if (context != null && context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == UI_MODE_NIGHT_YES) {
            return SimpleTheme.DARK
        } else {
            return SimpleTheme.DEFAULT
        }
    }

    return SimpleTheme.DEFAULT
}