package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB

fun clearErrorMessage(messageId: String) {
    val db: CarrotSdkDB = SdkApp.getInstance().database
    db.failSendingMessageDao().remove(messageId)
}