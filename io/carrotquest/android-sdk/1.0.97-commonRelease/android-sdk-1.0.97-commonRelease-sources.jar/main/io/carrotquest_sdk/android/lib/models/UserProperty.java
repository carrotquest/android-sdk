package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

@Keep
public class UserProperty {

    @SerializedName("op")
    public String operation;
    @SerializedName("key")
    private String key;
    @SerializedName("value")
    private String value;

    public UserProperty(String key, String value) {
        this("update_or_create", key, value);
    }

    public UserProperty(String operation, String key, String value) {
        this.operation = operation;
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public String getOperation() {
        return operation;
    }
}
