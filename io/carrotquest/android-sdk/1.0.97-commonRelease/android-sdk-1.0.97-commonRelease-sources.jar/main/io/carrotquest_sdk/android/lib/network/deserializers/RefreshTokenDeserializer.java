package io.carrotquest_sdk.android.lib.network.deserializers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshData;
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

public class RefreshTokenDeserializer implements JsonDeserializer<RefreshResponse> {
    public RefreshTokenDeserializer() {
    }

    @Override
    public RefreshResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("RefreshTokenDeserializer. meta is null or dataJsonElement is null");
        }

        JsonElement metaJsonElement = json.getAsJsonObject().get(F.META);
        JsonElement dataJsonElement = json.getAsJsonObject().get(F.DATA);

        try {
            Meta meta = new Gson().fromJson(metaJsonElement, Meta.class);

            String access = dataJsonElement.getAsJsonObject().get("access").getAsString();
            String refresh = dataJsonElement.getAsJsonObject().get("refresh").getAsString();

            RefreshData data = new RefreshData(access, refresh);

            return new RefreshResponse(meta, data);
        }
        catch (JsonParseException e) {
            return new GsonBuilder().create().fromJson(json, RefreshResponse.class);
        }
    }
}