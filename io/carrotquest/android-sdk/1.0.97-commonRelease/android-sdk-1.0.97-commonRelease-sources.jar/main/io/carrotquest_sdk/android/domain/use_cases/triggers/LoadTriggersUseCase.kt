package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.data.repositories.triggers.TriggersRepository
import io.reactivex.Observable

class LoadTriggersUseCase {
    fun call(): Observable<Boolean> {
        return TriggersRepository.getInstance().loadTriggers()
    }
}