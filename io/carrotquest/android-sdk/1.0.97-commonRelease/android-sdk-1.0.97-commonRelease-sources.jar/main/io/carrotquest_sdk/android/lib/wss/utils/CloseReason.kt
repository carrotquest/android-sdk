package io.carrotquest_sdk.android.lib.wss.utils

enum class CloseReason {
    INTERNET_DISAPPEARED,
    APP_TO_BACKGROUND,
    DEINIT,
    RECONNECT,
    NONE,
}