package io.carrotquest_sdk.android.core.util.sentry;

import android.content.Context;

import io.carrotquest_sdk.android.BuildConfig;
//import io.sentry.Sentry;



public class SentryCQ_SDK {
    private static SentryCQ_SDK instance;

    private SentryCQ_SDK(Context context, String dsn) {
//        SentryAndroid.init(context, options -> {
//            options.setDsn(dsn);
//            options.setRelease(BuildConfig.VERSION_SDK_NAME);
//            options.setBeforeSend((event, hint) -> {
//                if(hint instanceof String && hint.equals("cq_sdk")) {
//                    return event;
//                }
//                return null;
//            });
//        });
    }

    public static void init(Context context) {
        if (instance == null) {
            instance = new SentryCQ_SDK(context, "https://03dfe81a4f434f11b3c54d94c88b4bfb@sentry.io/1463162");
            addDefaultContext();
        }
    }

    private static void addDefaultContext() {
//        Sentry.configureScope(scope -> {
//            scope.setContexts("CQ SDK Version", BuildConfig.VERSION_SDK_NAME);
//            scope.setContexts("Android SDK version", String.valueOf(Build.VERSION.SDK_INT));
//            scope.setContexts("OS version", Build.VERSION.RELEASE);
//            scope.setContexts("Manufacturer", Build.MANUFACTURER);
//            scope.setContexts("Model", Build.MODEL);
//        });
    }

    public static void setUser(io.carrotquest_sdk.android.lib.models.User user) {
//        User userSentry = new User();
//        userSentry.setId(user.getId());
//
//        Sentry.configureScope(scope -> {
//            scope.setUser(userSentry);
//            scope.setContexts("Android SDK version", String.valueOf(Build.VERSION.SDK_INT));
//            scope.setContexts("OS version", Build.VERSION.RELEASE);
//            scope.setContexts("Manufacturer", Build.MANUFACTURER);
//            scope.setContexts("Model", Build.MODEL);
//        });
    }


    public static void sendError(Throwable t) {
        //addLog();
//        Sentry.captureException(t, "cq_sdk");
//        Sentry.clearBreadcrumbs();
    }

    public static void sendError(Exception e) {
        //Sentry.captureException(e, "cq_sdk");
        //Sentry.clearBreadcrumbs();
    }

    public static void sendError(String s) {
        //Sentry.captureException(new Exception(s), "cq_sdk");
        //Sentry.clearBreadcrumbs();
    }
}
