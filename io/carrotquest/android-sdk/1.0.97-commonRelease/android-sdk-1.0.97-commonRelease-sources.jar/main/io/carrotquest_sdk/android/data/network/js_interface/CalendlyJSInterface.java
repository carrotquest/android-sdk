package io.carrotquest_sdk.android.data.network.js_interface;

import android.content.Context;
import android.webkit.JavascriptInterface;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.presentation.mvp.calendly.presenter.CalendlyPresenter;
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView;

public class CalendlyJSInterface extends BaseJsInterface implements JSInterface {

    private static final String TAG = "CalendlyJSInterface";

    private Context context;
    private CalendlyPresenter presenter;

    public CalendlyJSInterface(Context context, CalendlyPresenter presenter, CarrotWebView webView) {
        super(webView);
        this.context = context;
        this.presenter = presenter;
    }

    @JavascriptInterface
    public void shareData(String data) {
        Log.i(TAG, data);
    }
}

