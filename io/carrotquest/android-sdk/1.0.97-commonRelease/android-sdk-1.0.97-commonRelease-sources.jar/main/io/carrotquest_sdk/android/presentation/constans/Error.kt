package io.carrotquest_sdk.android.presentation.constans

enum class Error {
    NO_INTERNET, 
    SOMETHING_ERROE
}