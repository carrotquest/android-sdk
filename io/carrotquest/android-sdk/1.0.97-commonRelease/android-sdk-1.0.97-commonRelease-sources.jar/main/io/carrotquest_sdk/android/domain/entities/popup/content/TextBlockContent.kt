package io.carrotquest_sdk.android.domain.entities.popup.content

import io.carrotquest_sdk.android.domain.entities.popup.TypeBlockPopUp

class TextBlockContent(private val id: String): IBlockContent {

    override fun getId() = id
    override fun getType() = TypeBlockPopUp.TEXT
}