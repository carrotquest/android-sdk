package io.carrotquest_sdk.android.data.db.popup

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class PopUpDbEntity (
    @PrimaryKey
    var id: String,
    val state: String,
    var bodyJson: String,
    val expirationTime: Long,
    val backgroundColor: String
)