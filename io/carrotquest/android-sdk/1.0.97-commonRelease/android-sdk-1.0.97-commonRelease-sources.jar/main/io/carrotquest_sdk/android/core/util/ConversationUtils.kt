package io.carrotquest_sdk.android.core.util

fun String.recipientTypeIsRight() : Boolean {
    return this == "all" || this == "sdk" || this == "sdk_a" //|| this == "web" //TODO: LEAD_BOT
}
