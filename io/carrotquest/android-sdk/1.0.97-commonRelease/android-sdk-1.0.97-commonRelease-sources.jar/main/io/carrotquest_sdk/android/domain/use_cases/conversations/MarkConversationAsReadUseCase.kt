package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.reactivex.Observable

fun Observable<Optional<DataConversation>>.markConversationAsRead() : Observable<Optional<DataConversation>> {
    val tag = "Observable.markConversationAsRead()"
    return Observable.defer {
        this.flatMap {
            if(it.value == null) {
                return@flatMap Observable.just(it)
            }

            val conversation = it.value
            if(conversation.id == null) {
                return@flatMap Observable.just(it)
            }

            return@flatMap CarrotInternal.getService().carrotLib.markRead(conversation.id)
                    .doOnNext {response->
                        if(response.status == 200) {
                            ConversationsRepository.getInstance().removeUnreadConversation(conversation.id)
                        }
                    }
                    .doOnError { error ->
                        Log.e(tag, error)
                    }
                    .onErrorReturn {
                        return@onErrorReturn null
                    }
                    .flatMap {response->
                        Observable.just(it)
                    }
        }
    }
}

fun Observable<String>.markConversationAsReadById() : Observable<String> {
    val tag = "Observable.markConversationAsRead()"
    return Observable.defer {
        this.flatMap {conversationId->
            return@flatMap CarrotInternal.getService().carrotLib.markRead(conversationId)
                    .doOnNext {response->
                        if(response.status == 200) {
                            ConversationsRepository.getInstance().removeUnreadConversation(conversationId)
                        }
                    }
                    .doOnError { error ->
                        Log.e(tag, error)
                    }
                    .flatMap {response->
                        Observable.just(conversationId)
                    }
        }
    }
}