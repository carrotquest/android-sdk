package io.carrotquest_sdk.android.presentation.mvp.button.model

data class LastMessage(
        var text: String,
        var adminIcon: String,
        var state: StateLastMessage
)