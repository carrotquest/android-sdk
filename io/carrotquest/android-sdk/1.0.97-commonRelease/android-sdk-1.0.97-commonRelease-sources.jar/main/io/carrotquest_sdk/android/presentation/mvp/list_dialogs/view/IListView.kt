package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView

interface IListView : IBaseView {
    fun setupWebView(webView: CarrotWebView)
    fun loadUrl()

    fun hideLoading()

    fun initList(initJson: String)
    fun addDialog(dialogJson: String)
    fun deleteDialog(dialogJson: String)
    fun updateDialog(dialogJson: String)

    fun showErrorNoInternet()
    fun showErrorAirplaneMode()
    fun showErrorSomething()
    fun showErrorFileNotFound()
    fun showErrorSendMessage()

    fun showEmptyList()
    fun hideError()

    fun closeActivity()
}