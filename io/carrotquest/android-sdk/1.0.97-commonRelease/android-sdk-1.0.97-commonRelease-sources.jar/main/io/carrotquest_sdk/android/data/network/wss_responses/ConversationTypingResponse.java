package io.carrotquest_sdk.android.data.network.wss_responses;

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.core.main.CarrotInternal;

public class ConversationTypingResponse extends MessageData implements IRtsMessage {
    int duration = 5;

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

    @Override
    public void process() {
        CarrotInternal.getLibComponent().getCarrotService().adminTyping(this);
    }
}
