package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.countries.SaveCountryRegionUseCase
import io.reactivex.subjects.BehaviorSubject

class SettingsRepository {
    private val currentSettingsSubject: BehaviorSubject<SettingsEntity?> = BehaviorSubject.create()

    private var settings: SettingsEntity? = null

    companion object {
        private var instance : SettingsRepository? = null
        fun getInstance(): SettingsRepository {
            if(instance == null) {
                instance = SettingsRepository()
            }
            return instance!!
        }
    }

    fun getSettings() : BehaviorSubject<SettingsEntity?> {
        return this.currentSettingsSubject
    }

    fun getLastSettings() : SettingsEntity? {
        return this.currentSettingsSubject.value
    }

    fun saveSettings(settings: SettingsEntity) {
        this.settings = settings
        this.currentSettingsSubject.onNext(this.settings!!)

        //save current country
        val locale = settings.locale
        if(locale.isNotEmpty()) {
            if(locale.length > 2 && locale.contains("-")) {
                val region = locale.substring(0, locale.indexOf("-"))
                SaveCountryRegionUseCase().call(region)
            } else if(locale.length == 2) {
                SaveCountryRegionUseCase().call(locale)
            }

        }
    }

    fun getSettingsObject() = this.settings
}