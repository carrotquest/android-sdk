package io.carrotquest_sdk.android.lib.network.responses.user;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

import io.carrotquest_sdk.android.lib.network.responses.base.Data;

@Keep
public class UserData extends Data {
    @SerializedName("id")
    private String id;

    @SerializedName("props")
    private Map<String, Object> props;

    public String getId() {
        return id;
    }

    public Map<String, Object> getProps() {
        return props;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setProps(Map<String, Object> props) {
        this.props = props;
    }
}
