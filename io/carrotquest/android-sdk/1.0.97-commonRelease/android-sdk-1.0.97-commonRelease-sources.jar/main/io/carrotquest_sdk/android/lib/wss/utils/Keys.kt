package io.carrotquest_sdk.android.lib.wss.utils


const val shPrefTagKey: String = "TIME_"
const val shPrefTimeKey: String = "TAG_"