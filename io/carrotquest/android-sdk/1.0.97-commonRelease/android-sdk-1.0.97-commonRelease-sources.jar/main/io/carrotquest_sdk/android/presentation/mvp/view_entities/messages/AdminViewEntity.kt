package io.carrotquest_sdk.android.presentation.mvp.view_entities.messages

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F

data class AdminViewEntity (
        @SerializedName(F.ID)
        var id: String?,
        @SerializedName(F.NAME)
        var name: String?,
        @SerializedName(F.AVATAR)
        var avatar: String?,
        @SerializedName(F.TYPE)
        var type: String?
)