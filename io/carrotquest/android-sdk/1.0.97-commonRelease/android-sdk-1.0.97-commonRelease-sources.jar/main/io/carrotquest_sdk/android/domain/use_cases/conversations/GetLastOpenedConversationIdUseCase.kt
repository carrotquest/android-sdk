package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.reactivex.Observable

public fun <T> Observable<T>.getLastOpenedConversationId() : Observable<String> {
    return Observable.just(ConversationsRepository.getInstance().getLastOpenedConversationId())
}