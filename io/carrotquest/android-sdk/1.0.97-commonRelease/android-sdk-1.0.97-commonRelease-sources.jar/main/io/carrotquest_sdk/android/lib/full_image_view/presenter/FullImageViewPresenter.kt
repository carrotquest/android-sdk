package io.carrotquest_sdk.android.lib.view.full_image_view.presenter

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.StrictMode
import android.text.TextUtils
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback
import io.carrotquest_sdk.android.lib.utils.files.saveBitmapImageToGallery
import io.carrotquest_sdk.android.lib.full_image_view.view.FullImageViewDialogFragment
import java.io.File
import java.io.FileOutputStream
import android.provider.MediaStore
import io.carrotquest_sdk.android.lib.utils.loging.Log
import java.lang.Exception
import java.lang.reflect.Method


class FullImageViewPresenter {

    private var view: FullImageViewDialogFragment? = null
    private var bitmap: Bitmap? = null

    fun attachView(view: FullImageViewDialogFragment) {
        this.view = view
    }

    fun detachView() {
        this.view = null
    }

    fun onStart(imageUrl: String) {
        if (!TextUtils.isEmpty(imageUrl)) {
            view?.showImage(imageUrl)
        } else {
            view?.showError()
        }
    }

    fun onStart(file: File) {
        if (file.exists()) {
            view?.showImage(file)
        } else {
            view?.showError()
        }
    }

    fun onStart(bitmap: Bitmap?) {
        if (bitmap != null) {
            view?.showImage(bitmap)
        } else {
            view?.showError()
        }
    }

    fun onImageTap(isHideControls: Boolean) {
        if (isHideControls) {
            view?.showControls()
        } else {
            view?.hideControls()
        }
    }

    fun onTapShareImage(context: Context) {
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "image/*"
        val path: String = MediaStore.Images.Media.insertImage(
            context.contentResolver,
            bitmap,
            "",
            ""
        )
        val uri = Uri.parse(path)
        intent.putExtra(Intent.EXTRA_STREAM, uri)

        view?.openShareInterface(intent)
    }

    fun onTapSaveImage(
        contentResolver: ContentResolver,
        callback: SaveImageCallback
    ) {
        if (bitmap != null) {
            saveBitmapImageToGallery(bitmap!!, contentResolver, callback)
        }
    }

    fun onLoadResource(resource: Drawable, context: Context) {
        try {
            val cachePath = File(context.cacheDir, "images")
            cachePath.mkdirs() // don't forget to make the directory
            val nFile = File(cachePath, "image.png")
            val stream = FileOutputStream(nFile) // overwrites this image every time

            bitmap = (if (resource is BitmapDrawable) {
                resource.bitmap
            } else {
                null
            }) ?: return

            bitmap!!.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()

            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    val m: Method =
                        StrictMode::class.java.getMethod("disableDeathOnFileUriExposure")
                    m.invoke(null)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri = Uri.fromFile(nFile)
            view?.updateContentUri(uri)
        }
        catch (e: Exception) {
            Log.e("onLoadResource", e)
        }
    }
}