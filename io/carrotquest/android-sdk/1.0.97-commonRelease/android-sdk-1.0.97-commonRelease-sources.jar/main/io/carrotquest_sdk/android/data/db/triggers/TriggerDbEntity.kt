package io.carrotquest_sdk.android.data.db.triggers

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class TriggerDbEntity (
    @PrimaryKey
    var id: String,
    var kind: Int,
    var url: String,
    var comparison: String,
)