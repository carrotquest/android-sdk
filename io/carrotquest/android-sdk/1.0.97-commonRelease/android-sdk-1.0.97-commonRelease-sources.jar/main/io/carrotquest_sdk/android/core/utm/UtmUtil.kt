package io.carrotquest_sdk.android.core.utm

import android.content.Context
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.models.Operation
import java.net.URLDecoder
import java.util.*
import kotlin.collections.HashMap

object UtmUtil {
    private var isSuccess = false
    fun sendSavedUtm(context: Context) {
        if (SavedUtm.getInstance(context).hasUtm()) {
            NetworkManager.getInstance(context).addObserver({ isConnect ->
                if (isConnect && !isSuccess) {
                    val sourceUtm = SavedUtm.getInstance(context = context).getUtmSource()
                    val mediumUtm = SavedUtm.getInstance(context = context).getUtmMedium()
                    val campaignUtm = SavedUtm.getInstance(context = context).getUtmCampaign()
                    val termUtm = SavedUtm.getInstance(context = context).getUtmTerm()
                    val contentUtm = SavedUtm.getInstance(context = context).getUtmContent()

                    val params = "{\"\$utm_source\":\"$sourceUtm\"," +
                            "\"\$utm_medium\":\"$mediumUtm\"," +
                            "\"\$utm_campaign\":\"$campaignUtm\"," +
                            "\"\$utm_term\":\"$termUtm\"," +
                            "\"\$utm_content\":\"$contentUtm\"}"

                    CarrotSDK.trackEvent("\$utm_hit",
                            params)


                    if (sourceUtm.isNotEmpty()) {
                        CarrotSDK.setUserProperty(Operation.set_once, "\$initial_utm_source", sourceUtm)
                    }


                    if (mediumUtm.isNotEmpty()) {
                        CarrotSDK.setUserProperty(Operation.set_once, "\$initial_utm_medium", mediumUtm)
                    }


                    if (campaignUtm.isNotEmpty()) {
                        CarrotSDK.setUserProperty(Operation.set_once, "\$initial_utm_campaign", campaignUtm)
                    }


                    if (termUtm.isNotEmpty()) {
                        CarrotSDK.setUserProperty(Operation.set_once, "\$initial_utm_term", termUtm)
                    }


                    if (contentUtm.isNotEmpty()) {
                        CarrotSDK.setUserProperty(Operation.set_once, "\$initial_utm_content", contentUtm)
                    }

                    clearUtm(context = context)
                    isSuccess = true
                }
            }, { t ->
                Log.e("UtmUtil", t)
            }, {

            })
        }
    }

    fun getReferrer(context: Context): String {
        var res = ""
        val sourceUtm = SavedUtm.getInstance(context = context).getUtmSource()
        val mediumUtm = SavedUtm.getInstance(context = context).getUtmMedium()
        val campaignUtm = SavedUtm.getInstance(context = context).getUtmCampaign()
        val termUtm = SavedUtm.getInstance(context = context).getUtmTerm()
        val contentUtm = SavedUtm.getInstance(context = context).getUtmContent()


        if(sourceUtm.isNotEmpty()) {
            res = res + UTM.SOURCE.value + "=" + sourceUtm
        }
        if(mediumUtm.isNotEmpty()) {
            res = res + "&" + UTM.MEDIUM.value + "=" + mediumUtm
        }
        if(campaignUtm.isNotEmpty()) {
            res = res + "&" + UTM.CAMPAIGN.value + "=" + campaignUtm
        }
        if(termUtm.isNotEmpty()) {
            res = res + "&" + UTM.TERM.value + "=" + termUtm
        }
        if(contentUtm.isNotEmpty()) {
            res = res + "&" + UTM.CONTENT.value + "=" + contentUtm
        }

        return res
    }

    fun saveUtm(utms: HashMap<String, String>, context: Context?) {
        for (utmKey in utms.keys) {
            when (utmKey.lowercase(Locale.getDefault())) {
                UTM.SOURCE.value -> {
                    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_SOURCE, utms[utmKey])
                }
                UTM.MEDIUM.value -> {
                    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_MEDIUM, utms[utmKey])
                }
                UTM.CAMPAIGN.value -> {
                    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_CAMPAIGN, utms[utmKey])
                }
                UTM.TERM.value -> {
                    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_TERM, utms[utmKey])
                }
                UTM.CONTENT.value -> {
                    SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_CONTENT, utms[utmKey])
                }
            }
        }
    }

    fun getSavedUtm(context: Context) = SavedUtm.getInstance(context)

    fun getHashMapParamsFromQuery(query: String): HashMap<String, String> {
        val hashMap = HashMap<String, String>()
        val pairs = query.split("&")
        for (pair in pairs) {
            val index = pair.indexOf("=")
            val key = URLDecoder.decode(pair.substring(0, index), "UTF-8").trim()
            val value = URLDecoder.decode(pair.substring(index + 1), "UTF-8").trim()
            hashMap[key] = value
        }

        return hashMap
    }

    private fun clearUtm(context: Context) {
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_SOURCE, "")
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_MEDIUM, "")
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_CAMPAIGN, "")
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_TERM, "")
        SharedPreferencesLib.saveString(context, SharedPreferenceKeys.UTM_CONTENT, "")
    }
}