package io.carrotquest_sdk.android.di;

import android.app.Application;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.application.SdkApp;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;

import javax.inject.Singleton;

@Module
public class DataBaseModule {
    private Application application;
    public DataBaseModule(Application application) {
        this.application = application;
    }

    @Provides
    @Singleton
    public CarrotSdkDB provideDb() {
        return SdkApp.getInstance().getDatabase();
    }
}
