package io.carrotquest_sdk.android.data.db.messages

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class ShowedPush (
    @PrimaryKey
    var id: String
)