package io.carrotquest_sdk.android.domain.entities.popup

data class PopUpMessageEntity(
        val id: String,
        //val content: ArrayList<BlockPopUp>,
        val sourceBodyJson: String,
        val expirationTime: Long,
        val backgroundColor: String
)