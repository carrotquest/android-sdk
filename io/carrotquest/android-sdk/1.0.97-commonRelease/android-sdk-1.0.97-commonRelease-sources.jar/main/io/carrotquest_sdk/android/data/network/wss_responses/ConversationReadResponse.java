package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.SerializedName;

public class ConversationReadResponse {
    @SerializedName("id")
    public String id;

}
