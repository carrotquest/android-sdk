package io.carrotquest_sdk.android.data.data_entities.popup

data class PopUpModel(
        val id: String,
        val bodyJson: String,
        val state: String
)