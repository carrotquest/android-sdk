package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.reactivex.Observable
import java.io.File

fun <T> Observable<T>.createConversation(textMessage: String) : Observable<String?> {
    return Observable.defer {
        return@defer this.flatMap {
            this.getCurrentUser()
                    .flatMap { user ->
                        CarrotInternal.getService().carrotLib.startConversation(user.id, textMessage.replace("\n","<br/>"))
                                .flatMap { res ->
                                    if (res.meta.error == null) {
                                        ConversationsRepository.getInstance().saveOpenedConversation(res.data.conversationId)
                                        Observable.just(true)
                                                .getConversation(res.data.conversationId)
                                                .flatMap { optionalConversation ->
                                                    if (optionalConversation.value != null && optionalConversation.value.id != null) {
                                                        ConversationsRepository.getInstance().addConversation(optionalConversation.value)
                                                        return@flatMap Observable.just(optionalConversation.value.id)
                                                    } else {
                                                        return@flatMap Observable.just("")
                                                    }

                                                }

                                    } else {
                                        Observable.just("")
                                    }
                                }

                    }
        }
    }
}

fun <T> Observable<T>.createConversation(file: File) : Observable<String?> {
    return Observable.defer {
        return@defer this.flatMap {
            this.getCurrentUser()
                    .flatMap { user ->
                        CarrotInternal.getService().carrotLib.startConversation(user.id, file)
                                .flatMap { res ->
                                    if (res.meta.error == null) {
                                        Observable.just(true)
                                                .getConversation(res.data.conversationId)
                                                .flatMap { optionalConversation ->
                                                    if (optionalConversation.value != null) {
                                                        ConversationsRepository.getInstance().addConversation(optionalConversation.value)
                                                        return@flatMap Observable.just(optionalConversation.value.id)
                                                    } else {
                                                        return@flatMap Observable.just("")
                                                    }

                                                }
                                    } else {
                                        Observable.just("")
                                    }
                                }

                    }
        }
    }
}