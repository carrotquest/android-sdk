package io.carrotquest_sdk.android.core.constants;

public class AutoReplayContactType {
    public static final String PHONE = "phone";
    public static final String EMAIL = "email";

    public static final String LOADING = "loading";
    public static final String REPLIED = "replied";

    public static final String VOTE = "vote";
}
