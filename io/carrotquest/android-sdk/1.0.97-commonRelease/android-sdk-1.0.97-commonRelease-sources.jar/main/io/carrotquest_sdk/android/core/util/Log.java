package io.carrotquest_sdk.android.core.util;

import io.carrotquest_sdk.android.Carrot;

public class Log {
    public static void i(String tag, String msg) {
        android.util.Log.i("CQ_" + tag, msg);
    }

    public static void e(String tag, String msg) {
        android.util.Log.e("CQ_" + tag, msg);
    }

    public static void e(String tag, Exception e) {
        android.util.Log.e("CQ_" + tag, e.toString());
    }

    public static void e(String tag, Throwable t) {
        android.util.Log.e("CQ_" + tag, t.toString());
    }

    public static void d(String tag, String msg) {
        if(Carrot.isDebug()) {
            android.util.Log.d("CQ_" + tag, msg);
        }
    }

    public static void v(String tag, String msg) {
        if(Carrot.isDebug()) {
            android.util.Log.v("CQ_" + tag, msg);
        }
    }
}
