package io.carrotquest_sdk.android.presentation.constans

enum class StatusOperators(val value: String) {
    ONLINE("online"),
    OFFLINE("offline"),
    UNKNOWN("")
}