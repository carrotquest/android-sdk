package io.carrotquest_sdk.android.lib.managers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;

public interface IStateManager {
    /**
     * Добавить наблюдателя за состоянием
     * @param observer Наблюдатель
     */
    void addObserver(Consumer<Boolean> observer, Consumer<Throwable> errorConsumer, Action complete);

    /**
     * Необходимо вызывать после завершения работы
     */
    void deInit();
}
