package io.carrotquest_sdk.android.domain.use_cases.conversations

import com.google.gson.GsonBuilder
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.network.PopUpDeserializer
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.reactivex.Observable

const val SHOWED_POPUP_IDS = "SHOWED_POPUP_IDS_KEY"

fun Observable<UserEntity>.findLastUnreadPopup() : Observable<List<PopUpMessage>> {
    return Observable.defer {
        return@defer this.flatMap {
            this.loadConversations()
                .getUnreadConversations()
                .getPopupConversations()
                .take(1)
                .flatMap { popUpUnreadConversations ->
                    val context = CarrotInternal.getLibComponent().contextSdk
                    val exitedSet = SharedPreferencesLib.getStringSet(context, SHOWED_POPUP_IDS)
                    popUpUnreadConversations.removeAll { x -> x.id == null || exitedSet.contains(x.id) }

                    if (popUpUnreadConversations.isEmpty()) {
                        return@flatMap Observable.just(null)
                    }

                    popUpUnreadConversations.sortBy { x -> x.created.toLong() }.let {
                        return@flatMap Observable.just(popUpUnreadConversations.mapNotNull { x ->
                            getPopUpMessage(
                                x
                            )
                        })
                    }
                }
        }
    }
}

private fun getPopUpMessage(conversation: DataConversation) : PopUpMessage?{
    if(conversation.id == null) {
        return null
    }

    val messageData = conversation.partLast
    val jsonBody = messageData?.bodyJson?.asJsonObject
    if (jsonBody != null) {
        jsonBody.addProperty("id", conversation.id)
        jsonBody.addProperty("expiration_time", conversation.expirationTime)
        val gson = GsonBuilder()
            .registerTypeAdapter(PopUpMessage::class.java, PopUpDeserializer())
            .create()
        return gson.fromJson(jsonBody, PopUpMessage::class.java)
    }

    return null
}