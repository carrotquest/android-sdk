package io.carrotquest_sdk.android.domain.use_cases.popup

enum class StatePopUp {
    PROCESS_SHOWING,
    SHOWED,
    FAILED_SHOWED,
    WAITING
}