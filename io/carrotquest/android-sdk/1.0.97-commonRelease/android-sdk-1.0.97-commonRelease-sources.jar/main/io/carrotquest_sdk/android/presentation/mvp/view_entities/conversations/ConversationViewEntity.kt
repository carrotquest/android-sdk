package io.carrotquest_sdk.android.presentation.mvp.view_entities.conversations

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.presentation.mvp.view_entities.messages.AdminViewEntity
import io.carrotquest_sdk.android.presentation.mvp.view_entities.messages.MessageViewEntity

data class ConversationViewEntity (
        @SerializedName(F.ID)
        private var id: String?,
        @SerializedName(F.CREATED)
        private var created: String?,
        @SerializedName(F.READ)
        private var read: Boolean?,
        @SerializedName(F.CLIKCKED)
        private var clicked: Boolean?,
        @SerializedName(F.UNSUBSCRIBED)
        private var unsubscribed: Boolean?,
        @SerializedName(F.CLOSED)
        private var closed: Boolean?,
        @SerializedName(F.MESSAGE)
        private var message: Any?,
        @SerializedName(F.TYPE)
        private var type: String?,
        @SerializedName(F.REPLY_TYPE)
        private var replyType: String?,
        @SerializedName(F.PART_LAST)
        private var partLast: MessageViewEntity?,
        @SerializedName(F.PARTS_COUNT)
        private var partsCount: Int?,
        @SerializedName(F.ASSIGNEE)
        private var assignee: Any?,
        @SerializedName(F.UNREAD_PARTS_COUNT)
        private var unreadPartsCount: Int?,
        @SerializedName(F.USER_UNREAD_COUNT)
        private var userUnreadCount: Int?,
        @SerializedName(F.LAST_ADMIN)
        private var lastAdmin: AdminViewEntity?,
        @SerializedName(F.LAST_UPDATE)
        private var lastUpdate: String?,
        @SerializedName(F.TAGS)
        private var tags: List<Any>?
)