package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

@Keep
public class ActionMessage {
    @SerializedName("id")
    private String id;
    @SerializedName("message_id")
    private String messageId;
    @SerializedName("body")
    private String body;
    @SerializedName("type")
    private String type;
    @SerializedName("next_branch_id")
    private String nextBranchId;
    @SerializedName("body_json")
    private JsonElement bodyJson;
    @SerializedName("attachments")
    private ArrayList<Attachment> attachments;
    @SerializedName("placeholder")
    private Placeholder placeholder;

    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getNextBranchId() {
        return nextBranchId;
    }

    public void setNextBranchId(String nextBranchId) {
        this.nextBranchId = nextBranchId;
    }

    public ArrayList<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(ArrayList<Attachment> attachments) {
        this.attachments = attachments;
    }

    public Placeholder getPlaceholder() {
        return placeholder;
    }

    public void setPlaceholder(Placeholder placeholder) {
        this.placeholder = placeholder;
    }

    public JsonElement getBodyJson() {
        return bodyJson;
    }

    public void setBodyJson(JsonElement bodyJson) {
        this.bodyJson = bodyJson;
    }
}
