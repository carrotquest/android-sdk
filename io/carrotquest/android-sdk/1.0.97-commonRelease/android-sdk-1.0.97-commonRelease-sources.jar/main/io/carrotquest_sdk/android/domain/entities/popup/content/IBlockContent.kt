package io.carrotquest_sdk.android.domain.entities.popup.content

import io.carrotquest_sdk.android.domain.entities.popup.TypeBlockPopUp

interface IBlockContent {
    fun getId(): String
    fun getType(): TypeBlockPopUp
}