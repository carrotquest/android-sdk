package io.carrotquest_sdk.android.lib.network.deserializers;

import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse;
import com.google.gson.*;

import java.lang.reflect.Type;

public class PushSubscribeDeserializer implements JsonDeserializer<PushSubResponse> {

    public PushSubscribeDeserializer(){
    }

    @Override
    public PushSubResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        return new Gson().fromJson(json, PushSubResponse.class);
    }
}
