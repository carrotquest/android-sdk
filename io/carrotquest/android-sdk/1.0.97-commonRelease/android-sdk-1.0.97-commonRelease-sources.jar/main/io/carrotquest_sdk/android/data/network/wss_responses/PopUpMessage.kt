package io.carrotquest_sdk.android.data.network.wss_responses

data class PopUpMessage (
        val id: String,
        val sourceJson: String,
        val rows: ArrayList<Row>,
        val expirationTime: Long,
        val backgroundColor: String
)

data class Row(
        val blocks: ArrayList<BlockPopUpNet>
)

data class BlockPopUpNet(
        val type: String,
        val backgroundImage: String?
)