package io.carrotquest_sdk.android.lib.network.responses.base;

public interface IBaseResponse {
    Data getData();
    Meta getMeta();

    void setData(Data data);
    void setMeta(Meta meta);
}
