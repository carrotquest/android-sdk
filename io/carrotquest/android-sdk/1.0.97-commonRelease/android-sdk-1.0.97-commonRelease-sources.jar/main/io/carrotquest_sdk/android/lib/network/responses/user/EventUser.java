package io.carrotquest_sdk.android.lib.network.responses.user;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;
@Keep
public class EventUser {
    @SerializedName("first")
    private Integer first;
    @SerializedName("last")
    private Integer last;
    @SerializedName("count")
    private Integer count;
    @SerializedName("event_type")
    private EventUserType eventType;

    public Integer getFirst() {
        return first;
    }

    public void setFirst(Integer first) {
        this.first = first;
    }

    public Integer getLast() {
        return last;
    }

    public void setLast(Integer last) {
        this.last = last;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public EventUserType getEventType() {
        return eventType;
    }

    public void setEventType(EventUserType eventType) {
        this.eventType = eventType;
    }
}
