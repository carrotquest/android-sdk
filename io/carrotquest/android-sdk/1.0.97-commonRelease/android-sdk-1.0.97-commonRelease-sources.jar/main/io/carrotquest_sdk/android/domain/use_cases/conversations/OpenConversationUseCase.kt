package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper
import io.reactivex.Observable

fun <T> Observable<T>.openConversation(id: String?) : Observable<Boolean> {
    val tag = "Observable.openConversation()"
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(true)
                    .doOnNext {
                        val mId = when (id) {
                            null -> ""
                            else -> id
                        }
                        ConversationsRepository.getInstance().saveOpenedConversation(mId)
                        PushNotificationHelper.getInstance().clearNotifications(mId)
                    }
                    .doOnError { t->
                        Log.e(tag, t)
                    }
        }
    }
}