package io.carrotquest_sdk.android.lib.network.responses.bot

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Data
import io.carrotquest_sdk.android.lib.network.responses.base.IBaseResponse
import io.carrotquest_sdk.android.lib.network.responses.base.Meta

@Keep
class ChooseRoutingBotResponse: IBaseResponse {
    @SerializedName(F.DATA)
    @Expose
    private var data: ChooseRoutingBotData? = null

    @SerializedName(F.META)
    @Expose
    private var meta: Meta? = null

    override fun getData(): ChooseRoutingBotData? {
        return data
    }

    override fun getMeta(): Meta? {
        return meta
    }

    override fun setData(data: Data?) {
        if (data is ChooseRoutingBotData) {
            this.data = data
        }
    }

    override fun setMeta(meta: Meta?) {
        this.meta = meta
    }
}