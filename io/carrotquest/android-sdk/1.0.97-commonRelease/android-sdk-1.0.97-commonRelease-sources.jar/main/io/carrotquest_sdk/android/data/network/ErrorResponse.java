package io.carrotquest_sdk.android.data.network;

import com.google.gson.annotations.SerializedName;
import io.carrotquest_sdk.android.core.constants.ResponseFields;

public class ErrorResponse {
    int status;
    String error;
    @SerializedName(ResponseFields.ERROR_MESSAGE)
    public String errorMessage;
}
