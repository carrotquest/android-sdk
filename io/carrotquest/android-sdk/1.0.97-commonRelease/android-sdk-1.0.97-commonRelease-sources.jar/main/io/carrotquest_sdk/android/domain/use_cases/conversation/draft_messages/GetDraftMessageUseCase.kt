package io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun getDraftMessageUseCase(conversationId: String): String? {
    val context = CarrotLib.getLibComponents().context
    val tempValue = SharedPreferencesLib.getString(context, DRAFT_MESSAGES_KEY + conversationId)

    return tempValue.ifEmpty { return null }
}