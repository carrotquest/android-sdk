package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.content.Context
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.presentation.chat.input.AttachmentUploadState
import io.carrotquest_sdk.android.presentation.chat.input.PendingAttachment
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView

internal interface IDialogView : IBaseView {

    fun updateAppColor(color: Int)

    // Ответ chooseRoutingBot: тело чата решает по нему, рисовать дерево бота или дефолтное
    // приветствие. Презентер — единственный, кто спрашивает бэкенд (у него ретрай и повтор
    // после возврата сети), поэтому вызов приходит только отсюда. data == null — узнать не
    // удалось при живой сети. Пока вызова не было, приветствие не показываем.
    // [restart] — ответ на перезапуск бота в этом же окне после закрытия сгоревшего диалога
    // (CAR-77064): тело чата пинит шаблон нового прогона внизу ленты и снимает локальные отметки
    // ответа на стартовую ветку прошлого прогона.
    fun setRoutingBotResolved(data: ChooseRoutingBotData?, restart: Boolean = false)

    // Оптимистичный текстовый ответ боту: тело чата рисует его пузырём на самой части-вопросе
    // ([partId]), пока сервер не пришлёт meta_data.answer_body. Тот же мост, что у
    // setRoutingBotResolved. Отдельного reply_user-сообщения бэкенд для такого ответа не создаёт.
    fun setBotTextAnswer(partId: String, answer: String)

    // Сгорание бота по тайм-ауту (CAR-77064): при [expired] тело чата прячет неотвеченные кнопки
    // бота (кроме заново показанной стартовой ветки нового прогона), а внизу вместо поля ввода —
    // плашка «Диалог завершён» в режиме [plate]. Из диалога не уходим (по карточке; веб уходит на
    // стартовый экран).
    fun setBotExpired(expired: Boolean, plate: BotExpiredPlate)

    // Сервер отверг ответ боту (диалог закрыт), сгорания как состояния нет: снять оптимистичную
    // подсветку выбранной кнопки у части [messageId], иначе она осталась бы «отвеченной» навсегда.
    fun resetBotAnswer(messageId: String)

    // Пользователь ответил на стартовую ветку routing-бота (кнопкой или текстом в поле). С этого
    // момента шаблон первой ветки — часть диалога и не удаляется при приходе новых сообщений
    // (веб: setWelcomeBotAsPartOfDialog). До ответа любое новое сообщение (например, оператора по
    // RTS) убирает шаблон целиком вместе с текстом, а не только схлопывает кнопки.
    fun markRoutingTemplateAnswered()

    // Закрытый диалог read-only (CAR-77491): при true тело чата прячет неотвеченные кнопки бота и
    // шаблон стартовой ветки, а внизу вместо поля ввода рисуется плашка «Начать новый диалог».
    // false — диалог переоткрыт (оператор написал) или закрыт без запрета: блокировка снята.
    fun setConversationClosed(readOnly: Boolean)

    // Мультиаттачи (upload-on-select): бридж презентер → MessageInputViewModel (лента чипов).
    fun addPendingAttachment(attachment: PendingAttachment)
    fun updatePendingAttachmentState(clientId: String, state: AttachmentUploadState)
    fun removePendingAttachment(clientId: String)
    fun clearPendingAttachments()

    fun showErrorNoInternet()
    fun showErrorAirplaneMode()
    fun showErrorSomething()
    fun showErrorFileNotFound()
    fun showErrorSendMessage()

    fun showSendButton()
    fun hideSendButton()
    fun showAttachFileButton()
    fun hideAttachFileButton()
    fun enableSendButton()
    fun disableSendButton()

    fun showPhonePrefix()
    fun hidePhonePrefix()

    // Блок согласия над баром (BOT_INPUT запрос перс. данных). null — убрать.
    fun setConsent(consent: ConsentUiState?)

    fun enableInput()
    fun disableInput()
    fun hideInput()
    fun showInput(conversationId: String)
    fun clearInput()
    fun setInputMod(mod: InputMod)
    fun updateHint(hint: String?)
    fun updateMaxLengthInput(maxLength: Int?)

    fun showDataSavedMessage()

    fun hideLoadError()
    fun hideLoading()
    fun showLoadingOlderMessages()
    fun hideLoadingOlderMessages()

    fun openFilePicker()

    fun updatePhoneRegionFlag(flag: String)
    fun updatePhoneRegionPrefix(prefix: String)

    fun setKeyboardType(keyboardType: Int)

    fun getCurrentContext(): Context?
    fun getSupportFragmentManager(): FragmentManager?
}