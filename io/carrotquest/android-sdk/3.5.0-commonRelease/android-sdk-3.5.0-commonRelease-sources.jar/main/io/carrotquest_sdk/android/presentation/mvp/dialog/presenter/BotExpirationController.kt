package io.carrotquest_sdk.android.presentation.mvp.dialog.presenter

import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.BotExpiredPlate
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Сгорание бота по тайм-ауту (CAR-77064) — вся логика поверх [BotExpirationTracker], без привязки
 * к презентеру и синглтонам: окружение приходит через [Host], поэтому класс тестируется целиком.
 *
 * Бэк планирует закрытие через close_delay бота и проставляет диалогу conversation.expiration_time
 * (свежий объект приходит в каждом conversation_parts_batch). RTS о самом закрытии не будет:
 * bulk_close на бэке намеренно молчит, — поэтому таймер ведёт клиент по серверным часам
 * (ServerClock), как веб (cqstatic bot-expiration.js). По истечении кнопки бота и поле ввода
 * прячем сразу, из диалога НЕ уходим (веб уходит на стартовый экран — SDK следует карточке):
 *  • новые диалоги разрешены и кнопка «Написать» есть → плашка «Диалог завершён» + «Создать
 *    новый диалог»;
 *  • «одно окно» (messenger_enable_new_conversation_button=false) или пользователю вообще нельзя
 *    начинать диалоги → плашка без кнопки, ждём закрытия на сервере (бит раз в минуту; RTS
 *    conversation_closed или опрос GET беседы) и перезапрашиваем choose — бот перезапускается в
 *    этом же диалоге стартовой веткой (штатный путь переоткрытия, CAR-77439). Метку при этом
 *    держим до ответа choose: снять её раньше значило бы на время запроса вернуть кнопки
 *    сгоревшей ветки и поле ввода — тап по ним уходил в routing/start со старым branchId, и бот
 *    продолжал мёртвый сценарий (QA CAR-77343). Показанная стартовая ветка снимает плашку сама
 *    ([Host.templateShown]), кнопки сгоревшей ветки остаются скрытыми до ответа на новый прогон;
 *    found=false (бот выключен) — метку отпускаем, иначе плашка без кнопки осталась бы навсегда.
 *    Перед choose перезагружаем историю: первая ветка прошлого прогона жила в ленте шаблоном
 *    (по RTS её части отбрасываются), новый шаблон его заменит, и без серверных частей
 *    приветствие прошлого прогона пропало бы из ленты. При включённом запрете писать в закрытые
 *    (CAR-77491) перезапуск невозможен по бэкенду (choose → found=false): по closed=true бота не
 *    запрашиваем — свежий closed уходит в репозиторий, и updateInput сам переключает диалог на
 *    read-only плашку 77491 с «Начать новый диалог», не дожидаясь RTS.
 * Диалог, открытый уже сгоревшим, показываем так же; открытый уже закрытым сервером сгоревшим
 * не считаем (см. [BotExpirationTracker.sync]).
 */
internal class BotExpirationController(
    private val host: Host,
    private val tracker: BotExpirationTracker = BotExpirationTracker(),
    private val pollIntervalsMs: List<Long> = BOT_CLOSE_POLL_INTERVALS_MS,
) {

    /** Окружение презентера. Все методы зовутся на Main. */
    internal interface Host {
        /** Скоуп сессии диалога — пересоздаётся презентером, поэтому функция, а не значение. */
        fun scope(): CoroutineScope
        fun currentConversationId(): String
        fun isPseudoConversationId(conversationId: String): Boolean
        fun currentConversation(): DataConversation?
        /** В ленте показана стартовая ветка нового прогона бота. */
        fun templateShown(): Boolean
        fun newDialogEnabled(): Boolean
        fun canStartDialog(): Boolean
        fun restrictEnabled(): Boolean
        /** Состояние во вью: фильтр кнопок в ленте + плашка. */
        fun publish(expired: Boolean, plate: BotExpiredPlate)
        fun updateInput(conversation: DataConversation)
        /**
         * Перезапуск бота после закрытия на сервере: choose по текущему диалогу. Результат
         * хост сообщает через [onRestartResolved] — для него любой ответ choose, пришедший при
         * [isRestartPending], и есть ответ на перезапуск (в том числе повторный бутстрап после
         * возврата сети, если первый запрос упал офлайн).
         */
        fun restartRoutingBot()
        /** Догрузить историю диалога с сервера перед перезапуском; сбой — не ошибка. */
        suspend fun reloadHistory()
        suspend fun reloadConversation(conversationId: String): DataConversation?
    }

    private var timerJob: Job? = null
    private var pollJob: Job? = null
    private var restartJob: Job? = null

    // Закрытие на сервере увидено, бот перезапрашивается — метку держим до ответа choose.
    private var restartPending = false

    /** Есть ли у нас метка сгорания (null — бот не ждёт ответа или диалог не велком-бота). */
    val hasMark: Boolean get() = tracker.expirationSec != null

    /** Диалог закрыт сервером, ждём ответ choose на перезапуск бота (см. [Host.restartRoutingBot]). */
    fun isRestartPending(): Boolean = restartPending

    fun isExpired(): Boolean = tracker.isExpired()

    /** Писать в диалог сгоревшего бота нельзя (веб: isExpiredBotDialog), пока не показан новый прогон. */
    fun isInputHidden(): Boolean = tracker.isExpired() && !host.templateShown()

    fun plate(): BotExpiredPlate = botExpiredPlateFor(
        expired = tracker.isExpired(),
        templateShown = host.templateShown(),
        newDialogEnabled = host.newDialogEnabled(),
        canStartDialog = host.canStartDialog(),
    )

    /** Свежий объект диалога (conversationsFlow): метка, перехват оператором, таймер. */
    fun onConversation(conversation: DataConversation) {
        // close_delay бывает только у routing-бота; у остальных диалогов expiration_time — срок
        // жизни автосообщения (легаси-протухание попапов), его не трогаем.
        if (conversation.type != ConversationType.ROUTING_BOT.stringValue) return
        log { "sync conv=${conversation.id} closed=${conversation.closed} expiration=${conversation.expirationTime}" }
        tracker.sync(conversation.expirationTime, closedByServer = conversation.closed == true)
        // Диалог перехватил человек: реплика оператора или закрытие не от бота. Бэкенд при этом
        // сбрасывает assistant_type и бит закрытия такой диалог пропускает, но expiration_time не
        // чистит — без этого SDK «сжёг» бы диалог, в котором оператор продолжает писать.
        val last = conversation.partLast
        if (isBotExpirationSuperseded(last?.type, last?.sentVia)) tracker.cancel()
        arm(conversation)
        // Закрытие пришло по RTS conversation_closed (или с батчем) раньше опроса — не ждём
        // следующего тика, перезапускаем бота сразу.
        if (conversation.closed == true && tracker.isExpired()) onClosedByServer()
    }

    /**
     * Взвести (или снять) таймер по текущему состоянию метки и обновить UI. Вызывается и как
     * перепроверка: delay на Main спит вместе с устройством и после пробуждения не догоняет
     * пропущенное время (веб перепроверяет на visibilitychange/focus, презентер — в onResume).
     */
    fun arm(conversation: DataConversation? = host.currentConversation()) {
        timerJob?.cancel()
        timerJob = null
        publish()
        if (tracker.isExpired()) watchServerCloseIfNeeded()
        val decision = tracker.arm()
        log { "arm expiration=${tracker.expirationSec} expired=${tracker.isExpired()} decision=$decision" }
        when (decision) {
            BotExpirationTracker.Decision.None -> Unit
            BotExpirationTracker.Decision.Fire -> fire()
            is BotExpirationTracker.Decision.Wait -> timerJob = host.scope().launch {
                delay(decision.delayMs)
                arm()
            }
        }
    }

    /**
     * Сервер принял ответ боту или свободный текст: бэк снял метку и закрытие, снимаем и мы.
     * Только после успеха запроса — веб снимает оптимистично, но при сетевом сбое метка терялась бы
     * навсегда (sync игнорирует метки не новее снятой).
     */
    fun cancel() {
        tracker.cancel()
        timerJob?.cancel()
        timerJob = null
        pollJob?.cancel()
        pollJob = null
        restartJob?.cancel()
        restartJob = null
        restartPending = false
        publish()
    }

    /**
     * Ответ choose на перезапуск бота (хост зовёт при [isRestartPending]). found=true — шаблон
     * стартовой ветки уже у тела чата: плашка уйдёт по [Host.templateShown], метку снимет ответ
     * на новый прогон. found=false — бота нет (выключен, choose упал при живой сети): метку
     * отпускаем, иначе плашка без кнопки и скрытое поле ввода остались бы навсегда; без запрета
     * в закрытый диалог можно написать текстом, и он переоткроется.
     */
    fun onRestartResolved(found: Boolean) {
        if (!restartPending) return
        restartPending = false
        log { "restart resolved: conv=${host.currentConversationId()} found=$found" }
        if (found) return
        tracker.cancel()
        publish()
        host.currentConversation()?.let { host.updateInput(it) }
    }

    /** Показан/снят шаблон стартовой ветки — от него зависит плашка и поле ввода. */
    fun onTemplateStateChanged() = publish()

    /**
     * Ответ боту (веб: ChatBotButtons/BotAnswerField). Между «метка прошла» и «бит закрыл диалог»
     * сервер ответ ещё примет, а закрыть это окно может только клиент — запрос не шлём. Ответ на
     * стартовую ветку нового прогона ([isTemplateAnswer]) сгореть не мог: метка на диалоге
     * осталась от прошлого прогона, новый стартует на сервере только этим ответом.
     * @return true — отправку надо прервать, сгорание уже отработано.
     */
    fun interceptAnswer(isTemplateAnswer: Boolean): Boolean {
        if (isTemplateAnswer) return false
        if (!tracker.isExpired()) return false
        fire()
        return true
    }

    /**
     * Сервер ответил 400 «Conversation is already closed»: бот сгорел раньше нашего таймера
     * (часы, бит). При метке считаем её истёкшей и реагируем как на сгорание.
     * @return false — метки нет (лид-бот, бот не велком-типа): сгорания как состояния нет,
     *   презентер действует сам.
     */
    fun onAlreadyClosed(): Boolean {
        if (!hasMark) return false
        tracker.forceExpire()
        fire()
        // Сервер уже сказал, что диалог закрыт, — опроса не ждём, перезапуск (если он нужен) сразу.
        onClosedByServer()
        return true
    }

    /** Новая сессия диалога — прошлую метку не переносим (таймеры умерли вместе со скоупом). */
    fun reset() {
        tracker.reset()
        timerJob = null
        pollJob = null
        restartJob = null
        restartPending = false
    }

    // Бот сгорел, пока диалог был открыт: кнопки и ввод прячем сразу, внизу — плашка.
    private fun fire() {
        timerJob?.cancel()
        timerJob = null
        log { "bot expired: conv=${host.currentConversationId()} plate=${plate()}" }
        publish()
        host.currentConversation()?.let { host.updateInput(it) }
        watchServerCloseIfNeeded()
    }

    private fun publish() = host.publish(tracker.isExpired(), plate())

    // Плашка без кнопки: дальше диалог ведёт сервер, а он закрывает битом раз в минуту — RTS
    // conversation_closed может задержаться или не дойти, поэтому параллельно опрашиваем беседу,
    // пока диалог открыт (интервал растёт до минуты; бросать пользователя без кнопки нельзя).
    // reloadConversation обновляет репозиторий, свежий closed уходит в conversationsFlow.
    private fun watchServerCloseIfNeeded() {
        if (!shouldWatchServerClose(plate())) return
        if (pollJob?.isActive == true) return
        val conversationId = host.currentConversationId()
        if (conversationId.isEmpty() || host.isPseudoConversationId(conversationId)) return
        pollJob = host.scope().launch {
            var attempt = 0
            while (true) {
                delay(pollIntervalsMs[minOf(attempt, pollIntervalsMs.lastIndex)])
                attempt++
                // Метку сняли (ответ/прерывание), новый прогон уже на экране или перезапуск уже
                // запрошен по RTS — ждать нечего.
                if (!tracker.isExpired() || host.templateShown() || restartPending) return@launch
                val fresh = try {
                    host.reloadConversation(conversationId)
                } catch (e: CancellationException) {
                    throw e
                } catch (t: Throwable) {
                    SdkLogger.e(TAG, "poll: reload failed", t)
                    null
                }
                if (fresh?.closed == true) {
                    onClosedByServer()
                    return@launch
                }
            }
        }
    }

    // Сервер закрыл сгоревший диалог. Без запрета — перезапуск бота в этом же окне: метку держим
    // (кнопки сгоревшей ветки и поле ввода остаются скрытыми), догружаем историю и зовём choose;
    // ответ придёт в onRestartResolved. При запрете (CAR-77491) перезапуск невозможен по бэкенду:
    // ничего не делаем, updateInput переключит диалог на read-only плашку по closed=true.
    private fun onClosedByServer() {
        if (restartPending) return
        if (plate() != BotExpiredPlate.WAITING_RESTART) return
        val conversationId = host.currentConversationId()
        if (conversationId.isEmpty() || host.isPseudoConversationId(conversationId)) return
        val restricted = host.restrictEnabled()
        log { "conversation closed by server: conv=$conversationId restricted=$restricted" }
        if (restricted) return
        restartPending = true
        restartJob = host.scope().launch {
            try {
                host.reloadHistory()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                SdkLogger.e(TAG, "restart: history reload failed", t)
            }
            if (!restartPending) return@launch
            host.restartRoutingBot()
        }
    }

    private inline fun log(message: () -> String) =
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, TAG, message = message)

    private companion object {
        const val TAG = "BotExpiration"
    }
}

/**
 * Интервалы опроса закрытия на сервере после сгорания (CAR-77064): минуту часто (бит раз в минуту),
 * дальше реже — последний интервал повторяется, пока диалог открыт.
 */
internal val BOT_CLOSE_POLL_INTERVALS_MS: List<Long> =
    listOf(10_000L, 10_000L, 10_000L, 10_000L, 10_000L, 10_000L, 30_000L, 60_000L)

/**
 * Режим плашки после сгорания бота (CAR-77064).
 *  • бот не сгорел или новый прогон уже показан ([templateShown]) — плашки нет;
 *  • новые диалоги разрешены ([newDialogEnabled]) и пользователь может начать диалог
 *    ([canStartDialog], кнопка «Написать» не скрыта аппом) — «Диалог завершён» + «Начать новый диалог»;
 *  • иначе — «Диалог завершён» без кнопки: бот перезапустится здесь же после закрытия на сервере
 *    (см. [shouldWatchServerClose]).
 */
internal fun botExpiredPlateFor(
    expired: Boolean,
    templateShown: Boolean,
    newDialogEnabled: Boolean,
    canStartDialog: Boolean,
): BotExpiredPlate = when {
    !expired || templateShown -> BotExpiredPlate.NONE
    newDialogEnabled && canStartDialog -> BotExpiredPlate.START_NEW_DIALOG
    else -> BotExpiredPlate.WAITING_RESTART
}

/**
 * Опрашивать ли закрытие на сервере после сгорания. Только в режиме без кнопки: с кнопкой
 * пользователь уходит в новый диалог сам. Что делать по закрытию, решает контроллер: без запрета
 * писать в закрытые — перезапуск бота в этом же окне (метка держится до ответа choose), при
 * запрете (CAR-77491) — read-only плашка с кнопкой «Начать новый диалог», и чем раньше она
 * появится, тем меньше пользователь ждёт.
 */
internal fun shouldWatchServerClose(plate: BotExpiredPlate): Boolean =
    plate == BotExpiredPlate.WAITING_RESTART

/**
 * Перехватил ли диалог человек, после чего метка сгорания бота больше не актуальна: реплика
 * оператора или закрытие, отправленные не ботом. Части самого бота (sent_via=message_chat_bot) —
 * в том числе служебная реплика автозакрытия — метку не снимают.
 */
internal fun isBotExpirationSuperseded(lastPartType: String?, lastPartSentVia: String?): Boolean =
    (lastPartType == ResponseFields.REPLY_ADMIN || lastPartType == ResponseFields.PART_TYPE_CLOSED) &&
        lastPartSentVia != "message_chat_bot"
