package io.carrotquest_sdk.android.data.network.wss_responses;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.core.util.ConversationUtilsKt;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.util.ServerClock;
import io.carrotquest_sdk.android.data.network.wss_responses.conversation.ConversationRtsModel;


@Keep
public class ConversationStartedUserMessage implements IRtsMessage {

    @SerializedName(ResponseFields.CONVERSATION)
    ConversationRtsModel conversation;

    @SerializedName(ResponseFields.PARTS)
    List<MessageData> parts;

    @Override
    public void process() {
        // Серверное «сейчас» для часов сгорания бота (CAR-77064) — как веб в messageConversationStarted.
        if (parts != null && !parts.isEmpty()) {
            ServerClock.syncCreated(parts.get(0).getCreated());
        }
        if(ConversationUtilsKt.recipientTypeIsRight(conversation.getRecipientType())) {
            ArrayList<MessageData> messages = new ArrayList<>(parts);
            // Части здесь разобраны Gson'ом напрямую, минуя convertJsonToMessageData — инлайн-<img>
            // ручной рассылки переносим во вложения так же, как на остальных путях (CAR-77331).
            for (MessageData part : messages) {
                ConvertUtilsKt.extractInlineImages(part);
            }
            conversation.process(messages);
        }
    }
}