package io.carrotquest_sdk.android.presentation.container

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import io.carrotquest_sdk.android.domain.use_cases.tickets.refreshTickets
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.coroutines.SdkCoroutineExceptionHandler
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.constants.isPopUpConversationType
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.displayAdmin
import io.carrotquest_sdk.android.domain.use_cases.conversations.lastDisplayableConversationId
import io.carrotquest_sdk.android.domain.use_cases.conversations.unread
import io.carrotquest_sdk.android.domain.use_cases.popup.reshowPopup
import io.carrotquest_sdk.android.domain.use_cases.settings.isNewConversationButtonEnabled
import io.carrotquest_sdk.android.domain.use_cases.settings.isReplyToClosedConversationRestricted
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils
import io.carrotquest_sdk.android.presentation.mvp.utils.getPatternUrl
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

@Immutable
data class SdkContainerUiState(
    val accentColor: Color,
    val patternUrl: String?,
)

data class OperatorInfo(val name: String?, val avatarUrl: String?)

class SdkContainerViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(buildUiState())
    val uiState: StateFlow<SdkContainerUiState> = _uiState.asStateFlow()

    private val _navState = MutableStateFlow<SdkNavState>(SdkNavState.Determining)
    val navState: StateFlow<SdkNavState> = _navState.asStateFlow()

    private val _unreadConversationsCount = MutableStateFlow(0)
    val unreadConversationsCount: StateFlow<Int> = _unreadConversationsCount.asStateFlow()

    private val _operatorInfo = MutableStateFlow<OperatorInfo?>(null)
    val operatorInfo: StateFlow<OperatorInfo?> = _operatorInfo.asStateFlow()

    private val _closeEvent = Channel<Unit>(Channel.BUFFERED)
    val closeEvent = _closeEvent.receiveAsFlow()

    /**
     * ID последнего открытого непустого диалога в текущей сессии. Используется в [onBack]
     * для возврата из списка обратно в последний открытый чат.
     */
    private var lastOpenedDialogId: String? = null

    /**
     * Реальный id открытого диалога для шапки (оператор/непрочитанные). Отличается от
     * navState.conversationId для НОВОГО диалога: тот открывается с пустым id, а реальный
     * становится известен только после создания (newConversationFlow). navState намеренно НЕ
     * меняем — иначе DialogScreen пересоздаст фрагмент, а шапка перезапустит AnimatedContent.
     */
    private val _openDialogId = MutableStateFlow<String?>(null)

    // Счётчик запросов «новый черновой диалог» (navigateToDialog("", isNew = true)) — см. его
    // использование там же.
    private var newDraftCounter = 0

    init {
        // Обновляем accentColor и patternUrl при изменении настроек.
        // drop(1) — пропускаем реплеенную текущую эмиссию (раньше .skip(1) на Observable).
        SettingsRepository.getInstance().settingsChangesFlow()
            .drop(1)
            .onEach { _uiState.value = buildUiState() }
            .launchIn(viewModelScope)

        // Синхронизируем navState с репозиторием, чтобы старый код знал, какой диалог открыт.
        // Заодно запоминаем last-opened id для back-навигации из списка и сбрасываем resolved id.
        _navState.onEach { state ->
            val dialogState = state as? SdkNavState.Dialog
            val openedId = dialogState?.conversationId ?: ""
            ConversationsRepository.getInstance().saveOpenedConversation(openedId)
            // Для нового диалога openedId пуст → реальный id подхватим из newConversationFlow ниже.
            _openDialogId.value = openedId.takeIf { it.isNotEmpty() }
            // Экран тикета в lastOpenedDialogId НЕ запоминаем: «назад» со списка открыло бы
            // диалог тикета как обычный чат — без инфо-панели и заголовка тикета в шапке,
            // с системным back, закрывающим SDK.
            if (openedId.isNotEmpty() && dialogState?.ticketId == null) {
                lastOpenedDialogId = openedId
            }
        }.launchIn(viewModelScope)

        // Новый диалог открывается с пустым id; реальный id известен только после создания.
        // Подхватываем его, чтобы шапка нашла диалог (оператора/непрочитанные) в реалтайме,
        // не дожидаясь переоткрытия. Берём первый созданный диалог, пока мы в новом (id ещё пуст).
        ConversationsRepository.getInstance().newConversationFlow
            .onEach { conv ->
                if (_navState.value is SdkNavState.Dialog && _openDialogId.value == null) {
                    conv.id?.takeIf { it.isNotEmpty() }?.let { realId ->
                        _openDialogId.value = realId
                        lastOpenedDialogId = realId
                    }
                }
            }
            .launchIn(viewModelScope)

        // Реактивно обновляем имя оператора и счетчик непрочитанных.
        // Источник — conversationsChangesFlow() (changeSignal-driven, НЕ дедупит), а не
        // conversationsFlow (StateFlow дедупит равные по содержимому списки). При смене оператора
        // updateConversation переставляет тот же объект → StateFlow глотает эмиссию, и шапка не
        // обновлялась в реалтайме. Список диалогов уже на conversationsChangesFlow по той же причине.
        // Ищем диалог по _openDialogId (резолвнутый реальный id), а не navState.conversationId —
        // последний пуст для нового диалога.
        combine(
            ConversationsRepository.getInstance().conversationsChangesFlow(),
            _openDialogId
        ) { conversations, openId ->

            // 1. Считаем непрочитанные через канонический фильтр unread() (id + unreadPartsCount>0 +
            // recipientTypeIsRight) — тот же, что у публичного getUnreadConversations. Раньше шапка
            // считала сырой список по одному unreadPartsCount>0, БЕЗ recipientType-фильтра: пагинация
            // подтягивала диалоги с чужим recipientType ("web" и пр.), и счётчик раздувался до 99+.
            // Исключаем открытый прямо сейчас диалог и тикет-диалоги: они хранятся в общем кэше
            // (нужны пайплайну открытого тикета), но их непрочитанное считает TicketsRepository —
            // иначе бейдж «Сообщений» задваивал бы счёт с бейджем «Тикетов».
            _unreadConversationsCount.value = conversations.unread()
                .count { it.id != openId && !it.isTicketConversation }

            // 2. Обновляем данные оператора, если мы в диалоге — в отдельный StateFlow,
            // чтобы не менять navState и не провоцировать повторную анимацию AnimatedContent.
            if (openId != null) {
                val conversation = conversations.find { it.id == openId }
                // displayAdmin, а не lastAdmin: шапка обязана показывать ту же персону,
                // что превью в списке и аватарки сообщений (у ботов это message_sender)
                val admin = conversation?.displayAdmin()
                val newName = admin?.name
                val newAvatar = admin?.avatar
                val current = _operatorInfo.value
                if (newName != current?.name || newAvatar != current?.avatarUrl) {
                    _operatorInfo.value = OperatorInfo(name = newName, avatarUrl = newAvatar)
                }
            }
        }.launchIn(viewModelScope)
    }

    override fun onCleared() {
        super.onCleared()
        // Сбрасываем ID открытого диалога при уничтожении ViewModel
        ConversationsRepository.getInstance().saveOpenedConversation("")
    }

    /**
     * Тап по диалогу из списка. Поп-ап-беседы (типы popup_* и block_popup_*) не открываем как чат —
     * там нет сообщений и тело было бы пустым (баг #11); вместо этого заново показываем сам поп-ап
     * оверлеем. Обычные беседы открываем как диалог.
     */
    fun onConversationClicked(conversationId: String) {
        val type = ConversationsRepository.getInstance()
            .getConversationById(conversationId)?.type
        if (isPopUpConversationType(type)) {
            viewModelScope.launch(SdkCoroutineExceptionHandler) { reshowPopup(conversationId) }
        } else {
            navigateToDialog(conversationId)
        }
    }

    /**
     * Тап по кнопке «Написать» в списке диалогов. Если апп запретил создавать новые диалоги
     * (messenger_enable_new_conversation_button == false) — открываем последний диалог, и только
     * при его отсутствии создаём новый пустой. Решение синхронное: и флаг, и id уже в памяти.
     *
     * Зовём navigateToDialog напрямую, а не onConversationClicked: поп-ап-беседы отфильтрованы
     * в lastDisplayableConversationId, и уход в reshowPopup по кнопке «Написать» был бы багом.
     */
    fun onWriteButtonClicked() {
        val lastConversationId = if (isNewConversationButtonEnabled(getApplication())) {
            null
        } else {
            // «Один диалог за раз, в закрытые писать нельзя» (CAR-77491): последний диалог закрыт
            // и апп запретил в него писать — создаём новый, как и кнопка на плашке закрытого диалога.
            lastDisplayableConversationId()?.takeUnless { isConversationReadOnly(it) }
        }

        if (lastConversationId != null) {
            navigateToDialog(lastConversationId)
        } else {
            navigateToDialog("", isNew = true)
        }
    }

    private fun isConversationReadOnly(conversationId: String): Boolean =
        isReplyToClosedConversationRestricted(getApplication()) &&
            ConversationsRepository.getInstance().getConversationById(conversationId)?.closed == true

    fun navigateToDialog(conversationId: String, isNew: Boolean = false) {
        val conversation = if (conversationId.isNotEmpty()) {
            ConversationsRepository.getInstance().getConversationById(conversationId)
        } else null

        // displayAdmin — та же персона, что в превью списка (у ботов message_sender)
        val admin = conversation?.displayAdmin()
        _operatorInfo.value = OperatorInfo(
            name = admin?.name,
            avatarUrl = admin?.avatar
        )
        _navState.value = SdkNavState.Dialog(
            conversationId = conversationId,
            isNew = isNew,
            // Пустой id у ВСЕХ черновиков одинаков ("") — без токена повторный запрос
            // нового диалога после того, как предыдущий черновик уже материализовался в
            // реальную (и, возможно, уже закрытую) беседу под тем же navState.conversationId
            // (см. комментарий у _openDialogId выше), даёт структурно РАВНЫЙ Dialog(...).
            // MutableStateFlow не эмитит дубликат → экран не меняется, хотя обработчик
            // отработал полностью (CAR-77493: кнопка «Создать новый диалог» на плашке
            // закрытого диалога молча переставала работать после первого использования).
            newDraftToken = if (isNew && conversationId.isEmpty()) ++newDraftCounter else 0,
        )
    }

    fun navigateToList() {
        _operatorInfo.value = null
        _navState.value = SdkNavState.ConversationList
    }

    /**
     * Экран тикета: лента диалога тикета в ticket mode + инфо-панель (Шаг 6 тикетов).
     * conversationId пуст у тикета без диалога (nullable на бэке) — рендерится только панель.
     * lastOpenedDialogId сознательно не трогаем: «назад со списка» не должен вести в тикет.
     */
    fun navigateToTicket(ticketId: String, conversationId: String?) {
        _operatorInfo.value = null
        _navState.value = SdkNavState.Dialog(
            conversationId = conversationId ?: "",
            isNew = false,
            ticketId = ticketId,
        )
        // Список мог устареть, пока пользователь был на других экранах, — обновляем,
        // чтобы StateFlow-lookup экрана (панель/шапка) показал актуальный статус
        // (веб делает так же в onMount страницы тикета). Дубли схлопывает in-flight guard.
        viewModelScope.launch(SdkCoroutineExceptionHandler) { refreshTickets() }
    }

    fun onBack() {
        when (val state = _navState.value) {
            // Из диалога системная "Назад" полностью закрывает SDK — пользователь
            // попадает обратно в своё приложение, а не на промежуточный список.
            // Исключение — экран тикета: он открывается только из вкладки «Тикеты»,
            // назад возвращаемся в список (вкладка сохранена rememberSaveable).
            is SdkNavState.Dialog ->
                if (state.ticketId != null) navigateToList() else _closeEvent.trySend(Unit)

            // Из списка — возврат в последний открытый диалог, или в новый пустой,
            // если в этой сессии ничего не открывали.
            is SdkNavState.ConversationList -> {
                val id = lastOpenedDialogId
                if (!id.isNullOrEmpty()) {
                    navigateToDialog(id)
                } else {
                    navigateToDialog("", isNew = true)
                }
            }

            // Determining — начальная загрузка, нечего показывать; закрываем SDK.
            is SdkNavState.Determining -> _closeEvent.trySend(Unit)
        }
    }

    fun close() {
        _closeEvent.trySend(Unit)
    }

    private fun buildUiState(): SdkContainerUiState {
        val ctx = getApplication<Application>()
        val settings = SettingsRepository.getInstance().getSettingsObject()

        // Fallback chain для cold start через push: при запуске приложения через PendingIntent
        // SDK ещё не инициализирован, SettingsRepository пуст. Берём кэш из SharedPreferences,
        // куда SettingsManager сохраняет цвет аппа и pattern при каждом успешном connect.
        val rawColor = (settings?.originalAppColor ?: settings?.appColor)?.takeIf { it.isNotEmpty() }
            ?: io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib.getString(
                ctx, io.carrotquest_sdk.android.data.settings.SettingsManager.CACHED_ORIGINAL_APP_COLOR
            ).takeIf { !it.isNullOrEmpty() }
            ?: io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib.getString(
                ctx, io.carrotquest_sdk.android.data.settings.SettingsManager.CACHED_APP_COLOR
            ).takeIf { !it.isNullOrEmpty() }

        val normalizedColor = rawColor?.removePrefix("#")?.takeIf { it.isNotEmpty() }
        val accentColor = if (normalizedColor != null) {
            val contrastHex = AppColorUtils.getColorPalette(ctx, normalizedColor).contrastAccentColor
            Color("#$contrastHex".toColorInt())
        } else {
            Color(ContextCompat.getColor(ctx, R.color.colorButton))
        }
        val isDark = getThemeUseCase(ctx) == ThemeSdk.DARK
        val rawPattern = settings?.messengerPattern?.takeIf { it.isNotEmpty() }
            ?: io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib.getString(
                ctx, io.carrotquest_sdk.android.data.settings.SettingsManager.CACHED_MESSENGER_PATTERN
            ).takeIf { !it.isNullOrEmpty() }
        val patternUrl = rawPattern?.let { getPatternUrl(it, isDark) }
        return SdkContainerUiState(accentColor = accentColor, patternUrl = patternUrl)
    }
}
