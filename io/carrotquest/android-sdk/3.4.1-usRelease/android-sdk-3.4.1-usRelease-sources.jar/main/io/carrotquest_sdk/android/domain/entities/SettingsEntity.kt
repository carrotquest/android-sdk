package io.carrotquest_sdk.android.domain.entities

import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.presentation.constans.StatusOperators

data class SettingsEntity (
        val userId: String,
        val isShowVK: Boolean = false,
        val textLinkVK: String? = null,
        val isShowViber: Boolean = false,
        val textLinkViber: String? = null,
        val isShowFB: Boolean = false,
        val textLinkFB: String? = null,
        val isShowTelegram: Boolean = false,
        val textLinkTelegram: String? = null,
        val isShowInstagram: Boolean = false,
        val textLinkInstagram: String? = null,
        val isShowWhatsapp: Boolean = false,
        val textLinkWhatsapp: String? = null,
        val appColor: String? = null,
        val originalAppColor: String? = null,
        val welcomeMessage: String? = null,
        val messengerAvatar: String? = null,
        val showPoweredBy: Boolean = false,
        val sourceData: String,
        val appName: String?,
        val appId: String?,
        val showLinkKbAtWelcomeMessage: Boolean = false,
        val statusOperators: StatusOperators = StatusOperators.UNKNOWN,
        val onlineMessage: String? = null,
        val offlineMessage: String? = null,
        val showOfflineMessage: Boolean = true,
        val admins: ArrayList<Admin>,
        val theme: String?,
        val locale: String,
        val messengerPattern: String? = null,
        // null = тикет-система выключена; число >= 0 = включена (стартовый счётчик непрочитанных)
        val ticketsUnread: Int? = null,
        // false — апп запретил создавать новые диалоги: кнопка «Написать» открывает последний
        // диалог вместо создания нового. Дефолт true = прежнее поведение.
        val enableNewConversationButton: Boolean = true,
        // false — апп выключил голосовые: кнопка микрофона в инпуте скрыта. Прослушивание уже
        // присланных голосовых от настройки не зависит. Дефолт true = прежнее поведение.
        val enableAudioMessages: Boolean = true,
        // true — апп запретил писать в финально закрытые диалоги (CAR-77491): такой диалог
        // read-only, вместо поля ввода — плашка с кнопкой нового диалога. Дефолт false.
        val restrictReplyToClosedConversation: Boolean = false,
        // Бэкенд прислал ключ messenger_restrict_reply_to_closed_conversation (любым значением) —
        // значит, релиз с каналом RTS conversation_closed уже выкатан и на него можно подписываться.
        // Подписка на канал, которого RTS-сервер не знает, ронит ВСЁ соединение (scope check).
        val supportsConversationClosedRts: Boolean = false,
        // false — апп запретил писать оператору: кнопки «Написать» и поля ввода нет. Ответ боту
        // (property_field) и экран тикета настройке не подчиняются — см. isWriteButtonAndInputEnabled.
        // Дефолт true = прежнее поведение.
        val showWriteButtonAndInput: Boolean = true,
)