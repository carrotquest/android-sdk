package io.carrotquest_sdk.android.domain.use_cases.settings

import android.content.Context
import io.carrotquest_sdk.android.data.settings.SettingsManager

/**
 * Настройка аппа messenger_show_write_button_and_input — можно ли писать оператору.
 *
 * true (и значение по умолчанию) — всё как раньше: кнопка «Написать» в списке диалогов и
 * поле ввода в диалоге на месте.
 * false — апп запретил писать: кнопки «Написать» нет, поле ввода скрыто. Настройке НЕ
 * подчиняются (как и в вебе, см. respectWriteButtonSetting):
 *  - ответ боту с полем ввода (property_field) — веб показывает BotAnswerField независимо;
 *  - экран тикета — там поле открывает своё действие пользователя («Дополнить тикет»).
 *
 * Источники по порядку: настройки в памяти → кэш SharedPreferences (настройки ещё не пришли:
 * cold start через push, обрыв сети) → true. Кэш пишет [SettingsManager] при каждом connect.
 */
fun isWriteButtonAndInputEnabled(context: Context): Boolean {
    getSettings()?.let { return it.showWriteButtonAndInput }
    return SettingsManager.cachedFlagOrTrue(
        context,
        SettingsManager.CACHED_SHOW_WRITE_BUTTON_AND_INPUT
    )
}
