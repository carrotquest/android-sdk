package io.carrotquest_sdk.android.lib.network

import retrofit2.HttpException

// Тексты ошибок бэка (cqapi messages/exceptions.py). Стабильного кода в теле нет — матчим по
// имени класса (meta.error) и сообщению (meta.error_message), как веб для закрытых тикетов
// (CLOSED_TICKET_REPLY_ERROR).
//  • ConversationReopenRestrictedError — апп запретил писать в закрытые диалоги (CAR-77491):
//    reply и meta_data (кнопка бота) в финально закрытый диалог → 400.
//  • ConversationAlreadyClosedError — кнопка бота нажата в уже закрытом ботом диалоге.
private val CLOSED_MARKERS = listOf(
    "ConversationReopenRestrictedError",
    "restricts reopening closed conversations",
    "ConversationAlreadyClosedError",
    "Conversation is already closed",
)

/**
 * Сервер отверг реплику/ответ боту, потому что диалог закрыт (HTTP 400). Данные не записаны,
 * поэтому такую ошибку показываем не как «не удалось отправить», а переводим UI в состояние
 * «диалог закрыт» (DialogPresenter.onConversationClosedByServer).
 */
internal fun Throwable.isConversationClosedError(): Boolean = when (this) {
    is ReplySendException -> httpCode == 400 && serverBody.containsClosedMarker()
    is HttpException -> code() == 400 && errorBodySafe().containsClosedMarker()
    else -> false
}

private fun String.containsClosedMarker(): Boolean = CLOSED_MARKERS.any { contains(it) }

// errorBody().string() одноразовый и может бросить — диагностика не должна подменять ошибку.
private fun HttpException.errorBodySafe(): String = try {
    response()?.errorBody()?.string().orEmpty()
} catch (t: Exception) {
    ""
}
