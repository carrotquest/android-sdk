package io.carrotquest_sdk.android.data.network.wss_responses

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.lib.network.F

/**
 * RTS conversation_closed.{app}.{user} (CAR-77491): диалог финально закрыт — оператором, действием
 * бота или автозакрытием по тайм-ауту. Данные: {"conversation": "<id>"}, реплики нет.
 *
 * Бэкенд шлёт событие независимо от настройки messenger_restrict_reply_to_closed_conversation,
 * поэтому здесь только фиксируем факт (closed=true в репозитории); решение «read-only или нет»
 * принимает UI диалога по настройке (DialogPresenter.updateInput). Если беседы в репозитории нет
 * (диалог ещё не открывался) — ничего не делаем: при открытии актуальный closed придёт по HTTP.
 */
class ConversationClosedRtsMessage : IRtsMessage {

    @SerializedName(F.CONVERSATION)
    val conversationId: String = ""

    override fun process() {
        if (conversationId.isEmpty()) return
        val repository = ConversationsRepository.getInstance()
        val conversation = repository.getConversationById(conversationId) ?: run {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, TAG) {
                "conversation_closed: conv=$conversationId not in repository, skip"
            }
            return
        }
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, TAG) {
            "conversation_closed: conv=$conversationId (was closed=${conversation.closed})"
        }
        conversation.closed = true
        // sourceJsonData — второй источник правды для части экранов; держим в согласии с полем.
        conversation.sourceJsonData?.addProperty(F.CLOSED, true)
        repository.updateConversation(conversationId, conversation)
    }

    private companion object {
        const val TAG = "ConversationClosedRts"
    }
}
