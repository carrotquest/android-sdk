package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

import io.carrotquest_sdk.android.lib.utils.loging.LogToElk;
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType;
import io.carrotquest_sdk.android.lib.wss.ChannelEnum;
import io.carrotquest_sdk.android.lib.wss.response.WssResponse;
import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.data.network.AdminTypingMessageDeserializer;
import io.carrotquest_sdk.android.data.network.ConversationBatchDeserializer;
import io.carrotquest_sdk.android.data.network.ConversationReplyChangedMessageDeserializer;
import io.carrotquest_sdk.android.data.network.ConversationReplyMessageDeserializer;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.logging.SdkLogCategory;
import io.carrotquest_sdk.android.core.logging.SdkLogLevel;
import io.carrotquest_sdk.android.core.logging.SdkLogger;
import io.carrotquest_sdk.android.data.network.PopUpDeserializer;
import io.carrotquest_sdk.android.domain.use_cases.conversations.UpdateOpenedConversationIdUseCaseKt;

public class RtsMessageFactory {
    private static final String TAG = "RtsMessageFactory";
    //private static ArrayList<String> ids = new ArrayList<>();
    private static CopyOnWriteArrayList<PrMessage> processedMessages = new CopyOnWriteArrayList<>();


    private static String appId = Carrot.getAppId();

    private static class PrMessage {
        private final String id;
        private final int messageHashCode;

        PrMessage(String id, String message) {
            this.id = id;
            this.messageHashCode = message == null ? 0 : message.hashCode();
        }

        public String getId() {
            return id;
        }

        public int getMessageHashCode() {
            return messageHashCode;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            PrMessage prMessage = (PrMessage) o;
            return id.equals(prMessage.id) && messageHashCode == prMessage.messageHashCode;
        }

        @Override
        public int hashCode() {
            return Objects.hash(id, messageHashCode);
        }
    }

    private static final Gson gson = new GsonBuilder()
            .registerTypeAdapter(ConversationReplyMessage.class, new ConversationReplyMessageDeserializer())
            .registerTypeAdapter(ConversationReplyChangedMessage.class, new ConversationReplyChangedMessageDeserializer())
            .registerTypeAdapter(PopUpMessage.class, new PopUpDeserializer())
            .registerTypeAdapter(ConversationTypingResponse.class, new AdminTypingMessageDeserializer())
            .registerTypeAdapter(ConversationPartsBatchRtsMessage.class, new ConversationBatchDeserializer())
            .create();

    public static IRtsMessage createResponse(WssResponse response) {
        // Общий try/catch: любой malformed WSS-пакет (null fields, unexpected types,
        // сломанная структура от proxy/бэкэнда) не должен ломать всю RTS-подписку.
        // Конкретный битый пакет пропускается, остальные продолжают обрабатываться.
        try {
            if (response == null || response.getChannel() == null) return null;
            int index = response.getChannel().indexOf('.') > 1 ? response.getChannel().indexOf('.') : response.getChannel().length();
            String channelName = response.getChannel().substring(0, index);
            String id = response.getId();


            String rawMessage = response.getMessage() == null ? "" : response.getMessage().toString();
            PrMessage prMessage = new PrMessage(id, rawMessage);
            boolean isDuplicate = processedMessages.contains(prMessage);

            // Трассировка входящего RTS-потока: канал, id фрейма, дубль-флаг и размер payload.
            // Без тела сообщения (PII) — безопасно для релиза. DEBUG по умолчанию молчит,
            // попадает в getDiagnostics при включённом DEBUG-уровне.
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, TAG,
                    "RTS in: channel=" + channelName + " frameId=" + id
                            + (isDuplicate ? " DUPLICATE→skip" : "") + " size=" + rawMessage.length());

            if (!isDuplicate) {
                // Если сообщений пришло уже много, то очищаем массив с обработанными сообщениями, чтобы не переполнять память
                if (processedMessages.size() > 500) {
                    processedMessages.clear();
                }
                processedMessages.add(prMessage);

                if (channelName.equalsIgnoreCase(ChannelEnum.conversation_reply.name())) {
                    //ConversationReplyMessage reply = gson.fromJson(response.getMessage(), ConversationReplyMessage.class);
                    //return reply;
                    return null;
                } else if (channelName.equalsIgnoreCase(ChannelEnum.conversation_read.name())) {
                    return new Gson().fromJson(response.getMessage(), ConversationReadMessage.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.message_conversation_started.name())) {
                    sendLog(response, channelName);
                    ConversationStartedUserMessage conversationStartedUserMessage = new Gson().fromJson(response.getMessage(), ConversationStartedUserMessage.class);
                    if (conversationStartedUserMessage != null && conversationStartedUserMessage.conversation != null) {
                        conversationStartedUserMessage.conversation.updateConversationSource(response.getMessage());
                        String conversationType = conversationStartedUserMessage.conversation.getType();
                        if ("routing_bot".equals(conversationType)) {
                            UpdateOpenedConversationIdUseCaseKt.updateOpenedConversationId(conversationStartedUserMessage.conversation.getId());
                        }
                    }
                    return conversationStartedUserMessage;
                } else if (channelName.equalsIgnoreCase(ChannelEnum.users_removed.name())) {
                    sendLog(response, channelName);
                    return new Gson().fromJson(response.getMessage(), UsersRemovedResponse.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.user_ban.name())) {
                    sendLog(response, channelName);
                    return new Gson().fromJson(response.getMessage(), UserBanResponse.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.conversation_typing.name())) {
                    return gson.fromJson(response.getMessage(), ConversationTypingResponse.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.conversation_assigned.name())) {
                    return new Gson().fromJson(response.getMessage(), ConversationAssigned.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.app_online_changed.name())) {
                    sendLog(response, channelName);
                    return new Gson().fromJson(response.getMessage(), AppOnlineChanged.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.popup.name())) {
                    //return new Gson().fromJson(response.getMessage(), PopUpMessage.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.conversation_reply_changed.name())) {
                    sendLog(response, channelName);
                    return gson.fromJson(response.getMessage(), ConversationReplyChangedMessage.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.chat_bot_conversation_finished.name())) {
                    sendLog(response, channelName);
                    return gson.fromJson(response.getMessage(), ChatBotFinishedRtsMessage.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.conversation_parts_batch.name())) {
                    sendLog(response, channelName);
                    return gson.fromJson(response.getMessage(), ConversationPartsBatchRtsMessage.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.ticket.name())) {
                    sendLog(response, channelName);
                    return gson.fromJson(response.getMessage(), TicketRtsMessage.class);
                } else if (channelName.equalsIgnoreCase(ChannelEnum.conversation_closed.name())) {
                    sendLog(response, channelName);
                    return gson.fromJson(response.getMessage(), ConversationClosedRtsMessage.class);
                }
            }
            return null;
        } catch (Throwable t) {
            Log.e(TAG, "createResponse failed, skipping pkt: " + t);
            return null;
        }
    }

    private static void sendLog(WssResponse response, String channelName) {
        try {
            Map<String, Object> params = new HashMap<>();
            params = gson.fromJson(response.getMessage(), params.getClass());
            LogToElk.getInstance().write(appId, "RTS message: " + channelName, MessageToElkType.RTS_MESSAGE, new HashMap<>(params));
        } catch (Exception e) {
            Log.e(TAG+ "_SendLog", e);
        }
    }
}