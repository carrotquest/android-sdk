package io.carrotquest_sdk.android.lib.wss.utils

import com.google.gson.JsonElement
import io.carrotquest_sdk.android.lib.network.F

// Начало error_message RTS-сервера при отказе по scope (api/auth/channels.py,
// check_access_to_channels). Сервер обрезает сообщение до 120 символов и дописывает "...".
private const val NO_ACCESS_PREFIX = "No access to channels:"
private const val TRUNCATION_MARK = "..."

/**
 * Разбор текстового фрейма-отказа RTS-сервера на хендшейке подписки.
 *
 * Обычные фреймы RTS несут `id`/`channel`/`message`; отказ приходит без них — обёрткой
 * `{"error": {"status": 403, "error": "PermissionDeniedError", "error_message": "…", "url": "…"}}`
 * (api/exception_handlers.py, handle_websocket_error: `send_json({"error": err_data})`, затем
 * close с кодом 3000+status). На всякий случай принимаем и плоскую форму без обёртки.
 * Отказ по scope (`PermissionDeniedError`, «No access to channels: a, b»)
 * сервер выносит на ВСЁ соединение: одного канала, которого он не знает или не даёт юзеру
 * (рассинхрон релизов RTS и бэкенда, старый стенд), достаточно, чтобы realtime умер целиком, а
 * реконнект-петля увела сессию в recovery. Клиент реагирует точечно — переподписывается без
 * запрещённых каналов (JwtClientWebSocket).
 *
 * @return имена запрещённых каналов (часть до первой точки: `conversation_closed.4.123` →
 *   `conversation_closed`), или null, если фрейм — не отказ по scope. Обрезанный сервером хвост
 *   (без точки) отбрасывается: по нему имя канала не восстановить, но следующий хендшейк без
 *   уже вырезанных каналов покажет остаток полным.
 */
internal fun parseForbiddenChannels(frame: JsonElement?): List<String>? {
    val root = frame?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
    if (root.has(F.ID)) return null
    // Обёртка {"error": {...}} — основная форма; плоская — запасная.
    val wrapped = root.get(F.ERROR)?.takeIf { it.isJsonObject }?.asJsonObject
    val obj = wrapped ?: root
    if (!obj.has(F.STATUS)) return null
    val status = runCatching { obj.get(F.STATUS).asInt }.getOrNull() ?: return null
    if (status != 403) return null
    val message = runCatching { obj.get(F.ERROR_MESSAGE)?.asString }.getOrNull() ?: return null
    if (!message.startsWith(NO_ACCESS_PREFIX)) return null

    val list = message.removePrefix(NO_ACCESS_PREFIX).removeSuffix(TRUNCATION_MARK)
    return list.split(',')
        .map { it.trim() }
        .filter { it.contains('.') }
        .map { it.substringBefore('.') }
        .filter { it.isNotEmpty() }
        .distinct()
}
