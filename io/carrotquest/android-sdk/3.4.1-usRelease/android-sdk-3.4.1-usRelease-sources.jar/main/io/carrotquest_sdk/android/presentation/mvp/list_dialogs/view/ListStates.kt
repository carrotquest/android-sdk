package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.remember
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.ErrorContent
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ErrorType
import io.carrotquest_sdk.android.presentation.tickets.ListTab
import io.carrotquest_sdk.android.presentation.tickets.SegmentedTabs
import androidx.core.net.toUri

internal val WriteButtonHeight = 52.dp

// ── Ошибка (список диалогов) ──────────────────────────────────────────────────

@Composable
internal fun ListErrorContent(errorType: ErrorType, isDark: Boolean, onRetry: () -> Unit) {
    // Единые формулировки с телом диалога (chat_error_*) — экран ошибки унифицирован (см. ErrorContent).
    val (title, message) = when (errorType) {
        ErrorType.NO_INTERNET -> Pair(
            stringResource(R.string.chat_error_no_internet_title),
            stringResource(R.string.chat_error_no_internet_message)
        )
        ErrorType.AIRPLANE_MODE -> Pair(
            stringResource(R.string.chat_error_airplane_title),
            stringResource(R.string.chat_error_airplane_message)
        )
        ErrorType.SOMETHING_WENT_WRONG -> Pair(
            stringResource(R.string.chat_error_generic_title),
            stringResource(R.string.chat_error_generic_message)
        )
    }
    ErrorContent(
        title = title,
        message = message,
        retryText = stringResource(R.string.chat_retry),
        isDark = isDark,
        onRetry = onRetry
    )
}

// ── Пустой список ─────────────────────────────────────────────────────────────

@Composable
internal fun EmptyState(
    isDark: Boolean,
    bottomPadding: Dp = 0.dp,
    // false — апп запретил писать (messenger_show_write_button_and_input): кнопки «Написать»
    // внизу нет, поэтому и подсказка про неё меняется на нейтральную (текст веб-виджета).
    writeButtonEnabled: Boolean = true,
) {
    val cardBg = SdkColors.background(isDark)
    // Низ резервирует ровно высоту плавающего низа (кнопка + подложка), измеренную один раз
    // вызывающим — навбар в неё уже входит, повторно не прибавляем (см. ListContentScreen).
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = bottomPadding + 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .background(cardBg)
                .padding(horizontal = 24.dp, vertical = 40.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.ic_cq_zero_conversations_list),
                contentDescription = null,
                modifier = Modifier.size(50.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = stringResource(R.string.empty_conversation_list_title),
                color = SdkColors.secondaryText(isDark),
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(
                    if (writeButtonEnabled) R.string.empty_conversation_list_message
                    else R.string.cq_sdk_empty_conversation_list_message_no_write
                ),
                color = SdkColors.secondaryText(isDark).copy(alpha = 0.6f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Нижняя подложка: сегмент-табы и/или плашка Powered by ─────────────────────

internal val PoweredByHeight = 33.dp

/**
 * Белая подложка, приклеенная к низу списка. Рисуется, когда есть что показать —
 * табы (включена тикет-система) и/или плашка «Работает на …». Скруглены верхние углы (30dp)
 * и отбрасывается мягкая тень (по макету — вверх на ленту).
 *
 * Навбар НЕ добавляем: контейнер SDK уже оборачивает контент в navigationBarsPadding()
 * (SdkContainerActivity), а фон карточки заходит под навбар — свой отступ здесь = двойной учёт
 * (низ раздувался при кнопочной навигации).
 */
@Composable
internal fun BottomTabPanel(
    showTabs: Boolean,
    selectedTab: ListTab,
    messagesUnreadCount: Int,
    ticketsUnreadCount: Int,
    showPoweredBy: Boolean,
    appName: String,
    isDark: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onSelectTab: (ListTab) -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            // Панель — pointer-input узел: тапы по «мёртвым» зонам (паддинги, зазоры) не должны
            // проваливаться в список под ней и открывать невидимые карточки
            .pointerInput(Unit) {}
            .panelUpwardShadow(cornerRadius = PanelCornerRadius)
            .clip(RoundedCornerShape(topStart = PanelCornerRadius, topEnd = PanelCornerRadius))
            .background(SdkColors.pageBackground(isDark))
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showTabs) {
            SegmentedTabs(
                selected = selectedTab,
                messagesUnreadCount = messagesUnreadCount,
                ticketsUnreadCount = ticketsUnreadCount,
                isDark = isDark,
                accentColor = accentColor,
                onSelect = onSelectTab
            )
        }
        if (showTabs && showPoweredBy) {
            Spacer(modifier = Modifier.height(16.dp))
        }
        if (showPoweredBy) {
            PoweredByBar(appName = appName)
        }
    }
}

// ── Плашка «Работает на / Powered by» ────────────────────────────────────────

@Composable
internal fun PoweredByBar(appName: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val providerName = when (BuildConfig.FLAVOR) {
        "common" -> "Carrot quest"
        "us" -> "Dashly"
        else -> "Dashly"
    }
    val providerIcon = when (BuildConfig.FLAVOR) {
        "common" -> R.drawable.ic_cq_logo_carrot
        "us" -> R.drawable.ic_logo_dashly
        else -> R.drawable.ic_logo_dashly
    }
    val urlBase = when (BuildConfig.FLAVOR) {
        "common" -> "https://www.carrotquest.io/"
        "us" -> "https://www.dashly.io/"
        else -> "https://www.dashly.io/"
    }
    val url = "${urlBase}?utm_campaign=testdrive&utm_medium=outbound&utm_source=cqchat" +
            "&utm_term=mobile&app_name=${Uri.encode(appName)}&platform=android"

    Row(
        // Без fillMaxWidth: Row обворачивает контент по ширине — нужно, чтобы в чате плашку можно
        // было показать «плавающей» скруглённой пилюлей (фон/паддинги приходят через modifier).
        // В списке (BottomTabPanel) контент по-прежнему центрируется самим Column'ом.
        modifier = modifier
            .height(PoweredByHeight)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                context.startActivity(Intent(Intent.ACTION_VIEW, url.toUri()))
            },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = stringResource(R.string.popup_powered_by_start_text),
            color = SdkColors.sectionLabel,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            painter = painterResource(providerIcon),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = Color.Unspecified
        )
        if (providerName.isNotEmpty()) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = providerName,
                color = SdkColors.sectionLabel,
                fontSize = 12.sp
            )
        }
    }
}

internal val PanelCornerRadius = 30.dp

/**
 * Тень панели по макету (Chat/Content-shadow: #000 @10%, offset −20, blur 50) — мягкий
 * градиент, поднимающийся над верхней кромкой. Рисуется строго ВНЕ скруглённого контура
 * панели (clipPath Difference): тень заполняет и «выемки» углов, обнимая кривую, поэтому
 * скругление остаётся читаемым. Прямая градиентная полоса без выреза по контуру визуально
 * «съедает» углы — не заменять на неё (проверено на предыдущей итерации).
 */
private fun Modifier.panelUpwardShadow(
    cornerRadius: Dp,
    height: Dp = 40.dp,
    color: Color = SdkColors.panelShadow
): Modifier = drawBehind {
    val h = height.toPx()
    val r = cornerRadius.toPx()
    val panelPath = Path().apply {
        addRoundRect(
            RoundRect(
                left = 0f,
                top = 0f,
                right = size.width,
                bottom = size.height,
                topLeftCornerRadius = CornerRadius(r, r),
                topRightCornerRadius = CornerRadius(r, r),
                bottomLeftCornerRadius = CornerRadius.Zero,
                bottomRightCornerRadius = CornerRadius.Zero
            )
        )
    }
    clipPath(panelPath, ClipOp.Difference) {
        // Градиент до y=0 (кромка); ниже, в угловых выемках, — ровный цвет кромки (Clamp)
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, color),
                startY = -h,
                endY = 0f
            ),
            topLeft = Offset(0f, -h),
            size = Size(size.width, h + r)
        )
    }
}

// ── Плавающая кнопка «Написать» ───────────────────────────────────────────────

/**
 * Кнопка «Написать» — плавает над нижней подложкой (или над лентой, если подложки нет).
 * Отбрасывает мягкую тень (по макету — двухслойную; аппроксимируем штатной [shadow]).
 * [bottomPadding] задаёт зазор до подложки, а без подложки — небольшой отступ от края.
 * [enabled] = false во время fade-out (AnimatedVisibility держит узел кликабельным весь
 * exit): тап по гаснущей кнопке не должен открывать новый диалог с вкладки «Тикеты».
 */
@Composable
internal fun FloatingWriteButton(
    accentColor: Color,
    bottomPadding: Dp,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val onAccent = remember(accentColor) { SdkColors.onAccent(accentColor) }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(bottom = bottomPadding)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(WriteButtonHeight)
                .shadow(
                    elevation = 6.dp,
                    shape = CircleShape,
                    clip = false,
                    ambientColor = SdkColors.buttonShadowAmbient,
                    spotColor = SdkColors.buttonShadowSpot
                )
                .clip(CircleShape)
                .background(accentColor)
                // Кнопка всегда перехватывает тап (не пропускает его в контент под собой),
                // но действие выполняет только пока видима
                .clickable(role = Role.Button) { if (enabled) onClick() }
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_cq_write),
                contentDescription = null,
                tint = onAccent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.list_write_button),
                color = onAccent,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
