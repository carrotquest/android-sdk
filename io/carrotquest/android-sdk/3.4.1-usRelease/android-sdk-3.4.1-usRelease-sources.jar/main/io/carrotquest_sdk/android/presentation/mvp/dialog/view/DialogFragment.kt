package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.Manifest
import android.content.Context
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.widget.Toast
import android.app.Activity
import androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.lifecycle.lifecycleScope
import io.carrotquest_sdk.android.core.audio.VoiceRecorder
import io.carrotquest_sdk.android.core.coroutines.SdkDetachedWorkScope
import io.carrotquest_sdk.android.presentation.chat.WaveformExtractor
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.clearDraftReplyUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftReplyUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.saveDraftReplyUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.quotableBodyText
import io.carrotquest_sdk.android.domain.use_cases.settings.areAudioMessagesEnabled
import io.carrotquest_sdk.android.domain.use_cases.settings.isWriteButtonAndInputEnabled
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.chat.ChatEvent
import io.carrotquest_sdk.android.presentation.chat.ChatScreen
import io.carrotquest_sdk.android.presentation.chat.ChatScreenState
import io.carrotquest_sdk.android.presentation.chat.ChatViewModel
import io.carrotquest_sdk.android.presentation.chat.ClosedDialogPlate
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.presentation.chat.ContactInputType
import io.carrotquest_sdk.android.presentation.chat.ErrorKind
import io.carrotquest_sdk.android.presentation.chat.MessageMapper
import io.carrotquest_sdk.android.presentation.chat.isPositiveVote
import io.carrotquest_sdk.android.presentation.chat.input.AttachmentUploadState
import io.carrotquest_sdk.android.presentation.chat.input.PendingAttachment
import io.carrotquest_sdk.android.presentation.chat.input.MessageInput
import io.carrotquest_sdk.android.presentation.chat.input.MessageInputEvent
import io.carrotquest_sdk.android.presentation.chat.input.MessageInputViewModel
import io.carrotquest_sdk.android.presentation.chat.input.ReplyPreviewUi
import io.carrotquest_sdk.android.presentation.chat.input.VoiceState
import io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.MessageActionsBottomSheetActivity
import java.util.Locale
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.TicketsRepository
import io.carrotquest_sdk.android.domain.entities.TicketStage
import io.carrotquest_sdk.android.domain.use_cases.tickets.isMessengerVoteEnabled
import io.carrotquest_sdk.android.domain.use_cases.tickets.sendTicketCsat
import io.carrotquest_sdk.android.presentation.tickets.SupplementTicketButton
import io.carrotquest_sdk.android.presentation.tickets.TicketResolutionPrompt
import io.carrotquest_sdk.android.presentation.tickets.TicketResolutionState
import io.carrotquest_sdk.android.presentation.tickets.isQuotingEnabledOnScreen
import io.carrotquest_sdk.android.presentation.tickets.isSupplementButtonVisible
import io.carrotquest_sdk.android.presentation.tickets.ticketResolutionUiState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import io.carrotquest_sdk.android.presentation.mvp.dialog.presenter.DialogPresenter
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper

class DialogFragment : Fragment(), IDialogView {

    companion object {
        private const val TAG = "DialogFragment"
        private const val ARG_CONVERSATION_ID = "conversation_id"
        private const val ARG_TICKET_MODE = "ticket_mode"
        // Число палочек волны для превью голосового (из WaveformExtractor).
        private const val VOICE_PREVIEW_BARS = 40

        fun newInstance(conversationId: String, isTicket: Boolean = false) = DialogFragment().apply {
            arguments = bundleOf(
                ARG_CONVERSATION_ID to conversationId,
                ARG_TICKET_MODE to isTicket,
            )
        }
    }

    private val presenter = DialogPresenter()
    private val chatViewModel: ChatViewModel by viewModels()
    private val inputViewModel: MessageInputViewModel by viewModels()

    // ── Ticket mode (Шаг 6 тикетов) ──────────────────────────────────────────
    // Диалог принадлежит тикету: автопоказ инпута подавлён (гейт в showInput), внизу ленты —
    // кнопка «Дополнить тикет» (нефинальные), финальный тикет read-only.
    private var isTicketMode = false
    private var fragmentConversationId: String = ""
    // Compose-state: по тапу «Дополнить» кнопка исчезает и появляется обычный инпут
    // (одноразово в рамках экрана; сбрасывается только финализацией тикета по RTS)
    private var supplementActivated by androidx.compose.runtime.mutableStateOf(false)

    // Закрытый диалог read-only (CAR-77491): вместо инпута рисуем плашку «Создать новый диалог».
    // Compose-state — чтобы setContent среагировал на смену состояния по RTS/HTTP.
    private var closedReadOnly by androidx.compose.runtime.mutableStateOf(false)

    // Может ли пользователь сам начать диалог (messenger_show_write_button_and_input). Гейтит
    // плашку закрытого диалога целиком: без права писать подпись «писать нельзя» ничего не
    // объясняет (поля и так нет везде), а «Создать новый диалог» открыл бы пустой диалог без
    // поля. Обновляется вместе с настройками (settingsChangesFlow), как voiceAvailable.
    private var canStartNewConversation by androidx.compose.runtime.mutableStateOf(true)

    // Мульти-выбор файлов/картинок (мультиаттачи). Пустой список = отмена пикера.
    private val documentPick = registerForActivityResult(OpenMultipleDocuments()) { uris ->
        if (!uris.isNullOrEmpty()) presenter.onFilesPicked(uris)
    }

    // Запрос storage-разрешений для file picker (pre-T); раньше RxPermission, теперь AndroidX.
    private val storagePermissionLauncher = registerForActivityResult(RequestMultiplePermissions()) { results ->
        if (results.values.any { it }) {
            documentPick.launch(FilePickerHelper.mAllowMimeTypes)
        }
    }

    private val selectRegionLauncher = registerForActivityResult(
        io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries.SelectCountryContract()
    ) { country ->
        if (country != null) presenter.onCountrySelected(country)
    }

    // Шторка действий над сообщением: раньше запускалась fire-and-forget из презентера, теперь —
    // через launcher, чтобы получить результат «Ответить» (цитирование, CAR-75966).
    private val messageActionsLauncher = registerForActivityResult(StartActivityForResult()) { result ->
        val replyId = result.data
            ?.getStringExtra(MessageActionsBottomSheetActivity.RESULT_REPLY_MESSAGE_ID)
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
            "sheet result: code=${result.resultCode} replyId=$replyId"
        }
        if (result.resultCode == Activity.RESULT_OK && replyId != null) startReplyTo(replyId)
    }

    // Текущий режим инпута (зеркало presenter.currentInputMod через setInputMod): в BOT_INPUT
    // режим ответа недоступен — гейтим точки входа и сбрасываем активный reply.
    private var currentInputMod = InputMod.NORMAL

    // Диалог, для которого инпут показан последним. showInput дёргается НЕ только при смене
    // диалога (RTS updateInput, onResume после шторки действий) — сбрасывать reply можно
    // только при реальной смене id, иначе режим ответа гаснет через секунду после включения.
    private var inputConversationId: String? = null

    // ── Голосовые (Ф2) ──────────────────────────────────────────────────────────
    private var voiceRecorder: VoiceRecorder? = null
    private var voiceAmplitudeJob: Job? = null
    private var voiceTimerJob: Job? = null
    private var voicePreviewProgressJob: Job? = null
    private var voicePlayer: MediaPlayer? = null

    // Запрос RECORD_AUDIO по тапу на mic: при выдаче — стартуем запись.
    private val recordAudioPermissionLauncher = registerForActivityResult(RequestPermission()) { granted ->
        if (granted) startVoiceRecordingInternal()
        else Toast.makeText(requireContext(), R.string.cq_voice_permission_required, Toast.LENGTH_LONG).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Тело чата и поле ввода — единое Compose-дерево (Column). Отдельный View-bottom_bar и
        // RootContainerForKeyboard убраны: клавиатуру (imePadding) обеспечивает контейнер
        // SdkContainerScreen, поэтому отдельный layout больше не нужен.
        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val conversationId = arguments?.getString(ARG_CONVERSATION_ID) ?: ""
        fragmentConversationId = conversationId
        // Ticket mode: явный аргумент (экран тикета) ИЛИ детект по кэшу — вход в обход списка
        // (openChat по conversationId тикета) обязан включить режим, иначе финальный тикет
        // откроется как обычный чат с инпутом
        isTicketMode = arguments?.getBoolean(ARG_TICKET_MODE) == true ||
            (conversationId.isNotEmpty() &&
                TicketsRepository.getInstance().getTicketByConversationId(conversationId) != null)
        chatViewModel.setConversationId(conversationId, isTicket = isTicketMode)
        // Стартовый хинт — дефолтный: у MessageInputState hint == null, а для нового диалога
        // updateInput (единственный, кто ставит хинт) не отрабатывает — беседы нет. Раньше дефолт
        // приезжал побочным сбросом в loadConversationAndUpdateInput; тот затирал кастомный
        // плейсхолдер бота и убран, поэтому дефолт задаём явно здесь.
        inputViewModel.setHint(defaultHint())
        // Стартовое значение — из кэша/дефолта (настройки могли ещё не прийти: cold start через
        // push); дальше — живые обновления из /connect через settingsChangesFlow (replay=1),
        // иначе флаг, приехавший при открытом «тихом» диалоге, никогда бы не дошёл до UI.
        applyVoiceAvailability()
        canStartNewConversation = isWriteButtonAndInputEnabled(requireContext())
        viewLifecycleOwner.lifecycleScope.launch {
            io.carrotquest_sdk.android.data.repositories.SettingsRepository.getInstance()
                .settingsChangesFlow()
                .collect {
                    applyVoiceAvailability()
                    canStartNewConversation = isWriteButtonAndInputEnabled(requireContext())
                }
        }
        // Чип «Ответ на сообщение» держит снапшот оригинала, а оператор может отредактировать
        // или удалить оригинал, пока чип активен, — на каждое изменение данных переснимаем превью.
        viewLifecycleOwner.lifecycleScope.launch {
            MessagesRepository.getInstance().dataFlow.collect { refreshReplyPreview() }
        }
        // Стартовая ветка routing-бота как последний элемент ленты: по ней презентер решает
        // видимость поля ввода (updateInput), иначе серверный partLast закрытого диалога
        // (reply_admin) возвращал инпут при боте с запрещённым прерыванием.
        viewLifecycleOwner.lifecycleScope.launch {
            chatViewModel.routingTemplateState.collect { presenter.onRoutingTemplateStateChanged(it) }
        }

        try {
            presenter.attachView(this)
            presenter.onCreate()
        } catch (e: Exception) {
            // Со стектрейсом: раньше писали "$e" — по такому логу нельзя было понять, где именно
            // упал бутстрап (краш NPE в loadSettings сначала глохнул именно здесь).
            Log.e(TAG, e)
        }

        val isDark = getThemeUseCase(requireContext()) == ThemeSdk.DARK
        // Единый акцент — из SdkContainerViewModel (тот же, что в ChatScreen и шапке).
        val accentColor = (activity as? io.carrotquest_sdk.android.presentation.container.SdkContainerActivity)
            ?.let {
                val vm = androidx.lifecycle.ViewModelProvider(it)[io.carrotquest_sdk.android.presentation.container.SdkContainerViewModel::class.java]
                vm.uiState.value.accentColor
            } ?: Color(0xFF5C6BC0)

        // Плашка «Powered by» внизу тела чата — по настройке аппа.
        val settings = io.carrotquest_sdk.android.data.repositories.SettingsRepository.getInstance().getSettingsObject()
        val showPoweredBy = settings?.showPoweredBy == true
        val appName = settings?.appName ?: ""

        (view as ComposeView).setContent {
            // Живой тикет экрана: RTS ticket/updated патчит кэш → стадия/закрытость и всё, что
            // от них зависит (гейт цитирования, кнопка «Дополнить», карточка резолюции, инпут),
            // реагируют прямо во время просмотра. Для обычного диалога ticket == null.
            val tickets by TicketsRepository.getInstance().ticketsFlow.collectAsState()
            val ticket = if (isTicketMode) {
                tickets.find { it.conversationId == fragmentConversationId }
            } else null
            val ticketStage = ticket?.status?.stage
            val quotingEnabled = isQuotingEnabledOnScreen(isTicketMode, ticketStage, closedReadOnly)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SdkColors.pageBackground(isDark))
            ) {
                ChatScreen(
                    viewModel = chatViewModel,
                    accentColor = accentColor,
                    isDark = isDark,
                    showPoweredBy = showPoweredBy,
                    appName = appName,
                    quotingEnabled = quotingEnabled,
                    onEvent = { event -> handleChatEvent(event) },
                    modifier = Modifier.weight(1f),
                )
                // Инпут показываем только когда тело чата реально показано (Content). В полноэкранных
                // состояниях — ошибка (нет сети/авиарежим/generic) И загрузка (спиннер, в т.ч. после
                // Retry) — отправка невозможна, поэтому поле прячем целиком. Бизнес-видимость
                // (inputViewModel.visible: боты/allow_user_replies) не трогаем — вернётся сама.
                val chatState by chatViewModel.state.collectAsState()
                if (chatState is ChatScreenState.Content) {
                    if (isTicketMode) {
                        // Тикет и его стадия — из живого кэша выше (RTS ticket/updated патчит его,
                        // и кнопка/инпут/карточка реагируют прямо во время просмотра).
                        // null-стадия = тикета НЕТ в кэше (перезагрузка списка его вымыла, лимит
                        // 20 на бэке): стадия неизвестна — нижние контролы не рисуем вовсе.
                        // Прежний дефолт INTERMEDIATE показывал у ЗАКРЫТОГО тикета кнопку
                        // «Дополнить тикет», как будто он открыт.
                        val stage = ticketStage
                        val isReopenable = ticket?.isReopenable == true
                        val closedAtMillis = ticket?.closedAtMillis

                        // Ответ на «Ваш вопрос решён?» текущего цикла закрытия (CAR-76310).
                        // Ключ ticketId+closedAt: новое закрытие пересоздаёт стейт → вопрос снова
                        var resolutionAnswer by remember(ticket?.id, closedAtMillis) {
                            mutableStateOf(
                                ticket?.id?.let { TicketResolutionState.getAnswer(it, closedAtMillis) }
                            )
                        }

                        LaunchedEffect(stage, isReopenable, resolutionAnswer) {
                            if (stage == TicketStage.FINAL) {
                                // В закрытом тикете цитировать нельзя: снимаем чип ответа и его
                                // драфт — иначе после «Не решён» инпут откроется с цитатой
                                // (или она восстановится из персиста при следующем входе)
                                cancelReplyMode("ticket closed")
                                // Закрытый тикет: инпут только у переоткрываемого после «Не решён»
                                // (сообщение авто-переоткроет тикет на бэке). Легаси/старый бэк —
                                // read-only. Сообщение, отправленное «в последний момент» до
                                // закрытия, не виснет: generic-путь пометит его failed.
                                val wantsReopen = isReopenable &&
                                    resolutionAnswer == TicketResolutionState.Answer.NOT_RESOLVED
                                supplementActivated = wantsReopen
                                if (wantsReopen) {
                                    showInput(fragmentConversationId)
                                } else {
                                    inputViewModel.setVisible(false)
                                }
                            }
                            // Переоткрытие (финал → нефинал) при открытом инпуте ничего не прячет:
                            // пользователь только что отправил сообщение — пусть продолжает
                        }

                        if (stage != null && isSupplementButtonVisible(stage, supplementActivated)) {
                            SupplementTicketButton(
                                accentColor = accentColor,
                                isDark = isDark,
                                onClick = {
                                    supplementActivated = true
                                    showInput(fragmentConversationId)
                                }
                            )
                        }

                        val ticketId = ticket?.id
                        if (stage == TicketStage.FINAL && isReopenable && ticketId != null) {
                            TicketResolutionPrompt(
                                state = ticketResolutionUiState(resolutionAnswer),
                                isVoteEnabled = remember { isMessengerVoteEnabled() },
                                accentColor = accentColor,
                                isDark = isDark,
                                onResolved = {
                                    resolutionAnswer = TicketResolutionState.Answer.RESOLVED
                                    TicketResolutionState.setAnswer(
                                        ticketId, closedAtMillis, TicketResolutionState.Answer.RESOLVED
                                    )
                                    // CSAT по клику (закрытие тикета опрос не шлёт): best-effort,
                                    // VOTE-реплика прилетит в ленту по RTS. Отвязанный скоуп:
                                    // вью-скоуп отменялся в onDestroyView и обрывал HTTP, а ответ
                                    // «Решён» уже записан — повторить запрос было бы некому
                                    SdkDetachedWorkScope.launch { sendTicketCsat(ticketId) }
                                },
                                onNotResolved = {
                                    resolutionAnswer = TicketResolutionState.Answer.NOT_RESOLVED
                                    TicketResolutionState.setAnswer(
                                        ticketId, closedAtMillis, TicketResolutionState.Answer.NOT_RESOLVED
                                    )
                                }
                            )
                        }
                    }
                    // Закрытый диалог read-only (CAR-77491): вместо поля ввода — плашка «В закрытый
                    // диалог писать нельзя» + «Создать новый диалог» (инпут уже спрятан презентером).
                    // Кнопка наследует логику «Написать» в списке: onWriteButtonClicked сам решает,
                    // новый диалог или последний открытый (режим «один диалог за раз»). В режиме
                    // «пользователь не может начать диалог» плашки нет вовсе (см. canStartNewConversation).
                    if (!isTicketMode && closedReadOnly && canStartNewConversation) {
                        ClosedDialogPlate(
                            accentColor = accentColor,
                            isDark = isDark,
                            onStartNewConversation = {
                                (activity as? io.carrotquest_sdk.android.presentation.container.SdkContainerActivity)?.let {
                                    androidx.lifecycle.ViewModelProvider(it)[io.carrotquest_sdk.android.presentation.container.SdkContainerViewModel::class.java]
                                        .onWriteButtonClicked()
                                }
                            },
                        )
                    }
                    val inputState by inputViewModel.state.collectAsState()
                    MessageInput(
                        state = inputState,
                        accentColor = accentColor,
                        isDark = isDark,
                        onEvent = { event -> handleInputEvent(event) },
                    )
                }
            }
        }

        // Бутстрап диалога под защитой: этот код исполняется в fragment-транзакции, поэтому любое
        // исключение отсюда — фатальный краш ХОСТ-приложения (так и был потерян процесс на NPE
        // в loadSettings). Ошибку логируем и показываем экран «Что-то пошло не так» с «Повторить»,
        // а не роняем интегратора и не оставляем вечный спиннер.
        try {
            presenter.onChangeConversationId(conversationId)
            presenter.onCreateWebView(conversationId)

            // Запускаем логику диалога напрямую — без ожидания загрузки WebView
            when {
                conversationId == "last_conversation" -> presenter.onOpenLastDialog()
                conversationId.isNotEmpty() -> presenter.onOpenDialog()
                else -> presenter.onOpenNewDialog()
            }
        } catch (e: Exception) {
            Log.e(TAG, e)
            chatViewModel.showError(ErrorKind.GENERIC)
        }
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume()
    }

    override fun onStart() {
        super.onStart()
        if (isTicketMode && fragmentConversationId.isNotEmpty()) {
            val repo = TicketsRepository.getInstance()
            // Гейт гонки «RTS-сообщение во время просмотра инкрементит unread» + локальное
            // прочтение (бейдж карточки/таба). Серверный markread шлёт обычный пайплайн диалога.
            repo.currentlyViewedConversationId = fragmentConversationId
            repo.markAsRead(fragmentConversationId)
        }
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun onStop() {
        // Сворачивание/звонок во время записи: не пишем в фоне — фиксируем запись в превью
        // (или idle, если устройство дало сбой). Воспроизведение превью тоже останавливаем.
        if (inputViewModel.state.value.voiceState is VoiceState.Recording) {
            stopRecordingToPreview()
        }
        if (voicePlayer != null) {
            stopVoicePlayer()
            inputViewModel.setVoicePreviewProgress(0f)
            inputViewModel.setVoicePreviewPlaying(false)
        }
        if (isTicketMode &&
            TicketsRepository.getInstance().currentlyViewedConversationId == fragmentConversationId
        ) {
            TicketsRepository.getInstance().currentlyViewedConversationId = null
        }
        super.onStop()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Освобождаем рекордер/плеер голоса (amplitude-job отменится с viewLifecycleScope сам).
        voiceRecorder?.cancel(); voiceRecorder = null
        stopVoicePlayer()
        presenter.onDestroy()
    }

    // ── Event routing ───────────────────────────────────────────────────────

    private fun handleChatEvent(event: ChatEvent) {
        chatViewModel.onEvent(event)
        when (event) {
            // Кнопки быстрого ответа (реплика админа из public API) и кнопки бота отправляются
            // по-разному: quick_reply — обычной репликой пользователя с meta_data кнопки,
            // бот-ветка — через meta_data части/старт бота. Развилка по типу экшена, как в вебе.
            is ChatEvent.BotOptionSelected ->
                if (event.option.actionType == ResponseFields.ACTION_QUICK_REPLY) {
                    presenter.onQuickReplySelected(
                        answerBody = event.option.text,
                        metaData = event.option.metaData,
                        href = event.option.link ?: "",
                        context = requireContext(),
                    )
                } else {
                    presenter.onSelectBotBrunch(
                        messageId = event.messageId,
                        branchId = event.option.id,
                        branchLinkId = event.option.branchId ?: "",
                        answerBody = event.option.text,
                        href = event.option.link ?: "",
                        context = requireContext(),
                    )
                }
            // Позитивную оценку отправляем сразу — комментарий не нужен. Низкие оценки НЕ отправляем
            // по тапу: сначала показываем поле комментария (ChatViewModel.onEvent → setVotePending),
            // реальная отправка — в CommentVoteSent. Иначе оценка уходила бы без комментария и сервер
            // помечал сообщение как Rated, пока локальный оверрайд ещё Pending — карточка мигала и
            // откатывалась к выбору эмодзи (баг оценки оператора). Порог — isPositiveVote (не магия «5»).
            is ChatEvent.VoteSelected -> if (isPositiveVote(event.score)) presenter.sendVote(event.messageId, event.score)
            is ChatEvent.CommentVoteSent -> presenter.sendCommentVote(event.messageId, event.score, event.comment)
            is ChatEvent.ContactFormSubmitted -> {
                val type = when (event.inputType) {
                    ContactInputType.EMAIL -> "email"
                    ContactInputType.PHONE -> "phone"
                    ContactInputType.NAME  -> "name"
                    ContactInputType.TEXT  -> "text"
                }
                presenter.setContactDetails(event.messageId, type, event.value)
            }
            is ChatEvent.Retry -> presenter.retry()
            is ChatEvent.LoadOlderMessages -> presenter.paginationMessages()
            is ChatEvent.MessageTapped -> openMessageActions(event.messageId)
            is ChatEvent.LinkTapped -> presenter.onGoToLink(event.url, requireContext())
            // Общая точка входа в режим ответа: свайп по сообщению (Э5) и пункт bottom sheet.
            is ChatEvent.ReplyRequested -> startReplyTo(event.messageId)
            // Тап по цитате: оригинал загружен — VM уже выставил скролл (onEvent выше);
            // не загружен — прыжок: around-загрузка через презентер, затем скролл.
            is ChatEvent.QuoteTapped -> {
                if (!chatViewModel.hasLoadedMessage(event.originalId)) {
                    viewLifecycleOwner.lifecycleScope.launch {
                        val found = presenter.jumpToMessage(event.originalId)
                        if (found) chatViewModel.requestScrollTo(event.originalId)
                    }
                }
            }
            // Маркер разрыва истории показался — грузим страницу середины с ближайшего края.
            is ChatEvent.LoadGapMessages -> presenter.loadGapMessages(event.fromTail)
            else -> {}
        }
    }

    // Шторка действий: упавшее — «Повторить»/«Удалить», обычное — «Копировать» (+«Ответить» для
    // quotable вне BOT_INPUT). Логика выбора intent'а переехала из presenter.onTapMessage ради
    // результата «Ответить» через launcher.
    private fun openMessageActions(messageId: String) {
        val message = MessagesRepository.getInstance().findMessageById(messageId)
        val isFailed = message?.status == MessageStatus.WARNING.name.lowercase(Locale.getDefault())
        val intent = if (isFailed) {
            MessageActionsBottomSheetActivity.intentForError(requireContext(), messageId)
        } else {
            val quotable = message != null &&
                MessageMapper.isQuotable(message) &&
                currentInputMod != InputMod.BOT_INPUT &&
                isQuotingEnabledHere()
            // Пустую шторку не открываем: у сообщения без текста (файлы/картинки/статья —
            // у неё body = ID, не текст) единственный пункт — «Ответить»; если и он недоступен
            // (BOT_INPUT/не quotable) — тап по строке ничего не делает.
            val hasCopyableText = message?.type != ResponseFields.ARTICLE &&
                !(message?.messageMetaData?.answerBody?.takeIf { it.isNotBlank() }
                    ?: message?.body).isNullOrBlank()
            if (!quotable && !hasCopyableText) return
            MessageActionsBottomSheetActivity.intentForMessage(requireContext(), messageId, quotable)
        }
        messageActionsLauncher.launch(intent)
    }

    /**
     * Разрешено ли цитирование на этом экране прямо сейчас: в ЗАКРЫТОМ тикете нельзя (веб:
     * allowReply={!isFinal}). Синхронное чтение кэша — гейт нужен и в не-Compose путях
     * (шторка действий, startReplyTo по свайпу). Тикета нет в кэше → не блокируем.
     */
    private fun isQuotingEnabledHere(): Boolean = isQuotingEnabledOnScreen(
        isTicketMode,
        TicketsRepository.getInstance()
            .getTicketByConversationId(fragmentConversationId)?.status?.stage,
        closedReadOnly,
    )

    /** Снять режим ответа вместе с его драфтом (закрытие тикета, смена режима инпута). */
    private fun cancelReplyMode(reason: String) {
        if (inputViewModel.state.value.replyTo != null) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                "reply cleared: $reason"
            }
        }
        inputViewModel.clearReplyTo()
        // fallback на id фрагмента: при первом входе в тикет инпут ещё не показывался,
        // inputConversationId пуст, а стереть драфт нужно
        (inputConversationId ?: fragmentConversationId.takeIf { it.isNotEmpty() })
            ?.let { clearDraftReplyUseCase(it) }
    }

    // Включить режим ответа: чип «Ответ на сообщение» в инпуте + фокус в поле (в Compose — по
    // смене state.replyTo). Гейты дублируют точки входа (свайп мог прилететь по гонке).
    private fun startReplyTo(messageId: String) {
        if (currentInputMod == InputMod.BOT_INPUT) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                "startReplyTo rejected: BOT_INPUT mode (id=$messageId)"
            }
            return
        }
        if (!isQuotingEnabledHere()) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                "startReplyTo rejected: closed ticket or read-only conversation (id=$messageId)"
            }
            return
        }
        val message = MessagesRepository.getInstance().findMessageById(messageId)
        if (message == null || !MessageMapper.isQuotable(message)) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                "startReplyTo rejected: found=${message != null} quotable=${message?.let { MessageMapper.isQuotable(it) }} (id=$messageId)"
            }
            return
        }
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
            "reply mode ON: id=$messageId type=${message.type}"
        }
        // В нефинальном тикете инпута ещё нет (вместо него кнопка «Дополнить тикет»), а чип
        // ответа без поля ввода некуда положить. Цитирование — такой же вход в режим дополнения,
        // как сама кнопка: активируем его и показываем поле. ДО setReplyTo — showInput при первом
        // показе беседы сбрасывает режим ответа и поднимает драфт, иначе он затёр бы наш чип.
        if (isTicketMode && !supplementActivated) {
            supplementActivated = true
            showInput(fragmentConversationId)
        }
        val replyTo = ReplyPreviewUi(
            messageId = messageId,
            // quotableBodyText: у статьи body = id, название — в bodyJson.name.
            snippet = MessageMapper.snippetOf(message.quotableBodyText()),
            attachment = MessageMapper.quoteAttachmentKind(message.attachments ?: emptyList()),
        )
        inputViewModel.setReplyTo(replyTo)
        // Драфт ответа (как текстовый драфт): переживает закрытие диалога до отмены/отправки.
        inputConversationId?.let { saveDraftReplyUseCase(replyTo, it) }
    }

    /**
     * Переснимает превью в чипе «Ответ на сообщение» с актуального оригинала: оператор мог
     * отредактировать его при открытом диалоге (conversation_reply_changed → updateMessage →
     * dataFlow). Если оригинал стал нецитируемым (мягко удалён) — режим ответа сбрасывается,
     * иначе отправка ушла бы с replied_to на удалённое сообщение (400 от бэкенда).
     * Оригинал вне загруженной истории (чип восстановлен из драфта) не трогаем — сравнивать не с чем.
     */
    private fun refreshReplyPreview() {
        val current = inputViewModel.state.value.replyTo ?: return
        val message = MessagesRepository.getInstance().findMessageById(current.messageId) ?: return
        if (!MessageMapper.isQuotable(message)) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                "reply cleared: original became non-quotable (id=${current.messageId})"
            }
            inputViewModel.clearReplyTo()
            inputConversationId?.let { clearDraftReplyUseCase(it) }
            return
        }
        val updated = current.copy(
            snippet = MessageMapper.snippetOf(message.quotableBodyText()),
            attachment = MessageMapper.quoteAttachmentKind(message.attachments ?: emptyList()),
        )
        if (updated != current) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                "reply preview refreshed: original changed (id=${current.messageId})"
            }
            inputViewModel.setReplyTo(updated)
            // Драфт хранит тот же снапшот — обновляем, чтобы после закрытия/открытия диалога
            // чип не откатился к устаревшему тексту.
            inputConversationId?.let { saveDraftReplyUseCase(updated, it) }
        }
    }

    // UI инпута → оптимистичное состояние (VM) + реальный side-effect (presenter), как handleChatEvent.
    private fun handleInputEvent(event: MessageInputEvent) {
        inputViewModel.onEvent(event)
        when (event) {
            is MessageInputEvent.TextChanged -> presenter.onInputText(event.text)
            // repliedToId читаем ДО отправки: sendNormalMessage чистит инпут (clearInput → clearReplyTo).
            MessageInputEvent.SendTapped -> presenter.onTapSendMessage(
                inputViewModel.state.value.text,
                inputViewModel.state.value.replyTo?.messageId,
            )
            // В режиме ответа боту скрепки нет; гейт на случай гонки тапа со сменой режима.
            MessageInputEvent.AttachTapped ->
                if (!inputViewModel.state.value.botInput) presenter.onOpenPicker(getScreenHeight() * 2 / 3)
            MessageInputEvent.PhonePrefixTapped -> selectRegionLauncher.launch("")
            // Отмена/удаление вложения: отменяем фоновую загрузку (презентер) и убираем чип (VM).
            is MessageInputEvent.RemoveAttachment -> {
                presenter.onRemoveAttachment(event.clientId)
                inputViewModel.removeAttachment(event.clientId)
            }
            // Чекбокс согласия — уже применён inputViewModel.onEvent выше, side-effect нет.
            is MessageInputEvent.ConsentToggled -> {}
            // Крестик чипа «Ответ на сообщение» — чип уже снят VM (clearReplyTo); гасим драфт.
            MessageInputEvent.CancelReply -> inputConversationId?.let { clearDraftReplyUseCase(it) }
            // Ссылка на документ в блоке согласия — открываем через презентер (как ссылки в теле чата).
            is MessageInputEvent.ConsentLinkTapped -> presenter.onGoToLink(event.url, requireContext())
            // Голосовые (Ф2.4): пермишен + VoiceRecorder + плеер превью + upload/send.
            MessageInputEvent.StartVoiceRecording -> onStartVoiceRecording()
            MessageInputEvent.StopVoiceRecording -> stopRecordingToPreview()
            MessageInputEvent.CancelVoiceRecording -> cancelVoiceRecording()
            MessageInputEvent.PlayPreviewToggle -> togglePreviewPlayback()
            MessageInputEvent.DeleteVoicePreview -> deleteVoicePreview()
            MessageInputEvent.SendVoice -> sendVoice()
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    // ── Голосовые: связка рекордера/плеера/отправки (Ф2.4) ──────────────────────

    /**
     * Применяет настройку аппа messenger_enable_audio_messages к инпуту: при false кнопки
     * микрофона нет. Вызывается при создании вью (кэш/дефолт) и на каждую эмиссию
     * settingsChangesFlow (живые обновления из /connect при уже открытом диалоге).
     *
     * Единственная точка «выключено → Idle»: teardown записи/плеера (cancelVoiceRecording) —
     * ответственность фрагмента, [MessageInputViewModel.setVoiceAvailable] меняет только состояние.
     */
    private fun applyVoiceAvailability() {
        val enabled = areAudioMessagesEnabled(requireContext())
        // Если настройка «выключено» приехала уже во время записи/превью — сворачиваем их
        // полностью (рекордер и плеер), а не просто прячем кнопку.
        if (!enabled && inputViewModel.state.value.voiceState != VoiceState.Idle) {
            cancelVoiceRecording()
        }
        inputViewModel.setVoiceAvailable(enabled)
    }

    private fun onStartVoiceRecording() {
        // Ранний гейт (основной — в startVoiceRecordingInternal): не показываем системный диалог
        // RECORD_AUDIO, если голосовые уже выключены к моменту тапа.
        if (!inputViewModel.state.value.voiceAvailable || inputViewModel.state.value.botInput) return
        val granted = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startVoiceRecordingInternal()
        else recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoiceRecordingInternal() {
        // Гейт настройки в общей воронке обоих путей (прямой тап и колбэк пермишен-лончера):
        // настройка могла выключиться, пока висел системный диалог RECORD_AUDIO.
        if (!inputViewModel.state.value.voiceAvailable || inputViewModel.state.value.botInput) return
        val recorder = VoiceRecorder()
        // filesDir, не cacheDir: путь к WAV персистится в FailSendingMessage для ресенда после
        // сбоя сети — кэш ОС может вычистить раньше. Успешная отправка удаляет файл (onSendVoice).
        val voiceDir = File(requireContext().filesDir, "cq_voice").apply { mkdirs() }
        val file = File(voiceDir, "cq_voice_${System.currentTimeMillis()}.wav")
        if (!recorder.start(file)) {
            Toast.makeText(requireContext(), R.string.cq_lib_something_wrong, Toast.LENGTH_SHORT).show()
            return
        }
        voiceRecorder = recorder
        inputViewModel.startVoiceRecording()
        voiceAmplitudeJob = viewLifecycleOwner.lifecycleScope.launch {
            recorder.amplitude.collect { inputViewModel.addVoiceAmplitude(it) }
        }
        // Таймер записи в реальном времени (раз в секунду) + детект авто-стопа.
        voiceTimerJob = viewLifecycleOwner.lifecycleScope.launch {
            var sec = 0
            while (true) {
                kotlinx.coroutines.delay(1_000)
                // Рекордер мог остановиться сам (лимит длительности или сбой устройства) —
                // фиксируем запись в превью (recorder.stop() вернёт Success/Failed).
                if (voiceRecorder?.isRecording == false) {
                    stopRecordingToPreview()
                    break
                }
                sec++
                inputViewModel.setVoiceElapsed(sec)
            }
        }
    }

    private fun stopRecordingToPreview() {
        voiceAmplitudeJob?.cancel(); voiceAmplitudeJob = null
        voiceTimerJob?.cancel(); voiceTimerJob = null
        val recorder = voiceRecorder ?: return
        voiceRecorder = null
        when (val result = recorder.stop()) {
            is VoiceRecorder.RecordResult.Success -> {
                val durationSec = (result.durationMs / 1000L).toInt()
                val wave = WaveformExtractor.fromSource(result.file.absolutePath, VOICE_PREVIEW_BARS)
                    ?.amplitudes ?: emptyList()
                inputViewModel.showVoicePreview(result.file.absolutePath, durationSec, wave)
            }
            // TooShort/Failed — файл уже удалён рекордером, возвращаемся в обычный бар.
            else -> inputViewModel.clearVoice()
        }
    }

    private fun cancelVoiceRecording() {
        voiceAmplitudeJob?.cancel(); voiceAmplitudeJob = null
        voiceTimerJob?.cancel(); voiceTimerJob = null
        voiceRecorder?.cancel(); voiceRecorder = null
        stopVoicePlayer()
        inputViewModel.clearVoice()
    }

    private fun togglePreviewPlayback() {
        val state = inputViewModel.state.value.voiceState as? VoiceState.Preview ?: return
        val player = voicePlayer
        when {
            player != null && player.isPlaying -> {
                // Стоп: останавливаем воспроизведение и перематываем в начало (повторный тап — с нуля).
                player.pause()
                player.seekTo(0)
                stopVoiceProgressTick()
                inputViewModel.setVoicePreviewProgress(0f)
                inputViewModel.setVoicePreviewPlaying(false)
            }
            player != null -> {
                player.start()
                inputViewModel.setVoicePreviewPlaying(true)
                startVoiceProgressTick()
            }
            else -> try {
                val mp = MediaPlayer()
                mp.setDataSource(state.filePath)
                mp.setOnCompletionListener {
                    it.seekTo(0)
                    stopVoiceProgressTick()
                    inputViewModel.setVoicePreviewProgress(0f)
                    inputViewModel.setVoicePreviewPlaying(false)
                }
                mp.prepare()
                mp.start()
                voicePlayer = mp
                inputViewModel.setVoicePreviewPlaying(true)
                startVoiceProgressTick()
            } catch (t: Throwable) {
                Log.e(TAG, "voice preview playback failed: $t")
                stopVoicePlayer()
                inputViewModel.setVoicePreviewPlaying(false)
            }
        }
    }

    // Тик прогресса воспроизведения превью (для анимации волны, как в баббле).
    private fun startVoiceProgressTick() {
        voicePreviewProgressJob?.cancel()
        voicePreviewProgressJob = viewLifecycleOwner.lifecycleScope.launch {
            while (true) {
                val fraction = voicePlayer?.let { mp ->
                    val dur = mp.duration
                    if (dur > 0) mp.currentPosition.toFloat() / dur else null
                } ?: break
                inputViewModel.setVoicePreviewProgress(fraction)
                kotlinx.coroutines.delay(60)
            }
        }
    }

    private fun stopVoiceProgressTick() {
        voicePreviewProgressJob?.cancel()
        voicePreviewProgressJob = null
    }

    private fun deleteVoicePreview() {
        val state = inputViewModel.state.value.voiceState as? VoiceState.Preview
        stopVoicePlayer()
        state?.let { File(it.filePath).delete() }
        inputViewModel.clearVoice()
    }

    private fun sendVoice() {
        // Тап по отправке во время записи — сначала останавливаем (получаем файл), потом шлём.
        val preview: VoiceState.Preview? = when (val current = inputViewModel.state.value.voiceState) {
            is VoiceState.Preview -> current
            is VoiceState.Recording -> {
                voiceAmplitudeJob?.cancel(); voiceAmplitudeJob = null
        voiceTimerJob?.cancel(); voiceTimerJob = null
                val recorder = voiceRecorder; voiceRecorder = null
                val res = recorder?.stop()
                if (res is VoiceRecorder.RecordResult.Success) {
                    VoiceState.Preview(res.file.absolutePath, (res.durationMs / 1000L).toInt())
                } else null
            }
            VoiceState.Idle -> null
        }
        stopVoicePlayer()
        inputViewModel.clearVoice()
        if (preview != null) {
            // Режим ответа: id читаем ДО сброса; голос уходит с replied_to (через
            // /reply + attachments_cached), после отправки режим ответа закончился.
            val repliedToId = inputViewModel.state.value.replyTo?.messageId
            inputViewModel.clearReplyTo()
            inputConversationId?.let { clearDraftReplyUseCase(it) }
            presenter.onSendVoice(File(preview.filePath), preview.durationSec, repliedToId)
        }
    }

    private fun stopVoicePlayer() {
        stopVoiceProgressTick()
        voicePlayer?.let {
            try { it.stop() } catch (_: Throwable) {}
            it.release()
        }
        voicePlayer = null
    }

    private fun defaultHint(): String = getString(R.string.input_message_hint_text)

    // Тип клавиатуры презентера (InputType) → семантический тип поля. Презентерный keyboardTypeFor
    // возвращает ровно эти три варианта; всё прочее (mainInputType) — обычный текст.
    private fun keyboardTypeToContactType(keyboardType: Int): ContactInputType = when (keyboardType) {
        InputType.TYPE_CLASS_PHONE -> ContactInputType.PHONE
        InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> ContactInputType.EMAIL
        else -> ContactInputType.TEXT
    }

    private fun getScreenHeight(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            requireActivity().windowManager.currentWindowMetrics.bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val size = Point()
            @Suppress("DEPRECATION")
            requireActivity().windowManager.defaultDisplay.getSize(size)
            size.y
        }
    }

    override fun hideLoadError() {
        // Переходим в Loading только из Error — это семантика "скрыть оверлей ошибки".
        // Network observer вызывает hideLoadError() при каждом revalidate-пинге, и если
        // Content уже показан, сбрасывать его в Loading нельзя: setReady() после этого
        // не вызывается, и диалог зависает в вечной загрузке.
        if (chatViewModel.state.value is ChatScreenState.Error) {
            chatViewModel.setLoading()
        }
    }

    override fun hideLoading() {
        chatViewModel.setReady()
    }

    override fun setRoutingBotResolved(data: io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData?) {
        chatViewModel.setRoutingBotResolved(data)
    }

    override fun setBotTextAnswer(partId: String, answer: String) {
        chatViewModel.setBotTextAnswer(partId, answer)
    }

    override fun markRoutingTemplateAnswered() {
        chatViewModel.markRoutingTemplateAnswered()
    }

    override fun setConversationClosed(readOnly: Boolean) {
        if (closedReadOnly == readOnly) return
        closedReadOnly = readOnly
        // В read-only диалоге цитировать нечего: снимаем чип ответа и его драфт, иначе после
        // переоткрытия оператором инпут вернулся бы с протухшей цитатой.
        if (readOnly) cancelReplyMode("conversation closed")
        chatViewModel.setClosedReadOnly(readOnly)
    }

    override fun showLoadingOlderMessages() {
        chatViewModel.setLoadingOlderMessages(true)
    }

    override fun hideLoadingOlderMessages() {
        val canLoadMore = MessagesRepository.getInstance().getCurrentAfter().isNotEmpty()
        chatViewModel.setLoadingOlderMessages(false, canLoadMore)
    }

    // ── IDialogView: Errors ───────────────────────────────────────────────────

    override fun showErrorNoInternet() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.NO_INTERNET)
        }
    }

    override fun showErrorAirplaneMode() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.AIRPLANE_MODE)
        }
    }

    override fun showErrorSomething() {
        requireActivity().runOnUiThread {
            chatViewModel.showError(ErrorKind.GENERIC)
        }
    }

    override fun showErrorFileNotFound() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showErrorSendMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showDataSavedMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_your_data_is_saved),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    // ── IDialogView: Input (делегирование в MessageInputViewModel) ──────────────

    override fun enableInput() {
        inputViewModel.setEnabled(true)
        inputViewModel.setSendEnabled(true)
    }

    override fun disableInput() {
        inputViewModel.setEnabled(false)
        inputViewModel.setSendEnabled(false)
    }

    override fun hideInput() {
        inputViewModel.setVisible(false)
    }

    override fun showInput(conversationId: String) {
        // Ticket mode: автопоказ инпута для «существующей беседы» подавлён — видимостью управляет
        // только кнопка «Дополнить тикет». Обычный путь не тронут (new_dialog_input_hidden_fix).
        if (isTicketMode && !supplementActivated) return
        val draft = getDraftMessageUseCase(conversationId) ?: ""
        // Диагностика возврата отправленного текста в поле: если драфт не был очищен по
        // правильному ключу, именно эта строка вернёт его в инпут. Сам текст не логируем
        // (в бот-вводе это телефон/email) — только длину и id.
        if (draft.isNotEmpty()) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Draft") {
                "draft restored on showInput: conv=$conversationId len=${draft.length}"
            }
        }
        inputViewModel.setText(draft)
        inputViewModel.setVisible(true)
        // Согласие относится только к текущему BOT_INPUT-запросу: при показе бара сбрасываем,
        // а ветка property_field (applyBotPropertyFieldInput) выставит его заново после showInput.
        inputViewModel.setConsent(null)
        // Режим ответа привязан к конкретному диалогу: сброс ТОЛЬКО при смене id. Повторные
        // showInput того же диалога (RTS updateInput, onResume после шторки) reply не трогают.
        if (inputConversationId != conversationId) {
            if (inputViewModel.state.value.replyTo != null) {
                SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                    "reply cleared: conversation changed $inputConversationId -> $conversationId"
                }
            }
            inputViewModel.clearReplyTo()
            // Восстанавливаем драфт ответа нового диалога из персиста (НЕ из репозитория:
            // оригинал может быть ещё не загружен — чип должен появиться в любом случае).
            // В закрытом тикете цитировать нельзя — драфт не поднимаем, а стираем: иначе он
            // всплыл бы в режиме переоткрытия («Не решён» открывает инпут при финальном тикете).
            if (isQuotingEnabledHere()) {
                getDraftReplyUseCase(conversationId)?.let { draft ->
                    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") {
                        "reply draft restored: id=${draft.messageId}"
                    }
                    inputViewModel.setReplyTo(draft)
                }
            } else {
                clearDraftReplyUseCase(conversationId)
            }
        }
        inputConversationId = conversationId
        // Восстановленный непустой draft делает кнопку отправки активной (раньше это происходило
        // через TextWatcher при setText; программный setText в Compose событие ввода не порождает).
        inputViewModel.setSendEnabled(draft.isNotEmpty())
        // Драфт вложений: восстанавливаем ранее выбранные (уже загруженные) файлы как чипы.
        presenter.restoreAttachmentDraft(conversationId)
    }

    override fun clearInput() {
        inputViewModel.setText("")
        // Отправка состоялась (или презентер чистит поле) — режим ответа тоже закончился.
        if (inputViewModel.state.value.replyTo != null) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, "Reply") { "reply cleared: clearInput (send)" }
        }
        inputViewModel.clearReplyTo()
        inputConversationId?.let { clearDraftReplyUseCase(it) }
    }

    override fun setInputMod(mod: InputMod) {
        currentInputMod = mod
        // Управляет ТОЛЬКО видимостью прикрепления. Хинтом во всех ветках уже рулит updateHint(...),
        // поэтому setInputMod его не трогает. Раньше ветка BOT_INPUT ставила hint="" и затирала
        // вычисленный botAnswerHint (пример номера / «Введите email») — поле бот-ввода всегда было
        // с пустым плейсхолдером. Теперь плейсхолдер бот-ввода виден.
        when (mod) {
            InputMod.NORMAL, InputMod.ALLOW_USER_REPLIES -> {
                inputViewModel.setBotInput(false)
                inputViewModel.setAttachVisible(true)
            }
            InputMod.BOT_INPUT -> {
                // Ответ боту — только текст (веб: BotAnswerField вместо инпута). Идущую запись или
                // превью голоса сворачиваем целиком (рекордер/плеер), а не только прячем кнопку.
                if (inputViewModel.state.value.voiceState != VoiceState.Idle) {
                    cancelVoiceRecording()
                }
                inputViewModel.setBotInput(true)
                inputViewModel.setAttachVisible(false)
                // В режиме бот-ввода цитирование недоступно — активный reply и драфт сбрасываем.
                inputViewModel.clearReplyTo()
                inputConversationId?.let { clearDraftReplyUseCase(it) }
            }
        }
    }

    override fun updateHint(hint: String?) {
        Log.d("CQ_BotInput", "updateHint hint=${hint ?: "<default>"}")
        inputViewModel.setHint(hint ?: defaultHint())
    }

    override fun updateMaxLengthInput(maxLength: Int?) {
        inputViewModel.setMaxLength(maxLength)
    }

    override fun showSendButton() {
        inputViewModel.setSendVisible(true)
    }

    override fun hideSendButton() {
        inputViewModel.setSendVisible(false)
    }

    override fun enableSendButton() {
        inputViewModel.setSendVisible(true)
        inputViewModel.setSendEnabled(true)
    }

    override fun disableSendButton() {
        inputViewModel.setSendVisible(true)
        inputViewModel.setSendEnabled(false)
    }

    override fun showAttachFileButton() {
        // В режиме ответа боту скрепка не возвращается, пока режим не сменится (setInputMod).
        if (inputViewModel.state.value.botInput) return
        inputViewModel.setAttachVisible(true)
    }

    override fun hideAttachFileButton() {
        inputViewModel.setAttachVisible(false)
    }

    override fun showPhonePrefix() {
        inputViewModel.showPhonePrefix()
    }

    override fun hidePhonePrefix() {
        inputViewModel.hidePhonePrefix()
    }

    override fun updatePhoneRegionFlag(flag: String) {
        inputViewModel.setPhoneRegionFlag(flag)
    }

    override fun updatePhoneRegionPrefix(prefix: String) {
        inputViewModel.setPhoneRegionPrefix(prefix)
    }

    override fun setKeyboardType(keyboardType: Int) {
        inputViewModel.setInputType(keyboardTypeToContactType(keyboardType))
    }

    override fun setConsent(consent: io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState?) {
        inputViewModel.setConsent(consent)
    }

    override fun updateAppColor(color: Int) {
        // No-op: акцент кнопки отправки берётся из SdkContainerViewModel и передаётся в MessageInput
        // напрямую (как в ChatScreen). Презентерный цвет из настроек намеренно игнорируется.
    }

    // ── IDialogView: File ─────────────────────────────────────────────────────

    override fun openFilePicker() {
        requireActivity().runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                documentPick.launch(FilePickerHelper.mAllowMimeTypes)
            } else {
                val act = requireActivity()
                val readGranted = ContextCompat.checkSelfPermission(
                    act, Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                val writeGranted = ContextCompat.checkSelfPermission(
                    act, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (!readGranted || !writeGranted) {
                    storagePermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        )
                    )
                } else {
                    documentPick.launch(FilePickerHelper.mAllowMimeTypes)
                }
            }
        }
    }

    // ── IDialogView: мультиаттачи (делегирование в MessageInputViewModel) ────────
    override fun addPendingAttachment(attachment: PendingAttachment) {
        inputViewModel.addAttachment(attachment)
    }

    override fun updatePendingAttachmentState(clientId: String, state: AttachmentUploadState) {
        inputViewModel.updateAttachmentState(clientId, state)
    }

    override fun removePendingAttachment(clientId: String) {
        inputViewModel.removeAttachment(clientId)
    }

    override fun clearPendingAttachments() {
        inputViewModel.clearAttachments()
    }

    override fun getCurrentContext(): Context? = context ?: activity

    override fun getSupportFragmentManager(): androidx.fragment.app.FragmentManager? =
        if (isAdded) parentFragmentManager else null
}
