package io.carrotquest_sdk.android.domain.use_cases.settings

import android.content.Context
import io.carrotquest_sdk.android.data.settings.SettingsManager

/**
 * Настройка аппа messenger_restrict_reply_to_closed_conversation (CAR-77491).
 *
 * true — в финально закрытый диалог писать нельзя: поле ввода и кнопки бота скрыты, вместо них
 * плашка «В закрытый диалог писать нельзя» + «Создать новый диалог». Бэкенд на попытку ответить
 * вернёт 400 ConversationReopenRestrictedError. false (и значение по умолчанию) — как раньше:
 * ответ в закрытый диалог переоткрывает его.
 *
 * Источники по порядку: настройки в памяти → кэш SharedPreferences (cold start через push,
 * обрыв сети) → false. Кэш пишет [SettingsManager] при каждом connect.
 */
fun isReplyToClosedConversationRestricted(context: Context): Boolean {
    getSettings()?.let { return it.restrictReplyToClosedConversation }
    return SettingsManager.cachedFlagOrFalse(
        context,
        SettingsManager.CACHED_RESTRICT_REPLY_TO_CLOSED_CONVERSATION
    )
}

/**
 * Умеет ли бэкенд канал RTS conversation_closed.{app}.{user} (CAR-77491). Признак — в ответе
 * /connect есть ключ messenger_restrict_reply_to_closed_conversation: он появляется тем же
 * релизом бэкенда, который по регламенту выкатывается ПОСЛЕ релиза RTS-сервера с каналом.
 * Подписка на неизвестный RTS-серверу канал отклоняет всё WSS-соединение, поэтому без признака
 * не подписываемся (fallback — HTTP-флаг closed и 400 при отправке).
 */
fun isConversationClosedRtsSupported(context: Context): Boolean {
    getSettings()?.let { return it.supportsConversationClosedRts }
    return SettingsManager.cachedFlagOrFalse(
        context,
        SettingsManager.CACHED_SUPPORTS_CONVERSATION_CLOSED_RTS
    )
}
