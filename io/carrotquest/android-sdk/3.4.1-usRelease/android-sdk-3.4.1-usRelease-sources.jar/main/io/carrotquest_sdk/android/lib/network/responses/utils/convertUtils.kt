package io.carrotquest_sdk.android.lib.network.responses.utils

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParseException
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageMetaData
import io.carrotquest_sdk.android.lib.network.responses.messages.Placeholder
import io.carrotquest_sdk.android.lib.network.responses.messages.RepliedTo
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil
import org.json.JSONException
import org.json.JSONObject
import java.util.Locale

/**
 * Парсит `actions` сообщения (кнопки/контентные блоки/поля ввода бота) из его JSON. Единый
 * источник И для WSS-сообщений ([convertJsonToMessageData]), И для истории ([MessageDeserializer]):
 * раньше история шла через десериализатор, который actions НЕ парсил, из-за чего у повторно
 * показанной первой ветки welcome/routing-бота в существующем диалоге пропадали кнопки.
 */
/**
 * Щадящий разбор массива `attachments` (вложения цитаты и бот-блоков в actions): элемент без id
 * пропускаем, не роняя разбор сообщения — в отличие от строгого разбора топ-левел вложений
 * (там вложение без id = JsonParseException). Не массив / null → пустой список.
 */
internal fun parseAttachmentsLenient(attachmentsElement: JsonElement?): ArrayList<Attachment> {
    val attachments = ArrayList<Attachment>()
    if (attachmentsElement == null || !attachmentsElement.isJsonArray) return attachments
    for (attachmentElement in attachmentsElement.asJsonArray) {
        if (attachmentElement !is JsonObject) continue
        if (!GsonUtil.jsonElementNotNull(attachmentElement, F.ID)) continue
        val attachment = Attachment()
        attachment.id = attachmentElement[F.ID].asString
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.TYPE)) attachment.type = attachmentElement[F.TYPE].asString
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.FILENAME)) attachment.filename = attachmentElement[F.FILENAME].asString
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.CREATED)) attachment.created = attachmentElement[F.CREATED].asString
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.MIME_TYPE)) attachment.mimeType = attachmentElement[F.MIME_TYPE].asString
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.SIZE)) attachment.size = attachmentElement[F.SIZE].asLong
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.URL)) attachment.url = attachmentElement[F.URL].asString
        if (GsonUtil.jsonElementNotNull(attachmentElement, F.STATUS)) attachment.status = attachmentElement[F.STATUS].asString
        attachments.add(attachment)
    }
    return attachments
}

/** Строковое поле или null, если ключа нет либо значение — JSON null (asString на JsonNull кидает). */
private fun JsonObject.stringOrNull(key: String): String? {
    val el = get(key) ?: return null
    return if (el.isJsonNull) null else el.asString
}

fun parseMessageActions(jsonObject: JsonObject, messageId: String?): ArrayList<ActionMessage> {
    val actions = ArrayList<ActionMessage>()
    val actionsElement = jsonObject.get(F.ACTIONS)
    if (actionsElement == null || actionsElement.isJsonNull || !actionsElement.isJsonArray) return actions
    for ((index, actionJsonElement) in actionsElement.asJsonArray.withIndex()) {
        if (actionJsonElement !is JsonObject) continue
        val actionMessage = ActionMessage()
        // Строки читаем null-безопасно: has(key) истинно и для JSON null, а asString на JsonNull
        // кидает UnsupportedOperationException. У экшенов стартовой ветки routing-бота body у
        // property_field и next_branch_id у text приходят null — падение ронял весь разбор ответа
        // choose, и ChooseRoutingBotDeserializer откатывался на голый Gson без плейсхолдера.
        actionJsonElement.stringOrNull(F.ID)?.let { actionMessage.id = it }
        actionJsonElement.stringOrNull(F.TYPE)?.let { actionMessage.type = it }
        // У quick_reply-кнопок (реплика админа через public API) id с бэкенда НЕТ. Веб-виджет
        // присваивает синтетические id "<индекс>_quick_reply" и пишет выбор в
        // meta_data.answer_action_id в этом же формате — повторяем 1:1, иначе матчинг
        // «отвечено/какая кнопка выбрана» разъедется между платформами. Индекс — по
        // ИСХОДНОМУ массиву actions (как на вебе), у бот-кнопок id серверный, их не трогаем.
        if (actionMessage.type == ResponseFields.ACTION_QUICK_REPLY && !actionJsonElement.has(F.ID)) {
            actionMessage.id = "${index}_quick_reply"
        }
        actionJsonElement.stringOrNull(F.BODY)?.let { actionMessage.body = it }
        actionJsonElement.stringOrNull(F.NEXT_BRANCH_ID)?.let { actionMessage.nextBranchId = it }
        // meta_data кнопки быстрого ответа: при выборе уезжает как есть в реплику пользователя.
        val actionMetaData = actionJsonElement.get(F.META_DATA)
        if (actionMetaData != null && !actionMetaData.isJsonNull) actionMessage.metaData = actionMetaData
        val bodyJsonEl = actionJsonElement.get(F.BODY_JSON)
        if (bodyJsonEl != null && !bodyJsonEl.isJsonNull) {
            actionMessage.bodyJson = bodyJsonEl
            if (bodyJsonEl.isJsonObject) {
                val placeholderEl = bodyJsonEl.asJsonObject.get(F.PLACEHOLDER)
                if (placeholderEl != null && placeholderEl.isJsonObject) {
                    val placeholderJson = placeholderEl.asJsonObject
                    if (placeholderJson.has(F.TYPE) && placeholderJson.has(F.VALUE)) {
                        val type = if (!placeholderJson[F.TYPE].isJsonNull) placeholderJson[F.TYPE].asString else ""
                        val v = if (!placeholderJson[F.VALUE].isJsonNull) placeholderJson[F.VALUE].asString else ""
                        actionMessage.placeholder = Placeholder(type, v)
                    }
                }
            }
        }
        // Вложения бот-блока (картинка/файл в action, не в message.attachments). Раньше здесь не
        // парсились вовсе: у истории/WSS блоки с картинкой теряли её, а у шаблона стартовой ветки
        // routing-бота (после перевода на этот парсер) картинка первой ветки пропала — веб её рисует.
        val actionAttachments = parseAttachmentsLenient(actionJsonElement.get(F.ATTACHMENTS))
        if (actionAttachments.isNotEmpty()) actionMessage.attachments = actionAttachments
        actionMessage.messageId = messageId
        actions.add(actionMessage)
    }
    return actions
}

/**
 * Парсит вложенную цитату `replied_to` из JSON сообщения (CAR-75966). Единый источник И для
 * WSS-сообщений ([convertJsonToMessageData]), И для истории ([MessageDeserializer]) — тот же
 * паттерн, что у [parseMessageActions]. Возвращает null, если ключа нет (цитаты нет или
 * оригинал физически удалён — бэкенд убирает ключ целиком) либо объект без id.
 *
 * Парсим щадяще: битое вложение или неполный `from` не должны уронить разбор всего сообщения.
 */
fun parseRepliedTo(jsonObject: JsonObject): RepliedTo? {
    val repliedToElement = jsonObject.get(F.REPLIED_TO)
    if (repliedToElement == null || repliedToElement.isJsonNull || !repliedToElement.isJsonObject) return null
    val jo = repliedToElement.asJsonObject
    // Без id цитата бесполезна (не к чему навигироваться и нечем гейтить) — считаем её отсутствующей.
    if (!GsonUtil.jsonElementNotNull(jo, F.ID)) return null

    var from: Admin? = null
    val fromElement = jo.get(F.FROM)
    if (fromElement != null && fromElement.isJsonObject) {
        // Для reply_user бэкенд шлёт урезанный {id, name} без аватара — все поля опциональны.
        val fromJo = fromElement.asJsonObject
        from = Admin()
        if (GsonUtil.jsonElementNotNull(fromJo, F.ID)) from.id = fromJo[F.ID].asString
        if (GsonUtil.jsonElementNotNull(fromJo, F.NAME)) from.name = fromJo[F.NAME].asString
        if (GsonUtil.jsonElementNotNull(fromJo, F.TYPE)) from.type = fromJo[F.TYPE].asString
        if (GsonUtil.jsonElementNotNull(fromJo, F.AVATAR)) from.avatar = fromJo[F.AVATAR].asString
    }

    val attachments = parseAttachmentsLenient(jo.get(F.ATTACHMENTS))

    return RepliedTo(
        id = jo[F.ID].asString,
        type = if (GsonUtil.jsonElementNotNull(jo, F.TYPE)) jo[F.TYPE].asString else null,
        created = if (GsonUtil.jsonElementNotNull(jo, F.CREATED)) jo[F.CREATED].asString else null,
        body = if (GsonUtil.jsonElementNotNull(jo, F.BODY)) jo[F.BODY].asString else null,
        from = from,
        attachments = attachments,
        removed = readLooseBoolean(jo, F.REMOVED),
        edited = readLooseBoolean(jo, F.EDITED),
        partialText = if (GsonUtil.jsonElementNotNull(jo, F.PARTIAL_TEXT)) jo[F.PARTIAL_TEXT].asString else null,
    )
}

/**
 * Бэкенд исторически шлёт флаги удаления то булем, то строкой/таймстампом (топ-левел `removed`
 * у [MessageData] — String). Читаем терпимо: bool — как есть, строку/число — истина, если
 * непустое и не "false"/"0".
 */
private fun readLooseBoolean(jo: JsonObject, key: String): Boolean {
    val el = jo.get(key) ?: return false
    if (el.isJsonNull || !el.isJsonPrimitive) return false
    val prim = el.asJsonPrimitive
    if (prim.isBoolean) return prim.asBoolean
    val s = prim.asString
    return s.isNotEmpty() && !s.equals("false", ignoreCase = true) && s != "0"
}

fun convertJsonToMessageData(json : JsonElement): MessageData {
    val message = MessageData()
    if (!GsonUtil.jsonElementNotNull(json, F.ID)) {
        throw JsonParseException("message ID is null")
    }

    message.id = json.asJsonObject[F.ID].asString

    if (GsonUtil.jsonElementNotNull(json, F.CREATED)) {
        message.created = json.asJsonObject[F.CREATED].asString
    }

    if (GsonUtil.jsonElementNotNull(json, F.CONVERSATION)) {
        message.conversation = json.asJsonObject[F.CONVERSATION].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.BODY)) {
        message.body = json.asJsonObject[F.BODY].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.BODY_JSON) && json.asJsonObject[F.BODY_JSON].isJsonObject) {
        message.bodyJson = json.asJsonObject[F.BODY_JSON].asJsonObject
    }
    if (GsonUtil.jsonElementNotNull(json, F.DIRECTION)) {
        message.direction = json.asJsonObject[F.DIRECTION].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.READ)) {
        message.read = json.asJsonObject[F.READ].asBoolean
    }
    if (GsonUtil.jsonElementNotNull(json, F.TYPE)) {
        message.type = json.asJsonObject[F.TYPE].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.REMOVED)) {
        message.removed = json.asJsonObject[F.REMOVED].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.EXPIRATION_TIME)) {
        message.expirationTime = json.asJsonObject[F.EXPIRATION_TIME].asLong
    }


    // sent_via берём как есть. Раньше для "message_manual" (ручная рассылка в чат) здесь была
    // легаси-обработка: из body вытаскивался инлайн <img> как псевдо-вложение, а сам body обрезался
    // до первого <p>… — многострочное сообщение доходило до пользователя одной строкой (CAR-77331).
    // Веб-виджет ручные сообщения никак не выделяет: body — обычный HTML, вложения — в attachments.
    if (GsonUtil.jsonElementNotNull(json, F.SENT_VIA)) {
        message.sentVia = json.asJsonObject.get(F.SENT_VIA).asString
    }

    if (GsonUtil.jsonElementNotNull(json, F.REPLY_TYPE)) {
        message.replyType = json.asJsonObject[F.REPLY_TYPE].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.RANDOM_ID)) {
        message.randomId = json.asJsonObject[F.RANDOM_ID].asString
    }
    if (GsonUtil.jsonElementNotNull(json, F.CONVERSATION_TYPE)) {
        message.conversationType = json.asJsonObject[F.CONVERSATION_TYPE].asString
    }

    val parsedActions = parseMessageActions(json.asJsonObject, message.id)
    if (parsedActions.isNotEmpty()) {
        message.actions = parsedActions
    }

    message.repliedTo = parseRepliedTo(json.asJsonObject)

    try {
        message.sourceJsonData = JSONObject(Gson().toJson(json))
    } catch (e: JSONException) {
        Log.e("convertUtils", e)
    }

    if (GsonUtil.jsonElementNotNull(json, F.ATTACHMENTS)) {
        val attachmentsJsonArray = json.asJsonObject.getAsJsonArray(F.ATTACHMENTS)
        if (attachmentsJsonArray != null) {
            val attachments = ArrayList<Attachment>()
            for (attachmentJsonObject in attachmentsJsonArray) {
                val attachment = Attachment()
                val joAttachment = attachmentJsonObject.asJsonObject
                if (GsonUtil.jsonElementNotNull(joAttachment, F.ID)) {
                    attachment.id = joAttachment[F.ID].asString
                } else {
                    throw JsonParseException("Attachment ID is null")
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.TYPE)) {
                    attachment.type = joAttachment[F.TYPE].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.FILENAME)) {
                    attachment.filename = joAttachment[F.FILENAME].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.CREATED)) {
                    attachment.created = joAttachment[F.CREATED].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.MIME_TYPE)) {
                    attachment.mimeType = joAttachment[F.MIME_TYPE].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.SIZE)) {
                    attachment.size = joAttachment[F.SIZE].asLong
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.URL)) {
                    attachment.url = joAttachment[F.URL].asString
                }
                if (GsonUtil.jsonElementNotNull(joAttachment, F.STATUS)) {
                    attachment.status = joAttachment[F.STATUS].asString
                }
                attachments.add(attachment)
            }
            message.attachments = attachments
        }
    }

    // meta_data парсим Gson'ом целиком — как history-путь (MessageDeserializer). Раньше WSS-путь
    // собирал MessageMetaData вручную и ТЕРЯЛ answer_action_id/answer_body/answer_time, из-за
    // чего «отвеченность» кнопок (бот и quick_reply) не переживала realtime-обновление
    // conversation_reply_changed. Легаси-чтение replied/loading/comment/vote ниже сохранено.
    val metaDataElement = json.asJsonObject.get(F.META_DATA)
    val messageMetaData =
        if (metaDataElement != null && metaDataElement.isJsonObject) {
            Gson().fromJson(metaDataElement, MessageMetaData::class.java)
        } else {
            MessageMetaData()
        }
    if (messageMetaData.replied == null) messageMetaData.replied = false
    if (messageMetaData.loading == null) messageMetaData.loading = false
    if (json.asJsonObject.has(F.FROM)) {
        if (json.asJsonObject[F.FROM].isJsonObject) {
            val adminFrom = Admin()
            val fromJsonElement = json.asJsonObject[F.FROM].asJsonObject
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.ID)) {
                adminFrom.id = fromJsonElement[F.ID].asString
            }
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.NAME)) {
                adminFrom.name = fromJsonElement[F.NAME].asString
            }
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.TYPE)) {
                adminFrom.type = fromJsonElement[F.TYPE].asString
            }
            if (GsonUtil.jsonElementNotNull(fromJsonElement, F.AVATAR)) {
                adminFrom.avatar = fromJsonElement[F.AVATAR].asString
            }
            message.messageFrom = adminFrom
        } else {
            val adminFrom = Admin()
            adminFrom.id = json.asJsonObject[F.FROM].asString
            message.messageFrom = adminFrom
            if (json.asJsonObject[F.META_DATA] != null && json.asJsonObject[F.FROM].isJsonObject) {
                messageMetaData.comment = json.asJsonObject[F.FROM].asJsonObject[F.COMMENT].toString()
                messageMetaData.vote = json.asJsonObject[F.FROM].asJsonObject[F.VOTE].toString().toInt()
            }
        }
        if (json.asJsonObject[F.META_DATA] != null) {
            if (json.asJsonObject.has(F.REPLIED)) {
                messageMetaData.replied = json.asJsonObject[F.REPLIED].asBoolean
            }
            if (json.asJsonObject.has(F.LOADING)) {
                messageMetaData.loading = json.asJsonObject[F.LOADING].asBoolean
            }
        }
    }

    message.messageMetaData = messageMetaData

    extractInlineImages(message)

    return message
}
// --- Инлайн-картинки в body (CAR-77331) ---------------------------------------------------------

private val INLINE_IMG_TAG = Regex("""<img\b[^>]*>""", RegexOption.IGNORE_CASE)
private val INLINE_IMG_SRC = Regex("""\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))""", RegexOption.IGNORE_CASE)
// Абзац, в котором кроме картинок только пробелы/&nbsp;/<br> — убираем целиком, чтобы после
// извлечения картинки не оставалась пустая строка. Намеренно пустые <p></p> без <img> не трогаем.
private val INLINE_IMG_PARAGRAPH = Regex(
    """<p\b[^>]*>(?:\s|&nbsp;|<br\s*/?>)*(?:<img\b[^>]*>(?:\s|&nbsp;|<br\s*/?>)*)+</p>""",
    RegexOption.IGNORE_CASE,
)
private val IMAGE_MIME_BY_EXT = mapOf(
    "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "gif" to "image/gif",
    "webp" to "image/webp", "bmp" to "image/bmp", "heic" to "image/heic", "svg" to "image/svg+xml",
)

/**
 * Переносит инлайн-`<img>` из HTML-тела сообщения в [MessageData.attachments] (type = "image") и
 * вырезает теги из текста. Ручная рассылка из редактора панели кладёт картинку только в body — веб
 * рисует её браузером как есть, а нативный рендер `<img>` не умеет (HtmlCompat оставляет символ-
 * заглушку). Идемпотентно: после первого вызова в body тегов не остаётся. Единый вызов для всех
 * путей доставки: WSS ([convertJsonToMessageData]), история (MessageDeserializer) и
 * `message_conversation_started` (Gson без десериализатора).
 */
fun extractInlineImages(message: MessageData) {
    val body = message.body ?: return
    if (!body.contains("<img", ignoreCase = true)) return

    val inline = ArrayList<Attachment>()
    INLINE_IMG_TAG.findAll(body).forEachIndexed { index, tag ->
        val src = INLINE_IMG_SRC.find(tag.value)?.groupValues?.drop(1)?.firstOrNull { it.isNotEmpty() }
            ?.trim().orEmpty()
        if (!src.startsWith("http://", ignoreCase = true) && !src.startsWith("https://", ignoreCase = true)) {
            // data:/относительный src — показать нечем, тег из текста всё равно убираем
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.GENERAL, "convertUtils",
                "inline <img> without http(s) src dropped (message=${message.id})",
            )
            return@forEachIndexed
        }
        val fileName = src.substringBefore('?').substringBefore('#').substringAfterLast('/')
            .ifEmpty { "image" }
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        inline.add(Attachment().apply {
            id = "${message.id}_inline_img_$index"
            type = "image"
            url = src
            filename = fileName
            mimeType = IMAGE_MIME_BY_EXT[ext] ?: "image/*"
            created = message.created
            status = ""
        })
    }

    message.body = body.replace(INLINE_IMG_PARAGRAPH, "").replace(INLINE_IMG_TAG, "")
    if (inline.isNotEmpty()) {
        val all = ArrayList<Attachment>(message.attachments ?: emptyList())
        all.addAll(inline)
        message.attachments = all
    }
}
