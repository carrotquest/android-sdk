package io.carrotquest_sdk.android.lib.wss.utils

import com.google.gson.JsonParser
import com.neovisionaries.ws.client.WebSocket
import com.neovisionaries.ws.client.WebSocketAdapter
import com.neovisionaries.ws.client.WebSocketException
import com.neovisionaries.ws.client.WebSocketFrame
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.i
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.w
import io.carrotquest_sdk.android.lib.wss.WssMessageListener
import io.carrotquest_sdk.android.lib.wss.response.WssResponse


private const val tag = "SocketListener"

/**
 * Слушатель одного RTS-соединения. С версии фикса гонки реконнекта создаётся НА КАЖДОЕ соединение
 * заново (см. [io.carrotquest_sdk.android.lib.wss.jwt.JwtClientWebSocket]) — общего изменяемого
 * состояния между сокетами больше нет, поэтому `listener` уже нельзя обнулить «опоздавшим» stop().
 *
 * @param onDisconnected колбэк обрыва (вызывается из [onDisconnected]).
 * @param onInbound колбэк на ЛЮБОЙ входящий фрейм (text/pong/ping/binary) — метка живости канала,
 *                  по ней watchdog отличает живой сокет от «тихо умершего».
 * @param onChannelsForbidden сервер отверг подписку по scope и перечислил каналы
 *                  (см. [parseForbiddenChannels]); сокет он после этого закроет сам.
 */
class SocketListener @JvmOverloads constructor(
    private val appId: String,
    private val onDisconnected: (() -> Unit)? = null,
    private val onInbound: (() -> Unit)? = null,
    private val onChannelsForbidden: ((List<String>) -> Unit)? = null,
) : WebSocketAdapter() {
    private val context = CarrotLib.getLibComponents().context
    private var listener: WssMessageListener? = null

    fun setListener(listener: WssMessageListener?) {
        this.listener = listener
    }

    @Throws(Exception::class)
    override fun onConnected(websocket: WebSocket?, headers: Map<String?, List<String?>?>?) {
        super.onConnected(websocket, headers)
    }

    // Любой входящий фрейм — признак живого канала. При keepalive-пинге сервер отвечает pong
    // примерно каждые 20с, поэтому здоровый сокет регулярно «отмечается». Watchdog в JwtWssService
    // по давности этой метки детектит сокет, который «подключён», но молча перестал доставлять.
    @Throws(Exception::class)
    override fun onFrame(websocket: WebSocket?, frame: WebSocketFrame?) {
        super.onFrame(websocket, frame)
        onInbound?.invoke()
    }

    @Throws(Exception::class)
    override fun onTextMessage(websocket: WebSocket?, text: String?) {
        super.onTextMessage(websocket, text)

        val jsonParser = JsonParser()
        val jElement = jsonParser.parse(text)

        // Отказ хендшейка по scope — не RTS-событие: в общий парсер не отдаём (он бы только
        // залогировал «ID is null»), а сообщаем сокету, какие каналы вырезать перед переподпиской.
        parseForbiddenChannels(jElement)?.let { forbidden ->
            // Сырой фрейм целиком — для разбора с бэкендом (какой RTS ответил, какая формулировка).
            // Токена в нём нет: он уходит заголовком Authorization, а url в фрейме — без него.
            w(tag, "RTS refused channels $forbidden (appId=$appId); raw frame: $text")
            onChannelsForbidden?.invoke(forbidden)
            return
        }

        val response = WssResponse.fromJson(jElement)

        // Сохраение тэга и времени последнего полученного сообщения
        SharedPreferencesLib.saveString(context, shPrefTagKey + appId, response.tag)
        SharedPreferencesLib.saveString(context, shPrefTimeKey + appId, response.time)

        //Отправка сообщения слушателю
        val l = listener
        if (l == null) {
            // Сокет подключён и принимает фреймы, но доставлять их некому → реалтайм «мёртв» при
            // живом соединении. При корректном жизненном цикле не должно происходить; лог ловит регресс.
            w(tag, "onTextMessage but listener is null (appId=$appId) — RTS frame dropped")
        }
        l?.onMessage(response)
    }

    override fun onDisconnected(
        websocket: WebSocket?,
        serverCloseFrame: WebSocketFrame?,
        clientCloseFrame: WebSocketFrame?,
        closedByServer: Boolean
    ) {
        super.onDisconnected(websocket, serverCloseFrame, clientCloseFrame, closedByServer)
        // Закрытие сервером: код и причина close-фрейма (RTS при отказе шлёт код 3000+HTTP-статус,
        // reason = error_message) — второе свидетельство для разбора отказов подписки.
        if (closedByServer) {
            w(tag, "RTS closed by server: code=${serverCloseFrame?.closeCode} reason='${serverCloseFrame?.closeReason}' (appId=$appId)")
        }
        onDisconnected?.invoke()
    }

    override fun onError(websocket: WebSocket?, cause: WebSocketException) {
        i(tag, "Error -->" + cause.message)
    }
}
