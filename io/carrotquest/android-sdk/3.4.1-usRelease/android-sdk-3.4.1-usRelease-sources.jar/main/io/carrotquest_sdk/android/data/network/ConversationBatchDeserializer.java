package io.carrotquest_sdk.android.data.network;

import static io.carrotquest_sdk.android.lib.utils.json.GsonUtil.jsonElementNotNull;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationPartsBatchRtsMessage;

public class ConversationBatchDeserializer implements JsonDeserializer<ConversationPartsBatchRtsMessage> {
    private static final String TAG = "ConversationReplyMessageDeserializer";

    @Override
    public ConversationPartsBatchRtsMessage deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ConversationPartsBatchRtsMessage response = new ConversationPartsBatchRtsMessage();
        if (jsonElementNotNull(json, ResponseFields.RANDOM_ID)) {
            response.randomId = json.getAsJsonObject().get(ResponseFields.RANDOM_ID).getAsString();
        }

        if (jsonElementNotNull(json, ResponseFields.CONVERSATION)) {
            JsonElement je = json.getAsJsonObject().get(ResponseFields.CONVERSATION);
            response.conversation = geDataConversationFromJsonElement(je);
        }

        ArrayList<MessageData> partsArray = new ArrayList<>();
        if (jsonElementNotNull(json, ResponseFields.PARTS)) {
            JsonArray jsArray = json.getAsJsonObject().get(ResponseFields.PARTS).getAsJsonArray();
            for(JsonElement je : jsArray) {
                MessageData m = ConvertUtilsKt.convertJsonToMessageData(je);
                partsArray.add(m);
            }
        }
        response.parts = partsArray;

        return response;
    }

    private DataConversation geDataConversationFromJsonElement(JsonElement jsonElement) throws JsonParseException {
        DataConversation conversation = new DataConversation();
        JsonObject jsonObject = jsonElement.getAsJsonObject();

        if(!jsonElementNotNull(jsonObject, F.ID)) {
            throw new JsonParseException("Conversation Id is null");
        }
        conversation.setId(jsonObject.get(F.ID).getAsString());
        conversation.setSourceJsonData(jsonObject);

        if(jsonElementNotNull(jsonObject, F.RANDOM_ID)) {
            conversation.setRandomId(jsonObject.get(F.RANDOM_ID).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.CREATED)) {
            conversation.setCreated(jsonObject.get(F.CREATED).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.READ)) {
            conversation.setRead(jsonObject.get(F.READ).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.CLIKCKED)) {
            conversation.setClicked(jsonObject.get(F.CLIKCKED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.UNSUBSCRIBED)) {
            conversation.setUnsubscribed(jsonObject.get(F.UNSUBSCRIBED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.CLOSED)) {
            conversation.setClosed(jsonObject.get(F.CLOSED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.REPLY_TYPE)) {
            conversation.setReplyType(jsonObject.get(F.REPLY_TYPE).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.TYPE)) {
            conversation.setType(jsonObject.get(F.TYPE).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.PARTS_COUNT)) {
            conversation.setPartsCount(jsonObject.get(F.PARTS_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.UNREAD_PARTS_COUNT)) {
            conversation.setUnreadPartsCount(jsonObject.get(F.UNREAD_PARTS_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.USER_UNREAD_COUNT)) {
            conversation.setUserUnreadCount(jsonObject.get(F.USER_UNREAD_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.LAST_UPDATE)) {
            conversation.setLastUpdate(jsonObject.get(F.LAST_UPDATE).getAsString()
            );
        }

        if(jsonElementNotNull(jsonObject, F.PART_LAST)) {
            MessageData partLast = ConvertUtilsKt.convertJsonToMessageData(jsonObject.get(F.PART_LAST));
            conversation.setPartLast(partLast);
        }

        if(jsonElementNotNull(jsonObject, F.LAST_ADMIN)
                && jsonObject.get(F.LAST_ADMIN).isJsonObject()) {
            // См. ConversationDeserializer:139 — last_admin изредка приходит не объектом.
            conversation.setLastAdmin(parseAdmin(jsonObject.get(F.LAST_ADMIN).getAsJsonObject()));
        }

        // last_sender — публичная персона отправителя (message_sender у ботов/триггеров):
        // превью диалога обязано показывать его, а не last_admin (веб-паритет, getOperator)
        if(jsonElementNotNull(jsonObject, F.LAST_SENDER)
                && jsonObject.get(F.LAST_SENDER).isJsonObject()) {
            conversation.setLastSender(parseAdmin(jsonObject.get(F.LAST_SENDER).getAsJsonObject()));
        }

        if(jsonElementNotNull(jsonObject, F.RECIPIENT_TYPE)) {
            conversation.setRecipientType(jsonObject.get(F.RECIPIENT_TYPE).getAsString());
        }

        // Признак тикет-диалога (id тикета строкой) — по нему batch-кадр уходит в тикет-путь,
        // а не в обычную ленту/счётчики
        if(jsonElementNotNull(jsonObject, F.TICKET)) {
            conversation.setTicket(jsonObject.get(F.TICKET).getAsString());
        }

        return conversation;
    }

    private Admin parseAdmin(JsonObject lastAdminJsonObject) {
        Admin admin = new Admin();

        if (jsonElementNotNull(lastAdminJsonObject, F.ID)) {
            admin.setId(lastAdminJsonObject.get(F.ID).getAsString());
        }

        if (jsonElementNotNull(lastAdminJsonObject, F.NAME)) {
            admin.setName(lastAdminJsonObject.get(F.NAME).getAsString());
        }
        if (jsonElementNotNull(lastAdminJsonObject, F.TYPE)) {
            admin.setType(lastAdminJsonObject.get(F.TYPE).getAsString());
        }
        if (jsonElementNotNull(lastAdminJsonObject, F.AVATAR)) {
            admin.setAvatar(lastAdminJsonObject.get(F.AVATAR).getAsString());
        }

        return admin;
    }
}
