package io.carrotquest_sdk.android.lib.wss;

/**
 * Перечислимое популярных каналов
 */
public enum ChannelEnum {
    ping,
    conversation,
    message_conversation_started,
    conversation_reply,
    conversation_typing,
    conversation_assigned,
    conversation_read,
    run_script,
    users_removed,
    user_ban,
    app_online_changed,
    conversation_reply_changed,
    popup,
    chat_bot_conversation_finished,
    conversation_parts_batch,
    // События жизненного цикла тикетов (created/updated); имя канала ticket.{app}.{user}
    ticket,
    // Финальное закрытие диалога (оператор/бот/автозакрытие по тайм-ауту), CAR-77491;
    // имя канала conversation_closed.{app}.{user}, данные {"conversation": "<id>"}
    conversation_closed
}
