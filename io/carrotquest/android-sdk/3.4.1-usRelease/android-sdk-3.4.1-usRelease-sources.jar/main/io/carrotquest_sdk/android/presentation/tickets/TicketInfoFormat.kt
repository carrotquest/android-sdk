package io.carrotquest_sdk.android.presentation.tickets

import io.carrotquest_sdk.android.domain.entities.TicketStage
import java.util.concurrent.TimeUnit

/**
 * Чистые функции инфо-панели тикета — без Android-зависимостей, покрыты юнит-тестами.
 * Ресурсные строки/plurals подставляет composable.
 */

/** Число закрашенных сегментов прогресс-бара (из 3) по стадии. */
internal fun ticketProgressSegments(stage: TicketStage): Int = when (stage) {
    TicketStage.INITIAL -> 1
    TicketStage.INTERMEDIATE -> 2
    TicketStage.FINAL -> 3
}

internal enum class TicketTimeUnit { MINUTES, HOURS, DAYS, MONTHS }

internal data class TicketElapsed(val unit: TicketTimeUnit, val count: Int)

/**
 * «Время в работе» для нефинального тикета: от created до сейчас.
 * Правила веба: < 60 минут — минуты (минимум 1), < 24 часов — часы, < 30 дней — дни,
 * дальше — месяцы (по 30 дней). Отрицательный elapsed (рассинхрон часов) — как 0.
 */
internal fun ticketElapsed(elapsedMs: Long): TicketElapsed {
    val safeMs = elapsedMs.coerceAtLeast(0L)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(safeMs)
    val hours = TimeUnit.MILLISECONDS.toHours(safeMs)
    val days = TimeUnit.MILLISECONDS.toDays(safeMs)
    return when {
        minutes < 60 -> TicketElapsed(TicketTimeUnit.MINUTES, minutes.coerceAtLeast(1L).toInt())
        hours < 24 -> TicketElapsed(TicketTimeUnit.HOURS, hours.toInt())
        days < 30 -> TicketElapsed(TicketTimeUnit.DAYS, days.toInt())
        else -> TicketElapsed(TicketTimeUnit.MONTHS, (days / 30).toInt())
    }
}

/**
 * Видимость кнопки «Дополнить тикет»: только нефинальный тикет и только пока
 * пользователь её не нажал (одноразовый переход в режим ввода в рамках экрана).
 * Финальный тикет в v1 read-only — бэк блокирует reply в закрытый тикет.
 */
internal fun isSupplementButtonVisible(stage: TicketStage, supplementActivated: Boolean): Boolean =
    stage != TicketStage.FINAL && !supplementActivated

/** Показывать ли строку дедлайна: только нефинальный статус и при наличии due_date. */
internal fun isDueDateVisible(stage: TicketStage, dueDateMillis: Long?): Boolean =
    stage != TicketStage.FINAL && dueDateMillis != null

/**
 * Разрешено ли цитирование сообщений на экране: в ЗАКРЫТОМ тикете отвечать на сообщения
 * нельзя (веб: allowReply={!isFinal}) — свайп «ответить», пункт «Ответить» в шторке и
 * восстановление режима ответа отключаются. Гейт действует и в режиме переоткрытия
 * («Не решён» открывает инпут, но тикет остаётся финальным): сообщение авто-переоткроет
 * тикет, а цитата в закрытый тикет — нет.
 *
 * Второй гейт — закрытый read-only диалог чата (CAR-77491, [isClosedReadOnly]): отвечать в него
 * нельзя, значит и цитировать нечего — веб в таком диалоге убирает кнопку «Ответить» у реплик.
 *
 * @param isTicketMode экран тикета (в обычном диалоге по стадии не гейтим)
 * @param stage стадия тикета; null — тикета нет в кэше, не блокируем
 * @param isClosedReadOnly диалог закрыт при включённом запрете писать в закрытые
 */
internal fun isQuotingEnabledOnScreen(
    isTicketMode: Boolean,
    stage: TicketStage?,
    isClosedReadOnly: Boolean = false,
): Boolean = !isClosedReadOnly && !(isTicketMode && stage == TicketStage.FINAL)

/**
 * Подпись статуса (CAR-76566): имя с бэка КАК ЕСТЬ — упрощение intermediate до «В работе»
 * делает бэкенд по настройке аппа. Fallback на локализованное «В работе» — только для
 * ПУСТОГО имени intermediate (старые данные/RTS-null); пустые initial/final — пустая строка
 * (как getStatusLabel веба).
 */
internal fun ticketStatusLabel(name: String, stage: TicketStage, inProgressLabel: String): String =
    if (name.isBlank() && stage == TicketStage.INTERMEDIATE) inProgressLabel else name

private val HEX_COLOR_REGEX = Regex("^#([0-9a-fA-F]{6})$")

/**
 * Кастомный цвет статуса ("#RRGGBB" с бэка) как ARGB-Long для Compose Color —
 * ТОЛЬКО для INTERMEDIATE (initial/final остаются на стадийных цветах темы, как
 * getStatusColor веба). Пустой/битый цвет → null (вызывающий берёт стадийный).
 */
internal fun ticketCustomColorArgb(stage: TicketStage, colorHex: String?): Long? {
    if (stage != TicketStage.INTERMEDIATE) return null
    val hex = colorHex?.trim() ?: return null
    val match = HEX_COLOR_REGEX.matchEntire(hex) ?: return null
    return 0xFF000000L or match.groupValues[1].toLong(16)
}
