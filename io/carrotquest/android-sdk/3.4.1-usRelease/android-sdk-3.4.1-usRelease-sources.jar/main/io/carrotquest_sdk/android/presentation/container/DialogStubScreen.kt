package io.carrotquest_sdk.android.presentation.container

import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogFragment

private const val DIALOG_FRAGMENT_TAG = "sdk_dialog_fragment"
// КОСТЫЛЬ: задержка между удалением старого DialogFragment и добавлением нового —
// только когда реально заменяем один фрагмент другим (пересоздание). При быстром
// "Написать → ← → Написать" Chromium renderer process не успевает очистить ресурсы
// предыдущего WebView, и новый WebView получает сломанный renderer →
// "TypeError: window.webView.initDialogue is not a function" → кнопки бота не отрисовываются.
// 400мс хватает, чтобы Chromium выдохнул. Убрать, когда WebView выпилят из диалога.
private const val FRAGMENT_RECREATE_DELAY_MS = 400L

@Composable
fun DialogScreen(
    conversationId: String,
    fragmentManager: FragmentManager,
    modifier: Modifier = Modifier,
    // Экран тикета: фрагмент стартует в ticket mode (гейт автопоказа инпута,
    // кнопка «Дополнить тикет», локальный markAsRead)
    isTicket: Boolean = false
) {
    val containerId = remember { View.generateViewId() }
    // Свой Handler на композицию: removeCallbacksAndMessages(null) в onDispose отменяет
    // только колбэк ЭТОГО экрана, не задевая другие. Без этого при повторной навигации
    // раньше, чем истекли FRAGMENT_RECREATE_DELAY_MS с прошлого открытия, отложенный
    // addNewFragment всё равно срабатывал позже — добавлял DialogFragment под уже
    // неактуальный containerId, и следующий findFragmentByTag находил чужой/лишний
    // фрагмент вместо актуального.
    val handler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(conversationId) {
        onDispose {
            handler.removeCallbacksAndMessages(null)
            if (fragmentManager.isStateSaved) return@onDispose
            val frag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG) ?: return@onDispose
            if (frag.id == containerId) {
                fragmentManager.beginTransaction()
                    .remove(frag)
                    .commitAllowingStateLoss()
            }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            FragmentContainerView(ctx).also { fcv ->
                fcv.id = containerId

                if (!fragmentManager.isStateSaved) {
                    val existingFrag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG)
                    val addNewFragment = {
                        if (!fragmentManager.isStateSaved) {
                            fragmentManager.beginTransaction()
                                .add(
                                    containerId,
                                    DialogFragment.newInstance(conversationId, isTicket),
                                    DIALOG_FRAGMENT_TAG
                                )
                                .commitAllowingStateLoss()
                        }
                    }

                    if (existingFrag != null && existingFrag.id != containerId) {
                        // Пересоздание: прибираем старый фрагмент сразу, новый — с задержкой
                        // (см. FRAGMENT_RECREATE_DELAY_MS выше, костыль под Chromium).
                        fragmentManager.beginTransaction()
                            .remove(existingFrag)
                            .commitAllowingStateLoss()
                        handler.postDelayed(addNewFragment, FRAGMENT_RECREATE_DELAY_MS)
                    } else {
                        // Первое открытие — заменять нечего, Chromium-костыль не нужен:
                        // добавляем сразу, без искусственной задержки.
                        addNewFragment()
                    }
                }
            }
        },
        update = { /* Не пересоздаем фрагмент при обновлении параметров, если id тот же */ }
    )
}
