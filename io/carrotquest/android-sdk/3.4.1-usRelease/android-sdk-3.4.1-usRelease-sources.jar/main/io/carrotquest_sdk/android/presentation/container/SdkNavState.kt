package io.carrotquest_sdk.android.presentation.container

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Stable
sealed class SdkNavState {
    /** Начальное состояние: данные ещё грузятся, неизвестно — список или диалог. */
    @Immutable
    data object Determining : SdkNavState()
    @Immutable
    data object ConversationList : SdkNavState()
    @Immutable
    data class Dialog(
        val conversationId: String,
        val isNew: Boolean = false,
        /**
         * Не-null = экран тикета: шапка с title тикета, TicketInfoPanel над лентой,
         * ticket mode во фрагменте (гейт инпута/«Дополнить тикет»). Пустой
         * conversationId при ticketId != null = тикет без диалога (только панель).
         */
        val ticketId: String? = null,
        /**
         * Отличает один запрос «новый черновой диалог» от другого (CAR-77493): у ВСЕХ черновиков
         * conversationId == "" — без этого поля два последовательных navigateToDialog("", isNew =
         * true) дают структурно равный Dialog(...), MutableStateFlow не эмитит дубликат, и
         * AnimatedContent/DialogScreen не пересоздают фрагмент, даже если первый черновик уже
         * успел материализоваться в реальную (и, возможно, закрытую) беседу. См.
         * SdkContainerViewModel.navigateToDialog.
         */
        val newDraftToken: Int = 0,
    ) : SdkNavState()
}
